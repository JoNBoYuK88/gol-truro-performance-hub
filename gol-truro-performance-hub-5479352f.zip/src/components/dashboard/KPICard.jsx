
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function KPICard({ 
  title, 
  value, 
  target, 
  previousValue,
  comparisonValue,
  comparisonYear,
  showComparison = false,
  unit = "number",
  redThreshold,
  amberThreshold,
  greenThreshold,
  icon: Icon,
  className = "",
  isEditing = false,
  onValueChange,
  higherIsBetter = true,
  onClearData,
  showClearButton = false,
  clearIdentifier,
  compact = false,
  hideVariance = false
}) {
  const formatValue = (val, isDifference = false) => {
    if (val === null || val === undefined || val === '') return "—";
    
    const numericVal = typeof val === 'string' && !isNaN(parseFloat(val)) ? parseFloat(val) : val;
    if (typeof numericVal !== 'number') return "—";

    const titleStr = React.isValidElement(title) ? title.props.children : title;

    if (isDifference) {
        // If it's a difference, we format the absolute value based on unit type
        switch (unit) {
            case "currency":
                return `£${Math.abs(numericVal).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
            case "percentage":
                // Specific titles for more decimal places
                if (titleStr === "Sec Replen") {
                    return `${Math.abs(numericVal).toLocaleString(undefined, { minimumFractionDigits: 3, maximumFractionDigits: 3 })}%`;
                }
                if (["Shoppers", "OTDept", "Achievement Rate", "Availability", "DWC", "iCare"].includes(titleStr)) {
                    return `${Math.abs(numericVal).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%`;
                }
                // Score (Ops Score) should have no decimals
                if (titleStr === "Score" || titleStr === "Ops Score") {
                    return `${Math.abs(numericVal).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}%`;
                }
                // General percentage for 1 decimal place
                return `${Math.abs(numericVal).toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}%`;
            case "items":
                return `${Math.abs(numericVal).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
            case "number":
                // For numbers, handle decimals or integers appropriately
                return typeof numericVal === 'number' && Math.abs(numericVal) % 1 !== 0
                    ? Math.abs(numericVal).toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 })
                    : Math.abs(numericVal).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
            default:
                // Fallback for any other unit or general numeric formatting
                return Math.abs(numericVal).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 1 });
        }
    }


    if (titleStr === "Sales YOY") {
      return `£${numericVal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
    }
    
    if (titleStr === "Sec Replen") {
      return `${numericVal.toLocaleString(undefined, { minimumFractionDigits: 3, maximumFractionDigits: 3 })}%`;
    }

    if (["Shoppers", "OTDept", "Achievement Rate", "Availability", "DWC"].includes(titleStr)) {
        return `${numericVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%`;
    }

    // Score (Ops Score) should have no decimals
    if (titleStr === "Score" || titleStr === "Ops Score") {
        return `${numericVal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}%`;
    }

    switch (unit) {
      case "currency":
        return `£${numericVal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
      case "percentage":
        return `${numericVal.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}%`;
      case "items":
        return `${numericVal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
      case "number":
        return typeof numericVal === 'number' && numericVal % 1 !== 0 
          ? numericVal.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 }) 
          : numericVal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
      default:
        return numericVal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 1 });
    }
  };

  const getStatusClass = () => {
    const numericValue = typeof value === 'string' && !isNaN(parseFloat(value)) ? parseFloat(value) : value;

    // Skip status styling for cards with no meaningful thresholds
    if (title === "Remaining to Hit Target" || title === "Required to Hit 80%") {
      return "";
    }

    if (higherIsBetter) {
        if (greenThreshold !== undefined && numericValue >= greenThreshold) return "status-green";
        if (amberThreshold !== undefined && numericValue >= amberThreshold) return "status-amber";
        if (redThreshold !== undefined && numericValue <= redThreshold) return "status-red";
    } else {
        if (redThreshold !== undefined && numericValue >= redThreshold) return "status-red";
        if (greenThreshold !== undefined && numericValue <= greenThreshold) return "status-green";
        return "status-amber";
    }
    return "";
  };

  const getTextColor = () => {
    const numericValue = typeof value === 'string' && !isNaN(parseFloat(value)) ? parseFloat(value) : value;

    if (higherIsBetter) {
        if (greenThreshold !== undefined && numericValue >= greenThreshold) return "text-emerald-700";
        if (amberThreshold !== undefined && numericValue >= amberThreshold) return "text-amber-700";
        if (redThreshold !== undefined && numericValue <= redThreshold) return "text-red-600";
    } else {
        if (redThreshold !== undefined && numericValue >= redThreshold) return "text-red-600";
        if (greenThreshold !== undefined && numericValue <= greenThreshold) return "text-emerald-700";
        return "text-amber-700";
    }
    return "text-slate-700";
  };

  const getComparisonTextColor = () => {
    const numericComparisonValue = typeof comparisonValue === 'string' && !isNaN(parseFloat(comparisonValue)) ? parseFloat(comparisonValue) : comparisonValue;
    if (typeof numericComparisonValue !== 'number') return "text-slate-700";

    if (higherIsBetter) {
        if (greenThreshold !== undefined && numericComparisonValue >= greenThreshold) return "text-emerald-700";
        if (amberThreshold !== undefined && numericComparisonValue >= amberThreshold) return "text-amber-700";
        if (redThreshold !== undefined && numericComparisonValue <= redThreshold) return "text-red-600";
    } else {
        if (redThreshold !== undefined && numericComparisonValue >= redThreshold) return "text-red-600";
        if (greenThreshold !== undefined && numericComparisonValue <= greenThreshold) return "text-emerald-700";
        return "text-amber-700";
    }
    return "text-slate-700";
  };

  const getVariance = () => {
    if (hideVariance) return null;
    
    const numericValue = typeof value === 'string' && !isNaN(parseFloat(value)) ? parseFloat(value) : value;

    if (previousValue === null || previousValue === undefined || typeof numericValue !== 'number') return null;
    if (previousValue === 0) {
      return numericValue > 0 ? Infinity : (numericValue < 0 ? -Infinity : 0);
    }
    const variance = ((numericValue - previousValue) / previousValue) * 100;
    return variance;
  };

  const variance = getVariance();
  const statusClass = getStatusClass();
  const textColor = getTextColor();
  const comparisonTextColor = getComparisonTextColor();

  const cardSize = compact ? "p-3" : "p-4";
  const titleSize = compact ? "text-sm font-semibold" : "text-sm font-semibold";
  const valueSize = compact ? "text-4xl" : "text-3xl"; 
  const iconSize = compact ? "w-4 h-4" : "w-5 h-5";

  const numericValue = typeof value === 'string' && !isNaN(parseFloat(value)) ? parseFloat(value) : value;
  const numericComparisonValue = typeof comparisonValue === 'string' && !isNaN(parseFloat(comparisonValue)) ? parseFloat(comparisonValue) : comparisonValue;

  let comparisonDiff = null;
  if (typeof numericValue === 'number' && typeof numericComparisonValue === 'number') {
    comparisonDiff = numericValue - numericComparisonValue;
  }

  return (
    <Card className={`metric-card flex flex-col ${statusClass} ${className}`}>
      <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${cardSize}`}>
        <CardTitle className={`${titleSize} text-slate-600 tracking-tight`}>{title}</CardTitle>
        <div className="flex items-center gap-10">
          {Icon && (
            <Icon className={`${iconSize} text-slate-400`} />
          )}
          {showClearButton && onClearData && (
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all duration-200"
              onClick={() => onClearData(clearIdentifier || title)}
            >
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className={`${cardSize} pt-0 flex-grow flex flex-col items-center justify-center text-center`}>
        <div className="flex flex-col items-center justify-center">
          <div className="flex items-baseline justify-center gap-2">
            {isEditing ? (
              <Input
                type="number"
                step={
                  title === "Sec Replen" ? "0.001" : 
                  (["Shoppers", "OTDept", "Achievement Rate", "Availability", "DWC"].includes(title) ? "0.01" : "0.1")
                }
                value={value}
                onChange={(e) => {
                  if (onValueChange) {
                    onValueChange(e.target.value);
                  }
                }}
                className={`${valueSize} font-bold h-auto p-0 border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 ${textColor} input-modern text-center`}
                disabled={!isEditing}
              />
            ) : (
              <div className={`${valueSize} font-bold ${textColor} tracking-tight text-center`}>
                {formatValue(value)}
              </div>
            )}
            {target != null && target != 0 && !isEditing && (
              <div className="text-sm font-medium text-slate-400">
                / {formatValue(target)}
              </div>
            )}
          </div>
          
          {showComparison && !isEditing && comparisonValue !== undefined && (
            <div className="mt-2 space-y-1 text-center">
                <div className="text-xs text-blue-600">
                    vs {comparisonYear}: <span className={`font-semibold ${comparisonTextColor}`}>{formatValue(comparisonValue)}</span>
                </div>
                 {comparisonDiff !== null && (
                    <div className="flex items-center justify-center gap-1">
                        {comparisonDiff > 0 ? (
                            <TrendingUp className={`w-3 h-3 ${higherIsBetter ? 'text-emerald-500' : 'text-red-500'}`} />
                        ) : comparisonDiff < 0 ? (
                            <TrendingDown className={`w-3 h-3 ${higherIsBetter ? 'text-red-500' : 'text-emerald-500'}`} />
                        ) : (
                            <Minus className="w-3 h-3 text-slate-400" />
                        )}
                        <span className={`text-xs font-medium ${
                            comparisonDiff === 0 ? 'text-slate-400' :
                            (comparisonDiff > 0 && higherIsBetter) || (comparisonDiff < 0 && !higherIsBetter) ? 'text-emerald-600' : 'text-red-600'
                        }`}>
                            {comparisonDiff > 0 ? '+' : ''}{formatValue(comparisonDiff, true)}
                        </span>
                    </div>
                )}
            </div>
          )}

          {variance !== null && !isEditing && !hideVariance && (
            <div className="flex items-center justify-center gap-2 px-2 py-1 bg-slate-50/50 rounded-lg mt-2">
              {variance > 0 ? (
                <TrendingUp className="w-3 h-3 text-emerald-500" />
              ) : variance < 0 ? (
                <TrendingDown className="w-3 h-3 text-red-500" />
              ) : (
                <Minus className="w-3 h-3 text-slate-400" />
              )}
              <span className={`text-xs font-medium ${
                variance > 0 ? 'text-emerald-600' : variance < 0 ? 'text-red-600' : 'text-slate-400'
              }`}>
                {variance === Infinity ? '+∞%' : variance === -Infinity ? '-∞%' : `${variance > 0 ? '+' : ''}${variance.toFixed(1)}%`}
              </span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

