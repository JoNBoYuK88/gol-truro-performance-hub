
export const wormSections = [
  {
    title: 'Risk',
    id: 'risk',
    subsections: [
      {
        title: 'Risk App - Review Last 4 Weeks worth of W.O.R.M actions with Online Managers',
        questions: [
          { id: 'risk_1_1', text: 'What is outstanding and why?', weeks: [1] },
          { id: 'risk_1_2', text: 'What is the new time lime time to complete?', weeks: [1] },
          { id: 'risk_1_3', text: 'Who was responsible for the actions?', weeks: [1] },
          { id: 'risk_1_4', text: 'Were all actions SMART?', weeks: [1] },
        ],
      },
      {
        title: 'Store Manager & Online Manager to complete a fleet walk & Compare to Periodic Damage Tracker',
        questions: [
          { id: 'fleet_1_1', text: 'Does the damage match the tracker for each van.', weeks: [1] },
          { id: 'fleet_1_2', text: 'Is there new damage not annotated on the tracker.', weeks: [1] },
          { id: 'fleet_1_3', text: 'Is all the damage reported on SIMS, with a drivers name, and has the appropriate action taken.', weeks: [1] },
        ],
      },
      {
        title: 'Complete a Fit to Deliver',
        questions: [
          { id: 'fit_to_deliver_1', text: 'Complete a Fit to Deliver', weeks: [1] },
        ],
      },
      {
        title: 'Review Store Web View / DVC',
        questions: [
          { id: 'dvc_1_2', text: 'Any checks significantly under 10mins', weeks: [1] },
          { id: 'dvc_1_3', text: 'Tyre checks complete on all vans (Unless VOR) on Tuesday each week with tyre Pressure & Tread depths recorded.', weeks: [1] },
          { id: 'dvc_1_4', text: 'Evidence RIY being used (i.e topping up fluid, changing bulbs)', weeks: [1] },
          { id: 'dvc_1_5', text: 'Unresolved Defects/VOR that don\'t have a log number or corrective action taken.', weeks: [1] },
        ],
      },
      {
        title: 'Reports (Previous 4 Weeks)',
        questions: [
          { id: 'reports_1_1', text: '30% Speeding Report', weeks: [1] },
          { id: 'reports_1_2', text: '10% Speeding Report', weeks: [1] },
          { id: 'reports_1_3', text: 'Driver Break Report', weeks: [1] },
          { id: 'reports_1_4', text: 'DHR Report', weeks: [1] },
          { id: 'reports_1_5', text: 'WESAR', weeks: [1] },
        ],
      },
      {
        title: 'SIMS, TTC & Drive Time',
        questions: [
          { id: 'sims_1_1', text: 'Outstanding SIM Action', weeks: [1] },
          { id: 'sims_1_3', text: 'Agency Drivers', weeks: [1] },
          { id: 'sims_1_4', text: 'Leavers Removed From SIMS & TTC', weeks: [1] },
          { id: 'sims_1_5', text: 'Long Term Absence Marked as Leave/Absence', weeks: [1] },
          { id: 'sims_1_6', text: 'Drive Time Completion', weeks: [1], hasSpecialInputs: true },
          { id: 'sims_1_7', text: 'Names / ID Correct on Drive Time vs Masternaut', weeks: [1] },
          { id: 'sims_1_8', text: 'Outstanding Tasks Cleared on TTC', weeks: [1] },
          { id: 'sims_1_9', text: 'All Drivers on TTC', weeks: [1] },
          { id: 'sims_1_10', text: 'UKG Pro vs SIMS & TTC', weeks: [1] },
        ],
      },
    ],
  },
  {
    title: 'Commercial and Customer',
    id: 'commercial',
    subsections: [
      {
        title: 'Period Cost Report',
        questions: [
          { id: 'comm_1_1', text: 'Review Period Cost Report', weeks: [2], hasCostReportGrid: true },
          { id: 'comm_1_2', text: 'Cost Folder Up to Date', weeks: [2] },
          { id: 'comm_1_3', text: 'Cost Query Responses Submitted', weeks: [2] },
        ],
      },
      {
        title: 'Store Controlled Costs',
        questions: [
          { id: 'comm_2_1', text: 'SSP Items Counted', weeks: [2] },
          { id: 'comm_2_2', text: 'SSP Items Ordered', weeks: [2] },
          { id: 'comm_2_3', text: 'RIY Items Counted', weeks: [2] },
          { id: 'comm_2_4', text: 'RIY Items Ordered', weeks: [2] },
          { id: 'comm_2_5', text: 'D2D Returned Item Spot Check', weeks: [2] },
          { id: 'comm_2_6', text: 'OBS Products Checked', weeks: [2] },
        ],
      },
      {
        title: 'Fines',
        questions: [
          { id: 'comm_3_1', text: 'Parking', weeks: [2] },
          { id: 'comm_3_2', text: 'Speeding', weeks: [2] },
        ],
      },
      {
        title: 'CSAT/DWC',
        questions: [
          { id: 'comm_4_1', text: 'iCare Score (%)', weeks: [2], hasIcareInput: true },
          { id: 'comm_4_2', text: 'iCare Action Plan Updated', weeks: [2] },
          { id: 'comm_4_3', text: 'DWC Score', weeks: [2] },
          { id: 'comm_4_4', text: 'Delivery Arriving in Time', weeks: [2] },
          { id: 'comm_4_5', text: 'Availability', weeks: [2] },
          { id: 'comm_4_6', text: 'Used by Dates', weeks: [2] },
          { id: 'comm_4_7', text: 'Quality & Condition of Items (Spot Check 3 Totes)', weeks: [2] },
          { id: 'comm_4_8', text: 'Knowledge & Friendliness of Colleagues (Ask 2 Drivers Short Life Policy)', weeks: [2] },
        ],
      },
      {
        title: 'Complaints Dashboard',
        questions: [
          { id: 'comm_5_1', text: 'Refunds & Goodwill Cost', weeks: [2] },
          { id: 'comm_5_2', text: 'Damaged Items', weeks: [2] },
          { id: 'comm_5_3', text: 'Missing Items', weeks: [2] },
          { id: 'comm_5_4', text: 'DY1 Complaints', weeks: [2] },
          { id: 'comm_5_5', text: 'Cancelled Orders', weeks: [2] },
        ],
      },
      {
        title: 'ILS',
        questions: [
          { id: 'comm_6_1', text: 'Tote Checks Daily (25)', weeks: [2] },
          { id: 'comm_6_2', text: 'Van Searches Completed (18)', weeks: [2] },
        ],
      },
    ],
  },
  {
    title: 'Colleague',
    id: 'colleague',
    subsections: [
      {
        title: 'Drivers',
        questions: [
          { id: 'coll_d_1', text: 'Total Contracted Hours', weeks: [3] },
          { id: 'coll_d_2', text: 'Drive Time Hours', weeks: [3] },
          { id: 'coll_d_3', text: 'Drivetime 100% (4 Weeks)', weeks: [3] },
          { id: 'coll_d_4', text: 'Turnover', weeks: [3] },
          { id: 'coll_d_5', text: 'Holiday(%)', weeks: [3] },
        ],
      },
      {
        title: 'GA',
        questions: [
          { id: 'coll_ga_1', text: 'Total Contracted Hours', weeks: [3] },
          { id: 'coll_ga_2', text: 'Heads Required', weeks: [3] },
          { id: 'coll_ga_3', text: 'Schedules Fit for Purpose (3 Weeks)', weeks: [3] },
          { id: 'coll_ga_4', text: 'Turnover', weeks: [3] },
          { id: 'coll_ga_5', text: 'Holiday(%)', weeks: [3] },
        ],
      },
      {
        title: 'Shopper',
        questions: [
          { id: 'coll_s_1', text: 'Total Contracted Hours', weeks: [3] },
          { id: 'coll_s_2', text: 'Heads Required', weeks: [3] },
          { id: 'coll_s_3', text: 'Schedules Fit for Purpose (3 Weeks)', weeks: [3] },
          { id: 'coll_s_4', text: 'Turnover', weeks: [3] },
          { id: 'coll_s_5', text: 'Holiday(%)', weeks: [3] },
        ],
      },
      {
        title: 'Forecast, Productivity & Absence',
        questions: [
          { id: 'coll_fpa_1', text: 'Forecast vs Actual', weeks: [3] },
          { id: 'coll_fpa_2', text: 'RTW Completed', weeks: [3] },
          { id: 'coll_fpa_3', text: 'Department Sickness(%)', weeks: [3] },
          { id: 'coll_fpa_4', text: 'Live Vacancy\'s', weeks: [3] },
        ],
      },
      {
        title: 'Talent & Development',
        questions: [
          { id: 'coll_td_1', text: 'Overdue Training', weeks: [3] },
          { id: 'coll_td_2', text: 'UKG Pro Alerts', weeks: [3] },
          { id: 'coll_td_3', text: 'GA\'s Who Can Open Online', weeks: [3] },
          { id: 'coll_td_4', text: 'GOL Contingency Processes', weeks: [3] },
          { id: 'coll_td_5', text: 'Multi Skilled Colleagues', weeks: [3] },
          { id: 'coll_td_6', text: 'Uniform Correct', weeks: [3] },
          { id: 'coll_td_7', text: 'Anyone on Trainee Management Scheme', weeks: [3] },
          { id: 'coll_td_8', text: 'WIN Completed', weeks: [3] },
          { id: 'coll_td_9', text: 'Driver Mentors', weeks: [3] },
          { id: 'coll_td_10', text: 'Love IT Friday', weeks: [3] },
          { id: 'coll_td_11', text: 'Viva Engage Engagement', weeks: [3] },
          { id: 'coll_td_12', text: 'OBS Engagement (Store, Shift, Drivers, GA)', weeks: [3] },
        ],
      },
    ],
  },
  {
    title: 'KPIs',
    id: 'kpis',
    subsections: [
      {
        title: 'On Time Departures',
        questions: [
          { id: 'kpi_1_1', text: 'Late Vans (4 Weeks)', weeks: [4] },
          { id: 'kpi_1_2', text: 'Risk Days', weeks: [4] },
          { id: 'kpi_1_3', text: 'AM / PM / Late Evening', weeks: [4] },
          { id: 'kpi_1_4', text: 'GA Loading Headcount Correct', weeks: [4] },
          { id: 'kpi_1_5', text: 'Late Driver Patterns', weeks: [4] },
          { id: 'kpi_1_6', text: 'Shoppers Hit Cold Chain', weeks: [4] },
          { id: 'kpi_1_7', text: 'Tote Barcodes Fit for Purpose', weeks: [4] },
          { id: 'kpi_1_8', text: 'Backup Drivers Headcount', weeks: [4] },
          { id: 'kpi_1_9', text: 'Shopper Scheduling Fit for Purpose', weeks: [4] },
        ],
      },
      {
        title: 'IPH % of Heads Achieving',
        questions: [
          { id: 'kpi_2_1', text: 'Current IPH Displayed', weeks: [4] },
          { id: 'kpi_2_2', text: 'New Shopper Count (Under 4 Weeks)', weeks: [4] },
          { id: 'kpi_2_3', text: 'ILS Train Track Correct', weeks: [4] },
          { id: 'kpi_2_4', text: 'OBS Trained Shoppers', weeks: [4] },
          { id: 'kpi_2_5', text: 'Un-Nailed SKU List Completed', weeks: [4] },
          { id: 'kpi_2_6', text: 'Pre-Pick Released 4am (Excluding Bakery)', weeks: [4] },
          { id: 'kpi_2_7', text: 'CTM on Shopfloor Supporting Shoppers', weeks: [4] },
        ],
      },
      {
        title: 'Shopper Performance',
        questions: [
          { id: 'kpi_3_1', text: 'Pick Time vs Schedule', weeks: [4] },
          { id: 'kpi_3_2', text: 'Walk Time In / Out Shop', weeks: [4] },
          { id: 'kpi_3_3', text: 'Skipped Items', weeks: [4] },
          { id: 'kpi_3_4', text: 'Items Don\'t Fit', weeks: [4] },
          { id: 'kpi_3_5', text: 'Wrong SKU Scanned', weeks: [4] },
          { id: 'kpi_3_6', text: 'Shopper Performance Conversations', weeks: [4] },
          { id: 'kpi_3_7', text: 'How Many Shoppers Achieving Target', weeks: [4] },
        ],
      },
      {
        title: 'Online Availability',
        questions: [
          { id: 'kpi_4_1', text: 'Availability(%)', weeks: [4] },
          { id: 'kpi_4_2', text: 'Shift, Food & GM Manager Stratergy', weeks: [4] },
          { id: 'kpi_4_3', text: 'Shift Using Extra Stock Report', weeks: [4] },
          { id: 'kpi_4_4', text: 'CTM Completing SDP', weeks: [4] },
        ],
      },
      {
        title: 'Replenishment Failed Picks',
        questions: [
          { id: 'kpi_5_1', text: 'Highest Contributing Subcats', weeks: [4] },
          { id: 'kpi_5_2', text: 'GM Sub Cats', weeks: [4] },
          { id: 'kpi_5_3', text: 'What Action Has Been Taken', weeks: [4] },
        ],
      },
      {
        title: 'Top Failed Picks',
        questions: [
          { id: 'kpi_6_1', text: 'What is the Root Cause', weeks: [4] },
          { id: 'kpi_6_2', text: 'ISB Availability %', weeks: [4] },
          { id: 'kpi_6_3', text: 'Failed Picks 2/3 Day Life Products', weeks: [4] },
          { id: 'kpi_6_4', text: 'Range Review / Plinth Changes Completed on time', weeks: [4] },
          { id: 'kpi_6_5', text: 'GM up to date with Re-Dresses (Outside Range Reviews / Plinth Changes)', weeks: [4] },
          { id: 'kpi_6_6', text: 'Replenishment Team Prioritising Stock Replenishment', weeks: [4] },
          { id: 'kpi_6_7', text: 'Store NAG Count (Last Week/Action Taken)', weeks: [4] },
          { id: 'kpi_6_8', text: 'Plinths & Seasonal Indicators Setup', weeks: [4] },
          { id: 'kpi_6_9', text: 'OBS Dashboard Reviewed', weeks: [4] },
          { id: 'kpi_6_10', text: 'OBS Checked After Last Van (PM)', weeks: [4] },
          { id: 'kpi_6_11', text: 'GA Bulk / OBS Pick Trained', weeks: [4] },
        ],
      },
    ],
  },
];
