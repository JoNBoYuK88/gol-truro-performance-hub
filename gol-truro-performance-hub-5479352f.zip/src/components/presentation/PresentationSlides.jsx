import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { UploadFile } from "@/api/integrations";
import { Plus, Minus, Upload, FileDown, ArrowLeft, ArrowRight, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function PresentationSlides({ 
  title, 
  period, 
  year, 
  salesData, 
  opsData, 
  labourData, 
  costData,
  onBack 
}) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slides, setSlides] = useState([
    {
      type: 'cover',
      title: `${title} - Period ${period}, ${year}`,
      subtitle: 'Performance Overview',
      imageUrl: '',
      isUploading: false
    },
    {
      type: 'data',
      title: 'Performance Summary',
      content: 'summary'
    }
  ]);

  const updateSlide = (index, updates) => {
    setSlides(prev => prev.map((slide, i) => 
      i === index ? { ...slide, ...updates } : slide
    ));
  };

  const handleImageUpload = async (event, slideIndex) => {
    const file = event.target.files[0];
    if (!file) return;

    updateSlide(slideIndex, { isUploading: true });

    try {
      const result = await UploadFile({ file });
      updateSlide(slideIndex, { imageUrl: result.file_url, isUploading: false });
      toast.success("Image uploaded successfully!");
    } catch (error) {
      console.error("Error uploading image:", error);
      toast.error("Failed to upload image");
      updateSlide(slideIndex, { isUploading: false });
    }
  };

  const addSlide = () => {
    setSlides(prev => [...prev, {
      type: 'custom',
      title: `Slide ${prev.length + 1}`,
      content: '',
      imageUrl: '',
      isUploading: false
    }]);
    setCurrentSlide(slides.length); // Switch to the new slide
  };

  const removeSlide = (index) => {
    if (slides.length <= 1) return;
    setSlides(prev => prev.filter((_, i) => i !== index));
    if (currentSlide >= slides.length - 1) {
      setCurrentSlide(Math.max(0, slides.length - 2));
    }
  };

  const renderCoverSlide = (slide, index) => (
    <div className="h-full flex flex-col items-center justify-center text-center space-y-8 bg-gradient-to-br from-blue-50 to-indigo-100 p-12">
      {slide.imageUrl && (
        <div className="mb-8">
          <img 
            src={slide.imageUrl} 
            alt="Cover" 
            className="max-w-md max-h-64 object-contain rounded-lg shadow-lg"
          />
        </div>
      )}
      
      <Input
        value={slide.title}
        onChange={(e) => updateSlide(index, { title: e.target.value })}
        className="text-4xl font-bold text-center border-0 bg-transparent text-gray-900 focus-visible:ring-0"
        placeholder="Presentation Title"
      />
      
      <Input
        value={slide.subtitle}
        onChange={(e) => updateSlide(index, { subtitle: e.target.value })}
        className="text-xl text-center border-0 bg-transparent text-gray-600 focus-visible:ring-0"
        placeholder="Subtitle"
      />

      <div className="mt-8">
        <label className="cursor-pointer">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => handleImageUpload(e, index)}
            className="hidden"
            id={`image-upload-${index}`}
          />
          <Button asChild variant="outline" disabled={slide.isUploading}>
            <label htmlFor={`image-upload-${index}`} className="cursor-pointer">
              {slide.isUploading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  {slide.imageUrl ? "Change Image" : "Upload Image"}
                </>
              )}
            </label>
          </Button>
        </label>
      </div>
    </div>
  );

  const renderDataSlide = () => (
    <div className="h-full p-8 space-y-8 overflow-y-auto">
      <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">Performance Summary</h2>
      
      {/* Sales Summary */}
      {salesData && (
        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-gray-800">Sales Summary</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4 shadow text-center">
              <div className="text-sm text-gray-600">Sales</div>
              <div className="text-2xl font-bold text-green-600">
                £{(salesData['Sales'] || 0).toLocaleString()}
              </div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow text-center">
              <div className="text-sm text-gray-600">vs Budget</div>
              <div className={`text-2xl font-bold ${(salesData['vs Budget'] || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                £{(salesData['vs Budget'] || 0).toLocaleString()}
              </div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow text-center">
              <div className="text-sm text-gray-600">Orders</div>
              <div className="text-2xl font-bold text-blue-600">
                {(salesData['Delivered Orders'] || 0).toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Ops Summary */}
      {opsData && (
        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-gray-800">Operations Summary</h3>
          <div className="grid grid-cols-4 gap-4">
            <div className="bg-white rounded-lg p-4 shadow text-center">
              <div className="text-sm text-gray-600">Ops Score</div>
              <div className="text-2xl font-bold text-blue-600">
                {(opsData['Ops Score'] || 0).toFixed(1)}%
              </div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow text-center">
              <div className="text-sm text-gray-600">Availability</div>
              <div className="text-2xl font-bold text-green-600">
                {(opsData['Availability'] || 0).toFixed(1)}%
              </div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow text-center">
              <div className="text-sm text-gray-600">OT Departures</div>
              <div className="text-2xl font-bold text-orange-600">
                {(opsData['On Time Departures'] || 0).toFixed(1)}%
              </div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow text-center">
              <div className="text-sm text-gray-600">DWC</div>
              <div className="text-2xl font-bold text-purple-600">
                {(opsData['Delivery Without Complaints'] || 0).toFixed(1)}%
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Labour Summary */}
      {labourData && (
        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-gray-800">Labour Summary</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4 shadow text-center">
              <div className="text-sm text-gray-600">Labour Forecast</div>
              <div className="text-2xl font-bold text-gray-700">
                {(labourData.labour_forecast || 0).toLocaleString()}
              </div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow text-center">
              <div className="text-sm text-gray-600">Labour Actual</div>
              <div className="text-2xl font-bold text-gray-700">
                {(labourData.labour_actual || 0).toLocaleString()}
              </div>
            </div>
            <div className="bg-white rounded-lg p-4 shadow text-center">
              <div className="text-sm text-gray-600">Variance</div>
              <div className={`text-2xl font-bold ${(labourData.labour_variance || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {(labourData.labour_variance || 0).toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderCustomSlide = (slide, index) => (
    <div className="h-full p-8 space-y-6">
      <Input
        value={slide.title}
        onChange={(e) => updateSlide(index, { title: e.target.value })}
        className="text-3xl font-bold text-center border-0 bg-transparent focus-visible:ring-0"
        placeholder="Slide Title"
      />
      
      <Textarea
        value={slide.content}
        onChange={(e) => updateSlide(index, { content: e.target.value })}
        className="h-96 text-lg"
        placeholder="Add your content here..."
      />

      {slide.imageUrl && (
        <div className="flex justify-center">
          <img 
            src={slide.imageUrl} 
            alt="Slide content" 
            className="max-w-full max-h-64 object-contain rounded-lg shadow-lg"
          />
        </div>
      )}

      <div className="flex justify-center">
        <label className="cursor-pointer">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => handleImageUpload(e, index)}
            className="hidden"
            id={`image-upload-${index}`}
          />
          <Button asChild variant="outline" disabled={slide.isUploading}>
            <label htmlFor={`image-upload-${index}`} className="cursor-pointer">
              {slide.isUploading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  {slide.imageUrl ? "Change Image" : "Add Image"}
                </>
              )}
            </label>
          </Button>
        </label>
      </div>
    </div>
  );

  const currentSlideData = slides[currentSlide];

  return (
    <div className="h-screen flex flex-col bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm p-4 flex justify-between items-center no-print">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Results
          </Button>
          <span className="text-lg font-semibold">
            Slide {currentSlide + 1} of {slides.length}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={addSlide}>
            <Plus className="w-4 h-4 mr-2" />
            Add Slide
          </Button>
          
          {slides.length > 1 && (
            <Button 
              variant="outline" 
              onClick={() => removeSlide(currentSlide)}
              className="text-red-600 hover:text-red-700"
            >
              <Minus className="w-4 h-4 mr-2" />
              Remove Slide
            </Button>
          )}

          <Button onClick={() => window.print()}>
            <FileDown className="w-4 h-4 mr-2" />
            Export Slides
          </Button>
        </div>
      </div>

      {/* Slide Content */}
      <div className="flex-1 p-8">
        <Card className="h-full w-full max-w-6xl mx-auto slide-page">
          <CardContent className="h-full p-0">
            {currentSlideData && currentSlideData.type === 'cover' && renderCoverSlide(currentSlideData, currentSlide)}
            {currentSlideData && currentSlideData.type === 'data' && renderDataSlide()}
            {currentSlideData && currentSlideData.type === 'custom' && renderCustomSlide(currentSlideData, currentSlide)}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="bg-white shadow-sm p-4 flex justify-center items-center gap-4 no-print">
        <Button 
          variant="outline" 
          onClick={() => setCurrentSlide(Math.max(0, currentSlide - 1))}
          disabled={currentSlide === 0}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex gap-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full ${
                index === currentSlide ? 'bg-blue-600' : 'bg-gray-300'
              }`}
            />
          ))}
        </div>

        <Button 
          variant="outline" 
          onClick={() => setCurrentSlide(Math.min(slides.length - 1, currentSlide + 1))}
          disabled={currentSlide === slides.length - 1}
        >
          Next
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>

      <style jsx>{`
        @media print {
          .no-print { display: none !important; }
          .slide-page { 
            width: 210mm !important; 
            height: 297mm !important; 
            page-break-after: always;
            box-shadow: none !important;
            border: none !important;
          }
          body { margin: 0; padding: 0; }
        }
      `}</style>
    </div>
  );
}