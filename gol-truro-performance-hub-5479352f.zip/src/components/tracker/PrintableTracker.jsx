import React from 'react';

const damageKeys = {
  'B': 'Bent',
  'C': 'Cracked',
  'D': 'Dent',
  'L': 'Loose',
  'M': 'Missing',
  'S': 'Smashed',
  'T': 'Torn',
  'Z': 'Scratch / Scrape'
};

const DAMAGE_TYPE_COLORS = {
  'B': '#FF4500', // Orange Red for Bent
  'C': '#DC143C', // Crimson for Cracked
  'D': '#FFD700', // Gold for Dent
  'L': '#9932CC', // Dark Orchid for Loose
  'M': '#FF1493', // Deep Pink for Missing
  'S': '#00CED1', // Dark Turquoise for Smashed
  'T': '#FF6347', // Tomato for Torn
  'Z': '#32CD32'  // Lime Green for Scratch/Scrape
};

const createMarkerSVG = (letter, color, shape = 'circle') => {
  if (shape === 'square') {
    const svg = `
      <svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
        <rect x="1" y="1" width="14" height="14" rx="2" fill="${color}" stroke="white" stroke-width="1.25"/>
        <text x="8" y="8" font-family="Arial, sans-serif" font-size="8" font-weight="bold" 
              text-anchor="middle" dominant-baseline="central" fill="white">${letter}</text>
      </svg>
    `;
    return `data:image/svg+xml;base64,${btoa(svg)}`;
  }
  const svg = `
    <svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
      <circle cx="8" cy="8" r="7" fill="${color}" stroke="white" stroke-width="1.25"/>
      <text x="8" y="8" font-family="Arial, sans-serif" font-size="8" font-weight="bold" 
            text-anchor="middle" dominant-baseline="central" fill="white">${letter}</text>
    </svg>
  `;
  return `data:image/svg+xml;base64,${btoa(svg)}`;
};

const formatDateForDiagram = (dateString) => {
  if (!dateString) return '';
  try {
    const date = new Date(dateString);
    const adjustedDate = new Date(date.getTime() + date.getTimezoneOffset() * 60000);
    const day = String(adjustedDate.getDate()).padStart(2, '0');
    const month = String(adjustedDate.getMonth() + 1).padStart(2, '0');
    const year = adjustedDate.getFullYear().toString().slice(-2);
    return `${day}/${month}/${year}`;
  } catch (e) {
    return '';
  }
};

const formatDateForOverlay = (dateString) => {
  if (!dateString) return 'DD / MM / YY';
  const date = new Date(dateString);
  const adjustedDate = new Date(date.getTime() + date.getTimezoneOffset() * 60000);
  const day = String(adjustedDate.getDate()).padStart(2, '0');
  const month = String(adjustedDate.getMonth() + 1).padStart(2, '0');
  const year = adjustedDate.getFullYear().toString().slice(-2);
  return `${day} / ${month} / ${year}`;
};

export default function PrintableTracker({ report, overlayPositions }) {
  // Process damage markers to group them properly
  const damageMarkers = report.damage_markers ? report.damage_markers.map((marker, index) => ({
    id: Date.now() + index,
    x: marker.position.x,
    y: marker.position.y,
    area: marker.area,
    damageType: marker.damage_type,
    description: marker.description || '',
    date: marker.date_found,
    color: DAMAGE_TYPE_COLORS[marker.damage_type] || marker.color,
    groupId: marker.groupId,
    isGroupLeader: marker.isGroupLeader,
    groupDescription: marker.isGroupLeader ? marker.description : undefined,
    isNew: false,
    shape: marker.shape || 'circle'
  })) : [];

  // Calculate group descriptions for non-leaders
  const finalMarkers = damageMarkers.map(marker => {
    if (marker.groupId && !marker.isGroupLeader) {
      const leader = damageMarkers.find(m => m.groupId === marker.groupId && m.isGroupLeader);
      return { ...marker, groupDescription: leader ? leader.description : marker.description };
    }
    return marker;
  });

  return (
    <div className="relative w-full h-full">
      <img
        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/15e451ed5_NEWPeriodDamageTracker1.png"
        alt="Van damage diagram"
        className="w-full h-full object-contain"
      />
      
      {/* Overlays */}
      <div
        className="absolute p-1 rounded"
        style={{
          ...overlayPositions.vanReg,
          fontSize: '9px',
          fontWeight: 'bold',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'black',
          backgroundColor: 'rgba(255, 255, 255, 0.8)'
        }}
      >
        {report.van_registration}
      </div>

      <div
        className="absolute p-1 rounded"
        style={{
          ...overlayPositions.period,
          fontSize: '9px',
          fontWeight: 'bold',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'black',
          backgroundColor: 'rgba(255, 255, 255, 0.8)'
        }}
      >
        {report.period}
      </div>

      <div
        className="absolute p-1 rounded"
        style={{
          ...overlayPositions.exteriorCleanDate,
          fontSize: '9px',
          fontWeight: 'bold',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'black',
          backgroundColor: 'rgba(255, 255, 255, 0.8)'
        }}
      >
        {formatDateForOverlay(report.cleaning_dates?.exterior)}
      </div>

      <div
        className="absolute p-1 rounded"
        style={{
          ...overlayPositions.cabCleanDate,
          fontSize: '9px',
          fontWeight: 'bold',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'black',
          backgroundColor: 'rgba(255, 255, 255, 0.8)'
        }}
      >
        {formatDateForOverlay(report.cleaning_dates?.cab)}
      </div>

      <div
        className="absolute p-1 rounded"
        style={{
          ...overlayPositions.boxCleanDate,
          fontSize: '9px',
          fontWeight: 'bold',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'black',
          backgroundColor: 'rgba(255, 255, 255, 0.8)'
        }}
      >
        {formatDateForOverlay(report.cleaning_dates?.box)}
      </div>

      {/* Damage Markers */}
      {finalMarkers.map(marker => {
          return (
            <div
              key={marker.id}
              className="absolute"
              style={{
                left: `${marker.x}%`,
                top: `${marker.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
            >
              <div className="relative w-4 h-4">
                <img
                  src={createMarkerSVG(marker.damageType, marker.color, marker.shape)}
                  alt={`${damageKeys[marker.damageType]} damage marker`}
                  className="w-full h-full"
                />
                {!marker.isNew && (!marker.groupId || marker.isGroupLeader) && (
                  <div 
                    className="absolute flex flex-col items-center pointer-events-none"
                    style={{ 
                      top: marker.y > 80 ? '-30px' : '18px',
                      left: marker.x > 80 ? '-60px' : '-40px',
                      width: '80px',
                      textAlign: 'center'
                    }}
                  >
                    <div 
                      className="bg-white/90 text-blue-700 font-bold px-1 py-0.5 rounded text-xs whitespace-nowrap"
                      style={{ fontSize: '8px' }}
                    >
                      {formatDateForDiagram(marker.date)}
                    </div>
                    {(marker.description || marker.groupDescription) && (
                      <div 
                        className="bg-white/90 text-red-700 font-bold px-1 py-0.5 rounded text-xs mt-0.5"
                        style={{ 
                          fontSize: '8px',
                          maxWidth: '70px',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap'
                        }}
                      >
                        {marker.groupId ? marker.groupDescription : marker.description}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
    </div>
  );
}