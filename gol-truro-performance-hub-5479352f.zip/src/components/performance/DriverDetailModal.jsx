
import React, { useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown } from 'lucide-react';

export default function DriverDetailModal({ isOpen, onClose, driverData }) {
    if (!driverData) return null;

    const { name, performanceRecords } = driverData;

    const chartData = useMemo(() => {
        if (!performanceRecords) return [];

        const dataByWeek = Array.from({ length: 52 }, (_, i) => {
            const week = i + 1;
            const periodForWeek = Math.floor((week - 1) / 4) + 1;
            const weekInPeriod = (week - 1) % 4 + 1;
            
            // Find records for this specific period and week
            const recordsForWeek = performanceRecords.filter(r => 
                r.period === periodForWeek && r.week === weekInPeriod
            );

            const smootherRecord = recordsForWeek.find(r => r.metric_name === 'Smoother');
            const saferRecord = recordsForWeek.find(r => r.metric_name === 'Safer');
            const cleanerRecord = recordsForWeek.find(r => r.metric_name === 'Cleaner');
            const dhrRecord = recordsForWeek.find(r => r.metric_name === 'DHR');
            const breaksRecord = recordsForWeek.find(r => r.metric_name === 'Breaks');

            return {
                label: `P${periodForWeek} W${weekInPeriod}`,
                period: periodForWeek,
                week: weekInPeriod,
                smoother: smootherRecord ? smootherRecord.value : null,
                safer: saferRecord ? saferRecord.value : null,
                cleaner: cleanerRecord ? cleanerRecord.value : null,
                dhr: dhrRecord ? dhrRecord.value : null,
                breaks: breaksRecord ? breaksRecord.value : null,
                hasData: recordsForWeek.length > 0
            };
        });

        return dataByWeek.filter(d => d.hasData);
    }, [performanceRecords]);

    const getMetricStatus = (value, metricName) => {
        if (!value) return "gray";
        
        if (metricName === 'Smoother') {
            if (value >= 60) return "green";
            if (value >= 40.1) return "amber";
            return "red";
        } else if (metricName === 'Safer') {
            if (value >= 98) return "green";
            if (value >= 96) return "amber";
            return "red";
        } else if (metricName === 'Cleaner') {
            if (value >= 95) return "green";
            if (value >= 90) return "amber";
            return "red";
        }
        return "gray";
    };

    const groupedData = useMemo(() => {
        if (!performanceRecords) return [];
        
        const grouped = performanceRecords.reduce((acc, record) => {
            const key = `P${record.period} W${record.week}`;
            if (!acc[key]) {
                acc[key] = {
                    period: record.period,
                    week: record.week,
                    metrics: {}
                };
            }
            acc[key].metrics[record.metric_name] = record.value;
            return acc;
        }, {});

        return Object.values(grouped).sort((a, b) => {
            if (a.period !== b.period) return a.period - b.period;
            return a.week - b.week;
        });
    }, [performanceRecords]);

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-5xl bg-white border border-slate-200 shadow-xl rounded-xl">
                <DialogHeader className="pb-4">
                    <DialogTitle className="text-2xl font-bold text-slate-900">Driver Performance: {name}</DialogTitle>
                    <DialogDescription className="text-slate-600">
                        Weekly performance breakdown showing all metrics across periods.
                    </DialogDescription>
                </DialogHeader>

                <div className="h-[300px] w-full mt-4 bg-white/50 backdrop-blur-sm rounded-lg p-4 border border-slate-200">
                    <ResponsiveContainer>
                        <ComposedChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="label" stroke="#475569" fontSize={12} />
                            <YAxis yAxisId="left" orientation="left" stroke="#4c51bf" fontSize={12} label={{ value: 'Percentage', angle: -90, position: 'insideLeft' }} />
                            <YAxis yAxisId="right" orientation="right" stroke="#ef4444" fontSize={12} label={{ value: 'Count', angle: 90, position: 'insideRight' }} />
                            <Tooltip
                                formatter={(value, name) => {
                                    if (name && (name.includes('Smoother') || name.includes('Safer') || name.includes('Cleaner'))) {
                                        return [`${Number(value).toFixed(1)}%`, name];
                                    }
                                    return [value, name];
                                }}
                                contentStyle={{
                                    background: "rgba(255, 255, 255, 0.95)",
                                    backdropFilter: "blur(10px)",
                                    border: "1px solid #e2e8f0",
                                    borderRadius: "8px",
                                    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
                                }}
                            />
                            <Legend wrapperStyle={{ fontSize: "14px" }}/>
                            <Bar yAxisId="left" dataKey="smoother" fill="#22c55e" name="Smoother %" radius={[2, 2, 0, 0]} />
                            <Bar yAxisId="left" dataKey="safer" fill="#3b82f6" name="Safer %" radius={[2, 2, 0, 0]} />
                            <Bar yAxisId="left" dataKey="cleaner" fill="#f59e0b" name="Cleaner %" radius={[2, 2, 0, 0]} />
                            <Line yAxisId="right" type="monotone" dataKey="dhr" stroke="#ef4444" strokeWidth={2} name="DHR Count" dot={{ r: 4 }} />
                            <Line yAxisId="right" type="monotone" dataKey="breaks" stroke="#8b5cf6" strokeWidth={2} name="Breaks Count" dot={{ r: 4 }} />
                        </ComposedChart>
                    </ResponsiveContainer>
                </div>

                <div className="h-[300px] overflow-auto border border-slate-200 rounded-lg mt-4 bg-white">
                    <Table>
                        <TableHeader className="sticky top-0 bg-slate-50 z-10">
                            <TableRow className="border-b border-slate-200">
                                <TableHead className="font-semibold text-slate-700">Period</TableHead>
                                <TableHead className="font-semibold text-slate-700">Week</TableHead>
                                <TableHead className="font-semibold text-slate-700">Smoother</TableHead>
                                <TableHead className="font-semibold text-slate-700">Safer</TableHead>
                                <TableHead className="font-semibold text-slate-700">Cleaner</TableHead>
                                <TableHead className="font-semibold text-slate-700">DHR</TableHead>
                                <TableHead className="font-semibold text-slate-700">Breaks</TableHead>
                                <TableHead className="font-semibold text-slate-700">DWC</TableHead>
                                <TableHead className="font-semibold text-slate-700">Speeding 30%</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {groupedData.map(weekData => (
                                <TableRow 
                                    key={`${weekData.period}-${weekData.week}`} 
                                    className="border-b border-slate-100 hover:bg-slate-50 transition-colors duration-150"
                                >
                                    <TableCell className="font-medium text-slate-900">{weekData.period}</TableCell>
                                    <TableCell className="text-slate-700">{weekData.week}</TableCell>
                                    <TableCell>
                                        {weekData.metrics.Smoother !== undefined ? (
                                            <Badge
                                                className={
                                                    getMetricStatus(weekData.metrics.Smoother, 'Smoother') === "green" ? "bg-green-100 text-green-800 border-green-200" :
                                                    getMetricStatus(weekData.metrics.Smoother, 'Smoother') === "amber" ? "bg-amber-100 text-amber-800 border-amber-200" : 
                                                    "bg-red-100 text-red-800 border-red-200"
                                                }
                                            >
                                                {Number(weekData.metrics.Smoother).toFixed(1)}%
                                            </Badge>
                                        ) : (
                                            <span className="text-slate-400">-</span>
                                        )}
                                    </TableCell>
                                    <TableCell>
                                        {weekData.metrics.Safer !== undefined ? (
                                            <Badge
                                                className={
                                                    getMetricStatus(weekData.metrics.Safer, 'Safer') === "green" ? "bg-green-100 text-green-800 border-green-200" :
                                                    getMetricStatus(weekData.metrics.Safer, 'Safer') === "amber" ? "bg-amber-100 text-amber-800 border-amber-200" : 
                                                    "bg-red-100 text-red-800 border-red-200"
                                                }
                                            >
                                                {Number(weekData.metrics.Safer).toFixed(1)}%
                                            </Badge>
                                        ) : (
                                            <span className="text-slate-400">-</span>
                                        )}
                                    </TableCell>
                                    <TableCell>
                                        {weekData.metrics.Cleaner !== undefined ? (
                                            <Badge
                                                className={
                                                    getMetricStatus(weekData.metrics.Cleaner, 'Cleaner') === "green" ? "bg-green-100 text-green-800 border-green-200" :
                                                    getMetricStatus(weekData.metrics.Cleaner, 'Cleaner') === "amber" ? "bg-amber-100 text-amber-800 border-amber-200" : 
                                                    "bg-red-100 text-red-800 border-red-200"
                                                }
                                            >
                                                {Number(weekData.metrics.Cleaner).toFixed(1)}%
                                            </Badge>
                                        ) : (
                                            <span className="text-slate-400">-</span>
                                        )}
                                    </TableCell>
                                    <TableCell className="font-semibold text-slate-900">
                                        {weekData.metrics.DHR !== undefined ? weekData.metrics.DHR : '-'}
                                    </TableCell>
                                    <TableCell className="font-semibold text-slate-900">
                                        {weekData.metrics.Breaks !== undefined ? weekData.metrics.Breaks : '-'}
                                    </TableCell>
                                    <TableCell className="font-semibold text-slate-900">
                                        {weekData.metrics.DWC !== undefined ? weekData.metrics.DWC : '-'}
                                    </TableCell>
                                    <TableCell className="font-semibold text-slate-900">
                                        {weekData.metrics['Speeding 30%'] !== undefined ? weekData.metrics['Speeding 30%'] : '-'}
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            </DialogContent>
        </Dialog>
    );
}
