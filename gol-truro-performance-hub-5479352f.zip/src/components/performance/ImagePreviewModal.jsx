import React from 'react';
import { Dialog, DialogContent, DialogHeader } from '@/components/ui/dialog';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ImagePreviewModal({ isOpen, onClose, imageUrl }) {
    if (!imageUrl) return null;

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-5xl h-auto p-2 bg-transparent border-0 shadow-none outline-none ring-0 focus:ring-0">
                <DialogHeader className="relative">
                     <Button
                        variant="ghost"
                        size="icon"
                        onClick={onClose}
                        className="absolute -top-2 -right-2 z-50 bg-white rounded-full p-1 opacity-80 hover:opacity-100 transition-opacity h-8 w-8"
                        aria-label="Close"
                    >
                        <X className="w-5 h-5 text-gray-800" />
                    </Button>
                </DialogHeader>
                <div className="flex justify-center items-center p-4">
                    <img 
                        src={imageUrl} 
                        alt="Action log evidence" 
                        className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl"
                    />
                </div>
            </DialogContent>
        </Dialog>
    );
}