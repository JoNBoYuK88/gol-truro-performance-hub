import React, { useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown } from 'lucide-react';

export default function ShopperDetailModal({ isOpen, onClose, shopperData, iphTargets }) {
    if (!shopperData) return null;

    const { name, performanceRecords } = shopperData;

    const chartData = useMemo(() => {
        if (!performanceRecords) return [];

        const dataByWeek = Array.from({ length: 52 }, (_, i) => {
            const week = i + 1;
            const record = performanceRecords.find(r => {
                const recordWeekOfYear = (r.period - 1) * 4 + r.week;
                return recordWeekOfYear === week;
            });

            const periodForWeek = Math.floor((week - 1) / 4) + 1;
            const target = iphTargets.find(t => t.period === periodForWeek)?.iph_target || 0;

            return {
                label: `P${periodForWeek} W${(week - 1) % 4 + 1}`,
                iph: record ? record.iph : null,
                picked_items: record ? record.picked_items : 0,
                target_iph: target
            };
        });

        return dataByWeek.filter(d => d.iph !== null);

    }, [performanceRecords, iphTargets]);

    const getIPHStatus = (iph, target) => {
        if (iph >= target) return "green";
        if (iph >= target * 0.9) return "amber";
        return "red";
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-4xl bg-white border border-slate-200 shadow-xl rounded-xl">
                <DialogHeader className="pb-4">
                    <DialogTitle className="text-2xl font-bold text-slate-900">Yearly Performance: {name}</DialogTitle>
                    <DialogDescription className="text-slate-600">
                        Weekly performance breakdown for the selected year.
                    </DialogDescription>
                </DialogHeader>

                <div className="h-[300px] w-full mt-4 bg-white/50 backdrop-blur-sm rounded-lg p-4 border border-slate-200">
                    <ResponsiveContainer>
                        <ComposedChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="label" stroke="#475569" fontSize={12} />
                            <YAxis yAxisId="left" orientation="left" stroke="#4c51bf" fontSize={12} label={{ value: 'IPH', angle: -90, position: 'insideLeft' }} />
                            <YAxis yAxisId="right" orientation="right" stroke="#34d399" fontSize={12} label={{ value: 'Items', angle: 90, position: 'insideRight' }} />
                            <Tooltip
                                contentStyle={{
                                    background: "rgba(255, 255, 255, 0.95)",
                                    backdropFilter: "blur(10px)",
                                    border: "1px solid #e2e8f0",
                                    borderRadius: "8px",
                                    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
                                }}
                            />
                            <Legend wrapperStyle={{ fontSize: "14px" }}/>
                            <Bar yAxisId="left" dataKey="iph" fill="url(#colorIph)" name="Weekly IPH" radius={[4, 4, 0, 0]} />
                            <Line yAxisId="left" type="monotone" dataKey="target_iph" stroke="#f59e0b" strokeWidth={2} name="Target IPH" dot={false} />
                            <Line yAxisId="right" type="monotone" dataKey="picked_items" stroke="#34d399" strokeWidth={2} name="Picked Items" dot={false} />
                             <defs>
                                <linearGradient id="colorIph" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#4c51bf" stopOpacity={0.8}/>
                                <stop offset="95%" stopColor="#4c51bf" stopOpacity={0.2}/>
                                </linearGradient>
                            </defs>
                        </ComposedChart>
                    </ResponsiveContainer>
                </div>

                <div className="h-[300px] overflow-auto border border-slate-200 rounded-lg mt-4 bg-white">
                    <Table>
                        <TableHeader className="sticky top-0 bg-slate-50 z-10">
                            <TableRow className="border-b border-slate-200">
                                <TableHead className="font-semibold text-slate-700">Period</TableHead>
                                <TableHead className="font-semibold text-slate-700">Week</TableHead>
                                <TableHead className="font-semibold text-slate-700">IPH</TableHead>
                                <TableHead className="font-semibold text-slate-700">Picked Items</TableHead>
                                <TableHead className="font-semibold text-slate-700">IPH vs Target</TableHead>
                                <TableHead className="font-semibold text-slate-700">Status</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {performanceRecords && performanceRecords.sort((a, b) => a.period - b.period || a.week - b.week).map(record => {
                                const target = iphTargets.find(t => t.period === record.period)?.iph_target || 0;
                                const status = getIPHStatus(record.iph, target);
                                const variance = record.iph - target;

                                return (
                                    <TableRow 
                                        key={`${record.period}-${record.week}`} 
                                        className="border-b border-slate-100 hover:bg-slate-50 transition-colors duration-150"
                                    >
                                        <TableCell className="font-medium text-slate-900">{record.period}</TableCell>
                                        <TableCell className="text-slate-700">{record.week}</TableCell>
                                        <TableCell className="font-semibold text-slate-900">{record.iph.toFixed(2)}</TableCell>
                                        <TableCell className="text-slate-700">{record.picked_items}</TableCell>
                                        <TableCell className={`font-medium flex items-center gap-1 ${variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                            {variance >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                                            {variance.toFixed(2)}
                                        </TableCell>
                                        <TableCell>
                                            <Badge
                                                className={
                                                    status === "green" ? "bg-green-100 text-green-800 border-green-200" :
                                                    status === "amber" ? "bg-amber-100 text-amber-800 border-amber-200" : "bg-red-100 text-red-800 border-red-200"
                                                }
                                            >
                                                {status.charAt(0).toUpperCase() + status.slice(1)}
                                            </Badge>
                                        </TableCell>
                                    </TableRow>
                                )
                            })}
                        </TableBody>
                    </Table>
                </div>
            </DialogContent>
        </Dialog>
    )
}