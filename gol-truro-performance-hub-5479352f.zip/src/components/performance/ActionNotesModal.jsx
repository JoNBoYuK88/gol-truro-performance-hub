
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Driver } from '@/api/entities';
import { UploadFile, UploadPrivateFile } from '@/api/integrations'; // Added UploadPrivateFile
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Loader2, Trash2, PlusCircle, Calendar, FileText, Eye, Upload, X } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import ImagePreviewModal from './ImagePreviewModal';
import PrivateImage from './PrivateImage'; // Import the new component

const actionTypes = [
    { value: 'coaching', label: 'Coaching' },
    { value: 'irod', label: 'IROD' },
    { value: 'first_warning', label: 'First Warning' },
    { value: 'final_warning', label: 'Final Warning' },
    { value: 'dismissed', label: 'Dismissed' },
    { value: 'resigned', label: 'Resigned' },
    { value: 'celebrate', label: 'Celebrate' }
];

const violationTypes = [
    { value: 'DHR', label: 'DHR' },
    { value: 'Breaks', label: 'Breaks' },
    { value: 'Speeding 10%', label: 'Speeding 10%' },
    { value: 'Speeding 30%', label: 'Speeding 30%' },
    { value: 'Serve Legal Fail', label: 'Serve Legal Fail' },
    { value: 'Serve Legal Pass', label: 'Serve Legal Pass' },
    { value: 'Masternaut', label: 'Masternaut' },
    { value: 'Smoother Violation', label: 'Smoother' },
    { value: 'Safer Violation', label: 'Safer' },
    { value: 'Cleaner Violation', label: 'Cleaner' },
];

export default function ActionNotesModal({ isOpen, onClose, notesData, onSave, driverName, canEdit, isViewOnly }) {
    const [allNotes, setAllNotes] = useState([]);
    const [newViolation, setNewViolation] = useState('');
    const [newActionType, setNewActionType] = useState('');
    const [newActionDate, setNewActionDate] = useState('');
    const [newEventDate, setNewEventDate] = useState('');
    const [newActionByWho, setNewActionByWho] = useState('');
    const [autoIncrementValue, setAutoIncrementValue] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [uploadingImages, setUploadingImages] = useState(new Set());

    const [selectedDriverId, setSelectedDriverId] = useState('');
    const [drivers, setDrivers] = useState([]);

    const [isImagePreviewOpen, setIsImagePreviewOpen] = useState(false);
    const [previewImageUrl, setPreviewImageUrl] = useState('');

    const effectiveCanEdit = canEdit && !isViewOnly;
    const isAddingViolation = notesData?.isAddingViolation || false;

    useEffect(() => {
        if (isOpen && effectiveCanEdit) {
            const fetchUserAndSetDefaults = async () => {
                try {
                    const user = await User.me();
                    setNewActionByWho(user.full_name || user.email);
                } catch (e) {
                    console.error("Failed to fetch user", e);
                }
            };
            fetchUserAndSetDefaults();

            const today = new Date();
            const todayStr = today.toISOString().split('T')[0];
            setNewActionDate(todayStr);
            setNewEventDate(todayStr);

            if (!isAddingViolation && notesData?.clickedRecord?.metric_name) {
                setNewViolation(notesData.clickedRecord.metric_name);
            }
        }
    }, [isOpen, effectiveCanEdit, notesData, isAddingViolation]);

    useEffect(() => {
        if (isAddingViolation && isOpen) {
            const loadDrivers = async () => {
                try {
                    const driverData = await Driver.filter({ is_active: true });
                    setDrivers(driverData);
                } catch (error) {
                    console.error("Failed to load drivers:", error);
                }
            };
            loadDrivers();
        } else {
            setDrivers([]);
        }
    }, [isAddingViolation, isOpen]);

    useEffect(() => {
        if (notesData && !isAddingViolation) {
            const processedNotes = (notesData.allRecordsForDriver || [])
                .flatMap(rec =>
                    (rec.notes || []).map(note => ({
                        ...note,
                        sourceRecordId: rec.id,
                        sourceMetricName: rec.metric_name,
                        sourceLabel: `P${rec.period} W${rec.week}`,
                        // Keep both uri and url to differentiate between old and new images
                        image_uri: note.image_uri || null,
                        image_url: note.image_url || null, 
                    }))
                )
                .sort((a, b) => new Date(b.date) - new Date(a.date));

            setAllNotes(processedNotes);
        } else {
            setAllNotes([]);
        }
    }, [notesData, isAddingViolation]);

    const handleAddAction = () => {
        if (!effectiveCanEdit) return;

        if (isAddingViolation) {
            if (!selectedDriverId || !newViolation || !newActionType || !newActionDate || !newEventDate) {
                toast.error("Please fill in all required fields: Driver, Violation, Action Taken, Action Date, Violation Date.");
                return;
            }
        } else {
            if (!newViolation || !newActionType || !newActionDate || !newEventDate || !newActionByWho.trim()) {
                toast.error("Please fill in all required fields: Violation, Action Taken, Action Date, Violation Date, By Who.");
                return;
            }
        }

        const newNote = {
            isNew: true,
            violation: newViolation,
            action_type: newActionType,
            date: new Date(newActionDate + 'T' + new Date().toISOString().split('T')[1]).toISOString(),
            event_date: newEventDate,
            by_who: newActionByWho.trim(),
            auto_increment: autoIncrementValue,
            image_uri: null, // Set to null initially for new notes
            image_url: null, // Set to null initially for new notes
            sourceRecordId: null,
            sourceMetricName: newViolation,
            sourceLabel: 'New',
            selectedDriverId: isAddingViolation ? selectedDriverId : notesData?.clickedRecord?.shopper_colleague_id
        };
        
        setAllNotes(prev => [newNote, ...prev].sort((a, b) => new Date(b.date) - new Date(a.date)));

        setNewActionType('');
        if (isAddingViolation) {
            setNewViolation('');
            setSelectedDriverId('');
        }
    };

    const handleDeleteAction = (indexToDelete) => {
        if (!effectiveCanEdit) return;
        setAllNotes(prev => prev.filter((_, index) => index !== indexToDelete));
    };

    const handleEditNote = (index, field, value) => {
        if (!effectiveCanEdit) return;
        setAllNotes(prev => prev.map((note, i) =>
            i === index ? { ...note, [field]: value } : note
        ));
    };

    const handleImageUpload = async (index, file) => {
        if (!effectiveCanEdit || !file) return;

        if (!file.type.startsWith('image/')) {
            toast.error('Please select an image file');
            return;
        }

        if (file.size > 10 * 1024 * 1024) {
            toast.error('Image file too large. Please select a file under 10MB.');
            return;
        }

        const noteId = `note-${index}`;
        setUploadingImages(prev => new Set([...prev, noteId]));

        try {
            console.log('Uploading private image:', file.name, 'Size:', file.size);
            const { file_uri } = await UploadPrivateFile({ file }); // Changed to UploadPrivateFile and file_uri
            console.log('Image uploaded successfully to private storage:', file_uri);

            setAllNotes(prev => prev.map((note, i) =>
                i === index ? { ...note, image_uri: file_uri, image_url: null } : note // Set uri, clear url
            ));

            toast.success('Image uploaded successfully');
        } catch (error) {
            console.error('Error uploading image:', error);
            let errorMessage = 'Failed to upload image. Please try again.';
            if (error.message && (error.message.includes('500') || error.message.includes('timeout') || error.message.includes('544'))) {
                errorMessage = 'A server error occurred while uploading. Please try again in a few moments.';
            } else if (error.message) {
                errorMessage = `Failed to upload image: ${error.message}`;
            }
            toast.error(errorMessage);
        } finally {
            setUploadingImages(prev => {
                const newSet = new Set(prev);
                newSet.delete(noteId);
                return newSet;
            });
        }
    };

    const handleRemoveImage = (index) => {
        if (!effectiveCanEdit) return;
        setAllNotes(prev => prev.map((note, i) =>
            i === index ? { ...note, image_uri: null, image_url: null } : note
        ));
        toast.info('Image removed');
    };

    const handleImagePreview = (url) => {
        setPreviewImageUrl(url);
        setIsImagePreviewOpen(true);
    };

    const handleSaveAndClose = async () => {
        if (!effectiveCanEdit) return;
        setIsSaving(true);
        await onSave(allNotes);
        setIsSaving(false);
        onClose();
    };

    const getActionTypeBadge = (actionType) => {
        const badgeStyles = {
            coaching: 'bg-green-100 text-green-800',
            irod: 'bg-blue-100 text-blue-800',
            first_warning: 'bg-amber-100 text-amber-800',
            final_warning: 'bg-red-100 text-red-800',
            dismissed: 'bg-gray-100 text-gray-800',
            resigned: 'bg-gray-100 text-gray-800',
            celebrate: 'bg-yellow-100 text-yellow-800'
        };

        const label = actionTypes.find(type => type.value === actionType)?.label || actionType;
        return (
            <Badge className={`${badgeStyles[actionType] || 'bg-gray-100 text-gray-800'} text-xs`}>
                {label}
            </Badge>
        );
    };

    if (!notesData) return null;

    const { clickedRecord } = notesData;
    const selectedDriver = drivers.find(d => d.colleague_id === selectedDriverId);
    const displayDriverName = isAddingViolation ?
        (selectedDriver ? selectedDriver.name : 'Select Driver') :
        driverName;

    return (
        <>
            <Dialog open={isOpen} onOpenChange={onClose}>
                <DialogContent className="max-w-6xl max-h-[85vh] flex flex-col bg-gradient-to-br from-slate-50 to-white">
                    <DialogHeader className="flex-shrink-0 pb-6">
                        <div className="flex items-center gap-3">
                            <div className={`w-12 h-12 ${effectiveCanEdit ? 'bg-gradient-to-br from-blue-500 to-blue-600' : 'bg-gradient-to-br from-slate-500 to-slate-600'} rounded-xl flex items-center justify-center`}>
                                {effectiveCanEdit ? <FileText className="w-6 h-6 text-white" /> : <Eye className="w-6 h-6 text-white" />}
                            </div>
                            <div>
                                <DialogTitle className="text-xl font-bold text-slate-800">
                                    {isAddingViolation ? 'Add New Violation' : (effectiveCanEdit ? 'Action Log' : 'View Action Log')} for {displayDriverName}
                                </DialogTitle>
                                <DialogDescription className="text-slate-600 mt-1">
                                    {isAddingViolation ?
                                        'Add a new violation and associated action for a driver' :
                                        `Showing full history for driver: ${displayDriverName}`
                                    }
                                    {!effectiveCanEdit && <span className="block text-xs text-slate-500 mt-1">View-only mode</span>}
                                </DialogDescription>
                            </div>
                        </div>
                    </DialogHeader>

                    <div className="flex-grow overflow-hidden flex flex-col space-y-6">
                        <div className="flex-grow overflow-hidden">
                            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                                <Calendar className="w-5 h-5 text-blue-600" />
                                {isAddingViolation ? `New Action for ${displayDriverName}` : `Full Action History (${allNotes.length})`}
                            </h3>

                            <Card className="bg-white border border-slate-200 shadow-sm">
                                <CardContent className="p-0">
                                    <div className="max-h-80 overflow-y-auto">
                                        <Table>
                                            <TableHeader className="sticky top-0 bg-slate-50 z-10">
                                                <TableRow className="border-b border-slate-200">
                                                    <TableHead className="font-semibold text-slate-700 w-[12%]">Violation</TableHead>
                                                    <TableHead className="font-semibold text-slate-700 w-[12%]">Action Taken</TableHead>
                                                    <TableHead className="font-semibold text-slate-700 w-[15%]">Action Date</TableHead>
                                                    <TableHead className="font-semibold text-slate-700 w-[15%]">Violation Date</TableHead>
                                                    <TableHead className="font-semibold text-slate-700 w-[15%]">By Who</TableHead>
                                                    <TableHead className="font-semibold text-slate-700 w-[15%]">Image</TableHead>
                                                    <TableHead className="font-semibold text-slate-700 w-[8%]">Source</TableHead>
                                                    {effectiveCanEdit && <TableHead className="w-[8%]"></TableHead>}
                                                </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                                {allNotes.length > 0 ? (
                                                    allNotes.map((note, index) => (
                                                        <TableRow key={index} className="border-b border-slate-100 hover:bg-slate-50">
                                                            <TableCell className="p-2 text-sm font-medium text-slate-700">
                                                                {note.sourceMetricName}
                                                            </TableCell>
                                                            <TableCell className="p-2">
                                                                {effectiveCanEdit ? (
                                                                    <Select
                                                                        value={note.action_type || ''}
                                                                        onValueChange={(value) => handleEditNote(index, 'action_type', value)}
                                                                    >
                                                                        <SelectTrigger className="text-sm h-9">
                                                                            <SelectValue placeholder="Select type" />
                                                                        </SelectTrigger>
                                                                        <SelectContent>
                                                                            {actionTypes.map(type => (
                                                                                <SelectItem key={type.value} value={type.value}>
                                                                                    {type.label}
                                                                                </SelectItem>
                                                                            ))}
                                                                        </SelectContent>
                                                                    </Select>
                                                                ) : (
                                                                    getActionTypeBadge(note.action_type)
                                                                )}
                                                            </TableCell>
                                                            <TableCell className="p-2">
                                                                {effectiveCanEdit ? (
                                                                    <Input
                                                                        type="date"
                                                                        value={note.date && !isNaN(new Date(note.date)) ? new Date(note.date).toISOString().split('T')[0] : ''}
                                                                        onChange={(e) => {
                                                                            const originalTime = (note.date && !isNaN(new Date(note.date))) ? new Date(note.date).toISOString().split('T')[1] : '12:00:00.000Z';
                                                                            if (e.target.value) {
                                                                                const newDate = new Date(`${e.target.value}T${originalTime}`);
                                                                                handleEditNote(index, 'date', newDate.toISOString());
                                                                            } else {
                                                                                handleEditNote(index, 'date', '');
                                                                            }
                                                                        }}
                                                                        className="text-sm h-9"
                                                                    />
                                                                ) : (
                                                                    <span className="text-sm">
                                                                        {note.date && !isNaN(new Date(note.date)) ? format(new Date(note.date), 'PPP') : 'No date'}
                                                                    </span>
                                                                )}
                                                            </TableCell>
                                                            <TableCell className="p-2">
                                                                {effectiveCanEdit ? (
                                                                    <Input
                                                                        type="date"
                                                                        value={note.event_date || ''}
                                                                        onChange={(e) => handleEditNote(index, 'event_date', e.target.value)}
                                                                        className="text-sm h-9"
                                                                    />
                                                                ) : (
                                                                    <span className="text-sm">
                                                                        {note.event_date ? format(new Date(note.event_date + 'T00:00:00'), 'PPP') : 'No date'}
                                                                    </span>
                                                                )}
                                                            </TableCell>
                                                            <TableCell className="p-2">
                                                                {effectiveCanEdit ? (
                                                                    <Input
                                                                        value={note.by_who || ''}
                                                                        onChange={(e) => handleEditNote(index, 'by_who', e.target.value)}
                                                                        placeholder="Person name..."
                                                                        className="text-sm h-9"
                                                                    />
                                                                ) : (
                                                                    <span className="text-sm">{note.by_who || 'Unknown'}</span>
                                                                )}
                                                            </TableCell>
                                                            <TableCell className="p-2">
                                                                <div className="flex items-center gap-2">
                                                                    {note.image_uri ? ( // Prefer new private URI
                                                                        <div className="flex items-center gap-2">
                                                                            <PrivateImage // Using PrivateImage component
                                                                                uri={note.image_uri} // Pass image_uri
                                                                                alt="Evidence"
                                                                                className="w-8 h-8 object-cover rounded border cursor-pointer hover:scale-110 transition-transform"
                                                                                onPreview={handleImagePreview} // Pass handleImagePreview directly
                                                                            />
                                                                            {effectiveCanEdit && (
                                                                                <Button
                                                                                    variant="ghost"
                                                                                    size="sm"
                                                                                    onClick={() => handleRemoveImage(index)}
                                                                                    className="text-red-500 hover:text-red-700 h-6 w-6 p-0"
                                                                                    title="Remove image"
                                                                                >
                                                                                    <X className="w-3 h-3" />
                                                                                </Button>
                                                                            )}
                                                                        </div>
                                                                    ) : note.image_url ? ( // Fallback to old public URL
                                                                        <div className="flex items-center gap-2">
                                                                            <img
                                                                                src={note.image_url}
                                                                                alt="Old Evidence"
                                                                                className="w-8 h-8 object-cover rounded border cursor-pointer hover:scale-110 transition-transform"
                                                                                onClick={() => handleImagePreview(note.image_url)}
                                                                            />
                                                                            {effectiveCanEdit && (
                                                                                <Button
                                                                                    variant="ghost"
                                                                                    size="sm"
                                                                                    onClick={() => handleRemoveImage(index)}
                                                                                    className="text-red-500 hover:text-red-700 h-6 w-6 p-0"
                                                                                    title="Remove image"
                                                                                >
                                                                                    <X className="w-3 h-3" />
                                                                                </Button>
                                                                            )}
                                                                        </div>
                                                                    ) : effectiveCanEdit ? (
                                                                        <div className="flex items-center gap-1">
                                                                            <input
                                                                                type="file"
                                                                                accept="image/*"
                                                                                onChange={(e) => {
                                                                                    const file = e.target.files[0];
                                                                                    if (file) {
                                                                                        console.log('File selected:', file.name, file.type, file.size);
                                                                                        handleImageUpload(index, file);
                                                                                    }
                                                                                    e.target.value = '';
                                                                                }}
                                                                                className="hidden"
                                                                                id={`image-upload-${index}`}
                                                                            />
                                                                            <Button
                                                                                variant="ghost"
                                                                                size="sm"
                                                                                onClick={() => {
                                                                                    const input = document.getElementById(`image-upload-${index}`);
                                                                                    if (input) input.click();
                                                                                }}
                                                                                disabled={uploadingImages.has(`note-${index}`)}
                                                                                className="h-6 w-6 p-0 text-slate-500 hover:text-slate-700"
                                                                                title="Upload image"
                                                                            >
                                                                                {uploadingImages.has(`note-${index}`) ? (
                                                                                    <Loader2 className="w-3 h-3 animate-spin" />
                                                                                ) : (
                                                                                    <Upload className="w-3 h-3" />
                                                                                )}
                                                                            </Button>
                                                                        </div>
                                                                    ) : (
                                                                        <span className="text-xs text-slate-400">No image</span>
                                                                    )}
                                                                </div>
                                                            </TableCell>
                                                            <TableCell className="p-2 text-center">
                                                                <Badge variant="outline" className="text-xs">{note.sourceLabel}</Badge>
                                                            </TableCell>
                                                            {effectiveCanEdit && (
                                                                <TableCell className="p-2">
                                                                    <Button
                                                                        variant="ghost"
                                                                        size="sm"
                                                                        onClick={() => handleDeleteAction(index)}
                                                                        className="text-red-500 hover:text-red-700 hover:bg-red-50 h-8 w-8 p-0"
                                                                    >
                                                                        <Trash2 className="w-4 h-4" />
                                                                    </Button>
                                                                </TableCell>
                                                            )}
                                                        </TableRow>
                                                    ))
                                                ) : (
                                                    <TableRow>
                                                        <TableCell colSpan={effectiveCanEdit ? 8 : 7} className="p-8 text-center">
                                                            <FileText className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                                                            <p className="text-slate-600 font-medium">
                                                                {isAddingViolation ? 'Add the first action below' : 'No actions logged for this driver yet'}
                                                            </p>
                                                            {effectiveCanEdit && !isAddingViolation && <p className="text-slate-500 text-sm mt-1">Add the first action below</p>}
                                                        </TableCell>
                                                    </TableRow>
                                                )}
                                            </TableBody>
                                        </Table>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                        {effectiveCanEdit && (
                            <>
                                {!isAddingViolation && <Separator />}

                                <div className="flex-shrink-0">
                                    <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                                        <PlusCircle className="w-5 h-5 text-green-600" />
                                        {isAddingViolation ? 'Create New Violation' : 'Add New Action'}
                                    </h3>

                                    <Card className="bg-gradient-to-r from-green-50 to-blue-50 border border-green-200">
                                        <CardContent className="p-4">
                                            <div className={`grid gap-4 mb-4 ${isAddingViolation ? 'grid-cols-1 md:grid-cols-3 lg:grid-cols-3' : 'grid-cols-1 md:grid-cols-5'}`}>
                                                {isAddingViolation && (
                                                    <div>
                                                        <label className="text-sm font-medium text-slate-700 mb-2 block">Driver *</label>
                                                        <Select value={selectedDriverId} onValueChange={setSelectedDriverId}>
                                                            <SelectTrigger className="bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500">
                                                                <SelectValue placeholder="Select driver" />
                                                            </SelectTrigger>
                                                            <SelectContent>
                                                                {drivers.map(driver => (
                                                                    <SelectItem key={driver.colleague_id} value={driver.colleague_id}>
                                                                        {driver.name}
                                                                    </SelectItem>
                                                                ))}
                                                            </SelectContent>
                                                        </Select>
                                                    </div>
                                                )}
                                                <div>
                                                    <label className="text-sm font-medium text-slate-700 mb-2 block">Violation *</label>
                                                    <Select value={newViolation} onValueChange={setNewViolation}>
                                                        <SelectTrigger className="bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500">
                                                            <SelectValue placeholder="Select violation" />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            {violationTypes.map(type => (
                                                                <SelectItem key={type.value} value={type.value}>
                                                                    {type.label}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                </div>
                                                <div>
                                                    <label className="text-sm font-medium text-slate-700 mb-2 block">Action Taken *</label>
                                                    <Select value={newActionType} onValueChange={setNewActionType}>
                                                        <SelectTrigger className="bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500">
                                                            <SelectValue placeholder="Select action type" />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            {actionTypes.map(type => (
                                                                <SelectItem key={type.value} value={type.value}>
                                                                    {type.label}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                </div>
                                                <div>
                                                    <label className="text-sm font-medium text-slate-700 mb-2 block">Action Date *</label>
                                                    <Input
                                                        type="date"
                                                        value={newActionDate}
                                                        onChange={(e) => setNewActionDate(e.target.value)}
                                                        className="bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500"
                                                        readOnly
                                                    />
                                                </div>
                                                <div>
                                                    <label className="text-sm font-medium text-slate-700 mb-2 block">Violation Date *</label>
                                                    <Input
                                                        type="date"
                                                        value={newEventDate}
                                                        onChange={(e) => setNewEventDate(e.target.value)}
                                                        className="bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500"
                                                    />
                                                </div>
                                                {!isAddingViolation && (
                                                    <div>
                                                        <label className="text-sm font-medium text-slate-700 mb-2 block">By Who *</label>
                                                        <Input
                                                            value={newActionByWho}
                                                            onChange={(e) => setNewActionByWho(e.target.value)}
                                                            placeholder="Person name..."
                                                            className="bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500"
                                                        />
                                                    </div>
                                                )}
                                            </div>

                                            <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                                                <div className="flex items-center gap-3">
                                                    <input
                                                        type="checkbox"
                                                        id="autoIncrement"
                                                        checked={autoIncrementValue}
                                                        onChange={(e) => setAutoIncrementValue(e.target.checked)}
                                                        className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
                                                    />
                                                    <label htmlFor="autoIncrement" className="text-sm font-medium text-slate-700">
                                                        Auto-increment violation count
                                                    </label>
                                                </div>
                                                <p className="text-xs text-slate-600 mt-1 ml-7">
                                                    When enabled, this will automatically add +1 to the violation count for the appropriate week on the performance matrix
                                                </p>
                                            </div>

                                            <div className="flex justify-end">
                                                <Button
                                                    onClick={handleAddAction}
                                                    disabled={
                                                        isAddingViolation ?
                                                            (!selectedDriverId || !newViolation || !newActionType || !newActionDate || !newEventDate) :
                                                            (!newViolation || !newActionType || !newActionDate || !newEventDate || !newActionByWho.trim())
                                                    }
                                                    className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-medium"
                                                >
                                                    <PlusCircle className="w-4 h-4 mr-2" />
                                                    {isAddingViolation ? 'Create Violation' : 'Add to Log'}
                                                </Button>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </div>
                            </>
                        )}
                    </div>

                    <DialogFooter className="flex-shrink-0 pt-6 border-t border-slate-200">
                        <Button variant="outline" onClick={onClose} className="font-medium">
                            Close
                        </Button>
                        {effectiveCanEdit && (
                            <Button
                                onClick={handleSaveAndClose}
                                disabled={isSaving}
                                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium"
                            >
                                {isSaving ? (
                                    <>
                                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                                        Saving...
                                    </>
                                ) : (
                                    isAddingViolation ? 'Save New Violation & Close' : 'Save All & Close'
                                )}
                            </Button>
                        )}
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <ImagePreviewModal
                isOpen={isImagePreviewOpen}
                onClose={() => setIsImagePreviewOpen(false)}
                imageUrl={previewImageUrl}
            />
        </>
    );
}
