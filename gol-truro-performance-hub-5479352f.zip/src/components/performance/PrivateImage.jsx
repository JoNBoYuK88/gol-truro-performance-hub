import React, { useState, useEffect, useCallback } from 'react';
import { CreateFileSignedUrl } from '@/api/integrations';
import { Loader2, ImageOff, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

// Global request queue and cache to prevent rate limiting
const requestQueue = [];
let isProcessingQueue = false;
const urlCache = new Map();
const CACHE_DURATION = 4 * 60 * 1000; // 4 minutes (signed URLs last 5 minutes)
const MAX_RETRIES = 2;
const BASE_DELAY = 300; // Base delay between requests

const processQueue = async () => {
    if (isProcessingQueue || requestQueue.length === 0) return;
    
    isProcessingQueue = true;
    
    while (requestQueue.length > 0) {
        const { uri, resolve, reject, retryCount = 0 } = requestQueue.shift();
        
        try {
            // Check cache first
            const cached = urlCache.get(uri);
            if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
                resolve(cached.url);
                await new Promise(res => setTimeout(res, 50)); // Small delay between cached responses
                continue;
            }
            
            // Fetch new signed URL with timeout
            const timeoutPromise = new Promise((_, timeoutReject) => {
                setTimeout(() => timeoutReject(new Error('Request timeout')), 10000); // 10 second timeout
            });
            
            const fetchPromise = CreateFileSignedUrl({ file_uri: uri });
            
            const { signed_url } = await Promise.race([fetchPromise, timeoutPromise]);
            
            // Cache the result
            urlCache.set(uri, {
                url: signed_url,
                timestamp: Date.now()
            });
            
            resolve(signed_url);
            
            // Wait between requests to avoid rate limiting
            await new Promise(res => setTimeout(res, BASE_DELAY));
            
        } catch (error) {
            // Retry logic for network errors
            if (retryCount < MAX_RETRIES && (error.message?.includes('Network Error') || error.message?.includes('timeout'))) {
                console.log(`Retrying ${uri} (attempt ${retryCount + 1}/${MAX_RETRIES})`);
                // Re-queue with incremented retry count and exponential backoff
                const backoffDelay = BASE_DELAY * Math.pow(2, retryCount);
                await new Promise(res => setTimeout(res, backoffDelay));
                requestQueue.push({ uri, resolve, reject, retryCount: retryCount + 1 });
            } else {
                console.error(`Failed to get signed URL after ${retryCount} retries:`, error);
                reject(error);
            }
            
            // Wait longer after an error
            await new Promise(res => setTimeout(res, 1000));
        }
    }
    
    isProcessingQueue = false;
};

const queueRequest = (uri) => {
    return new Promise((resolve, reject) => {
        requestQueue.push({ uri, resolve, reject, retryCount: 0 });
        processQueue();
    });
};

export default function PrivateImage({ uri, alt, className, onPreview }) {
    const [signedUrl, setSignedUrl] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(false);

    const fetchSignedUrl = useCallback(async () => {
        if (!uri) {
            setError(true);
            setIsLoading(false);
            return;
        }
        
        setIsLoading(true);
        setError(false);

        try {
            const url = await queueRequest(uri);
            setSignedUrl(url);
            setError(false);
        } catch (err) {
            console.error(`Failed to get signed URL for ${uri}:`, err);
            setError(true);
            
            // Only show toast for non-rate-limit and non-network errors after retries
            if (!err.message?.includes('429') && !err.message?.includes('Network Error')) {
                toast.error("Could not load an image.");
            }
        } finally {
            setIsLoading(false);
        }
    }, [uri]);

    useEffect(() => {
        fetchSignedUrl();
    }, [fetchSignedUrl]);

    const handleImageError = (e) => {
        console.error('Image failed to load from signed URL:', signedUrl);
        setError(true);
        e.target.style.display = 'none';
    };

    const handleImageClick = () => {
        if (onPreview && signedUrl && !error) {
            onPreview(signedUrl);
        }
    };

    if (isLoading) {
        return (
            <div className={`${className} flex items-center justify-center bg-slate-100 rounded`}>
                <Loader2 className="w-4 h-4 animate-spin text-slate-400" />
            </div>
        );
    }

    if (error || !signedUrl) {
        return (
             <div className={`${className} flex flex-col items-center justify-center bg-red-50 rounded border-dashed border-red-200 p-1`}>
                <ImageOff className="w-4 h-4 text-red-400" />
                <button 
                    onClick={fetchSignedUrl}
                    className="flex items-center text-xs text-red-600 hover:underline mt-1"
                    title="Retry loading image"
                >
                    <RefreshCw className="w-3 h-3 mr-1"/>
                    Retry
                </button>
            </div>
        );
    }

    return (
        <img
            src={signedUrl}
            alt={alt}
            className={`${className} cursor-pointer`}
            onClick={handleImageClick}
            onError={handleImageError}
        />
    );
}