import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award, Trophy } from 'lucide-react';

export default function TopPerformersCard({ 
  title, 
  performers, 
  period, 
  week, 
  compact = false, 
  iconPosition = "left",
  isPeriodic = false
}) {
  const getRankingIcon = (index) => {
    switch (index) {
      case 0:
        return <Trophy className="w-6 h-6 text-yellow-500" />;
      case 1:
        return <Trophy className="w-6 h-6 text-gray-400" />;
      case 2:
        return <Trophy className="w-6 h-6 text-orange-600" />;
      default:
        return <Trophy className="w-6 h-6 text-indigo-400" />;
    }
  };
  
  const cardPadding = compact ? 'p-3' : 'p-4';
  const headerPadding = compact ? 'pb-2' : 'pb-4';
  const listPadding = compact ? 'p-2' : 'p-3';
  const listSpacing = compact ? 'space-y-2' : 'space-y-3';
  const listTopPadding = compact ? 'pt-1' : 'pt-2';

  return (
    <Card className="metric-card">
      <CardHeader className={`flex flex-row items-center justify-between space-y-0 ${cardPadding} ${headerPadding}`}>
        <div>
          <CardTitle className="text-sm font-medium text-slate-600">{title}</CardTitle>
          {period && week && (
            <p className="text-xs text-slate-500 mt-1">Period {period}, Week {week}</p>
          )}
          {period && !week && isPeriodic && (
            <p className="text-xs text-slate-500 mt-1">Period {period} Average</p>
          )}
        </div>
        <div className="w-10 h-10 bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl flex items-center justify-center">
          <Award className="w-5 h-5 text-amber-600" />
        </div>
      </CardHeader>
      <CardContent className={`${cardPadding} pt-0`}>
        {performers && performers.length > 0 ? (
          <ul className={`${listSpacing} ${listTopPadding}`}>
            {performers.map((p, index) => (
              <li key={p.id || p.colleague_id} className={`flex items-center gap-3 bg-slate-50/50 rounded-lg ${listPadding} ${
                iconPosition === 'right' ? 'flex-row-reverse' : 'flex-row'
              }`}>
                <div className="flex-shrink-0 w-8 flex items-center justify-center">
                  {getRankingIcon(index)}
                </div>
                <div className={`flex items-center justify-between gap-3 flex-1 ${
                  iconPosition === 'right' ? 'flex-row-reverse' : 'flex-row'
                }`}>
                  <div className={`truncate ${iconPosition === 'right' ? 'text-right' : 'text-left'}`}>
                    <span className="font-medium truncate text-sm block">{p.name}</span>
                    <span className="text-xs text-slate-500">
                      {isPeriodic 
                        ? `${p.total_picked_items?.toLocaleString()} items` 
                        : `${p.picked_items?.toLocaleString()} items`
                      }
                    </span>
                  </div>
                  <Badge variant="secondary" className="bg-gradient-to-r from-blue-50 to-indigo-50 text-blue-700 font-bold border-0">
                    {isPeriodic 
                      ? p.avg_iph?.toFixed(2) 
                      : p.iph?.toFixed(2)
                    }
                  </Badge>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <div className="text-center py-8">
            <p className="text-sm text-slate-500">No data available for this period{week ? '/week' : ''}.</p>
            <p className="text-xs text-slate-400 mt-1">
              Minimum {isPeriodic ? '4000' : '1000'} items required to qualify
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}