import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Target } from 'lucide-react';

export default function AchievementRatioCard({ title, achievers, total, compact = false, className = "" }) {
    const percentage = total > 0 ? (achievers / total) * 100 : 0;
    const getColor = () => {
        if (percentage >= 80) return "text-emerald-700";
        if (percentage >= 60) return "text-amber-600";
        return "text-red-600";
    }

    const getBgColor = () => {
        if (percentage >= 80) return "from-emerald-50 to-green-50";
        if (percentage >= 60) return "from-amber-50 to-orange-50";
        return "from-red-50 to-pink-50";
    }
    
    const cardPadding = compact ? 'p-3' : 'p-4';
    const headerPadding = compact ? 'pb-2' : 'pb-4';
    const contentTopPadding = compact ? 'pt-0' : 'pt-2';
    const achieversSize = compact ? 'text-4xl' : 'text-5xl';
    const totalSize = compact ? 'text-2xl' : 'text-3xl';

    // Calculate how many shoppers need to achieve target to reach 80%
    const requiredForGreen = Math.ceil(total * 0.8);
    const shoppersNeeded = Math.max(0, requiredForGreen - achievers);

    return (
        <Card className={`metric-card flex flex-col ${className}`}>
            <CardHeader className={`flex flex-row items-center justify-between space-y-0 ${cardPadding} ${headerPadding}`}>
                <CardTitle className="text-sm font-semibold text-slate-600">{title}</CardTitle>
                <div className={`w-10 h-10 bg-gradient-to-br ${getBgColor()} rounded-xl flex items-center justify-center`}>
                    <Users className="w-5 h-5 text-slate-700" />
                </div>
            </CardHeader>
            <CardContent className={`${cardPadding} ${contentTopPadding} flex-grow flex flex-col justify-center`}>
                <div className="flex items-baseline gap-3">
                    <span className={`${achieversSize} font-bold ${getColor()} tracking-tight`}>{achievers}</span>
                    <span className={`${totalSize} font-medium text-slate-400`}>/ {total}</span>
                </div>
                <div className="mt-4 p-3 bg-slate-50/50 rounded-lg space-y-2">
                    <p className="text-sm text-slate-600">
                        <span className={`font-semibold ${getColor()}`}>{percentage.toFixed(2)}%</span> achieving targets
                    </p>
                    {percentage < 80 && shoppersNeeded > 0 && (
                        <div className="flex items-center gap-2 text-xs text-amber-800">
                           <Target className="w-3.5 h-3.5"/>
                           <span>
                                Need <span className="font-bold">{shoppersNeeded}</span> more shopper{shoppersNeeded > 1 ? 's' : ''} to reach 80%
                           </span>
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}