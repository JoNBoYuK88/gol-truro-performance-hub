import React from 'react';

export const TECHNICAL_SPECIFICATIONS = {
  dataModels: {
    KPIMetric: {
      primaryKey: "id",
      requiredFields: ["name", "category", "value", "date"],
      relationships: {
        period: "1-13 financial periods",
        week: "1-4 weeks within period", 
        year: "Financial year",
        quarter: "1-4 quarters (calculated from period)"
      },
      businessRules: {
        aggregation: "Weekly data rolls up to period/quarter/YTD",
        thresholds: "RAG status based on green/amber/red thresholds",
        specialCases: {
          opsScore: "Custom rounding in quarter/YTD view",
          secondaryReplenishment: "Lower values are better (inverted)"
        }
      }
    }
  },

  calculations: {
    variance: {
      formula: "((current - previous) / previous) * 100",
      displayRules: "Show +/- with trend arrows",
      edgeCases: "Handle division by zero, show infinity symbol"
    },
    
    opsScoreRounding: {
      when: "Quarter or YTD view only",
      sequence: [44, 52, 60, 68, 76, 84, 92, 100],
      method: "Find nearest value in sequence",
      code: `
        const roundOpsScore = (value) => {
          const sequence = [44, 52, 60, 68, 76, 84, 92, 100];
          return sequence.reduce((prev, curr) => {
            return Math.abs(curr - value) < Math.abs(prev - value) ? curr : prev;
          });
        };
      `
    },

    shopperAchievement: {
      formula: "(shoppers_achieving_target / total_shoppers) * 100",
      minimumSampleSize: 1,
      roundingRules: "2 decimal places for display"
    },

    aggregations: {
      period: "Average of weeks 1-4 within the period",
      quarter: "Average of periods within quarter (Q1:P1-4, Q2:P5-7, Q3:P8-10, Q4:P11-13)",
      ytd: "Average of all weekly data in financial year",
      overrides: "Manually saved aggregate values take precedence over calculated averages"
    }
  },

  userInterface: {
    editMode: {
      trigger: "Admin users only",
      validation: "Numeric inputs with step controls",
      confirmation: "Show all changes before saving",
      bulkOperations: "Clear data, bulk target setting"
    },
    
    statusColors: {
      green: "#22c55e",
      amber: "#f59e0b", 
      red: "#ef4444",
      application: "Card backgrounds, text colors, trend indicators"
    },

    responsiveBreakpoints: {
      mobile: "< 768px - Stack cards, horizontal scroll tables",
      tablet: "768px - 1024px - Responsive grid layout",
      desktop: "> 1024px - Full grid layout"
    },

    mobileOptimizations: {
      touchTargets: "Minimum 44px for iOS accessibility",
      fontSizes: "16px minimum to prevent zoom",
      scrolling: "Horizontal scroll for wide tables",
      gestures: "Pull-to-refresh, swipe navigation"
    }
  },

  authentication: {
    levels: {
      viewer: "Read-only access to all data",
      admin: "Full edit permissions, can clear data"
    },
    implementation: "Base44 platform handles auth, check user.role",
    apiIntegration: "Bearer token in Authorization header"
  },

  performance: {
    dataLoading: {
      strategy: "Load 2000 records max, filter client-side",
      caching: "Cache period configs and thresholds",
      debouncing: "300ms delay on rapid filter changes"
    },
    
    offlineStrategy: {
      essential: "Cache latest period data for offline viewing",
      storage: "Core Data (iOS) or SQLite (cross-platform)",
      sync: "Background sync when connection restored"
    }
  },

  developmentPhases: {
    phase1: {
      title: "Core KPI Dashboard",
      features: [
        "Weekly KPI cards with RAG status",
        "Basic edit mode for admin users", 
        "Period/week/year navigation",
        "Data export functionality"
      ],
      estimatedTime: "4-6 weeks"
    },

    phase2: {
      title: "Extended Analytics",
      features: [
        "Ops Readiness and Sales Summary",
        "Comparison mode (year-over-year)",
        "Shopper performance tracking",
        "Customer complaints module"
      ],
      estimatedTime: "6-8 weeks"
    },

    phase3: {
      title: "Advanced Features",
      features: [
        "Regional performance comparisons",
        "Damage tracking with visual markers",
        "Driver performance matrix",
        "WORM review system"
      ],
      estimatedTime: "8-10 weeks"
    }
  }
};

export default function TechnicalSpecs() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Technical Implementation Guide</h2>
      <pre className="bg-gray-100 p-4 rounded text-sm overflow-x-auto whitespace-pre-wrap">
        {JSON.stringify(TECHNICAL_SPECIFICATIONS, null, 2)}
      </pre>
    </div>
  );
}