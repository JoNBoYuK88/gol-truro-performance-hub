
import React, { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Medal, Award, ChevronDown, ChevronRight } from 'lucide-react';

const RANKING_METRICS = ['shoppers_achieved_percentage', 'otdep_percentage', 'dwc_percentage'];

const getRankIcon = (rank) => {
    switch (rank) {
        case 1: return <Trophy className="w-4 h-4 text-yellow-500" />;
        case 2: return <Medal className="w-4 h-4 text-gray-400" />;
        case 3: return <Award className="w-4 h-4 text-orange-600" />;
        default: return <span className="w-4 h-4 flex items-center justify-center text-xs font-bold text-slate-500">#{rank}</span>;
    }
};

const getRankColorClass = (rank, total) => {
    if (total <= 1) return 'bg-emerald-50 border-emerald-200 text-emerald-700';

    const percentile = (rank - 1) / (total - 1);
    if (percentile <= 0.25) return 'bg-emerald-50 border-emerald-200 text-emerald-700';
    if (percentile <= 0.5) return 'bg-green-50 border-green-200 text-green-700';
    if (percentile <= 0.75) return 'bg-amber-50 border-amber-200 text-amber-700';
    return 'bg-red-50 border-red-200 text-red-700';
};

export default function StoreRankings({ data, viewType, year }) {
    const [isCollapsed, setIsCollapsed] = useState(true); // Collapsed by default

    const rankings = useMemo(() => {
        if (!data || data.length === 0) return [];

        // Separate Newton Abbot from other stores
        const newtonAbbotId = 882;
        const newtonAbbot = data.find(store => store.store_id === newtonAbbotId);
        const otherStores = data.filter(store => store.store_id !== newtonAbbotId);

        // Calculate simple average scores for non-Newton Abbot stores
        const storeScores = otherStores.map(store => {
            let totalScore = 0;
            let availableMetrics = [];

            RANKING_METRICS.forEach(metric => {
                const value = store[metric];
                if (value !== null && value !== undefined && value !== 0) { // Assuming 0 is a valid score if it means 0% achieved
                    totalScore += value;
                    availableMetrics.push(metric);
                }
            });

            // If no metrics available, averageScore is 0, so it will rank last or not at all depending on other 0 scores.
            const averageScore = availableMetrics.length > 0 ? totalScore / availableMetrics.length : 0;

            return {
                ...store,
                averageScore: averageScore,
                availableMetrics: availableMetrics,
            };
        });

        // Sort by average score (descending) as primary sort, not by store order
        const sortedStores = storeScores.sort((a, b) => {
            return b.averageScore - a.averageScore; // Sort by performance score first (highest to lowest)
        });

        const rankedStores = sortedStores.map((store, index) => ({
            ...store,
            overallRank: index + 1
        }));

        // Add Newton Abbot back at the bottom with excluded status
        const finalResults = [...rankedStores];
        if (newtonAbbot) {
            finalResults.push({
                ...newtonAbbot,
                overallRank: null, // No ranking for Newton Abbot
                averageScore: null, // Explicitly set to null
                availableMetrics: [] // Empty array for Newton Abbot
            });
        }

        return finalResults;
    }, [data]);

    const getYearDisplay = (viewType, year) => {
        switch (viewType) {
            case 'Last Year':
                return `${year - 1}/${String(year).slice(-2)}`;
            case 'Mid Year':
            case 'YTD':
                return `${year}/${String(year + 1).slice(-2)}`;
            default:
                return year;
        }
    };

    if (!data || data.length === 0 || rankings.length === 0) {
        return (
            <Card className="glass-card">
                <CardHeader>
                    <CardTitle className="text-lg font-semibold">Store Rankings</CardTitle>
                </CardHeader>
                <CardContent className="text-center py-8">
                    <p className="text-slate-500">No data available for rankings</p>
                </CardContent>
            </Card>
        );
    }

    // Determine the total number of ranked stores for color class calculation (excluding Newton Abbot)
    const totalRankedStores = rankings.filter(r => r.store_id !== 882).length;

    return (
        <Card className="glass-card">
            <CardHeader className="p-4 pb-2">
                <div className="flex items-center gap-2">
                    <button
                        onClick={() => setIsCollapsed(!isCollapsed)}
                        className="p-1 hover:bg-gray-100 rounded transition-colors"
                    >
                        {isCollapsed ? (
                            <ChevronRight className="w-4 h-4 text-gray-500" />
                        ) : (
                            <ChevronDown className="w-4 h-4 text-gray-500" />
                        )}
                    </button>
                    <CardTitle className="text-base font-semibold">Complete Store Rankings - {viewType} {getYearDisplay(viewType, year)}</CardTitle>
                </div>
                {!isCollapsed && (
                    <p className="text-xs text-slate-500 mt-1 ml-6">
                        Rankings calculated using available metrics. Missing data is compensated by redistributing weights fairly.
                    </p>
                )}
            </CardHeader>
            {!isCollapsed && (
                <CardContent className="p-4 pt-2">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                        {rankings.map(store => (
                            <div key={store.store_id} className={`p-2 rounded-lg border ${store.store_id === 882 ? 'bg-gray-50 border-gray-200 text-gray-500' : getRankColorClass(store.overallRank, totalRankedStores)}`}>
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        {store.store_id === 882 ? 
                                            <span className="w-5 h-5 flex items-center justify-center text-xs font-bold text-gray-400">—</span> :
                                            getRankIcon(store.overallRank)
                                        }
                                        <div>
                                            <p className="font-medium text-sm">{store.store_name}</p>
                                            <p className="text-xs text-slate-500">Store {store.store_id}</p>
                                        </div>
                                    </div>
                                    <div className="text-right shrink-0">
                                        {store.store_id === 882 ? (
                                            <div>
                                                <Badge variant="secondary" className="font-bold text-gray-500 bg-gray-200">
                                                    N/A
                                                </Badge>
                                                <p className="text-[10px] text-gray-400 mt-1 leading-tight">
                                                    Excluded from ranking
                                                </p>
                                            </div>
                                        ) : (
                                            <div>
                                                <Badge variant="secondary" className="font-bold">
                                                    {store.averageScore.toFixed(1)}
                                                </Badge>
                                                <p className="text-[10px] text-slate-400 mt-1 leading-tight">
                                                    {store.availableMetrics.length}/3 metrics
                                                </p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            )}
        </Card>
    );
}
