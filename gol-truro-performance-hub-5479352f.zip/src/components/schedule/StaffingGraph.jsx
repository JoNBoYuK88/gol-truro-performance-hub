import React, { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Users } from 'lucide-react';

export default function StaffingGraph({ scheduleData, viewMode }) {
  // Get list of days from scheduleData
  const availableDays = useMemo(() => {
    const days = new Set();
    Object.keys(scheduleData).forEach(key => {
      const [dayIndex] = key.split('-');
      days.add(dayIndex);
    });
    return Array.from(days).sort((a, b) => parseInt(a) - parseInt(b));
  }, [scheduleData]);

  const [selectedDay, setSelectedDay] = useState(availableDays[0] || '0');

  const hourlyStaffing = useMemo(() => {
    const hours = Array.from({ length: 24 }, (_, i) => ({
      hour: `${i.toString().padStart(2, '0')}:00`,
      count: 0
    }));

    // Filter schedule data for selected day only
    Object.keys(scheduleData).forEach(key => {
      const [dayIndex, shift] = key.split('-');
      if (dayIndex === selectedDay) {
        scheduleData[key].forEach(employee => {
          const shiftTime = employee.shift;
          const match = shiftTime.match(/(\d{2}):(\d{2})-(\d{2}):(\d{2})/);
          
          if (match) {
            const startHour = parseInt(match[1]);
            const endHour = parseInt(match[3]);
            
            for (let h = startHour; h < endHour; h++) {
              hours[h].count++;
            }
          }
        });
      }
    });

    return hours.filter(h => h.count > 0 || (parseInt(h.hour) >= 6 && parseInt(h.hour) <= 23));
  }, [scheduleData, selectedDay]);

  const maxStaffing = Math.max(...hourlyStaffing.map(h => Math.round(h.count)), 0);

  const dayNames = viewMode === 'week' 
    ? ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    : availableDays.map((_, i) => {
        const weekNum = Math.floor(i / 7) + 1;
        const dayInWeek = i % 7;
        const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][dayInWeek];
        return `W${weekNum} ${dayName}`;
      });

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            Staffing Levels by Hour
          </CardTitle>
          <Select value={selectedDay} onValueChange={setSelectedDay}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {availableDays.map((day, idx) => (
                <SelectItem key={day} value={day}>
                  {dayNames[idx] || `Day ${parseInt(day) + 1}`}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={hourlyStaffing}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="hour" />
            <YAxis label={{ value: 'Number of Staff', angle: -90, position: 'insideLeft' }} allowDecimals={false} />
            <Tooltip />
            <Legend />
            <Bar dataKey="count" fill="#3b82f6" name="Staff Count" label={{ position: 'inside', fill: 'white', fontSize: 12 }} />
          </BarChart>
        </ResponsiveContainer>
        <div className="mt-4 text-sm text-gray-600 text-center">
          Peak staffing: <span className="font-bold text-blue-600">{maxStaffing}</span> employees
        </div>
      </CardContent>
    </Card>
  );
}