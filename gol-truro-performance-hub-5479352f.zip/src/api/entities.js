import { base44 } from './base44Client';


export const KPIMetric = base44.entities.KPIMetric;

export const ShopperPerformance = base44.entities.ShopperPerformance;

export const CustomerComplaint = base44.entities.CustomerComplaint;

export const PeriodConfig = base44.entities.PeriodConfig;

export const Shopper = base44.entities.Shopper;

export const ShopperIPHTarget = base44.entities.ShopperIPHTarget;

export const Forecast = base44.entities.Forecast;

export const PerformanceMatrixData = base44.entities.PerformanceMatrixData;

export const Driver = base44.entities.Driver;

export const WormReview = base44.entities.WormReview;

export const DeliveryCostReportData = base44.entities.DeliveryCostReportData;

export const AppConfig = base44.entities.AppConfig;

export const DamageReport = base44.entities.DamageReport;

export const RegionalPerformance = base44.entities.RegionalPerformance;

export const IPHCalculationResult = base44.entities.IPHCalculationResult;

export const SurveyData = base44.entities.SurveyData;

export const ActionPlan = base44.entities.ActionPlan;

export const PeakPlanning = base44.entities.PeakPlanning;

export const ScheduleEmployee = base44.entities.ScheduleEmployee;

export const ScheduleAssignment = base44.entities.ScheduleAssignment;

export const ScheduleShiftTemplate = base44.entities.ScheduleShiftTemplate;

export const ScheduleDayVans = base44.entities.ScheduleDayVans;

export const WeekSchedule = base44.entities.WeekSchedule;

export const TrainingRecord = base44.entities.TrainingRecord;



// auth sdk:
export const User = base44.auth;