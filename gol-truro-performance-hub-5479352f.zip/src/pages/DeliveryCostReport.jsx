import React, { useState, useEffect, useCallback } from 'react';
import { DeliveryCostReportData } from '@/api/entities';
import { User } from '@/api/entities';
import { useEditLock } from '../Layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { PeriodConfig } from '@/api/entities';
import { toast } from 'sonner';
import { Loader2, Edit, Save, X, Plus, Trash2, ChevronRight, ChevronDown } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const costCategories = ['orders', 'damage', 'accidents', 'fines', 'equipment'];

const defaultCostData = costCategories.reduce((acc, cat) => {
    acc[cat] = { budget: 0, actual: 0 };
    return acc;
}, {});

// Utility function for delay
const delay = (ms) => new Promise(res => setTimeout(res, ms));

export default function DeliveryCostReport() {
    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
    const [currentPeriod, setCurrentPeriod] = useState(1);
    const [reportData, setReportData] = useState(defaultCostData);
    const [reviewAnswers, setReviewAnswers] = useState({});
    const [summaryActions, setSummaryActions] = useState([
        { action: '', assigned_manager: '' },
        { action: '', assigned_manager: '' },
        { action: '', assigned_manager: '' }
    ]);
    const [uploadingImages, setUploadingImages] = useState(new Set());
    const [isImagePreviewOpen, setIsImagePreviewOpen] = useState(false);
    const [previewImageUrl, setPreviewImageUrl] = useState('');
    const [damageBreakdown, setDamageBreakdown] = useState([]); // New state for damage breakdown
    const [accidentBreakdown, setAccidentBreakdown] = useState([]); // Corrected state for accident breakdown
    const [finesBreakdown, setFinesBreakdown] = useState([]); // New state for fines breakdown
    const [existingReport, setExistingReport] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [displayPeriod, setDisplayPeriod] = useState(null);
    const [viewMode, setViewMode] = useState('period');

    const { canEdit: unlockCanEdit } = useEditLock();
    const [isAdmin, setIsAdmin] = useState(false);
    const canEdit = isAdmin || unlockCanEdit;
    const [isEditing, setIsEditing] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [lastYearTotalAvoidableDamage, setLastYearTotalAvoidableDamage] = useState(null);
    const [lastYearTotalCostVariance, setLastYearTotalCostVariance] = useState(null); // New state for last year's total cost variance

    // New states for filtering and sorting
    const [selectedVanReg, setSelectedVanReg] = useState('all');
    const [selectedAvoidable, setSelectedAvoidable] = useState('all');
    const [sortOrder, setSortOrder] = useState('desc'); // 'asc' or 'desc' for total cost

    // State for confirmation dialog
    const [showConfirmDialog, setShowConfirmDialog] = useState(false);
    const [editedData, setEditedData] = useState(null); // To store data temporarily before confirmation

    const [expandedClaims, setExpandedClaims] = useState(new Set());

    const toggleClaimExpansion = (claimRef) => {
        const newExpanded = new Set(expandedClaims);
        if (newExpanded.has(claimRef)) {
            newExpanded.delete(claimRef);
        } else {
            newExpanded.add(claimRef);
        }
        setExpandedClaims(newExpanded);
    };

    // Function to process accident breakdown for display with grouping
    const getProcessedAccidentBreakdown = useCallback(() => {
        if (viewMode !== 'ytd') {
            return accidentBreakdown.map((item, originalIndex) => ({ ...item, originalIndex, isGroupHeader: false, isChildItem: false })); // Add originalIndex for consistency
        }

        // Group by claim reference
        const claimGroups = {};
        accidentBreakdown.forEach((item, originalIndex) => {
            const claimRef = item.claim_reference?.trim();
            if (claimRef && claimRef !== '') {
                if (!claimGroups[claimRef]) {
                    claimGroups[claimRef] = [];
                }
                claimGroups[claimRef].push({ ...item, originalIndex });
            } else {
                // Items without claim reference are treated individually
                // Use a unique key based on originalIndex to ensure no clashes
                claimGroups[`no_claim_${originalIndex}`] = [{ ...item, originalIndex }];
            }
        });

        // Process each group
        const processedItems = [];
        Object.keys(claimGroups).forEach(claimRef => {
            const group = claimGroups[claimRef];
            
            if (group.length === 1 || claimRef.startsWith('no_claim_')) { // Single item or no claim ref, show as normal
                processedItems.push({ ...group[0], isGroupHeader: false, isChildItem: false });
            } else {
                // Multiple items with same claim reference
                // Sort by period (descending) then by date_of_loss (descending)
                const sortedGroup = group.sort((a, b) => {
                    // Periods are numbers, can sort directly
                    const periodDiff = (b.period || 0) - (a.period || 0);
                    if (periodDiff !== 0) return periodDiff;

                    // If periods are same, sort by date_of_loss
                    const dateA = a.date_of_loss ? new Date(a.date_of_loss) : new Date(0);
                    const dateB = b.date_of_loss ? new Date(b.date_of_loss) : new Date(0);
                    return dateB.getTime() - dateA.getTime();
                });

                const hasClosedDate = sortedGroup.some(item => item.date_closed && item.date_closed.trim() !== '');
                
                if (hasClosedDate) {
                    // Show only the newest entry as header
                    const headerItem = { 
                        ...sortedGroup[0], 
                        isGroupHeader: true, 
                        isChildItem: false,
                        claimRef: claimRef 
                    };
                    processedItems.push(headerItem);
                    
                    // Add older entries if expanded
                    if (expandedClaims.has(claimRef)) {
                        sortedGroup.slice(1).forEach(item => {
                            processedItems.push({ 
                                ...item, 
                                isGroupHeader: false, 
                                isChildItem: true,
                                claimRef: claimRef 
                            });
                        });
                    }
                } else {
                    // No closed date, show all items normally
                    sortedGroup.forEach(item => {
                        processedItems.push({ ...item, isGroupHeader: false, isChildItem: false });
                    });
                }
            }
        });

        return processedItems;
    }, [accidentBreakdown, viewMode, expandedClaims]);


    // This effect resets filters when the main data view changes (year or mode)
    useEffect(() => {
        setSelectedVanReg('all');
        setSelectedAvoidable(viewMode === 'ytd' ? 'no' : 'all'); // Default to 'no' (Damage) for YTD
        setSortOrder('desc');
    }, [currentYear, viewMode]);

    useEffect(() => {
        const checkUserRole = async () => {
            try {
                const user = await User.me();
                setIsAdmin(user.role === 'admin');
            } catch (e) {
                setIsAdmin(false);
            }
        };
        checkUserRole();
    }, []);

    // This effect runs once on mount to set the initial period to the previous one.
    useEffect(() => {
        const initializeDefaultPeriod = async () => {
            try {
                const today = new Date();
                const currentYearValue = today.getFullYear();
                
                // Fetch period configs for the current year
                const periodsData = await PeriodConfig.filter({ year: currentYearValue });

                if (periodsData && periodsData.length > 0) {
                    // Find the period we are currently in
                    const currentPeriodConfig = periodsData.find(p => {
                        const startDate = new Date(p.start_date);
                        const endDate = new Date(p.end_date);
                        // Make sure to compare dates only, ignoring time
                        today.setHours(0, 0, 0, 0);
                        startDate.setHours(0, 0, 0, 0);
                        endDate.setHours(0, 0, 0, 0);
                        return today >= startDate && today <= endDate;
                    });

                    if (currentPeriodConfig) {
                        // If we are in Period 1, set to Period 13 of the previous year
                        if (currentPeriodConfig.period_number === 1) {
                            setCurrentYear(currentYearValue - 1);
                            setCurrentPeriod(13);
                        } else {
                            // Otherwise, set to the previous period of the current year
                            setCurrentYear(currentYearValue);
                            setCurrentPeriod(currentPeriodConfig.period_number - 1);
                        }
                    } else {
                        // Fallback if today is not in any defined period (e.g., year-end)
                        // Default to the latest available period in the config for the current year
                        const latestPeriod = [...periodsData].sort((a, b) => b.period_number - a.period_number)[0];
                        if (latestPeriod) {
                            setCurrentYear(currentYearValue); // Ensure we stay in current year if currentPeriodConfig is null
                            setCurrentPeriod(latestPeriod.period_number);
                        } else {
                            // If no periods found at all, default to P1 of current year
                            setCurrentYear(currentYearValue);
                            setCurrentPeriod(1);
                        }
                    }
                } else {
                    // If no periods data at all, default to P1 of current year
                    setCurrentYear(currentYearValue);
                    setCurrentPeriod(1);
                }
            } catch (error) {
                console.error("Failed to set default period:", error);
                // Fallback to P1 of current year on error
                setCurrentPeriod(1);
                setCurrentYear(new Date().getFullYear());
            }
        };

        initializeDefaultPeriod();
    }, []); // Empty dependency array ensures this runs only once on mount

    // Automatically calculate YTD accidents actual cost from breakdown
    useEffect(() => {
        if (viewMode === 'ytd') {
            const seenClaimRefs = new Set();
            const totalPAndL = accidentBreakdown.reduce((sum, accident) => {
                const claimRef = accident.claim_reference?.trim();
                // Process items with a claim reference only once
                if (claimRef && claimRef !== '') {
                    if (!seenClaimRefs.has(claimRef)) {
                        seenClaimRefs.add(claimRef);
                        return sum + (accident.p_and_l || 0);
                    }
                    return sum; // It's a duplicate, so don't add its P&L
                }
                // For items without a claim reference, sum them individually
                return sum + (accident.p_and_l || 0);
            }, 0);

            setReportData(prevData => {
                const newActual = Math.round((totalPAndL + Number.EPSILON) * 100) / 100;
                // Only update state if the value has changed to prevent infinite loops
                const currentActual = prevData.accidents?.actual || 0;
                
                if (currentActual !== newActual) {
                    return {
                        ...prevData,
                        accidents: {
                            budget: prevData.accidents?.budget || 0,
                            actual: newActual
                        }
                    };
                }
                return prevData;
            });
        }
    }, [accidentBreakdown, viewMode]);

    const loadReportData = useCallback(async () => {
        setIsLoading(true);
        setLastYearTotalAvoidableDamage(null);
        setLastYearTotalCostVariance(null); // Reset last year's total cost variance

        if (viewMode === 'ytd') {
            setDisplayPeriod(`YTD ${currentYear}`);
            try {
                // For YTD, always aggregate from period records, don't use specific YTD cost record
                const allRecords = await DeliveryCostReportData.filter({ year: currentYear });
                const periodRecords = allRecords.filter(r => r.period !== null && r.period >= 1 && r.period <= 13);

                // Find a specific YTD record (period: null) for review answers/summary actions if it exists
                const ytdSpecificRecord = allRecords.find(r => r.period === null);

                // ALWAYS aggregate cost data from periods to ensure it's the source of truth.
                const aggregatedCostData = JSON.parse(JSON.stringify(defaultCostData));
                if (periodRecords.length > 0) {
                    periodRecords.forEach(rec => {
                        costCategories.forEach(cat => {
                            if (rec.cost_data && rec.cost_data[cat]) {
                                aggregatedCostData[cat].budget += rec.cost_data[cat].budget || 0;
                                aggregatedCostData[cat].actual += rec.cost_data[cat].actual || 0;
                            }
                        });
                    });
                    costCategories.forEach(cat => {
                        if (aggregatedCostData[cat]) {
                            aggregatedCostData[cat].budget = Math.round((aggregatedCostData[cat].budget + Number.EPSILON) * 100) / 100;
                            aggregatedCostData[cat].actual = Math.round((aggregatedCostData[cat].actual + Number.EPSILON) * 100) / 100;
                        }
                    });
                }
                setReportData(aggregatedCostData);

                // Always aggregate breakdowns from all period records for the YTD view
                let allDamages = [];
                let allAccidents = [];
                let allFines = [];

                if (periodRecords.length > 0) {
                    periodRecords.forEach(rec => {
                        // When aggregating, ensure period is preserved for breakdown items
                        allDamages = allDamages.concat((rec.damage_breakdown || []).map(d => ({ ...d, period: rec.period })));
                        allAccidents = allAccidents.concat((rec.accident_breakdown || []).map(a => ({ ...a, period: rec.period })));
                        allFines = allFines.concat((rec.fines_breakdown || []).map(f => ({ ...f, period: rec.period })));
                    });
                    setDamageBreakdown(allDamages.map(d => ({ ...d, _tempId: Math.random() })));
                    setAccidentBreakdown(allAccidents);
                    setFinesBreakdown(allFines);
                } else {
                    // No period records found, so reset breakdowns
                    setDamageBreakdown([]);
                    setAccidentBreakdown([]);
                    setFinesBreakdown([]);
                }


                // Try to get review answers and summary actions from YTD-specific record if it exists
                setReviewAnswers(ytdSpecificRecord?.review_answers || {});
                setSummaryActions(ytdSpecificRecord?.summary_actions || [
                    { action: '', assigned_manager: '' },
                    { action: '', assigned_manager: '' },
                    { action: '', assigned_manager: '' }
                ]);
                setExistingReport(ytdSpecificRecord || null); // Set existing report if found for YTD-specific record

                // Fetch last year's YTD avoidable damage and total cost variance
                const lastYearRecords = await DeliveryCostReportData.filter({ year: currentYear - 1 });
                const lastYearPeriodRecords = lastYearRecords.filter(r => r.period !== null && r.period >= 1 && r.period <= 13);
                const lastYearYtdRecord = lastYearRecords.find(r => r.period === null);

                let calculatedLastYearTotalCostVariance = 0;

                if (lastYearYtdRecord && lastYearYtdRecord.cost_data) {
                    // Prioritize using the saved YTD summary record from last year if it exists
                    ['damage', 'accidents'].forEach(cat => {
                        if (lastYearYtdRecord.cost_data[cat]) {
                            const budget = lastYearYtdRecord.cost_data[cat].budget || 0;
                            const actual = lastYearYtdRecord.cost_data[cat].actual || 0;
                            calculatedLastYearTotalCostVariance += (actual - budget);
                        }
                    });
                } else {
                    // Fallback to aggregating from individual period records if no YTD summary exists
                    lastYearPeriodRecords.forEach(rec => {
                        if (rec.cost_data) {
                            ['damage', 'accidents'].forEach(cat => {
                                if (rec.cost_data[cat]) {
                                    const budget = rec.cost_data[cat].budget || 0;
                                    const actual = rec.cost_data[cat].actual || 0;
                                    calculatedLastYearTotalCostVariance += (actual - budget);
                                }
                            });
                        }
                    });
                }

                setLastYearTotalCostVariance(calculatedLastYearTotalCostVariance);
                
                // Avoidable damage should still be aggregated from all damage breakdowns across periods
                let lastYearDamages = [];
                lastYearPeriodRecords.forEach(rec => {
                    lastYearDamages = lastYearDamages.concat(rec.damage_breakdown || []);
                });
                const totalLastYearAvoidable = lastYearDamages
                    .filter(item => item.avoidable === 'Yes')
                    .reduce((sum, item) => sum + (item.total_cost || 0), 0);
                setLastYearTotalAvoidableDamage(totalLastYearAvoidable);

            } catch (error) {
                toast.error(`Failed to load YTD report data.`);
                console.error('Error loading YTD cost report data:', error);
                setReportData(defaultCostData);
                setReviewAnswers({});
                setSummaryActions([
                    { action: '', assigned_manager: '' },
                    { action: '', assigned_manager: '' },
                    { action: '', assigned_manager: '' }
                ]);
                setDamageBreakdown([]);
                setAccidentBreakdown([]);
                setFinesBreakdown([]);
                setExistingReport(null);
                setLastYearTotalAvoidableDamage(0);
                setLastYearTotalCostVariance(0);
            } finally {
                setIsLoading(false);
            }
        } else { // Period View
            if (!currentPeriod) {
                setIsLoading(false);
                return;
            }

            const targetPeriod = currentPeriod; // Period is 1-indexed for display, no need to subtract 1
            setDisplayPeriod(targetPeriod);

            if (targetPeriod < 1) { // This check might be redundant if currentPeriod is always >= 1 due to select
                setReportData(defaultCostData);
                setReviewAnswers({});
                setSummaryActions([
                    { action: '', assigned_manager: '' },
                    { action: '', assigned_manager: '' },
                    { action: '', assigned_manager: '' }
                ]);
                setDamageBreakdown([]);
                setAccidentBreakdown([]);
                setFinesBreakdown([]);
                setExistingReport(null);
                setIsLoading(false);
                return;
            }

            try {
                const records = await DeliveryCostReportData.filter({
                    year: currentYear,
                    period: targetPeriod
                });

                if (records.length > 0) {
                    setReportData(records[0].cost_data || defaultCostData);
                    setReviewAnswers(records[0].review_answers || {});
                    setSummaryActions(records[0].summary_actions || []);
                    setDamageBreakdown((records[0].damage_breakdown || []).map(d => ({ ...d, _tempId: Math.random() })));
                    setAccidentBreakdown(records[0].accident_breakdown || []);
                    setFinesBreakdown(records[0].fines_breakdown || []);
                    setExistingReport(records[0]);
                } else {
                    setReportData(defaultCostData);
                    setReviewAnswers({});
                    setSummaryActions([
                        { action: '', assigned_manager: '' },
                        { action: '', assigned_manager: '' },
                        { action: '', assigned_manager: '' }
                    ]);
                    setDamageBreakdown([]);
                    setAccidentBreakdown([]);
                    setFinesBreakdown([]);
                    setExistingReport(null);
                }

                // Fetch last year's same period avoidable damage and cost variance
                const lastYearPeriodRecords = await DeliveryCostReportData.filter({ year: currentYear - 1, period: targetPeriod });
                if (lastYearPeriodRecords.length > 0) {
                    const lastYearRecord = lastYearPeriodRecords[0];
                    const lastYearDamages = lastYearRecord.damage_breakdown || [];
                    const totalLastYearAvoidable = lastYearDamages
                        .filter(item => item.avoidable === 'Yes')
                        .reduce((sum, item) => sum + (item.total_cost || 0), 0);
                    setLastYearTotalAvoidableDamage(totalLastYearAvoidable);

                    // Calculate last year's cost variance for same period
                    let lastYearCostVariance = 0;
                    if (lastYearRecord.cost_data) {
                        ['damage', 'accidents'].forEach(cat => {
                            if (lastYearRecord.cost_data[cat]) {
                                const budget = lastYearRecord.cost_data[cat].budget || 0;
                                const actual = lastYearRecord.cost_data[cat].actual || 0;
                                lastYearCostVariance += (actual - budget);
                            }
                        });
                    }
                    setLastYearTotalCostVariance(lastYearCostVariance);
                } else {
                    setLastYearTotalAvoidableDamage(0);
                    setLastYearTotalCostVariance(0);
                }

            } catch (error) {
                toast.error(`Failed to load report data for Period ${targetPeriod}.`);
                console.error('Error loading cost report data:', error);
                setReportData(defaultCostData);
                setReviewAnswers({});
                setSummaryActions([
                    { action: '', assigned_manager: '' },
                    { action: '', assigned_manager: '' },
                    { action: '', assigned_manager: '' }
                ]);
                setDamageBreakdown([]);
                setAccidentBreakdown([]);
                setFinesBreakdown([]);
                setExistingReport(null);
                setLastYearTotalAvoidableDamage(0);
                setLastYearTotalCostVariance(0);
            } finally {
                setIsLoading(false);
            }
        }
    }, [currentYear, currentPeriod, viewMode]);

    useEffect(() => {
        if (!isEditing) {
            loadReportData();
        }
    }, [loadReportData, isEditing]);

    const handleDataChange = (category, type, value) => {
        if (!isEditing) return;
        
        // Prevent editing budget in YTD view
        if (viewMode === 'ytd' && type === 'budget') return;
        // Prevent editing accidents actual in YTD view (auto-calculated)
        if (viewMode === 'ytd' && category === 'accidents' && type === 'actual') return;

        setReportData(prev => {
            const newData = JSON.parse(JSON.stringify(prev)); // Deep copy
            if (!newData[category]) {
                newData[category] = { budget: 0, actual: 0 };
            }
            newData[category] = {
                ...newData[category],
                [type]: parseFloat(value) || 0
            };
            return newData;
        });
    };

    const handleEditToggle = () => {
        if (!canEdit) {
            toast.error("You don't have permission to edit this report.");
            return;
        }
        if (isEditing) {
            handleSave(); // Now calls the new handleSave which may open dialog
        } else {
            setIsEditing(true);
        }
    };

    const handleCancelEdit = () => {
        setIsEditing(false);
        // Reload data to discard changes
        loadReportData();
        // Also reset confirmation dialog state
        setShowConfirmDialog(false);
        setEditedData(null);
    };
    
    // New handleSave function to trigger confirmation for YTD
    const handleSave = () => {
        if (!canEdit) {
            toast.error("You don't have permission to edit this report.");
            return;
        }
        // For YTD, warn user about sync across periods
        if (viewMode === 'ytd') {
            setEditedData({
                reportData,
                damageBreakdown,
                accidentBreakdown,
                finesBreakdown
            });
            setShowConfirmDialog(true);
        } else {
            // Direct save for period view
            handleConfirmSave();
        }
    };

    // The actual save logic, now called after confirmation for YTD or directly for period view
    const handleConfirmSave = async () => {
        if (!canEdit) {
            toast.error("You must be logged in as an administrator to save data.");
            return;
        }
        setIsSaving(true);
        
        try {
            if (viewMode === 'ytd') {
                // For YTD view, we need to handle both cost data and breakdown data differently
                
                // Handle cost data aggregation - this stays as YTD summary
                // Note: cost_data for YTD should NOT be used to update the YTD specific record
                // because the YTD cost_data is always calculated on the fly as sum of periods.
                // The YTD specific record is mainly for review answers and summary actions.
                const ytdSpecificRecordPayload = {
                    year: currentYear,
                    period: null,
                    // cost_data is NOT part of this payload as it's always aggregated from periods.
                    review_answers: reviewAnswers,
                    summary_actions: summaryActions
                };
                
                // Check if YTD specific record exists
                const existingYtdRecords = await DeliveryCostReportData.filter({ 
                    year: currentYear, 
                    period: null 
                });
                
                if (existingYtdRecords.length > 0) {
                    await DeliveryCostReportData.update(existingYtdRecords[0].id, ytdSpecificRecordPayload);
                } else {
                    await DeliveryCostReportData.create(ytdSpecificRecordPayload);
                }
                
                // Handle breakdown data - update individual period records
                const damageBreakdownWithoutTempId = damageBreakdown.map(({ _tempId, ...rest }) => rest);
                const accidentBreakdownData = accidentBreakdown;
                const finesBreakdownData = finesBreakdown;
                
                // Group breakdown items by period
                const damageByPeriod = {};
                const accidentsByPeriod = {};
                const finesByPeriod = {};
                
                damageBreakdownWithoutTempId.forEach(item => {
                    const period = item.period || 1; // Default to P1 if no period specified
                    if (!damageByPeriod[period]) damageByPeriod[period] = [];
                    damageByPeriod[period].push(item);
                });
                
                accidentBreakdownData.forEach(item => {
                    const period = item.period || 1;
                    if (!accidentsByPeriod[period]) accidentsByPeriod[period] = [];
                    accidentsByPeriod[period].push(item);
                });
                
                finesBreakdownData.forEach(item => {
                    const period = item.period || 1;
                    if (!finesByPeriod[period]) finesByPeriod[period] = [];
                    finesByPeriod[period].push(item);
                });
                
                // Also include all existing periods to ensure they are updated/cleared if no breakdown data for them
                const allPeriods = new Set();
                const allExistingPeriodRecords = await DeliveryCostReportData.filter({ year: currentYear });
                allExistingPeriodRecords.forEach(rec => {
                    if (rec.period !== null) { // Only consider period records, not the YTD summary
                        allPeriods.add(rec.period);
                    }
                });
                // Add periods from current breakdown data
                Object.keys(damageByPeriod).map(Number).forEach(p => allPeriods.add(p));
                Object.keys(accidentsByPeriod).map(Number).forEach(p => allPeriods.add(p));
                Object.keys(finesByPeriod).map(Number).forEach(p => allPeriods.add(p));


                for (const period of Array.from(allPeriods).sort((a,b)=>a-b)) { // Sort for consistent order
                    const existingPeriodRecords = await DeliveryCostReportData.filter({
                        year: currentYear,
                        period: period
                    });
                    
                    // For period records, use the existing cost_data to avoid overwriting it with YTD totals.
                    const preservedCostData = (existingPeriodRecords.length > 0 && existingPeriodRecords[0].cost_data) 
                        ? existingPeriodRecords[0].cost_data 
                        : defaultCostData;

                    const periodPayload = {
                        year: currentYear,
                        period: period,
                        cost_data: preservedCostData, // Use the preserved cost data
                        damage_breakdown: damageByPeriod[period] || [],
                        accident_breakdown: accidentsByPeriod[period] || [],
                        fines_breakdown: finesByPeriod[period] || []
                    };
                    
                    await delay(100); // Small delay between operations
                    
                    if (existingPeriodRecords.length > 0) {
                        await DeliveryCostReportData.update(existingPeriodRecords[0].id, periodPayload);
                    } else {
                        await DeliveryCostReportData.create(periodPayload);
                    }
                }
                
            } else {
                // Original logic for non-YTD views
                const targetPeriod = currentPeriod;
                if (targetPeriod < 1) {
                    toast.error("Cannot save a report for an invalid period.");
                    setIsSaving(false);
                    return;
                }
                
                const payload = {
                    year: currentYear,
                    period: targetPeriod,
                    cost_data: reportData,
                    damage_breakdown: damageBreakdown.map(({ _tempId, ...rest }) => rest),
                    accident_breakdown: accidentBreakdown,
                    fines_breakdown: finesBreakdown,
                };
                
                const savePromise = existingReport
                    ? DeliveryCostReportData.update(existingReport.id, payload)
                    : DeliveryCostReportData.create(payload);
                    
                await savePromise;
            }
            
            toast.success('Report saved successfully!');
            setIsEditing(false);
            await loadReportData(); // Reload data after save
            
        } catch (error) {
            console.error("Save failed", error);
            toast.error('Failed to save report.');
        } finally {
            setIsSaving(false);
            setShowConfirmDialog(false);
            setEditedData(null);
        }
    };

    const handleDamageRowChange = (id, field, value) => {
        if (!isEditing) return;
        
        setDamageBreakdown(prev => prev.map(item => 
            item._tempId === id ? { ...item, [field]: value } : item
        ));
    };

    const handleAccidentRowChange = (originalIndex, field, value) => {
        if (!isEditing) return;
        
        const updatedBreakdown = [...accidentBreakdown];
        updatedBreakdown[originalIndex] = { ...updatedBreakdown[originalIndex], [field]: value };
        setAccidentBreakdown(updatedBreakdown);
    };

    const handleFinesRowChange = (index, field, value) => {
        if (!isEditing) return;
        
        const updatedBreakdown = [...finesBreakdown];
        updatedBreakdown[index] = { ...updatedBreakdown[index], [field]: value };
        setFinesBreakdown(updatedBreakdown);
    };

    const handleAddAccidentRow = () => {
        if (!isEditing) return;
        setAccidentBreakdown([...accidentBreakdown, {
            claim_reference: '',
            van_reg: '',
            date_of_loss: new Date().toISOString().split('T')[0],
            date_closed: '',
            claim_cause: '',
            sims_incident_number: null,
            sopp_and_sopp: null,
            down_payment: 0,
            part_final_settlement: 0,
            p_and_l: 0,
            period: viewMode === 'ytd' ? null : currentPeriod // Default period for new YTD rows is null, otherwise currentPeriod
        }]);
    };

    const handleRemoveAccidentRow = (index) => {
        if (!isEditing) return;
        const updatedBreakdown = accidentBreakdown.filter((_, i) => i !== index);
        setAccidentBreakdown(updatedBreakdown);
    };

    const handleAddFinesRow = () => {
        if (!isEditing) return;
        setFinesBreakdown([...finesBreakdown, {
            pcn: '',
            van_reg: '',
            date_of_ticket: new Date().toISOString().split('T')[0],
            time_of_ticket: '',
            notification: '',
            cause: '',
            location: '',
            cost: 0,
            period: viewMode === 'ytd' ? null : currentPeriod // Default period for new YTD rows is null, otherwise currentPeriod
        }]);
    };

    const handleRemoveFinesRow = (index) => {
        if (!isEditing) return;
        const updatedBreakdown = finesBreakdown.filter((_, i) => i !== index);
        setFinesBreakdown(updatedBreakdown);
    };

    const handleAddDamageRow = () => {
        if (!isEditing) return;
        setDamageBreakdown([...damageBreakdown, {
            _tempId: Math.random(), // Add temporary ID for stable keys
            incident_date: new Date().toISOString().split('T')[0], // Default to current date
            incident_number: '',
            sims_incident_number: null,
            van_reg: '',
            defect_reported: '',
            recharge_text: '',
            total_cost: 0,
            avoidable: 'No',
            challenged: 'No', // Default to 'No'
            period: viewMode === 'ytd' ? null : currentPeriod // Default period for new YTD rows is null, otherwise currentPeriod
        }]);
    };

    const handleRemoveDamageRow = (id) => {
        if (!isEditing) return;
        const updatedBreakdown = damageBreakdown.filter(item => item._tempId !== id);
        setDamageBreakdown(updatedBreakdown);
    };

    // New functions for filtering and sorting
    const getUniqueVanRegs = () => {
        const vanRegs = [...new Set(damageBreakdown.map(item => item.van_reg).filter(reg => reg))];
        return vanRegs.sort();
    };

    const getFilteredAndSortedDamageBreakdown = () => {
        let filtered = damageBreakdown;

        // Filter by Van Reg
        if (selectedVanReg !== 'all') {
            filtered = filtered.filter(item => item.van_reg === selectedVanReg);
        }

        // Filter by Avoidable status
        if (selectedAvoidable !== 'all') {
            if (selectedAvoidable === 'yes') {
                filtered = filtered.filter(item => item.avoidable === 'Yes');
            } else if (selectedAvoidable === 'credit') {
                filtered = filtered.filter(item => item.avoidable === 'Credit');
            } else if (selectedAvoidable === 'no') {
                // For "Damage" filter, exclude "Parts Ordered Through Repair it Yourself"
                filtered = filtered.filter(item => 
                    item.avoidable === 'No' && 
                    !(item.defect_reported && item.defect_reported.toLowerCase().includes('parts ordered through repair it yourself'))
                );
            } else if (selectedAvoidable === 'defect') {
                filtered = filtered.filter(item => 
                    item.defect_reported && 
                    item.defect_reported.toLowerCase().includes('defect found at service')
                );
            } else if (selectedAvoidable === 'challenged') {
                filtered = filtered.filter(item => item.challenged === 'Yes');
            }
        }

        // Sort by total cost
        const sorted = [...filtered].sort((a, b) => {
            const costA = a.total_cost || 0;
            const costB = b.total_cost || 0;
            return sortOrder === 'desc' ? costB - costA : costA - b.total_cost;
        });

        return sorted;
    };

    const renderGrid = () => {
        if (isLoading) {
            return <div className="flex justify-center items-center h-48"><Loader2 className="w-8 h-8 animate-spin text-gray-500" /></div>;
        }

        const totalDamageAccidentBudget = (reportData.damage?.budget || 0) + (reportData.accidents?.budget || 0);
        const totalDamageAccidentActual = (reportData.damage?.actual || 0) + (reportData.accidents?.actual || 0);
        const totalDamageAccidentVariance = totalDamageAccidentActual - totalDamageAccidentBudget;

        const renderValue = (cat, type) => {
            const value = reportData[cat]?.[type];
            const formattedValue = (value ?? 0).toLocaleString(undefined, {
                style: cat === 'orders' ? 'decimal' : 'currency',
                currency: 'GBP',
                minimumFractionDigits: cat === 'orders' ? 0 : 2,
                maximumFractionDigits: cat === 'orders' ? 0 : 2,
            });

            if (isEditing) {
                const isDisabled = (viewMode === 'ytd' && cat === 'accidents' && type === 'actual') || (viewMode === 'ytd' && type === 'budget');
                return (
                    <div className="relative">
                        {cat !== 'orders' && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">£</span>}
                        <Input
                            type="number"
                            value={value ?? ''}
                            onChange={(e) => handleDataChange(cat, type, e.target.value)}
                            disabled={isSaving || isDisabled}
                            className={`h-8 text-center font-semibold text-lg bg-white/50 border-slate-300 focus:bg-white ${cat !== 'orders' ? 'pl-8' : ''} ${isDisabled ? 'bg-slate-100 cursor-not-allowed' : ''}`}
                        />
                    </div>
                );
            }
            return (
                <div className="h-8 flex items-center justify-center text-lg font-semibold text-slate-800">
                    {formattedValue}
                </div>
            );
        };

        const totalCostVariance = ['damage', 'accidents'].reduce((total, cat) => {
            const budget = reportData[cat]?.budget || 0;
            const actual = reportData[cat]?.actual || 0;
            return total + (actual - budget);
        }, 0);

        const totalAvoidableDamage = damageBreakdown
            .filter(item => item.avoidable === 'Yes')
            .reduce((sum, item) => sum + (item.total_cost || 0), 0);
        
        const avoidableDamageVariance = lastYearTotalAvoidableDamage !== null 
            ? totalAvoidableDamage - lastYearTotalAvoidableDamage
            : null;

        const costVarianceVariance = lastYearTotalCostVariance !== null
            ? totalCostVariance - lastYearTotalCostVariance
            : null;

        return (
            <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-7 gap-4">
                    {/* Column headers for larger screens */}
                    <div className="hidden md:block font-bold text-sm text-slate-700 self-end pb-2">Metric</div>
                    
                    {['orders', 'damage', 'accidents'].map(cat => (
                        <div key={cat} className="text-center font-bold text-sm capitalize text-slate-700 pb-2 border-b-2 border-slate-200/80">{cat}</div>
                    ))}
                    <div key="total" className="text-center font-bold text-sm capitalize text-slate-700 pb-2 border-b-2 border-blue-300">Total</div>
                    {['fines', 'equipment'].map(cat => (
                        <div key={cat} className="text-center font-bold text-sm capitalize text-slate-700 pb-2 border-b-2 border-slate-200/80">{cat}</div>
                    ))}
                
                    {/* Budget Row */}
                    <div className="font-bold text-sm text-slate-700 flex items-center md:justify-end pr-4">Budget</div>
                    {['orders', 'damage', 'accidents'].map(cat => (
                        <div key={`${cat}-budget`}>{renderValue(cat, 'budget')}</div>
                    ))}
                    <div className="h-8 flex items-center justify-center text-lg font-semibold text-slate-800">
                        {totalDamageAccidentBudget.toLocaleString(undefined, { style: 'currency', currency: 'GBP' })}
                    </div>
                    {['fines', 'equipment'].map(cat => (
                        <div key={`${cat}-budget`}>{renderValue(cat, 'budget')}</div>
                    ))}

                    {/* Actual Row */}
                    <div className="font-bold text-sm text-slate-700 flex items-center md:justify-end pr-4">Actual</div>
                    {['orders', 'damage', 'accidents'].map(cat => (
                        <div key={`${cat}-actual`}>{renderValue(cat, 'actual')}</div>
                    ))}
                    <div className="h-8 flex items-center justify-center text-lg font-semibold text-slate-800">
                        {totalDamageAccidentActual.toLocaleString(undefined, { style: 'currency', currency: 'GBP' })}
                    </div>
                    {['fines', 'equipment'].map(cat => (
                        <div key={`${cat}-actual`}>{renderValue(cat, 'actual')}</div>
                    ))}
                
                    {/* Variance Row */}
                    <div className="font-bold text-sm text-slate-700 flex items-center md:justify-end pr-4">Variance</div>
                    {['orders', 'damage', 'accidents'].map(cat => {
                        const budget = reportData[cat]?.budget || 0;
                        const actual = reportData[cat]?.actual || 0;
                        const variance = actual - budget;
                        const isCost = cat !== 'orders';
                        const isGood = isCost ? variance <= 0 : variance > 0; // Fixed: for orders, positive variance is good
                        const colorClass = variance === 0 ? 'bg-slate-100 text-slate-800' : isGood ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
                        const formattedVariance = (cat === 'orders' ? variance.toLocaleString() : variance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
                        const sign = variance > 0 ? '+' : '';

                        return (
                            <div key={`${cat}-variance`} className={`h-8 flex items-center justify-center text-sm font-bold rounded-lg ${colorClass}`}>
                                {cat !== 'orders' && `£`}{sign}{formattedVariance}
                            </div>
                        );
                    })}
                    {/* Total Variance Cell */}
                    {(() => {
                        const variance = totalDamageAccidentVariance;
                        const isGood = variance <= 0;
                        const colorClass = variance === 0 ? 'bg-slate-100 text-slate-800' : isGood ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
                        const formattedVariance = variance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                        const sign = variance > 0 ? '+' : '';

                        return (
                            <div key="total-variance" className={`h-8 flex items-center justify-center text-sm font-bold rounded-lg ${colorClass}`}>
                                £{sign}{formattedVariance}
                            </div>
                        );
                    })()}
                    {['fines', 'equipment'].map(cat => {
                        const budget = reportData[cat]?.budget || 0;
                        const actual = reportData[cat]?.actual || 0;
                        const variance = actual - budget;
                        const isCost = cat !== 'orders';
                        const isGood = isCost ? variance <= 0 : true; // All other costs, so <=0 is good.
                        const colorClass = variance === 0 ? 'bg-slate-100 text-slate-800' : isGood ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
                        const formattedVariance = variance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                        const sign = variance > 0 ? '+' : '';

                        return (
                            <div key={`${cat}-variance`} className={`h-8 flex items-center justify-center text-sm font-bold rounded-lg ${colorClass}`}>
                                £{sign}{formattedVariance}
                            </div>
                        );
                    })}
                </div>

                {/* Total Cost Variance & Avoidable Damage */}
                <div className="pt-4 mt-4 border-t border-slate-200/80 flex justify-between items-center flex-wrap gap-y-4">
                    <div className="flex items-center gap-3 flex-wrap">
                        <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-800">{viewMode === 'ytd' ? 'Avoidable Damage YTD' : 'Total Avoidable Damage'}</span>
                            <div className={`text-md font-bold py-1 px-2 rounded-md w-36 text-center shadow-md bg-orange-500 text-white`}>
                                £{totalAvoidableDamage.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </div>
                        </div>
                        {viewMode === 'ytd' && lastYearTotalAvoidableDamage !== null && (
                             <>
                                <div className="flex items-center gap-2">
                                    <span className="font-bold text-sm text-slate-800">vs LY</span>
                                    <div className={`text-md font-bold py-1 px-2 rounded-md w-36 text-center shadow-md bg-slate-400 text-white`}>
                                        £{lastYearTotalAvoidableDamage.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className="font-bold text-sm text-slate-800">Variance</span>
                                    <div className={`text-md font-bold py-1 px-2 rounded-md w-36 text-center shadow-md ${avoidableDamageVariance > 0 ? 'bg-red-500 text-white' : 'bg-green-500 text-white'}`}>
                                        £{avoidableDamageVariance > 0 ? '+' : ''}{avoidableDamageVariance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                    </div>
                                </div>
                             </>
                        )}
                    </div>
                    <div className="flex items-center gap-3 flex-wrap">
                        <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-800">{viewMode === 'ytd' ? 'Cost Variance vs Budget' : 'Total Cost Variance'}</span>
                            <div className={`text-md font-bold py-1 px-2 rounded-md w-36 text-center shadow-md ${totalCostVariance <= 0 ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
                                £{totalCostVariance > 0 ? '+' : ''}{totalCostVariance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </div>
                        </div>
                        {viewMode === 'ytd' && lastYearTotalCostVariance !== null && (
                             <>
                                <div className="flex items-center gap-2">
                                    <span className="font-bold text-sm text-slate-800">LY Variance</span>
                                    <div className={`text-md font-bold py-1 px-2 rounded-md w-36 text-center shadow-md ${lastYearTotalCostVariance <= 0 ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
                                        £{Math.abs(lastYearTotalCostVariance).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className="font-bold text-sm text-slate-800">Variance</span>
                                    <div className={`text-md font-bold py-1 px-2 rounded-md w-36 text-center shadow-md ${costVarianceVariance <= 0 ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
                                        £{costVarianceVariance > 0 ? '+' : ''}{costVarianceVariance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                    </div>
                                </div>
                             </>
                        )}
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="p-4 space-y-4 min-h-screen">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Delivery Cost Report</h1>
                </div>
                <div className="flex items-center gap-2">
                    {canEdit && (
                        <>
                            {isEditing && (
                                <Button variant="outline" size="sm" onClick={handleCancelEdit} disabled={isSaving}>
                                    <X className="w-4 h-4 mr-1" />
                                    Cancel
                                </Button>
                            )}
                            <Button size="sm" onClick={handleEditToggle} disabled={isSaving || isLoading} className="bg-blue-600 hover:bg-blue-700 text-white">
                                {isEditing ? <><Save className="w-4 h-4 mr-1"/>Save</> : <><Edit className="w-4 h-4 mr-1"/>Edit</>}
                            </Button>
                        </>
                    )}
                    <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))} disabled={isEditing}>
                        <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                        <SelectContent>{Array.from({ length: 3 }, (_, i) => new Date().getFullYear() - i).map(y => <SelectItem key={y} value={y.toString()}>{y}</SelectItem>)}</SelectContent>
                    </Select>
                    
                    <Tabs value={viewMode} onValueChange={setViewMode} className="w-auto">
                        <TabsList className="h-8">
                            <TabsTrigger value="period" className="text-xs px-2">Period</TabsTrigger>
                            <TabsTrigger value="ytd" className="text-xs px-2">YTD</TabsTrigger>
                        </TabsList>
                    </Tabs>

                    {viewMode === 'period' && (
                        <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))} disabled={isEditing}>
                            <SelectTrigger className="w-20"><SelectValue placeholder="P" /></SelectTrigger>
                            <SelectContent>{Array.from({ length: 13 }, (_, i) => i + 1).map(p => <SelectItem key={p} value={p.toString()}>P{p}</SelectItem>)}</SelectContent>
                        </Select>
                    )}
                </div>
            </div>

            <Card className="glass-card">
                <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Cost Report for {viewMode === 'ytd' ? `YTD ${currentYear}` : `Period ${displayPeriod > 0 ? displayPeriod : 'N/A'}`}</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                    {renderGrid()}
                </CardContent>
            </Card>

            <Card className="glass-card -mt-4 rounded-t-none">
                <CardHeader className="pb-3">
                    <div className="flex justify-between items-center">
                        <div>
                            <CardTitle className="text-lg">Damage Breakdown - {viewMode === 'ytd' ? `YTD ${currentYear}` : `P${displayPeriod > 0 ? displayPeriod : 'N/A'}`}</CardTitle>
                        </div>
                        <div className="flex items-center gap-2">
                            {viewMode === 'ytd' && (
                                <>
                                    <Select value={selectedVanReg} onValueChange={setSelectedVanReg} disabled={isLoading}>
                                        <SelectTrigger className="w-28 h-8">
                                            <SelectValue placeholder="Van" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">All Vans</SelectItem>
                                            {getUniqueVanRegs().map(reg => (
                                                <SelectItem key={reg} value={reg}>{reg}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    <Select value={selectedAvoidable} onValueChange={setSelectedAvoidable} disabled={isLoading}>
                                        <SelectTrigger className="w-40 h-8">
                                            <SelectValue placeholder="Avoidable & Credited" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">All Types</SelectItem>
                                            <SelectItem value="yes">Avoidable</SelectItem>
                                            <SelectItem value="no">Damage</SelectItem>
                                            <SelectItem value="credit">Credit</SelectItem>
                                            <SelectItem value="defect">Defect</SelectItem>
                                            <SelectItem value="challenged">Challenged</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </>
                            )}
                            {isEditing && (
                                <Button size="sm" onClick={handleAddDamageRow} disabled={isSaving} className="bg-green-600 hover:bg-green-700 text-white">
                                    <Plus className="w-4 h-4 mr-1" />
                                    Add
                                </Button>
                            )}
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="pt-0">
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow className="h-10">
                                    <TableHead className="w-20 text-xs">Date</TableHead>
                                    <TableHead className="w-28 text-xs">Incident #</TableHead>
                                    <TableHead className="w-16 text-xs">SIMS</TableHead>
                                    <TableHead className="w-24 text-xs">Van Reg</TableHead>
                                    {viewMode === 'ytd' && <TableHead className="w-16 text-xs">Period</TableHead>}
                                    <TableHead className="text-xs">Defect Reported</TableHead>
                                    <TableHead className="text-xs">Recharge Text</TableHead>
                                    <TableHead 
                                        className="w-24 cursor-pointer hover:bg-gray-50 text-xs" 
                                        onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
                                    >
                                        <div className="flex items-center gap-1">
                                            Cost
                                            <span className="text-xs text-gray-400">
                                                {sortOrder === 'desc' ? '↓' : '↑'}
                                            </span>
                                        </div>
                                    </TableHead>
                                    <TableHead className="w-20 text-xs">Type</TableHead>
                                    <TableHead className="w-16 text-xs">Challenge</TableHead>
                                    {isEditing && <TableHead className="w-12 text-center text-xs">Del</TableHead>}
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {isLoading ? (
                                    <TableRow>
                                        <TableCell colSpan={isEditing ? (viewMode === 'ytd' ? 11 : 10) : (viewMode === 'ytd' ? 10 : 9)} className="text-center py-6">
                                            <Loader2 className="w-5 h-5 animate-spin mx-auto text-gray-400" />
                                        </TableCell>
                                    </TableRow>
                                ) : getFilteredAndSortedDamageBreakdown().length > 0 ? (
                                    <>
                                        {getFilteredAndSortedDamageBreakdown().map((item) => (
                                            <TableRow key={item._tempId} className={`h-10 transition-colors ${item.avoidable === 'Yes' ? 'bg-red-100' : ''}`}>
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Input type="date" value={item.incident_date || ''} onChange={(e) => handleDamageRowChange(item._tempId, 'incident_date', e.target.value)} disabled={isSaving} className="h-7 text-xs"/>
                                                    ) : (
                                                        <span className="text-xs">
                                                        {item.incident_date ? 
                                                            new Date(item.incident_date + 'T00:00:00').toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: '2-digit' }) : '—'
                                                        }
                                                        </span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Input value={item.incident_number || ''} onChange={(e) => handleDamageRowChange(item._tempId, 'incident_number', e.target.value)} disabled={isSaving} className="h-7 text-xs"/>
                                                    ) : (
                                                        <span className="text-xs">{item.incident_number || '—'}</span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Input 
                                                            type="number" 
                                                            value={item.sims_incident_number ?? ''} 
                                                            onChange={(e) => handleDamageRowChange(item._tempId, 'sims_incident_number', e.target.value === '' ? null : parseFloat(e.target.value))} 
                                                            disabled={isSaving} 
                                                            className="h-7 text-xs"
                                                        />
                                                    ) : (
                                                        <span className="text-xs">{item.sims_incident_number ?? '—'}</span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top">
                                                     {isEditing ? (
                                                        <Input value={item.van_reg || ''} onChange={(e) => handleDamageRowChange(item._tempId, 'van_reg', e.target.value)} disabled={isSaving} className="h-7 text-xs"/>
                                                    ) : (
                                                        <span className="text-xs">{item.van_reg || '—'}</span>
                                                    )}
                                                </TableCell>
                                                {viewMode === 'ytd' && (
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Select onValueChange={(value) => handleDamageRowChange(item._tempId, 'period', parseInt(value))} value={item.period?.toString() || ''}>
                                                                <SelectTrigger className="h-7 w-14">
                                                                    <SelectValue placeholder="P" />
                                                                </SelectTrigger>
                                                                <SelectContent>
                                                                    {Array.from({ length: 13 }, (_, i) => i + 1).map(p => (
                                                                        <SelectItem key={p} value={p.toString()}>P{p}</SelectItem>
                                                                    ))}
                                                                </SelectContent>
                                                            </Select>
                                                        ) : (
                                                            <span className="text-xs font-medium">
                                                                {item.period ? `P${item.period}` : '—'}
                                                            </span>
                                                        )}
                                                    </TableCell>
                                                )}
                                                <TableCell className="py-1 align-top max-w-xs">
                                                    {isEditing ? (
                                                        <Textarea value={item.defect_reported || ''} onChange={(e) => handleDamageRowChange(item._tempId, 'defect_reported', e.target.value)} disabled={isSaving} className="min-h-[28px] text-xs"/>
                                                    ) : (
                                                        <div className="break-words whitespace-pre-wrap text-xs">{item.defect_reported || '—'}</div>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top max-w-xs">
                                                    {isEditing ? (
                                                        <Textarea value={item.recharge_text || ''} onChange={(e) => handleDamageRowChange(item._tempId, 'recharge_text', e.target.value)} disabled={isSaving} className="min-h-[28px] text-xs"/>
                                                    ) : (
                                                        <div className="break-words whitespace-pre-wrap text-xs">{item.recharge_text || '—'}</div>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Input type="number" value={item.total_cost ?? ''} onChange={(e) => handleDamageRowChange(item._tempId, 'total_cost', parseFloat(e.target.value))} disabled={isSaving} className="h-7 text-xs"/>
                                                    ) : (
                                                        <span className="text-xs">{item.total_cost ? `£${item.total_cost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}</span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Select onValueChange={(value) => handleDamageRowChange(item._tempId, 'avoidable', value)} value={item.avoidable || 'No'}>
                                                            <SelectTrigger className="h-7 w-20">
                                                                <SelectValue />
                                                            </SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="Yes">Yes</SelectItem>
                                                                <SelectItem value="No">No</SelectItem>
                                                                <SelectItem value="Credit">Credit</SelectItem>
                                                                <SelectItem value="Defect Found at Service">Defect</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                    ) : (
                                                        <span className={`px-1 py-0.5 rounded text-xs font-medium ${
                                                            item.avoidable === 'Yes' ? 'bg-red-100 text-red-800' : 
                                                            item.avoidable === 'Credit' ? 'bg-amber-100 text-amber-800' :
                                                            item.avoidable === 'Defect Found at Service' ? 'bg-blue-100 text-blue-800' :
                                                            'bg-green-100 text-green-800' 
                                                        }`}>
                                                            {item.avoidable === 'Defect Found at Service' ? 'Defect' : item.avoidable || 'No'}
                                                        </span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Select onValueChange={(value) => handleDamageRowChange(item._tempId, 'challenged', value)} value={item.challenged || 'No'}>
                                                            <SelectTrigger className="h-7 w-14">
                                                                <SelectValue />
                                                            </SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="Yes">Yes</SelectItem>
                                                                <SelectItem value="No">No</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                    ) : (
                                                         <span className={`px-1 py-0.5 rounded text-xs font-medium ${
                                                            item.challenged === 'Yes' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                                                        }`}>
                                                            {item.challenged || 'No'}
                                                        </span>
                                                    )}
                                                </TableCell>
                                                {isEditing && (
                                                    <TableCell className="text-center py-1 align-top">
                                                        <Button variant="ghost" size="icon" onClick={() => handleRemoveDamageRow(item._tempId)} disabled={isSaving} className="text-red-500 hover:text-red-700 h-7 w-7">
                                                            <Trash2 className="w-3 h-3" />
                                                        </Button>
                                                    </TableCell>
                                                )}
                                            </TableRow>
                                        ))}
                                        {/* Total Row */}
                                        <TableRow className="border-t-2 border-gray-300 bg-gray-50 font-semibold">
                                            <TableCell colSpan={viewMode === 'ytd' ? 7 : 6} className="text-right py-2 text-sm">
                                                Total:
                                            </TableCell>
                                            <TableCell className="py-2 text-sm font-bold">
                                                £{getFilteredAndSortedDamageBreakdown().reduce((sum, item) => sum + (item.total_cost || 0), 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                            </TableCell>
                                            <TableCell colSpan={isEditing ? 3 : 2}></TableCell>
                                        </TableRow>
                                    </>
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={isEditing ? (viewMode === 'ytd' ? 11 : 10) : (viewMode === 'ytd' ? 10 : 9)} className="text-center py-6 text-sm">
                                            {selectedVanReg !== 'all' || selectedAvoidable !== 'all' ? 
                                                'No damage records match the selected filters.' :
                                                (isEditing ? 'Click "Add" to add the first incident.' : 'No damage breakdown data for this period.')
                                            }
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            <Card className="glass-card -mt-4 rounded-t-none">
                <CardHeader className="pb-3">
                    <div className="flex justify-between items-center">
                        <div>
                            <CardTitle className="text-lg">Accident Report - {viewMode === 'ytd' ? `YTD ${currentYear}` : `P${displayPeriod > 0 ? displayPeriod : 'N/A'}`}</CardTitle>
                        </div>
                        {isEditing && (
                            <Button size="sm" onClick={handleAddAccidentRow} disabled={isSaving} className="bg-orange-600 hover:bg-orange-700 text-white">
                                <Plus className="w-4 h-4 mr-1" />
                                Add
                            </Button>
                        )}
                    </div>
                </CardHeader>
                <CardContent className="pt-0">
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow className="h-10">
                                    {viewMode === 'ytd' && <TableHead className="w-8 text-center"></TableHead>}
                                    <TableHead className="w-28 text-xs">Claim Ref</TableHead>
                                    <TableHead className="w-20 text-xs">Van Reg</TableHead>
                                    {viewMode === 'ytd' && <TableHead className="w-16 text-xs">Period</TableHead>}
                                    <TableHead className="w-24 text-xs">Loss Date</TableHead>
                                    <TableHead className="w-24 text-xs">Closed Date</TableHead>
                                    <TableHead className="text-xs">Claim Cause</TableHead>
                                    <TableHead className="w-20 text-xs">SIMS</TableHead>
                                    <TableHead className="w-20 text-xs">Sopp & Sopp</TableHead>
                                    <TableHead className="w-24 text-xs">Down Payment</TableHead>
                                    <TableHead className="w-24 text-xs">Settlement</TableHead>
                                    <TableHead className="w-20 text-xs">P&L</TableHead>
                                    {isEditing && <TableHead className="w-12 text-center text-xs">Del</TableHead>}
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {isLoading ? (
                                    <TableRow>
                                        <TableCell colSpan={isEditing ? (viewMode === 'ytd' ? 13 : 11) : (viewMode === 'ytd' ? 12 : 10)} className="text-center py-6">
                                            <Loader2 className="w-5 h-5 animate-spin mx-auto text-gray-400" />
                                        </TableCell>
                                    </TableRow>
                                ) : getProcessedAccidentBreakdown().length > 0 ? (
                                    <>
                                        {getProcessedAccidentBreakdown().map((item, displayIndex) => {
                                            let rowClass = '';

                                            // Simplified highlighting: if an item (or its group in YTD) has a closed date, highlight green.
                                            if (viewMode === 'ytd') {
                                                const claimRef = item.claim_reference?.trim();
                                                if (claimRef) {
                                                    const groupHasClosedDate = accidentBreakdown.some(acc => acc.claim_reference?.trim() === claimRef && acc.date_closed && acc.date_closed.trim());
                                                    if (groupHasClosedDate) {
                                                        rowClass = 'bg-green-100';
                                                    }
                                                } else if (item.date_closed && item.date_closed.trim()) {
                                                    rowClass = 'bg-green-100';
                                                }
                                            } else { // Period view logic
                                                if (item.date_closed && item.date_closed.trim()) {
                                                    rowClass = 'bg-green-100';
                                                }
                                            }


                                            // Additional styling for grouped items
                                            if (item.isChildItem) {
                                                rowClass += ' bg-slate-50 border-l-4 border-slate-300';
                                            }
                                            
                                            return (
                                                <TableRow key={`${item.claimRef || 'no_claim'}-${item.originalIndex}-${item.isChildItem ? 'child' : 'parent'}`} className={`${rowClass} h-10`}>
                                                    {viewMode === 'ytd' && (
                                                        <TableCell className="py-1 align-top text-center">
                                                            {item.isGroupHeader ? (
                                                                <button
                                                                    onClick={() => toggleClaimExpansion(item.claimRef)}
                                                                    className="text-slate-400 hover:text-slate-600 transition-colors p-1 rounded hover:bg-slate-100"
                                                                >
                                                                    {expandedClaims.has(item.claimRef) ? 
                                                                        <ChevronDown className="w-4 h-4" /> : 
                                                                        <ChevronRight className="w-4 h-4" />
                                                                    }
                                                                </button>
                                                            ) : null}
                                                        </TableCell>
                                                    )}
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Input 
                                                                value={item.claim_reference || ''} 
                                                                onChange={(e) => handleAccidentRowChange(item.originalIndex, 'claim_reference', e.target.value)} 
                                                                disabled={isSaving} 
                                                                className="h-7 text-xs" 
                                                            />
                                                        ) : (
                                                            <span className={`text-xs ${rowClass ? 'font-medium' : ''}`}>
                                                                {item.claim_reference || '—'}
                                                            </span>
                                                        )}
                                                    </TableCell>
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Input value={item.van_reg || ''} onChange={(e) => handleAccidentRowChange(item.originalIndex, 'van_reg', e.target.value)} disabled={isSaving} className="h-7 text-xs" />
                                                        ) : (
                                                        <span className="text-xs">{item.van_reg || '—'}</span>
                                                        )}
                                                    </TableCell>
                                                    {viewMode === 'ytd' && (
                                                        <TableCell className="py-1 align-top">
                                                            {isEditing ? (
                                                                <Select onValueChange={(value) => handleAccidentRowChange(item.originalIndex, 'period', parseInt(value))} value={item.period?.toString() || ''}>
                                                                    <SelectTrigger className="h-7 w-14">
                                                                        <SelectValue placeholder="P" />
                                                                    </SelectTrigger>
                                                                    <SelectContent>
                                                                        {Array.from({ length: 13 }, (_, i) => i + 1).map(p => (
                                                                            <SelectItem key={p} value={p.toString()}>P{p}</SelectItem>
                                                                        ))}
                                                                    </SelectContent>
                                                                </Select>
                                                            ) : (
                                                                <span className="text-xs font-medium">
                                                                    {item.period ? `P${item.period}` : '—'}
                                                                </span>
                                                            )}
                                                        </TableCell>
                                                    )}
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Input type="date" value={item.date_of_loss || ''} onChange={(e) => handleAccidentRowChange(item.originalIndex, 'date_of_loss', e.target.value)} disabled={isSaving} className="h-7 text-xs"/>
                                                        ) : (
                                                            <span className="text-xs">
                                                            {item.date_of_loss ? 
                                                                new Date(item.date_of_loss + 'T00:00:00').toLocaleDateString('en-GB', {
                                                                    day: '2-digit',
                                                                    month: '2-digit',
                                                                    year: '2-digit'
                                                                }) : '—'
                                                            }
                                                            </span>
                                                        )}
                                                    </TableCell>
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Input type="date" value={item.date_closed || ''} onChange={(e) => handleAccidentRowChange(item.originalIndex, 'date_closed', e.target.value)} disabled={isSaving} className="h-7 text-xs"/>
                                                        ) : (
                                                            <span className="text-xs">
                                                            {item.date_closed ? 
                                                                new Date(item.date_closed + 'T00:00:00').toLocaleDateString('en-GB', {
                                                                    day: '2-digit',
                                                                    month: '2-digit',
                                                                    year: '2-digit'
                                                                }) : '—'
                                                            }
                                                            </span>
                                                        )}
                                                    </TableCell>
                                                    <TableCell className="py-1 align-top max-w-xs">
                                                        {isEditing ? (
                                                            <Textarea value={item.claim_cause || ''} onChange={(e) => handleAccidentRowChange(item.originalIndex, 'claim_cause', e.target.value)} disabled={isSaving} className="min-h-[28px] text-xs" />
                                                        ) : (
                                                            <div className="break-words whitespace-pre-wrap text-xs">{item.claim_cause || '—'}</div>
                                                        )}
                                                    </TableCell>
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Input 
                                                                type="number" 
                                                                value={item.sims_incident_number ?? ''} 
                                                                onChange={(e) => handleAccidentRowChange(item.originalIndex, 'sims_incident_number', e.target.value === '' ? null : parseFloat(e.target.value))} 
                                                                disabled={isSaving} 
                                                                className="h-7 text-xs"
                                                            />
                                                        ) : (
                                                            <span className="text-xs">{item.sims_incident_number === 0 ? 'N/A' : (item.sims_incident_number ?? 'N/A')}</span>
                                                        )}
                                                    </TableCell>
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Input 
                                                                type="number" 
                                                                value={item.sopp_and_sopp ?? ''} 
                                                                onChange={(e) => handleAccidentRowChange(item.originalIndex, 'sopp_and_sopp', e.target.value === '' ? null : parseFloat(e.target.value))} 
                                                                disabled={isSaving} 
                                                                className="h-7 text-xs"
                                                            />
                                                        ) : (
                                                            <span className="text-xs">{item.sopp_and_sopp === 0 ? 'N/A' : (item.sopp_and_sopp ?? 'N/A')}</span>
                                                        )}
                                                    </TableCell>
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Input type="number" value={item.down_payment ?? ''} onChange={(e) => handleAccidentRowChange(item.originalIndex, 'down_payment', parseFloat(e.target.value))} disabled={isSaving} className="h-7 text-xs"/>
                                                        ) : (
                                                            <span className="text-xs">{item.down_payment ? `£${item.down_payment.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}</span>
                                                        )}
                                                    </TableCell>
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Input type="number" value={item.part_final_settlement ?? ''} onChange={(e) => handleAccidentRowChange(item.originalIndex, 'part_final_settlement', parseFloat(e.target.value))} disabled={isSaving} className="h-7 text-xs"/>
                                                        ) : (
                                                            <span className="text-xs">{item.part_final_settlement ? `£${item.part_final_settlement.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}</span>
                                                        )}
                                                    </TableCell>
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Input type="number" value={item.p_and_l ?? ''} onChange={(e) => handleAccidentRowChange(item.originalIndex, 'p_and_l', parseFloat(e.target.value))} disabled={isSaving} className="h-7 text-xs"/>
                                                        ) : (
                                                            <span className="text-xs">{item.p_and_l ? `£${item.p_and_l.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}</span>
                                                        )}
                                                    </TableCell>
                                                    {isEditing && (
                                                        <TableCell className="text-center py-1 align-top">
                                                            <Button variant="ghost" size="icon" onClick={() => handleRemoveAccidentRow(item.originalIndex)} disabled={isSaving} className="text-red-500 hover:text-red-700 h-7 w-7">
                                                                <Trash2 className="w-3 h-3" />
                                                            </Button>
                                                        </TableCell>
                                                    )}
                                                </TableRow>
                                            );
                                        })}
                                        {/* Total Row for Accident Report */}
                                        <TableRow className="border-t-2 border-gray-300 bg-gray-50 font-semibold">
                                            <TableCell colSpan={viewMode === 'ytd' ? (isEditing ? 12 : 11) : (isEditing ? 10 : 9)} className="text-right py-2 text-sm">
                                                Total:
                                            </TableCell>
                                            <TableCell className="py-2 text-sm font-bold">
                                                £{accidentBreakdown.reduce((sum, item) => sum + (item.p_and_l || 0), 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                            </TableCell>
                                            {isEditing && <TableCell></TableCell>}
                                        </TableRow>
                                    </>
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={isEditing ? (viewMode === 'ytd' ? 13 : 11) : (viewMode === 'ytd' ? 12 : 10)} className="text-center py-6 text-sm">
                                            {isEditing ? 'Click "Add" to add the first incident.' : 'No accident breakdown data for this period.'}
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            <Card className="glass-card -mt-4 rounded-t-none">
                <CardHeader className="pb-3">
                    <div className="flex justify-between items-center">
                        <div>
                            <CardTitle className="text-lg">Fines Report - {viewMode === 'ytd' ? `YTD ${currentYear}` : `P${displayPeriod > 0 ? displayPeriod : 'N/A'}`}</CardTitle>
                        </div>
                        {isEditing && (
                            <Button size="sm" onClick={handleAddFinesRow} disabled={isSaving} className="bg-red-600 hover:bg-red-700 text-white">
                                <Plus className="w-4 h-4 mr-1" />
                                Add
                            </Button>
                        )}
                    </div>
                </CardHeader>
                <CardContent className="pt-0">
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow className="h-10">
                                    <TableHead className="text-xs">PCN</TableHead>
                                    <TableHead className="text-xs">Van Reg</TableHead>
                                    {viewMode === 'ytd' && <TableHead className="w-16 text-xs">Period</TableHead>}
                                    <TableHead className="text-xs">Ticket Date</TableHead>
                                    <TableHead className="text-xs">Time</TableHead>
                                    <TableHead className="text-xs">Notification</TableHead>
                                    <TableHead className="text-xs">Cause</TableHead>
                                    <TableHead className="text-xs">Location</TableHead>
                                    <TableHead className="text-xs">Cost</TableHead>
                                    {isEditing && <TableHead className="w-12 text-center text-xs">Del</TableHead>}
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {isLoading ? (
                                    <TableRow>
                                        <TableCell colSpan={isEditing ? (viewMode === 'ytd' ? 10 : 9) : (viewMode === 'ytd' ? 9 : 8)} className="text-center py-6">
                                            <Loader2 className="w-5 h-5 animate-spin mx-auto text-gray-400" />
                                        </TableCell>
                                    </TableRow>
                                ) : finesBreakdown.length > 0 ? (
                                    <>
                                        {finesBreakdown.map((item, index) => (
                                            <TableRow key={index} className="h-10">
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Input value={item.pcn || ''} onChange={(e) => handleFinesRowChange(index, 'pcn', e.target.value)} disabled={isSaving} className="h-7 text-xs" />
                                                    ) : (
                                                        <span className="text-xs">{item.pcn || '—'}</span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Input value={item.van_reg || ''} onChange={(e) => handleFinesRowChange(index, 'van_reg', e.target.value)} disabled={isSaving} className="h-7 text-xs" />
                                                    ) : (
                                                        <span className="text-xs">{item.van_reg || '—'}</span>
                                                    )}
                                                </TableCell>
                                                {viewMode === 'ytd' && (
                                                    <TableCell className="py-1 align-top">
                                                        {isEditing ? (
                                                            <Select onValueChange={(value) => handleFinesRowChange(index, 'period', parseInt(value))} value={item.period?.toString() || ''}>
                                                                <SelectTrigger className="h-7 w-14">
                                                                    <SelectValue placeholder="P" />
                                                                </SelectTrigger>
                                                                <SelectContent>
                                                                    {Array.from({ length: 13 }, (_, i) => i + 1).map(p => (
                                                                        <SelectItem key={p} value={p.toString()}>P{p}</SelectItem>
                                                                    ))}
                                                                </SelectContent>
                                                            </Select>
                                                        ) : (
                                                            <span className="text-xs font-medium">
                                                                {item.period ? `P${item.period}` : '—'}
                                                                </span>
                                                        )}
                                                    </TableCell>
                                                )}
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Input type="date" value={item.date_of_ticket || ''} onChange={(e) => handleFinesRowChange(index, 'date_of_ticket', e.target.value)} disabled={isSaving} className="h-7 text-xs"/>
                                                    ) : (
                                                        <span className="text-xs">
                                                        {item.date_of_ticket ? 
                                                            new Date(item.date_of_ticket + 'T00:00:00').toLocaleDateString('en-GB', {
                                                                day: '2-digit',
                                                                month: '2-digit',
                                                                year: '2-digit'
                                                            }) : '—'
                                                        }
                                                        </span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Input type="time" value={item.time_of_ticket || ''} onChange={(e) => handleFinesRowChange(index, 'time_of_ticket', e.target.value)} disabled={isSaving} className="h-7 text-xs"/>
                                                    ) : (
                                                        <span className="text-xs">{item.time_of_ticket || '—'}</span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Input value={item.notification || ''} onChange={(e) => handleFinesRowChange(index, 'notification', e.target.value)} disabled={isSaving} className="h-7 text-xs" />
                                                    ) : (
                                                        <span className="text-xs">{item.notification || '—'}</span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top max-w-xs">
                                                    {isEditing ? (
                                                        <Textarea value={item.cause || ''} onChange={(e) => handleFinesRowChange(index, 'cause', e.target.value)} disabled={isSaving} className="min-h-[28px] text-xs" />
                                                    ) : (
                                                        <div className="break-words whitespace-pre-wrap text-xs">{item.cause || '—'}</div>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top max-w-xs">
                                                    {isEditing ? (
                                                        <Textarea value={item.location || ''} onChange={(e) => handleFinesRowChange(index, 'location', e.target.value)} disabled={isSaving} className="min-h-[28px] text-xs" />
                                                    ) : (
                                                        <div className="break-words whitespace-pre-wrap text-xs">{item.location || '—'}</div>
                                                    )}
                                                </TableCell>
                                                <TableCell className="py-1 align-top">
                                                    {isEditing ? (
                                                        <Input type="number" value={item.cost ?? ''} onChange={(e) => handleFinesRowChange(index, 'cost', parseFloat(e.target.value) || 0)} disabled={isSaving} className="h-7 text-xs"/>
                                                    ) : (
                                                        <span className="text-xs">{item.cost ? `£${item.cost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}</span>
                                                    )}
                                                </TableCell>
                                                {isEditing && (
                                                    <TableCell className="text-center py-1 align-top">
                                                        <Button variant="ghost" size="icon" onClick={() => handleRemoveFinesRow(index)} disabled={isSaving} className="text-red-500 hover:text-red-700 h-7 w-7">
                                                            <Trash2 className="w-3 h-3" />
                                                        </Button>
                                                    </TableCell>
                                                )}
                                            </TableRow>
                                        ))}
                                        {/* Total Row for Fines Report */}
                                        <TableRow className="border-t-2 border-gray-300 bg-gray-50 font-semibold">
                                            <TableCell colSpan={viewMode === 'ytd' ? (isEditing ? 9 : 8) : (isEditing ? 8 : 7)} className="text-right py-2 text-sm">
                                                Total:
                                            </TableCell>
                                            <TableCell className="py-2 text-sm font-bold">
                                                £{finesBreakdown.reduce((sum, item) => sum + (item.cost || 0), 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                            </TableCell>
                                            {isEditing && <TableCell></TableCell>}
                                        </TableRow>
                                    </>
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={isEditing ? (viewMode === 'ytd' ? 10 : 9) : (viewMode === 'ytd' ? 9 : 8)} className="text-center py-6 text-sm">
                                            {isEditing ? 'Click "Add" to add the first incident.' : 'No fines data for this period.'}
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            {/* Confirmation Dialog for YTD Save */}
            <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Confirm YTD Report Save</AlertDialogTitle>
                        <AlertDialogDescription>
                            You are currently viewing and editing the Year-to-Date (YTD) report.
                            Saving in YTD mode will update the overall YTD summary and also
                            distribute/sync the breakdown data (Damages, Accidents, Fines) to their
                            respective period records.
                            <br /><br />
                            The aggregated cost data you see will be saved as the YTD summary, AND
                            the *individual cost data for each period will be preserved*.
                            Breakdown data (Damages, Accidents, Fines) will be updated/synced across relevant periods.
                            <br /><br />
                            Do you wish to proceed with saving?
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel onClick={() => { setShowConfirmDialog(false); setEditedData(null); }}>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleConfirmSave}>Confirm Save</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}