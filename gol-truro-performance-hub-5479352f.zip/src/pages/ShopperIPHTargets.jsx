import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { ShopperIPHTarget } from '@/api/entities';
import { PeriodConfig } from '@/api/entities';
import { useEditLock } from '../Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Target, Save, Edit, X } from 'lucide-react';
import { toast } from 'sonner';

export default function ShopperIPHTargets() {
  const [periodData, setPeriodData] = useState([]);
  const [year, setYear] = useState(new Date().getFullYear());
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState([]);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);

  useEffect(() => {
    const checkUserRole = async () => {
        try {
            const currentUser = await User.me();
            setIsAdmin(currentUser && currentUser.role === 'admin');
        } catch (error) {
            console.error('Failed to fetch user role:', error);
            setIsAdmin(false);
        }
    };
    checkUserRole();
    loadData();
  }, [year]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [targetsData, periodsData] = await Promise.all([
        ShopperIPHTarget.filter({ year: year }, 'period'),
        PeriodConfig.filter({ year: year }, 'period_number')
      ]);
      
      const mergedData = Array.from({ length: 13 }, (_, i) => {
        const period = i + 1;
        
        // For Period 11, load week-specific targets
        if (period === 11) {
          const weeklyTargets = [];
          for (let week = 1; week <= 4; week++) {
            const target = targetsData.find(t => t.period === period && t.week === week);
            weeklyTargets.push({
              period: period,
              week: week,
              year: year,
              iph_target: target?.iph_target ?? 85,
              green_threshold: target?.green_threshold ?? 80,
              iph_target_id: target?.id,
            });
          }
          return weeklyTargets;
        }
        
        // For all other periods, single target
        const target = targetsData.find(t => t.period === period && !t.week);
        const periodConfig = periodsData.find(p => p.period_number === period);

        return {
          period: period,
          year: year,
          iph_target: target?.iph_target ?? 85,
          green_threshold: target?.green_threshold ?? 80,
          start_date: periodConfig?.start_date ?? '',
          end_date: periodConfig?.end_date ?? '',
          iph_target_id: target?.id,
          period_config_id: periodConfig?.id,
        };
      }).flat();
      
      setPeriodData(mergedData);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load period data.');
    }
    setIsLoading(false);
  };

  const handleEditToggle = () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to edit data.");
      return;
    }
    
    if (isEditing) {
        setShowConfirmDialog(true);
    } else {
      setIsEditing(true);
      setEditedData(JSON.parse(JSON.stringify(periodData)));
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedData([]);
    setShowConfirmDialog(false);
    toast.info("Edit mode cancelled. Changes were not saved.");
  };

  const handleDataChange = (index, field, value) => {
    if (!canEdit || !isEditing) return;
    setEditedData(prev => 
      prev.map((item, i) => i === index ? { ...item, [field]: value } : item)
    );
  };

  const handleConfirmSave = async () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to save data.");
      return;
    }
    
    setIsSaving(true);
    setShowConfirmDialog(false);
    
    const updatePromises = editedData.map(data => {
      const targetPayload = {
        period: data.period,
        year: data.year,
        iph_target: parseFloat(data.iph_target) || 85,
        green_threshold: parseFloat(data.green_threshold) || 80,
      };
      
      // For Period 11 weekly targets, include week
      if (data.week) {
        targetPayload.week = data.week;
      }

      const periodConfigPayload = {
        period_number: data.period,
        year: data.year,
        start_date: data.start_date,
        end_date: data.end_date,
      };

      const promises = [];

      // Update or Create ShopperIPHTarget
      if (data.iph_target_id) {
        promises.push(ShopperIPHTarget.update(data.iph_target_id, targetPayload));
      } else {
        promises.push(ShopperIPHTarget.create(targetPayload));
      }

      // Update or Create PeriodConfig (skip for weekly targets)
      if (!data.week && data.start_date && data.end_date) {
        if (data.period_config_id) {
          promises.push(PeriodConfig.update(data.period_config_id, periodConfigPayload));
        } else {
          promises.push(PeriodConfig.create(periodConfigPayload));
        }
      }

      return Promise.all(promises);
    });

    try {
      await toast.promise(Promise.all(updatePromises.flat()), {
          loading: 'Saving all changes...',
          success: 'All data saved successfully!',
          error: 'An error occurred while saving.',
      });
      
      setIsEditing(false);
      setEditedData([]);
      await loadData();
    } catch (error) {
      console.error('Save operation failed:', error);
    } finally {
      setIsSaving(false);
    }
  };



  const dataToDisplay = isEditing ? editedData : periodData;

  return (
    <div className="p-6 space-y-6 min-h-screen">
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Changes</DialogTitle>
            <DialogDescription>
              Are you sure you want to save all the changes you made? This will update the IPH targets and period dates.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={handleCancelEdit}>Cancel</Button>
            <Button onClick={handleConfirmSave} disabled={isSaving}>
              {isSaving ? 'Saving...' : 'Confirm & Save'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Shopper IPH Targets</h1>
          <p className="text-gray-600 mt-1">Set IPH targets for each financial period.</p>
        </div>
        <div className="flex items-center gap-3">
          {canEdit && (
            <>
              {isEditing && (
                <Button variant="outline" onClick={handleCancelEdit} disabled={isSaving}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
              )}
              <Button onClick={handleEditToggle} disabled={isSaving} className="bg-blue-600 hover:bg-blue-700 text-white">
                {isEditing ? (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </>
                ) : (
                  <>
                    <Edit className="w-4 h-4 mr-2" />
                    Edit Mode
                  </>
                )}
              </Button>
            </>
          )}
        </div>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <CardTitle className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <Target className="w-5 h-5 text-blue-600" />
              Configuration for Financial Year {year}
            </CardTitle>
            <Select value={year.toString()} onValueChange={(val) => setYear(parseInt(val))} disabled={isEditing}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i).map(y => (
                  <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p>Loading configuration data...</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Period</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>End Date</TableHead>
                  <TableHead>IPH Target</TableHead>
                  <TableHead>Green Threshold (%)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dataToDisplay.map((data, index) => (
                  <TableRow key={data.week ? `${data.period}-${data.week}` : data.period}>
                    <TableCell className="font-medium">
                      {data.week ? `Period ${data.period} - Week ${data.week}` : `Period ${data.period}`}
                    </TableCell>
                    <TableCell>
                      {data.week ? (
                        '—'
                      ) : isEditing ? (
                        <Input
                          type="date"
                          className="bg-white/50 w-40"
                          value={data.start_date}
                          onChange={e => handleDataChange(index, 'start_date', e.target.value)}
                          disabled={!isEditing}
                        />
                      ) : (
                        data.start_date ? new Date(data.start_date + 'T00:00:00').toLocaleDateString() : '—'
                      )}
                    </TableCell>
                    <TableCell>
                      {data.week ? (
                        '—'
                      ) : isEditing ? (
                        <Input
                          type="date"
                          className="bg-white/50 w-40"
                          value={data.end_date}
                          onChange={e => handleDataChange(index, 'end_date', e.target.value)}
                          disabled={!isEditing}
                        />
                      ) : (
                        data.end_date ? new Date(data.end_date + 'T00:00:00').toLocaleDateString() : '—'
                      )}
                    </TableCell>
                    <TableCell>
                      {isEditing ? (
                        <Input
                          type="number"
                          step="0.1"
                          className="bg-white/50 w-24"
                          value={data.iph_target}
                          onChange={e => handleDataChange(index, 'iph_target', e.target.value)}
                          disabled={!isEditing}
                        />
                      ) : (
                        data.iph_target
                      )}
                    </TableCell>
                    <TableCell>
                      {isEditing ? (
                        <Input
                          type="number"
                          step="1"
                          className="bg-white/50 w-24"
                          value={data.green_threshold}
                          onChange={e => handleDataChange(index, 'green_threshold', e.target.value)}
                          disabled={!isEditing}
                        />
                      ) : (
                        data.green_threshold
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}