
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { MessageSquareText, Upload, Download, Plus, Trash2, Edit, Save, X, TrendingUp, AlertCircle, CheckCircle, Users, Target } from "lucide-react";
import { toast } from "sonner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { User } from "@/api/entities";
import { SurveyData } from "@/api/entities";
import { ActionPlan } from "@/api/entities";

const SURVEY_CATEGORIES = [
  "Trust - CEO",
  "Happiness - eSAT",
  "Collaboration - Across Teams",
  "Wellbeing",
  "Customer Experience",
  "Values",
  "Speak My Mind",
  "Trust - Managers",
  "Recommend",
  "Opinions and Ideas",
  "Barriers to Execution",
  "Team Communication",
  "Resources",
  "Purpose",
  "Communication",
  "Pride",
  "Prioritisation",
  "Support",
  "Wellbeing Initiatives",
  "Recognition",
  "Coaching Colleagues",
  "Health and Safety",
  "Decision Making",
  "Plan for Better",
  "Execution",
  "Recommend - Products and Services",
  "Corporate Citizenship",
  "Responsibility",
  "Empowerment",
  "Contribution",
  "Trust - Senior Leaders",
  "Respectful Treatment",
  "Authenticity",
  "Role Model",
  "Change Support",
  "Vision",
  "Growth",
  "Work Life Balance",
  "Anything else"
];

const SENTIMENT_COLORS = {
  positive: "bg-green-100 text-green-800",
  neutral: "bg-gray-100 text-gray-800",
  negative: "bg-red-100 text-red-800"
};

export default function WereListeningSurvey() {
  const [canEdit, setCanEdit] = useState(false);
  const [surveyPeriod, setSurveyPeriod] = useState("August 2025");
  const [surveyYear, setSurveyYear] = useState(2025);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedSentiment, setSelectedSentiment] = useState("all");
  const [comments, setComments] = useState([]);
  const [actionPlans, setActionPlans] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showAddAction, setShowAddAction] = useState(false);
  const [editingActionId, setEditingActionId] = useState(null); // New state for tracking the action being edited
  const [editedAction, setEditedAction] = useState({}); // New state for holding changes to an action
  const [newAction, setNewAction] = useState({
    category: "",
    issue: "",
    action: "",
    assigned_to: "",
    priority: "medium",
    status: "pending",
    due_date: ""
  });

  useEffect(() => {
    const checkUserRole = async () => {
      try {
        const user = await User.me();
        setCanEdit(user && user.role === 'admin');
      } catch (error) {
        setCanEdit(false);
      }
    };
    checkUserRole();
  }, []);

  useEffect(() => {
    // Add a small delay to prevent rapid requests
    const timer = setTimeout(() => {
      if (surveyPeriod && surveyYear) {
        loadSurveyData();
        loadActionPlans();
      }
    }, 300);
    
    return () => clearTimeout(timer);
  }, [surveyPeriod, surveyYear]);

  const loadSurveyData = async () => {
    if (!surveyPeriod || !surveyYear) return;
    
    setIsLoading(true);
    try {
      // Add a small delay before making the request
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const data = await SurveyData.filter({ 
        period: surveyPeriod, 
        year: surveyYear 
      }, '-created_date', 500); // Limit to 500 records and sort by newest
      
      console.log(`Loaded ${data.length} survey comments`);
      setComments(data);
      
      if (data.length === 0) {
        toast.info("No survey data found for this period. You can import data using the Import button.");
      }
    } catch (error) {
      console.error("Failed to load survey data:", error);
      if (error.message?.includes('aborted')) {
        toast.error("Request was interrupted. Please try refreshing the page or checking your network.");
      } else {
        toast.error("Failed to load survey data");
      }
      setComments([]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadActionPlans = async () => {
    if (!surveyPeriod || !surveyYear) return;
    
    try {
      // Add a small delay to stagger requests
      await new Promise(resolve => setTimeout(resolve, 200));
      
      const plans = await ActionPlan.filter({ 
        period: surveyPeriod, 
        year: surveyYear 
      }, '-created_date', 100);
      
      console.log(`Loaded ${plans.length} action plans`);
      setActionPlans(plans);
    } catch (error) {
      console.error("Failed to load action plans:", error);
      if (!error.message?.includes('aborted')) { // Don't toast for expected aborted requests
        toast.error("Failed to load action plans");
      }
      setActionPlans([]);
    }
  };

  const handleImportData = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const text = e.target.result;
        // Parse the pasted Glint data format
        const parsedComments = parseGlintData(text);
        
        if (parsedComments.length === 0) {
          toast.error("No valid comments found in the file.");
          return;
        }
        
        // Save to database in batches to avoid overwhelming the system
        const batchSize = 50;
        let imported = 0;
        
        for (let i = 0; i < parsedComments.length; i += batchSize) {
          const batch = parsedComments.slice(i, i + batchSize);
          await SurveyData.bulkCreate(batch.map(comment => ({
            ...comment,
            period: surveyPeriod,
            year: surveyYear
          })));
          imported += batch.length;
          
          // Small delay between batches
          await new Promise(resolve => setTimeout(resolve, 300));
        }
        
        toast.success(`Imported ${imported} comments`);
        loadSurveyData();
      } catch (error) {
        console.error("Import failed:", error);
        toast.error("Failed to import survey data");
      }
    };
    reader.readAsText(file);
  };

  const parseGlintData = (text) => {
    // Simple parser for the Glint format
    const comments = [];
    const lines = text.split('\n');
    let currentCategory = "";
    let currentComment = "";
    let currentTeam = "";

    for (const line of lines) {
      if (line.includes('expanded')) {
        currentCategory = line.split(' ')[0].trim();
      } else if (line.includes('of ')) {
        // Comment line
        const parts = line.split('.');
        if (parts.length >= 2) {
          currentComment = parts[1].split(/Team|Suppressed/)[0].trim();
          currentTeam = line.includes('Team') ? line.split('Team')[0].split('.').pop().trim() + ' Team' : 'Suppressed';
          
          if (currentComment && currentCategory) {
            comments.push({
              category: currentCategory,
              comment: currentComment,
              team: currentTeam,
              sentiment: detectSentiment(currentComment)
            });
          }
        }
      }
    }

    return comments;
  };

  const detectSentiment = (text) => {
    const negativeWords = ['no', 'not', 'never', 'poor', 'bad', 'terrible', 'awful', 'hate', 'worst', 'useless', 'fail', 'broken'];
    const positiveWords = ['yes', 'good', 'great', 'excellent', 'love', 'best', 'happy', 'positive', 'support', 'thank'];
    
    const lowerText = text.toLowerCase();
    const negCount = negativeWords.filter(word => lowerText.includes(word)).length;
    const posCount = positiveWords.filter(word => lowerText.includes(word)).length;
    
    if (negCount > posCount) return 'negative';
    if (posCount > negCount) return 'positive';
    return 'neutral';
  };

  const getSentimentStats = () => {
    const filtered = filterComments();
    const total = filtered.length;
    if (total === 0) return { positive: 0, neutral: 0, negative: 0 };
    
    const positive = filtered.filter(c => c.sentiment === 'positive').length;
    const neutral = filtered.filter(c => c.sentiment === 'neutral').length;
    const negative = filtered.filter(c => c.sentiment === 'negative').length;
    
    return {
      positive: ((positive / total) * 100).toFixed(0),
      neutral: ((neutral / total) * 100).toFixed(0),
      negative: ((negative / total) * 100).toFixed(0)
    };
  };

  const getTopIssues = () => {
    const filtered = comments; // Use all comments for top issues, not just filtered ones
    const categoryCount = {};
    
    filtered.forEach(comment => {
      categoryCount[comment.category] = (categoryCount[comment.category] || 0) + 1;
    });
    
    return Object.entries(categoryCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([category, count]) => ({ category, count }));
  };

  const filterComments = () => {
    let filtered = comments;
    
    if (selectedCategory !== "all") {
      filtered = filtered.filter(c => c.category === selectedCategory);
    }
    
    if (selectedSentiment !== "all") {
      filtered = filtered.filter(c => c.sentiment === selectedSentiment);
    }
    
    return filtered;
  };

  const handleAddAction = async () => {
    if (!newAction.issue || !newAction.action || !newAction.assigned_to) {
      toast.error("Please fill in all required fields.");
      return;
    }

    try {
      await ActionPlan.create({
        ...newAction,
        period: surveyPeriod,
        year: surveyYear
      });
      
      toast.success("Action plan created successfully");
      setShowAddAction(false);
      setNewAction({
        category: "",
        issue: "",
        action: "",
        assigned_to: "",
        priority: "medium",
        status: "pending",
        due_date: ""
      });
      loadActionPlans();
    } catch (error) {
      console.error("Failed to create action plan:", error);
      toast.error("Failed to create action plan");
    }
  };

  const handleUpdateActionStatus = async (id, status) => {
    try {
      await ActionPlan.update(id, { status });
      toast.success("Action status updated");
      loadActionPlans();
    } catch (error) {
      console.error("Failed to update action:", error);
      toast.error("Failed to update action status");
    }
  };

  const handleDeleteAction = async (id) => {
    if (!confirm("Are you sure you want to delete this action plan?")) return;
    
    try {
      await ActionPlan.delete(id);
      toast.success("Action plan deleted");
      loadActionPlans();
    } catch (error) {
      console.error("Failed to delete action:", error);
      toast.error("Failed to delete action plan");
    }
  };

  // New functions for editing
  const handleEditAction = (action) => {
    // Hide add form if open
    setShowAddAction(false);
    setEditingActionId(action.id);
    setEditedAction({
      action: action.action,
      assigned_to: action.assigned_to,
      due_date: action.due_date, // Assuming due_date is already in YYYY-MM-DD format
      priority: action.priority,
      status: action.status
    });
  };

  const handleCancelEdit = () => {
    setEditingActionId(null);
    setEditedAction({});
  };

  const handleSaveEdit = async (id) => {
    try {
      await ActionPlan.update(id, editedAction);
      toast.success("Action plan updated successfully");
      setEditingActionId(null);
      setEditedAction({});
      loadActionPlans();
    } catch (error) {
      console.error("Failed to update action:", error);
      toast.error("Failed to update action plan");
    }
  };

  const sentimentStats = getSentimentStats();
  const topIssues = getTopIssues();
  const filteredComments = filterComments();

  return (
    <div className="p-4 space-y-4 min-h-screen">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
        <div>
          <h1 className="text-xl font-bold text-gray-900">We're Listening Survey</h1>
          <p className="text-gray-600 text-sm mt-0.5">Employee feedback analysis and action planning</p>
        </div>
        <div className="flex items-center gap-2">
          <Input
            type="text"
            placeholder="Period (e.g. August 2025)"
            value={surveyPeriod}
            onChange={(e) => setSurveyPeriod(e.target.value)}
            className="w-40 h-8 text-sm"
          />
          <Select value={surveyYear.toString()} onValueChange={(val) => setSurveyYear(parseInt(val))}>
            <SelectTrigger className="w-24 h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 3 }, (_, i) => new Date().getFullYear() - i).map(y => (
                <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {canEdit && (
            <>
              <input
                type="file"
                id="survey-upload"
                className="hidden"
                accept=".txt,.csv"
                onChange={handleImportData}
              />
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => document.getElementById('survey-upload').click()}
                className="h-8 px-3 text-xs"
              >
                <Upload className="w-3.5 h-3.5 mr-1.5" />
                Import
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Loading State */}
      {isLoading && (
        <Card className="glass-card">
          <CardContent className="py-8 text-center">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600 mx-auto mb-3"></div>
            <p className="text-gray-600 text-sm">Loading survey data...</p>
          </CardContent>
        </Card>
      )}

      {/* Dashboard Cards and Top Issues - Render only when not loading and comments are available */}
      {!isLoading && comments.length > 0 && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <Card className="glass-card">
              <CardHeader className="pb-1 px-4 pt-3">
                <CardTitle className="text-xs font-medium text-gray-600">Total Comments</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-3">
                <div className="text-2xl font-bold">409</div>
                <p className="text-xs text-gray-500 mt-0.5">Across {SURVEY_CATEGORIES.length} categories</p>
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader className="pb-1 px-4 pt-3">
                <CardTitle className="text-xs font-medium text-gray-600">Sentiment Overview</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-3">
                <div className="flex gap-1.5 flex-wrap">
                  <Badge className="bg-green-100 text-green-800 text-xs">{sentimentStats.positive}% Positive</Badge>
                  <Badge className="bg-red-100 text-red-800 text-xs">{sentimentStats.negative}% Negative</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader className="pb-1 px-4 pt-3">
                <CardTitle className="text-xs font-medium text-gray-600">Action Plans</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-3">
                <div className="text-2xl font-bold">{actionPlans.length}</div>
                <p className="text-xs text-gray-500 mt-0.5">
                  {actionPlans.filter(a => a.status === 'completed').length} completed
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader className="pb-1 px-4 pt-3">
                <CardTitle className="text-xs font-medium text-gray-600">Priority Issues</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-3">
                <div className="text-2xl font-bold text-red-600">
                  {actionPlans.filter(a => a.priority === 'high' && a.status !== 'completed').length}
                </div>
                <p className="text-xs text-gray-500 mt-0.5">High priority pending</p>
              </CardContent>
            </Card>
          </div>

          {/* Top Issues */}
          {topIssues.length > 0 && (
            <Card className="glass-card">
              <CardHeader className="px-4 py-3">
                <CardTitle className="text-base font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-orange-500" />
                  Top 5 Issues by Comment Volume
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-3">
                <div className="space-y-2">
                  {topIssues.map((issue, index) => (
                    <div key={issue.category} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-bold text-gray-300">#{index + 1}</span>
                        <span className="font-medium text-sm">{issue.category}</span>
                      </div>
                      <Badge 
                        variant="secondary" 
                        className="text-xs cursor-pointer hover:bg-blue-200 transition-colors"
                        onClick={() => {
                          setSelectedCategory(issue.category);
                          setSelectedSentiment("all");
                          // Scroll to comments section
                          setTimeout(() => {
                            const commentsSection = document.querySelector('[data-comments-section]');
                            if (commentsSection) {
                              commentsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }
                          }, 100);
                          toast.success(`Filtered to show ${issue.count} ${issue.category} comments`);
                        }}
                      >
                        {issue.count} comments
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {/* Action Plans Section */}
      <Card className="glass-card">
        <CardHeader className="flex flex-row justify-between items-center px-4 py-3">
          <div>
            <CardTitle className="text-base font-bold flex items-center gap-2">
              <Target className="w-4 h-4 text-blue-500" />
              Action Plans & Next Steps
            </CardTitle>
            <CardDescription className="text-xs">Track and manage improvement initiatives</CardDescription>
          </div>
          {canEdit && (
            <Button 
              size="sm" 
              onClick={() => {
                setShowAddAction(!showAddAction);
                // Clear any ongoing edit when opening/closing add action form
                setEditingActionId(null);
                setEditedAction({});
              }} 
              className="h-8 px-3 text-xs"
            >
              {showAddAction ? <X className="w-3.5 h-3.5 mr-1.5" /> : <Plus className="w-3.5 h-3.5 mr-1.5" />}
              {showAddAction ? 'Cancel' : 'Add Action'}
            </Button>
          )}
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {showAddAction && (
            <Card className="mb-3 border-blue-200 bg-blue-50">
              <CardContent className="pt-3 pb-3 px-3 space-y-2">
                <Select value={newAction.category} onValueChange={(val) => setNewAction({...newAction, category: val})}>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select Category" />
                  </SelectTrigger>
                  <SelectContent>
                    {SURVEY_CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Input
                  placeholder="Issue Description"
                  value={newAction.issue}
                  onChange={(e) => setNewAction({...newAction, issue: e.target.value})}
                  className="h-8 text-sm"
                />
                
                <Textarea
                  placeholder="Action Plan (SMART: Specific, Measurable, Achievable, Relevant, Time-bound)"
                  value={newAction.action}
                  onChange={(e) => setNewAction({...newAction, action: e.target.value})}
                  className="h-20 text-sm"
                />
                
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="Assigned To"
                    value={newAction.assigned_to}
                    onChange={(e) => setNewAction({...newAction, assigned_to: e.target.value})}
                    className="h-8 text-sm"
                  />
                  
                  <Select value={newAction.priority} onValueChange={(val) => setNewAction({...newAction, priority: val})}>
                    <SelectTrigger className="h-8 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low Priority</SelectItem>
                      <SelectItem value="medium">Medium Priority</SelectItem>
                      <SelectItem value="high">High Priority</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Input
                    type="date"
                    value={newAction.due_date}
                    onChange={(e) => setNewAction({...newAction, due_date: e.target.value})}
                    className="h-8 text-sm"
                  />
                </div>
                
                <Button onClick={handleAddAction} className="w-full h-8 text-sm">
                  <Save className="w-3.5 h-3.5 mr-1.5" />
                  Save Action Plan
                </Button>
              </CardContent>
            </Card>
          )}

          {actionPlans.length === 0 ? (
            <div className="text-center py-6 text-gray-500">
              <Target className="w-10 h-10 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">No action plans yet. Create your first action plan above.</p>
              <p className="text-xs mt-1">Recommended actions will appear here based on survey comments.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs py-2">Category</TableHead>
                    <TableHead className="text-xs py-2">Issue</TableHead>
                    <TableHead className="text-xs py-2">Action</TableHead>
                    <TableHead className="text-xs py-2">Assigned To</TableHead>
                    <TableHead className="text-xs py-2">Priority</TableHead>
                    <TableHead className="text-xs py-2">Due Date</TableHead>
                    <TableHead className="text-xs py-2">Status</TableHead>
                    {canEdit && <TableHead className="text-xs py-2">Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {actionPlans.map((plan) => {
                    const isEditing = editingActionId === plan.id;
                    
                    return (
                      <TableRow key={plan.id}>
                        <TableCell className="font-medium text-xs py-2">{plan.category}</TableCell>
                        <TableCell className="max-w-xs text-xs py-2">{plan.issue}</TableCell>
                        <TableCell className="max-w-md text-xs py-2">
                          {isEditing ? (
                            <Textarea
                              value={editedAction.action}
                              onChange={(e) => setEditedAction({...editedAction, action: e.target.value})}
                              className="w-full text-xs h-20"
                            />
                          ) : (
                            plan.action
                          )}
                        </TableCell>
                        <TableCell className="text-xs py-2">
                          {isEditing ? (
                            <Input
                              value={editedAction.assigned_to}
                              onChange={(e) => setEditedAction({...editedAction, assigned_to: e.target.value})}
                              className="w-full text-xs h-7"
                            />
                          ) : (
                            plan.assigned_to
                          )}
                        </TableCell>
                        <TableCell className="py-2">
                          {isEditing ? (
                            <Select 
                              value={editedAction.priority} 
                              onValueChange={(val) => setEditedAction({...editedAction, priority: val})}
                            >
                              <SelectTrigger className="w-24 h-7 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <Badge className={`text-xs ${
                              plan.priority === 'high' ? 'bg-red-100 text-red-800' :
                              plan.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-blue-100 text-blue-800'
                            }`}>
                              {plan.priority}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-xs py-2">
                          {isEditing ? (
                            <Input
                              type="date"
                              value={editedAction.due_date}
                              onChange={(e) => setEditedAction({...editedAction, due_date: e.target.value})}
                              className="w-32 text-xs h-7"
                            />
                          ) : (
                            plan.due_date ? new Date(plan.due_date).toLocaleDateString() : '—'
                          )}
                        </TableCell>
                        <TableCell className="py-2">
                          {isEditing ? (
                            <Select 
                              value={editedAction.status} 
                              onValueChange={(val) => setEditedAction({...editedAction, status: val})}
                            >
                              <SelectTrigger className="w-28 h-7 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pending">Pending</SelectItem>
                                <SelectItem value="in_progress">In Progress</SelectItem>
                                <SelectItem value="completed">Completed</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <Select 
                              value={plan.status} 
                              onValueChange={(val) => handleUpdateActionStatus(plan.id, val)}
                              disabled={!canEdit}
                            >
                              <SelectTrigger className="w-28 h-7 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pending">Pending</SelectItem>
                                <SelectItem value="in_progress">In Progress</SelectItem>
                                <SelectItem value="completed">Completed</SelectItem>
                              </SelectContent>
                            </Select>
                          )}
                        </TableCell>
                        {canEdit && (
                          <TableCell className="py-2">
                            <div className="flex gap-1">
                              {isEditing ? (
                                <>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => handleSaveEdit(plan.id)}
                                    className="h-7 w-7 p-0"
                                  >
                                    <Save className="w-3.5 h-3.5 text-green-500" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={handleCancelEdit}
                                    className="h-7 w-7 p-0"
                                  >
                                    <X className="w-3.5 h-3.5 text-gray-500" />
                                  </Button>
                                </>
                              ) : (
                                <>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => handleEditAction(plan)}
                                    className="h-7 w-7 p-0"
                                  >
                                    <Edit className="w-3.5 h-3.5 text-blue-500" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={() => handleDeleteAction(plan.id)}
                                    className="h-7 w-7 p-0"
                                  >
                                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Comments Section - Render only when not loading and comments are available */}
      {!isLoading && comments.length > 0 && (
        <Card className="glass-card" data-comments-section>
          <CardHeader className="px-4 py-3">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
              <div>
                <CardTitle className="text-base font-bold flex items-center gap-2">
                  <MessageSquareText className="w-4 h-4 text-orange-500" />
                  Employee Comments ({filteredComments.length})
                </CardTitle>
                <CardDescription className="text-xs">Filter and analyze employee feedback</CardDescription>
              </div>
              <div className="flex gap-2">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-40 h-8 text-xs">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {SURVEY_CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Select value={selectedSentiment} onValueChange={setSelectedSentiment}>
                  <SelectTrigger className="w-28 h-8 text-xs">
                    <SelectValue placeholder="All Sentiment" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="positive">Positive</SelectItem>
                    <SelectItem value="neutral">Neutral</SelectItem>
                    <SelectItem value="negative">Negative</SelectItem>
                  </SelectContent>
                </Select>
                
                {selectedCategory !== "all" && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setSelectedCategory("all")}
                    className="h-8 px-2 text-xs"
                  >
                    <X className="w-3.5 h-3.5 mr-1" />
                    Clear Filter
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            {filteredComments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <MessageSquareText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p className="text-sm font-medium">No comments match your filters</p>
                <p className="text-xs">Try adjusting the category or sentiment filters</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredComments.map((comment, index) => (
                  <Card key={index} className="border-l-4 border-l-blue-400">
                    <CardContent className="pt-3 pb-3 px-3">
                      <div className="flex justify-between items-start mb-1.5">
                        <div>
                          <Badge variant="outline" className="mr-1.5 text-xs">{comment.category}</Badge>
                          <Badge className={`text-xs ${SENTIMENT_COLORS[comment.sentiment]}`}>
                            {comment.sentiment}
                          </Badge>
                        </div>
                        <span className="text-xs text-gray-500">{comment.team}</span>
                      </div>
                      <p className="text-xs text-gray-700">{comment.comment}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* No Data State - Render only when not loading and comments are genuinely empty */}
      {!isLoading && comments.length === 0 && (
        <Card className="glass-card">
          <CardContent className="py-10 text-center">
            <MessageSquareText className="w-14 h-14 mx-auto mb-3 text-gray-300" />
            <p className="text-base font-medium">No survey data for this period</p>
            <p className="text-sm text-gray-500 mt-1.5">
              {canEdit ? "Import data using the Import Data button above" : "Contact an administrator to import survey data"}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
