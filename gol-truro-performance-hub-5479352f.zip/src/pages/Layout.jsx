
import React, { useState, useEffect, createContext, useContext } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import {
  BarChart3,
  TrendingUp,
  MessageSquare,
  Settings,
  Calendar,
  Users,
  Target,
  Upload,
  Calculator,
  Lock,
  Unlock,
  ClipboardList,
  AlertTriangle,
  ClipboardCheck,
  ShieldCheck,
  Truck,
  Link as LinkIcon,
  MessageSquareText, // Added MessageSquareText import
  Presentation // Added Presentation import
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";

// Create EditLock Context
const EditLockContext = createContext();
export const useEditLock = () => useContext(EditLockContext);


const analyticsItems = [
  {
    title: "KPI Overview",
    url: createPageUrl("Dashboard"),
    icon: BarChart3,
  },
  {
    title: "DWC & iCare",
    url: createPageUrl("CustomerComplaints"),
    icon: MessageSquare,
  },
  {
    title: "Forecast & Labour",
    url: createPageUrl("ForecastAndLabour"),
    icon: TrendingUp,
  },
  {
    title: "Shopper Performance",
    url: createPageUrl("ShopperPerformance"),
    icon: Users,
  },
  {
    title: "Schedules",
    url: createPageUrl("Schedules"),
    icon: Calendar
  },
  {
    title: "W.O.R.M.",
    url: createPageUrl("Worm"),
    icon: ClipboardCheck,
  },
  {
    title: "Delivery Cost Report",
    url: createPageUrl("DeliveryCostReport"),
    icon: Truck,
  },
  {
    title: "Period Damage Tracker",
    url: createPageUrl("PeriodDamageTracker"),
    icon: AlertTriangle,
  },
  {
    title: "Driver Performance",
    url: createPageUrl("PerformanceMatrix"),
    icon: ClipboardList,
  },
  {
    title: "Driver Violations",
    url: createPageUrl("DriverViolations"),
    icon: AlertTriangle,
  },
  {
    title: "SIMS, TTC & MN",
    url: createPageUrl("SimsTtcMasternaut"),
    icon: ShieldCheck,
  },
  {
    title: "Period Report",
    url: createPageUrl("PeriodResults"),
    icon: BarChart3,
  },
  {
    title: "IPH Calculator",
    url: createPageUrl("IPHCalculator"),
    icon: Calculator,
  },
  {
    title: "LINK",
    url: createPageUrl("Link"),
    icon: LinkIcon
  },
  {
    title: "We're Listening Survey",
    url: createPageUrl("WereListeningSurvey"),
    icon: MessageSquareText
  },
  {
    title: "Slides",
    url: createPageUrl("Slides"),
    icon: Presentation
  },
  {
    title: "Training",
    url: createPageUrl("Training"),
    icon: Users
  }
  ];

  const configurationItems = [
    {
        title: "Period Dates",
        url: createPageUrl("PeriodSettings"),
        icon: Calendar,
    },
    {
        title: "KPI Thresholds",
        url: createPageUrl("KpiSettings"),
        icon: Target,
    },
    {
        title: "Shopper IPH Targets",
        url: createPageUrl("ShopperIPHTargets"),
        icon: Target,
    },
    {
        title: "Shopper Data Upload",
        url: createPageUrl("ShopperDataUpload"),
        icon: Upload
    },
    {
        title: "Driver Management",
        url: createPageUrl("DriverDataUpload"),
        icon: Users
    },
    {
        title: "Performance Matrix Upload",
        url: createPageUrl("PerformanceMatrixDataUpload"),
        icon: Upload
    },
    {
        title: "Regional Data Upload",
        url: createPageUrl("RegionalDataUpload"),
        icon: Upload
    }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [isAdmin, setIsAdmin] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isDriverAuthenticated, setIsDriverAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [driverCredentials, setDriverCredentials] = useState({ username: '', password: '' });
  const [showDriverLogin, setShowDriverLogin] = useState(false);
  const [isEditLocked, setIsEditLocked] = useState(() => {
    const saved = localStorage.getItem('golEditLocked');
    return saved ? JSON.parse(saved) : true;
  });
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [unlockPassword, setUnlockPassword] = useState('');
  
  const UNLOCK_PASSWORD = "ATi19162000JP";
  
  // This is the password for the gate screen.
  const CORRECT_PASSWORD = "Truro2024";
  
  // Driver credentials
  const DRIVER_USERNAME = "JP";
  const DRIVER_PASSWORD = "ATi19162000JP";

  // Check which pages require driver authentication
  const driverPages = ['PerformanceMatrix', 'DriverViolations', 'SimsTtcMasternaut'];
  const currentPageRequiresDriverAuth = driverPages.includes(currentPageName);

  // Check session storage on initial mount to see if user is already authenticated in this session.
  useEffect(() => {
    const sessionAuth = sessionStorage.getItem('golAppAuthenticated');
    const driverSessionAuth = sessionStorage.getItem('golDriverAuthenticated');
    
    if (sessionAuth === 'true') {
      setIsAuthenticated(true);
    }
    if (driverSessionAuth === 'true') {
      setIsDriverAuthenticated(true);
    }
  }, []);

  // This effect logs the driver out when they navigate away from a protected page,
  // requiring them to log in again when they return.
  useEffect(() => {
    if (!currentPageRequiresDriverAuth) {
        setIsDriverAuthenticated(false);
        sessionStorage.removeItem('golDriverAuthenticated');
    }
  }, [currentPageRequiresDriverAuth, currentPageName]);

  // Handle edit lock toggle
  const toggleEditLock = () => {
    if (isEditLocked) {
      // Trying to unlock - show password dialog
      setShowPasswordDialog(true);
    } else {
      // Locking - no password needed
      setIsEditLocked(true);
      localStorage.setItem('golEditLocked', JSON.stringify(true));
      toast.info('Editing locked');
    }
  };

  const handleUnlockSubmit = () => {
    if (unlockPassword === UNLOCK_PASSWORD) {
      setIsEditLocked(false);
      localStorage.setItem('golEditLocked', JSON.stringify(false));
      toast.success('Editing unlocked');
      setShowPasswordDialog(false);
      setUnlockPassword('');
    } else {
      toast.error('Incorrect password');
      setUnlockPassword('');
    }
  };


  // Show driver login if needed
  useEffect(() => {
    if (isAuthenticated && currentPageRequiresDriverAuth && !isDriverAuthenticated) {
      setShowDriverLogin(true);
    } else {
      setShowDriverLogin(false);
    }
  }, [currentPageName, isAuthenticated, isDriverAuthenticated, currentPageRequiresDriverAuth]);

  // This effect runs once the user is authenticated.
  useEffect(() => {
    if (isAuthenticated) {
      const checkUserRole = async () => {
        try {
          const currentUser = await User.me();
          if (currentUser && currentUser.role === 'admin') {
            setIsAdmin(true);
          } else {
            setIsAdmin(false);
          }
        } catch (error) {
          setIsAdmin(false);
        }
      };
      checkUserRole();
    }
  }, [isAuthenticated]);

  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    if (password === CORRECT_PASSWORD) {
      sessionStorage.setItem('golAppAuthenticated', 'true');
      setIsAuthenticated(true);
    } else {
      toast.error('Incorrect password. Please try again.');
      setPassword('');
    }
  };

  const handleDriverLogin = (e) => {
    e.preventDefault();
    if (driverCredentials.username === DRIVER_USERNAME && driverCredentials.password === DRIVER_PASSWORD) {
      sessionStorage.setItem('golDriverAuthenticated', 'true');
      setIsDriverAuthenticated(true);
      setShowDriverLogin(false);
      setDriverCredentials({ username: '', password: '' });
    } else {
      toast.error('Incorrect driver credentials. Please try again.');
      setDriverCredentials({ username: '', password: '' });
    }
  };

  if (!isAuthenticated) {
    return (
      <>
        <style>
          {`
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            :root { --primary: #0f172a; --primary-light: #1e293b; --accent: #3b82f6; --accent-light: #60a5fa; --accent-dark: #2563eb; --background: #f8fafc; --surface: #ffffff; --surface-alt: #f1f5f9; --border: #e2e8f0; --border-light: #f1f5f9; --text-primary: #0f172a; --text-secondary: #475569; --text-muted: #64748b; --success: #22c55e; --warning: #f59e0b; --error: #ef4444; --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%); --gradient-secondary: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); --gradient-success: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05); --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1); --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1); --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1); }
            * { box-sizing: border-box; }
            body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: var(--background); color: var(--text-primary); line-height: 1.6; font-feature-settings: 'cv02', 'cv03', 'cv04', 'cv11'; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
            .login-background {
              background: url('https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6866d9d13515e74b5479352f/04f95b8fe_image.png') center/cover no-repeat;
              min-height: 100vh;
              display: flex;
              align-items: center;
              justify-content: center;
            }
            .login-card {
              background: rgba(255, 255, 255, 0.15);
              backdrop-filter: blur(20px);
              border: 1px solid rgba(255, 255, 255, 0.2);
              border-radius: 20px;
              padding: 40px;
              width: 100%;
              max-width: 400px;
              text-align: center;
              box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            }
            .login-icon {
              width: 60px;
              height: 60px;
              background: rgba(255, 255, 255, 0.2);
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              margin: 0 auto 24px;
            }
            .login-title {
              font-size: 28px;
              font-weight: 600;
              color: white;
              margin-bottom: 8px;
            }
            .login-subtitle {
              font-size: 16px;
              color: rgba(255, 255, 255, 0.8);
              margin-bottom: 32px;
            }
            .login-input {
              width: 100%;
              padding: 16px 20px;
              background: rgba(255, 255, 255, 0.1);
              border: 1px solid rgba(255, 255, 255, 0.2);
              border-radius: 12px;
              color: white;
              font-size: 16px;
              margin-bottom: 24px;
            }
            .login-input::placeholder {
              color: rgba(255, 255, 255, 0.6);
            }
            .login-input:focus {
              outline: none;
              border-color: rgba(255, 255, 255, 0.4);
              background: rgba(255, 255, 255, 0.15);
            }
            .login-button {
              width: 100%;
              padding: 16px;
              background: #ff6b35;
              border: none;
              border-radius: 12px;
              color: white;
              font-size: 16px;
              font-weight: 600;
              cursor: pointer;
              transition: all 0.2s ease;
            }
            .login-button:hover {
              background: #e55a2b;
              transform: translateY(-1px);
            }
          `}
        </style>
        <div className="login-background">
          <div className="login-card">
            <div className="login-icon">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h1 className="login-title">Welcome Back</h1>
            <p className="login-subtitle">These aren't the droids you're looking for.</p>
            <form onSubmit={handlePasswordSubmit}>
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="login-input"
              />
              <button type="submit" className="login-button">
                Access Dashboard
              </button>
            </form>
          </div>
        </div>
      </>
    );
  }

  if (showDriverLogin) {
    return (
      <>
        <style>
          {`
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
            :root { --primary: #0f172a; --primary-light: #1e293b; --accent: #3b82f6; --accent-light: #60a5fa; --accent-dark: #2563eb; --background: #f8fafc; --surface: #ffffff; --surface-alt: #f1f5f9; --border: #e2e8f0; --border-light: #f1f5f9; --text-primary: #0f172a; --text-secondary: #475569; --text-muted: #64748b; --success: #22c55e; --warning: #f59e0b; --error: #ef4444; --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%); --gradient-secondary: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); --gradient-success: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05); --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1); --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1); --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1); }
            * { box-sizing: border-box; }
            body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: var(--background); color: var(--text-primary); line-height: 1.6; font-feature-settings: 'cv02', 'cv03', 'cv04', 'cv11'; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
            .glass-card { background: rgba(255, 255, 255, 0.8); backdrop-filter: blur(20px); border: 1px solid rgba(255, 255, 255, 0.2); box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1); border-radius: 16px; }
            .modern-gradient { background: var(--gradient-primary); box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3); }
            .btn-modern { background: var(--gradient-primary); border: none; border-radius: 12px; padding: 12px 24px; color: white; font-weight: 500; font-size: 14px; cursor: pointer; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3); }
            .input-modern { background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(10px); border: 1px solid var(--border-light); border-radius: 12px; padding: 12px 16px; font-size: 14px; }
            .input-modern:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
          `}
        </style>
        <div className="w-full min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50/20 to-indigo-50/20">
          <Card className="w-full max-w-sm glass-card shadow-xl">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 modern-gradient rounded-full flex items-center justify-center mb-4">
                <Users className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-slate-800">Driver Access Required</CardTitle>
              <CardDescription className="text-slate-600">
                Please enter your driver credentials to access performance data.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <form onSubmit={handleDriverLogin} className="space-y-4">
                <Input
                  type="text"
                  placeholder="Username"
                  value={driverCredentials.username}
                  onChange={(e) => setDriverCredentials(prev => ({ ...prev, username: e.target.value }))}
                  className="input-modern text-center"
                />
                <Input
                  type="password"
                  placeholder="Password"
                  value={driverCredentials.password}
                  onChange={(e) => setDriverCredentials(prev => ({ ...prev, password: e.target.value }))}
                  className="input-modern text-center"
                />
                <Button type="submit" className="w-full btn-modern">
                  Access Driver Data
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </>
    );
  }

  const editLockValue = {
    isEditLocked,
    canEdit: !isEditLocked
  };

  return (
    <EditLockContext.Provider value={editLockValue}>
      <SidebarProvider>
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

          :root {
            --primary: #0f172a;
            --primary-light: #1e293b;
            --accent: #3b82f6;
            --accent-light: #60a5fa;
            --accent-dark: #2563eb;
            --background: #f8fafc;
            --surface: #ffffff;
            --surface-alt: #f1f5f9;
            --border: #e2e8f0;
            --border-light: #f1f5f9;
            --text-primary: #0f172a;
            --text-secondary: #475569;
            --text-muted: #64748b;
            --success: #22c55e;
            --warning: #f59e0b;
            --error: #ef4444;
            --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --gradient-secondary: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --gradient-success: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
          }

          * {
            box-sizing: border-box;
          }

          body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: var(--background);
            color: var(--text-primary);
            line-height: 1.6;
            font-feature-settings: 'cv02', 'cv03', 'cv04', 'cv11';
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            /* PWA optimizations */
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -webkit-tap-highlight-color: transparent;
            overflow-x: hidden;
          }

          /* PWA Meta Tags */
          html {
            height: 100%;
            width: 100%;
            overflow-x: hidden;
          }

          /* Mobile optimizations */
          @media (max-width: 768px) {
            body {
              font-size: 16px; /* Prevent zoom on iOS */
            }
            
            input, select, textarea {
              font-size: 16px !important; /* Prevent zoom on iOS */
            }
          }

          /* PWA Install prompt styling */
          .pwa-install-prompt {
            position: fixed;
            bottom: 20px;
            left: 20px;
            right: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            padding: 16px;
            z-index: 1000;
            border: 1px solid var(--border);
          }

          .glass-card {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            border: none;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border-radius: 16px;
          }

          .modern-gradient {
            background: var(--gradient-primary);
            box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
          }

          .glass-nav {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: var(--shadow-lg);
          }

          .nav-item {
            position: relative;
            border-radius: 12px;
            overflow: hidden;
          }

          .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(147, 197, 253, 0.05) 100%);
            opacity: 0;
          }

          .nav-item:hover::before {
            opacity: 1;
          }

          .nav-item.active {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(147, 197, 253, 0.05) 100%);
            border-left: 3px solid var(--accent);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
          }

          .metric-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(20px);
            border: none;
            border-radius: 16px;
            position: relative;
            overflow: hidden;
            transition: transform 0.2s ease-out, box-shadow 0.2s ease-out;
          }

          .metric-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
          }

          .metric-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: var(--gradient-primary);
            opacity: 0;
            transition: opacity 0.2s ease-out;
          }

          .metric-card:hover::before {
            opacity: 1;
          }

          .status-green {
            background: linear-gradient(135deg, rgba(34, 197, 94, 0.1) 0%, rgba(134, 239, 172, 0.05) 100%);
            border-color: rgba(34, 197, 94, 0.3);
            box-shadow: 0 4px 20px rgba(34, 197, 94, 0.1);
          }

          .status-amber {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, rgba(251, 191, 36, 0.05) 100%);
            border-color: rgba(245, 158, 11, 0.3);
            box-shadow: 0 4px 20px rgba(245, 158, 11, 0.1);
          }

          .status-red {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1) 0%, rgba(248, 113, 113, 0.05) 100%);
            border-color: rgba(239, 68, 68, 0.3);
            box-shadow: 0 4px 20px rgba(239, 68, 68, 0.1);
          }

          .btn-modern {
            background: var(--gradient-primary);
            border: none;
            border-radius: 12px;
            padding: 12px 24px;
            color: white;
            font-weight: 500;
            font-size: 14px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
          }

          .table-modern {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: var(--shadow-lg);
          }

          .table-modern thead {
            background: linear-gradient(135deg, var(--surface-alt) 0%, rgba(241, 245, 249, 0.8) 100%);
          }

          .table-modern tbody tr {
            border-bottom: none;
          }

          .table-modern tbody tr:hover {
            background: rgba(59, 130, 246, 0.02);
          }

          table, thead, tbody, tfoot, tr, th, td {
            border: none !important;
          }

          [class*="border"] {
            border: none !important;
          }

          .input-modern {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            padding: 12px 16px;
            font-size: 14px;
          }

          .input-modern:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
          }

          .chart-container {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            padding: 24px;
            box-shadow: var(--shadow-lg);
          }

          [data-sonner-toaster] {
            top: auto !important;
            bottom: 32px !important;
            left: 32px !important;
            right: auto !important;
          }

          /* Mobile responsive sidebar */
          @media (max-width: 768px) {
            .sidebar-mobile-overlay {
              position: fixed;
              top: 0;
              left: 0;
              right: 0;
              bottom: 0;
              background: rgba(0, 0, 0, 0.5);
              z-index: 40;
            }
          }

          @media print {
            body {
              background: #fff;
            }
            .no-print, .glass-nav, header[class*="md:hidden"], .pwa-install-prompt {
              display: none !important;
            }
            main {
              padding: 0 !important;
              overflow: visible !important;
            }
            .glass-card, .metric-card {
              box-shadow: none !important;
              border: 1px solid #e2e8f0 !important;
              background: #fff !important;
              backdrop-filter: none !important;
              page-break-inside: avoid;
            }
          }
        `}
      </style>

      {/* Mobile Web App Meta Tags - Simplified */}
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      <meta name="apple-mobile-web-app-title" content="GOL Truro" />
      <meta name="mobile-web-app-capable" content="yes" />
      <meta name="theme-color" content="#3b82f6" />
      
      {/* Simple Icons */}
      <link rel="apple-touch-icon" href="https://via.placeholder.com/180x180/3b82f6/white?text=GOL" />
      <link rel="icon" href="https://via.placeholder.com/32x32/3b82f6/white?text=G" />
      
      {/* Basic Manifest */}
      <link rel="manifest" href="data:application/json;base64,ewogICJuYW1lIjogIkdPTCBUcnVybyBQZXJmb3JtYW5jZSBIdWIiLAogICJzaG9ydF9uYW1lIjogIkdPTCBUcnVybyIsCiAgImRlc2NyaXB0aW9uIjogIlBlcmZvcm1hbmNlIHRyYWNraW5nIGFuZCBhbmFseXRpY3MiLAogICJzdGFydF91cmwiOiAiLyIsCiAgImRpc3BsYXkiOiAic3RhbmRhbG9uZSIsCiAgImJhY2tncm91bmRfY29sb3IiOiAiI2Y4ZmFmYyIsCiAgInRoZW1lX2NvbG9yOiAiIzNiODJmNiIsCiAgImljb25zIjogWwogICAgewogICAgICAic3JjIjogImh0dHBzOi8vdmlhLnBsYWNlaG9sZGVyLmNvbS8xOTJ4MTkyLzNiODJmNi93aGl0ZT90ZXh0PUdPTCIsCiAgICAgICJzaXplcyI6ICIxOTJ4MTkyIiwKICAgICAgInR5cGUiOiAiaW1hZ2UvcG5nIgogICAgfSwKICAgIHsKICAgICAgInNyYyI6ICJodHRwczovL3ZpYS5wbGFjZWhvbGRlci5jb20vNTEyeDUxMi8zYjgyZjYvd2hpdGU/dGV4dD1HT0wiLAogICAgICAic2l6ZXMiOiAiNTEyeDUxMiIsCiAgICAgICJ0eXBlIjogImltYWdlL3BuZyIKICAgIH0KICBdCn0=" />

      {/* Password Dialog */}
      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Unlock Editing</DialogTitle>
            <DialogDescription>
              Enter the password to enable editing across all pages.
            </DialogDescription>
          </DialogHeader>
          <Input
            type="password"
            placeholder="Enter password"
            value={unlockPassword}
            onChange={(e) => setUnlockPassword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleUnlockSubmit()}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowPasswordDialog(false); setUnlockPassword(''); }}>
              Cancel
            </Button>
            <Button onClick={handleUnlockSubmit}>
              Unlock
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="min-h-screen flex w-full">
        <Sidebar className="glass-nav border-r-0">
          <SidebarHeader className="border-b border-slate-200/50 p-6 bg-white/80 backdrop-blur-xl">
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 modern-gradient rounded-xl flex items-center justify-center shadow-lg">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-semibold text-slate-900 text-lg">GOL Truro</h2>
                  <div className="md:hidden">
                    <button 
                      onClick={() => {
                        // Show install instructions
                        alert(`To install this app on your phone:\n\niPhone: Tap Share button → "Add to Home Screen"\n\nAndroid: Tap menu → "Add to Home screen" or "Install app"`);
                      }}
                      className="text-xs text-blue-600 underline"
                    >
                      📱 Add to Home Screen
                    </button>
                  </div>
                </div>
                </div>
                <Button
                variant="outline"
                size="sm"
                onClick={toggleEditLock}
                className={`w-full ${isEditLocked ? 'border-red-300 text-red-700 hover:bg-red-50' : 'border-green-300 text-green-700 hover:bg-green-50'}`}
                >
                {isEditLocked ? <Lock className="w-4 h-4 mr-2" /> : <Unlock className="w-4 h-4 mr-2" />}
                {isEditLocked ? 'Locked' : 'Unlocked'}
                </Button>
                </div>
          </SidebarHeader>

          <SidebarContent className="p-4 bg-white/80 backdrop-blur-xl">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-3 mb-2">
                Analytics
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-2">
                  {analyticsItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        className={`nav-item transition-all duration-200 mb-1 ${
                          location.pathname === item.url
                            ? 'active text-blue-700 font-medium'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3 relative z-10">
                          <item.icon className="w-4 h-4" />
                          <span className="font-medium text-xs">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            {isAdmin && (
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-3 mb-2 mt-6">
                  Configuration
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu className="space-y-2">
                    {configurationItems.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          className={`nav-item transition-all duration-200 mb-1 ${
                            location.pathname === item.url
                              ? 'active text-blue-700 font-medium'
                            : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-4 py-3 relative z-10">
                            <item.icon className="w-4 h-4" />
                            <span className="font-medium text-xs">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            )}
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 flex flex-col overflow-hidden">
          <header className="glass-card border-b border-slate-200/50 px-6 py-4 md:hidden m-4 rounded-xl">
            <div className="flex items-center gap-4 justify-between w-full">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="p-2 rounded-lg transition-all duration-200 hover:bg-slate-100" />
                <h1 className="text-lg font-semibold text-slate-900">GOL Truro Performance</h1>
                </div>
                <Button
                variant="outline"
                size="sm"
                onClick={toggleEditLock}
                className={`${isEditLocked ? 'border-red-300 text-red-700 hover:bg-red-50' : 'border-green-300 text-green-700 hover:bg-green-50'}`}
                >
                {isEditLocked ? <Lock className="w-4 h-4 mr-2" /> : <Unlock className="w-4 h-4 mr-2" />}
                {isEditLocked ? 'Locked' : 'Unlocked'}
                </Button>
                </div>
          </header>

          <div className="flex-1 overflow-auto bg-gradient-to-br from-slate-50 via-blue-50/20 to-indigo-50/20">
            {children}
          </div>
        </main>
      </div>
      </SidebarProvider>
    </EditLockContext.Provider>
  );
}
