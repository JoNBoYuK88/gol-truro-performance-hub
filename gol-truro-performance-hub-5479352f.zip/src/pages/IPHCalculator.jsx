import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calculator, RefreshCw, ShoppingBasket, Clock, ArrowRightLeft, Upload, FileText, Users, Trash2, Save, Database, Target } from 'lucide-react';
import { toast } from 'sonner';
import { IPHCalculationResult } from '@/api/entities';
import { ShopperIPHTarget } from '@/api/entities';
import { PeriodConfig } from '@/api/entities';

// Helper function to convert time string to decimal hours - handles both decimal and HH:MM formats
const convertTimeToHours = (timeStr, isWtd = false) => {
    if (typeof timeStr !== 'string' || !timeStr.trim()) return 0;

    if (isWtd) {
        // WTD data is assumed to be already in decimal hours (e.g., "8.75")
        return parseFloat(timeStr) || 0;
    } else {
        // Day data is assumed to be in HH:MM format (e.g., "8:45")
        if (timeStr.includes(':')) {
            const [hours, minutes] = timeStr.split(':').map(t => parseInt(t) || 0);
            return hours + (minutes / 60);
        } else {
            // Fallback for Day data: if it's just a number, treat it as decimal hours
            return parseFloat(timeStr) || 0;
        }
    }
};

export default function IPHCalculator() {
  // Main IPH Calculator State
  const [pickedItems1, setPickedItems1] = useState('');
  const [hours1, setHours1] = useState('');
  const [minutes1, setMinutes1] = useState('');
  const [seconds1, setSeconds1] = useState('');
  const [pickedItems2, setPickedItems2] = useState('');
  const [hours2, setHours2] = useState('');
  const [minutes2, setMinutes2] = useState('');
  const [seconds2, setSeconds2] = useState('');
  const [calculatedIPH, setCalculatedIPH] = useState(null);

  // Time Converter State
  const [decimalHoursInput, setDecimalHoursInput] = useState('');
  const [conversionResult, setConversionResult] = useState(null);

  // Bulk Data Upload State
  const [wtdData, setWtdData] = useState('');
  const [dayData, setDayData] = useState('');
  // Updated type for parsed data: { name: string, iph: number, items: number, time: string, timeInHours: number }
  const [wtdParsedData, setWtdParsedData] = useState([]);
  const [dayParsedData, setDayParsedData] = useState([]);
  const [isSaving, setIsSaving] = useState(false);

  // Save parameters - now auto-set to current period/week
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedPeriod, setSelectedPeriod] = useState(1);
  const [selectedWeek, setSelectedWeek] = useState(1);
  const [saveNotes, setSaveNotes] = useState('');

  // IPH Target state
  const [iphTarget, setIphTarget] = useState(85); // Default IPH target

  // Add sorting state for combined results
  const [combinedSortConfig, setCombinedSortConfig] = useState({ key: 'combinedIph', direction: 'asc' });

  // Add manual target calculator state
  const [nextShiftHours, setNextShiftHours] = useState(4); // Hours part
  const [nextShiftMinutes, setNextShiftMinutes] = useState(0); // Minutes part
  const [nextShiftItems, setNextShiftItems] = useState(''); // Manual items input

  // Add collapsible state for paste data
  const [isPasteDataVisible, setIsPasteDataVisible] = useState(false);

  // Helper function to determine current period and week
  const getCurrentPeriodAndWeek = async (year) => {
    try {
      const periods = await PeriodConfig.filter({ year: year }, 'period_number');
      
      if (periods.length === 0) {
        return { period: 1, week: 1 };
      }

      const today = new Date();
      today.setHours(0, 0, 0, 0); 

      const currentPeriodConfig = periods.find(p => {
        const startDate = new Date(p.start_date);
        const endDate = new Date(p.end_date);
        startDate.setHours(0, 0, 0, 0);
        endDate.setHours(0, 0, 0, 0);
        return today >= startDate && today <= endDate;
      });

      if (currentPeriodConfig) {
        const startDate = new Date(currentPeriodConfig.start_date);
        startDate.setHours(0, 0, 0, 0);
        const daysDiff = Math.floor((today - startDate) / (1000 * 60 * 60 * 24));
        const currentWeekNumber = Math.min(Math.floor(daysDiff / 7) + 1, 4); 
        
        return { period: currentPeriodConfig.period_number, week: currentWeekNumber };
      }
      
      // If today is not within any defined period, try to find the latest available period
      if (periods.length > 0) {
        const latestPeriod = periods.reduce((latest, current) => {
          const currentStartDate = new Date(current.start_date);
          const latestStartDate = new Date(latest.start_date);
          return currentStartDate > latestStartDate ? current : latest;
        }, periods[0]);
        
        return { period: latestPeriod.period_number, week: 4 };
      }

      return { period: 1, week: 1 };
    } catch (error) {
      console.error("Error determining current period:", error);
      return { period: 1, week: 1 };
    }
  };

  // Load current period/week and IPH target on mount
  useEffect(() => {
    const initialize = async () => {
      try {
        const currentYear = new Date().getFullYear();
        setSelectedYear(currentYear); // Ensure year is set before calling getCurrentPeriodAndWeek
        const { period, week } = await getCurrentPeriodAndWeek(currentYear);
        setSelectedPeriod(period);
        setSelectedWeek(week);
        
        // Load IPH target for the period
        const targets = await ShopperIPHTarget.filter({ period, year: currentYear });
        if (targets.length > 0) {
          setIphTarget(targets[0].iph_target);
        }
      } catch (error) {
        console.error("Error in initialization:", error);
      }
    };
    initialize();
  }, []);

  // Load IPH target when period or year changes
  useEffect(() => {
    const loadIphTarget = async () => {
      try {
        const targets = await ShopperIPHTarget.filter({ period: selectedPeriod, year: selectedYear });
        if (targets.length > 0) {
          setIphTarget(targets[0].iph_target);
        } else {
          setIphTarget(85); // Default fallback
        }
      } catch (error) {
        console.error("Error loading IPH target:", error);
        setIphTarget(85);
      }
    };
    loadIphTarget();
  }, [selectedPeriod, selectedYear]);

  // Load persistent data from localStorage on mount
  useEffect(() => {
    const savedWtdData = localStorage.getItem('iphCalculator_wtdData');
    const savedDayData = localStorage.getItem('iphCalculator_dayData');
    const savedWtdParsed = localStorage.getItem('iphCalculator_wtdParsed');
    const savedDayParsed = localStorage.getItem('iphCalculator_dayParsed');
    
    if (savedWtdData) setWtdData(savedWtdData);
    if (savedDayData) setDayData(savedDayData);
    if (savedWtdParsed) {
      try {
        setWtdParsedData(JSON.parse(savedWtdParsed));
      } catch (e) {
        console.error("Failed to parse saved WTD data:", e);
        localStorage.removeItem('iphCalculator_wtdParsed'); // Clear corrupted data
      }
    }
    if (savedDayParsed) {
      try {
        setDayParsedData(JSON.parse(savedDayParsed));
      } catch (e) {
        console.error("Failed to parse saved Day data:", e);
        localStorage.removeItem('iphCalculator_dayParsed'); // Clear corrupted data
      }
    }
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('iphCalculator_wtdData', wtdData);
  }, [wtdData]);

  useEffect(() => {
    localStorage.setItem('iphCalculator_dayData', dayData);
  }, [dayData]);

  useEffect(() => {
    localStorage.setItem('iphCalculator_wtdParsed', JSON.stringify(wtdParsedData));
  }, [wtdParsedData]);

  useEffect(() => {
    localStorage.setItem('iphCalculator_dayParsed', JSON.stringify(dayParsedData));
  }, [dayParsedData]);


  const calculateTimeFromHMS = (hours, minutes, seconds) => {
    const h = parseFloat(hours) || 0;
    const m = parseFloat(minutes) || 0;
    const s = parseFloat(seconds) || 0;
    return h + (m / 60) + (s / 3600);
  };

  const handleCalculateIPH = () => {
    const items1 = parseFloat(pickedItems1) || 0;
    const time1 = calculateTimeFromHMS(hours1, minutes1, seconds1);
    const items2 = parseFloat(pickedItems2) || 0;
    const time2 = calculateTimeFromHMS(hours2, minutes2, seconds2);

    const totalItems = items1 + items2;
    const totalTime = time1 + time2;

    if (totalItems <= 0 || totalTime <= 0) {
      toast.error("Please enter valid positive numbers. At least one day must have both items and time.");
      setCalculatedIPH(null);
      return;
    }

    const iph = totalItems / totalTime;
    setCalculatedIPH(iph);
  };

  const handleResetIPH = () => {
    setPickedItems1('');
    setHours1('');
    setMinutes1('');
    setSeconds1('');
    setPickedItems2('');
    setHours2('');
    setMinutes2('');
    setSeconds2('');
    setCalculatedIPH(null);
  };

  const handleConvertTime = () => {
    const decimal = parseFloat(decimalHoursInput);
    if (isNaN(decimal) || decimal < 0) {
      toast.error("Please enter a valid positive number for decimal hours.");
      setConversionResult(null);
      return;
    }
    const totalHours = Math.floor(decimal);
    const totalMinutes = Math.round((decimal - totalHours) * 60);
    setConversionResult({ hours: totalHours, minutes: totalMinutes });
  };

  const handleResetConverter = () => {
    setDecimalHoursInput('');
    setConversionResult(null);
  };

  const parseBulkData = (data, isWtd = false) => {
    if (!data.trim()) {
      toast.error(`Please paste ${isWtd ? 'WTD' : 'Day'} data before parsing.`);
      return [];
    }

    const lines = data.trim().split('\n');
    if (lines.length < 2) {
      toast.error("Data must include header row and at least one data row.");
      return [];
    }

    const headers = lines[0].split('\t').map(h => h.trim());
    
    // Find column indices - looking for Name, IPH, Items, Time
    const nameIndex = headers.findIndex(h => 
      h.toLowerCase().includes('name') || 
      h.toLowerCase().includes('user') ||
      h.toLowerCase() === 'id' // Added 'id' as a possible name identifier
    );
    
    const iphIndex = headers.findIndex(h => 
      h.toLowerCase().includes('iph')
    );
    
    const itemsIndex = headers.findIndex(h => 
      h.toLowerCase().includes('items') ||
      h.toLowerCase().includes('picked')
    );
    
    const timeIndex = headers.findIndex(h => 
      h.toLowerCase().includes('time') ||
      h.toLowerCase().includes('shift')
    );

    if (nameIndex === -1 || iphIndex === -1 || itemsIndex === -1 || timeIndex === -1) {
      toast.error("Could not find required columns: Name, IPH, Items, Time.");
      return [];
    }

    const parsed = [];
    for (let i = 1; i < lines.length; i++) {
      if (lines[i].trim()) {
        const values = lines[i].split('\t').map(v => v.trim());
        
        const name = values[nameIndex];
        const iph = parseFloat(values[iphIndex]) || 0;
        const items = parseInt(values[itemsIndex]) || 0;
        const time = values[timeIndex]; // Store as string for display
        
        // Only add if name is present, IPH is positive, and time is not empty, for meaningful data
        if (name && iph >= 0 && items >= 0 && time) { // IPH can be 0 or small for low performance
          parsed.push({
            name,
            iph,
            items,
            time, // Stored as a string for display and later conversion
            timeInHours: convertTimeToHours(time, isWtd) // Convert to hours immediately
          });
        }
      }
    }
    
    if (parsed.length === 0) {
      toast.error("No valid data rows found after parsing.");
      return [];
    }
    
    toast.success(`Parsed ${parsed.length} shoppers from ${isWtd ? 'WTD' : 'Day'} data.`);
    return parsed;
  };

  const handleParseWtdData = () => {
    const parsed = parseBulkData(wtdData, true);
    setWtdParsedData(parsed);
  };

  const handleParseDayData = () => {
    const parsed = parseBulkData(dayData, false);
    setDayParsedData(parsed);
  };

  const handleClearBulkData = (type) => {
    if (type === 'wtd') {
      setWtdData('');
      setWtdParsedData([]);
      localStorage.removeItem('iphCalculator_wtdData');
      localStorage.removeItem('iphCalculator_wtdParsed');
    } else {
      setDayData('');
      setDayParsedData([]);
      localStorage.removeItem('iphCalculator_dayData');
      localStorage.removeItem('iphCalculator_dayParsed');
    }
  };

  const handleClearAllData = () => {
    setWtdData('');
    setDayData('');
    setWtdParsedData([]);
    setDayParsedData([]);
    localStorage.removeItem('iphCalculator_wtdData');
    localStorage.removeItem('iphCalculator_dayData');
    localStorage.removeItem('iphCalculator_wtdParsed');
    localStorage.removeItem('iphCalculator_dayParsed');
    toast.success('All data cleared');
  };

  const handleParseAndSave = async () => {
    // First parse the data
    const wtdParsed = wtdData.trim() ? parseBulkData(wtdData, true) : [];
    const dayParsed = dayData.trim() ? parseBulkData(dayData, false) : [];
    
    setWtdParsedData(wtdParsed);
    setDayParsedData(dayParsed);

    if (wtdParsed.length === 0 && dayParsed.length === 0) {
      toast.error("No valid data to save. Please paste and parse data first.");
      return;
    }

    // Then save to database
    setIsSaving(true);

    try {
      const combined = {};
      
      // Combine WTD data
      wtdParsed.forEach(shopper => {
        combined[shopper.name] = { // Use shopper.name as key
          shopper_id: shopper.name, // Assuming name can serve as ID for now
          shopper_name: shopper.name,
          wtd_items: shopper.items,
          wtd_time_hours: shopper.timeInHours, // Use pre-converted time
          wtd_iph: shopper.iph, // Use parsed IPH
          day_items: 0,
          day_time_hours: 0,
          day_iph: 0
        };
      });

      // Add day data
      dayParsed.forEach(shopper => {
        if (combined[shopper.name]) {
          combined[shopper.name].day_items = shopper.items;
          combined[shopper.name].day_time_hours = shopper.timeInHours; // Use pre-converted time
          combined[shopper.name].day_iph = shopper.iph;
        } else {
          combined[shopper.name] = {
            shopper_id: shopper.name,
            shopper_name: shopper.name,
            wtd_items: 0,
            wtd_time_hours: 0,
            wtd_iph: 0,
            day_items: shopper.items,
            day_time_hours: shopper.timeInHours, // Use pre-converted time
            day_iph: shopper.iph
          };
        }
      });

      // Calculate combined values and create records to save
      const recordsToSave = Object.values(combined).map(shopper => {
        const combinedItems = shopper.wtd_items + shopper.day_items;
        const combinedTime = shopper.wtd_time_hours + shopper.day_time_hours;
        
        let calculatedCombinedIph;
        // If we have both WTD and Day data (items from both sources), calculate combined IPH
        if (shopper.wtd_items > 0 && shopper.day_items > 0) {
          calculatedCombinedIph = combinedTime > 0 ? combinedItems / combinedTime : 0;
        }
        // If only WTD data (items only from WTD source), trust the provided WTD IPH
        else if (shopper.wtd_items > 0 && shopper.day_items === 0) {
          calculatedCombinedIph = shopper.wtd_iph;
        }
        // If only Day data (items only from Day source), trust the provided Day IPH  
        else if (shopper.wtd_items === 0 && shopper.day_items > 0) {
          calculatedCombinedIph = shopper.day_iph;
        }
        // Fallback or no data
        else {
          calculatedCombinedIph = 0;
        }

        return {
          calculation_date: new Date().toISOString(),
          calculation_type: "wtd_day_combined",
          shopper_id: shopper.shopper_id,
          shopper_name: shopper.shopper_name,
          wtd_items: shopper.wtd_items,
          wtd_time_hours: shopper.wtd_time_hours,
          wtd_iph: shopper.wtd_iph,
          day_items: shopper.day_items,
          day_time_hours: shopper.day_time_hours,
          day_iph: shopper.day_iph,
          combined_items: combinedItems,
          combined_time_hours: combinedTime,
          combined_iph: calculatedCombinedIph,
          period: selectedPeriod,
          week: selectedWeek,
          year: selectedYear,
          notes: saveNotes || `IPH calculation for ${Object.keys(combined).length} shoppers`
        };
      });

      // Save all records
      await toast.promise(
        IPHCalculationResult.bulkCreate(recordsToSave),
        {
          loading: `Saving ${recordsToSave.length} IPH calculation results...`,
          success: `Successfully saved ${recordsToSave.length} IPH calculations for P${selectedPeriod}W${selectedWeek} ${selectedYear}!`,
          error: 'Failed to save IPH calculation results.'
        }
      );

      // Clear notes after successful save
      setSaveNotes('');

    } catch (error) {
      console.error("Error saving IPH calculations:", error);
      toast.error("Failed to save calculation results.");
    } finally {
      setIsSaving(false);
    }
  };

  const calculateCombinedIPH = () => {
    if (wtdParsedData.length === 0 && dayParsedData.length === 0) return null;

    // Combine data by user name
    const combined = {};
    
    wtdParsedData.forEach(shopper => {
      combined[shopper.name] = { // Use shopper.name as key
        name: shopper.name,
        wtdItems: shopper.items,
        wtdTime: shopper.timeInHours, // Use pre-converted time
        wtdIph: shopper.iph,
        dayItems: 0,
        dayTime: 0,
        dayIph: 0
      };
    });

    dayParsedData.forEach(shopper => {
      if (combined[shopper.name]) {
        combined[shopper.name].dayItems = shopper.items;
        combined[shopper.name].dayTime = shopper.timeInHours; // Use pre-converted time
        combined[shopper.name].dayIph = shopper.iph;
      } else {
        combined[shopper.name] = {
          name: shopper.name,
          wtdItems: 0,
          wtdTime: 0,
          wtdIph: 0,
          dayItems: shopper.items,
          dayTime: shopper.timeInHours, // Use pre-converted time
          dayIph: shopper.iph
        };
      }
    });

    // Calculate totals and combined IPH
    let totalItems = 0;
    let totalTime = 0;
    let shoppersAchieving = 0; // New: Counter for shoppers achieving target
    const results = [];

    Object.values(combined).forEach(shopper => {
      const combinedItems = shopper.wtdItems + shopper.dayItems;
      const combinedTime = shopper.wtdTime + shopper.dayTime;
      
      let combinedIph;
      // If we have both WTD and Day data (items from both sources), calculate combined IPH
      if (shopper.wtdItems > 0 && shopper.dayItems > 0) {
        combinedIph = combinedTime > 0 ? combinedItems / combinedTime : 0;
      }
      // If only WTD data (items only from WTD source), trust the provided WTD IPH
      else if (shopper.wtdItems > 0 && shopper.dayItems === 0) {
        combinedIph = shopper.wtdIph;
      }
      // If only Day data (items only from Day source), trust the provided Day IPH  
      else if (shopper.wtdItems === 0 && shopper.dayItems > 0) {
        combinedIph = shopper.dayIph;
      }
      // Fallback or no data
      else {
        combinedIph = 0;
      }
      
      totalItems += combinedItems;
      totalTime += combinedTime;

      // Check if shopper achieves target
      if (combinedIph >= iphTarget) {
        shoppersAchieving++;
      }
      
      results.push({
        ...shopper,
        combinedItems,
        combinedTime,
        combinedIph
      });
    });

    const overallIph = totalTime > 0 ? totalItems / totalTime : 0;
    const totalShoppers = results.length;
    const achievementRate = totalShoppers > 0 ? (shoppersAchieving / totalShoppers) * 100 : 0;
    
    return {
      shoppers: results,
      totals: { 
        totalItems, 
        totalTime, 
        overallIph,
        shoppersAchieving, // New: Number of shoppers achieving target
        totalShoppers,    // New: Total number of shoppers
        achievementRate   // New: Percentage of shoppers achieving target
      }
    };
  };

  // Format time from decimal hours to "Xh Ym" format
  const formatTimeDisplay = (decimalHours) => {
    if (decimalHours === null || typeof decimalHours === 'undefined' || isNaN(decimalHours)) return "N/A";
    if (decimalHours === 0) return "0h 0m";
    const hours = Math.floor(decimalHours);
    const minutes = Math.round((decimalHours - hours) * 60);
    return `${hours}h ${minutes}m`;
  };

  // Sort combined results
  const sortCombinedResults = (results) => {
    if (!combinedSortConfig.key || !results) return results;
    
    return [...results].sort((a, b) => {
      const aVal = a[combinedSortConfig.key];
      const bVal = b[combinedSortConfig.key];
      
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return combinedSortConfig.direction === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      
      if (combinedSortConfig.direction === 'asc') {
        return aVal - bVal;
      } else {
        return bVal - aVal;
      }
    });
  };

  // Handle sorting request
  const handleCombinedSort = (key) => {
    let direction = 'desc';
    if (combinedSortConfig.key === key && combinedSortConfig.direction === 'desc') {
      direction = 'asc';
    }
    setCombinedSortConfig({ key, direction });
  };

  const combinedResults = calculateCombinedIPH();
  const sortedCombinedResults = combinedResults ? {
    ...combinedResults,
    shoppers: sortCombinedResults(combinedResults.shoppers)
  } : null;


  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">IPH Calculator</h1>
          <p className="text-gray-600 mt-1">Calculate individual and bulk IPH for shoppers - Currently set to P{selectedPeriod}W{selectedWeek} {selectedYear}.</p>
        </div>
      </div>

      <Tabs defaultValue="bulk" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="individual">Individual Calculator</TabsTrigger>
          <TabsTrigger value="bulk">Bulk Data Upload</TabsTrigger>
          <TabsTrigger value="converter">Time Converter</TabsTrigger>
        </TabsList>

        <TabsContent value="individual">
          <Card className="glass-card">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 modern-gradient rounded-full flex items-center justify-center mb-4">
                <Calculator className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-slate-800">IPH Calculator</CardTitle>
              <CardDescription className="text-slate-600">
                Calculate a shopper's Items Per Hour based on their performance across multiple days.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Week to Date Column */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-slate-700 text-center">Week to Date</h3>
                  <div className="space-y-2">
                    <label htmlFor="pickedItems1" className="text-sm font-medium text-slate-700 flex items-center">
                      <ShoppingBasket className="w-4 h-4 mr-2 text-slate-500" />
                      Picked Items
                    </label>
                    <Input
                      id="pickedItems1"
                      type="number"
                      placeholder="e.g., 1500"
                      value={pickedItems1}
                      onChange={(e) => setPickedItems1(e.target.value)}
                      className="input-modern"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700 flex items-center">
                      <Clock className="w-4 h-4 mr-2 text-slate-500" />
                      Shift Time
                    </label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Hrs"
                        value={hours1}
                        onChange={(e) => setHours1(e.target.value)}
                        className="input-modern flex-1"
                      />
                      <Input
                        type="number"
                        placeholder="Min"
                        value={minutes1}
                        onChange={(e) => setMinutes1(e.target.value)}
                        className="input-modern flex-1"
                      />
                      <Input
                        type="number"
                        placeholder="Sec"
                        value={seconds1}
                        onChange={(e) => setSeconds1(e.target.value)}
                        className="input-modern flex-1"
                      />
                    </div>
                  </div>
                </div>

                {/* In Day Column */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-slate-700 text-center">In Day</h3>
                  <div className="space-y-2">
                    <label htmlFor="pickedItems2" className="text-sm font-medium text-slate-700 flex items-center">
                      <ShoppingBasket className="w-4 h-4 mr-2 text-slate-500" />
                      Picked Items
                    </label>
                    <Input
                      id="pickedItems2"
                      type="number"
                      placeholder="e.g., 1200"
                      value={pickedItems2}
                      onChange={(e) => setPickedItems2(e.target.value)}
                      className="input-modern"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700 flex items-center">
                      <Clock className="w-4 h-4 mr-2 text-slate-500" />
                      Shift Time
                    </label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Hrs"
                        value={hours2}
                        onChange={(e) => setHours2(e.target.value)}
                        className="input-modern flex-1"
                      />
                      <Input
                        type="number"
                        placeholder="Min"
                        value={minutes2}
                        onChange={(e) => setMinutes2(e.target.value)}
                        className="input-modern flex-1"
                      />
                      <Input
                        type="number"
                        placeholder="Sec"
                        value={seconds2}
                        onChange={(e) => setSeconds2(e.target.value)}
                        className="input-modern flex-1"
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-4">
                <Button onClick={handleResetIPH} variant="outline" className="w-full">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reset
                </Button>
                <Button onClick={handleCalculateIPH} className="w-full btn-modern">
                  <Calculator className="w-4 h-4 mr-2" />
                  Calculate IPH
                </Button>
              </div>

              {calculatedIPH !== null && (
                <div className="mt-6 text-center p-6 bg-slate-50/80 rounded-lg border border-slate-200">
                  <p className="text-sm font-medium text-slate-600">Combined IPH</p>
                  <p className="text-5xl font-bold text-blue-600 tracking-tight mt-2">
                    {calculatedIPH.toFixed(2)}
                  </p>
                  <div className="text-xs text-slate-500 mt-2 space-y-1">
                    <p>Total: {(parseFloat(pickedItems1) || 0) + (parseFloat(pickedItems2) || 0)} items ÷ {(calculateTimeFromHMS(hours1, minutes1, seconds1) + calculateTimeFromHMS(hours2, minutes2, seconds2)).toFixed(2)} hours</p>
                    {(pickedItems1 && (hours1 || minutes1 || seconds1)) && (
                      <p>Week to Date: {pickedItems1} items ÷ {calculateTimeFromHMS(hours1, minutes1, seconds1).toFixed(2)} hours = {((parseFloat(pickedItems1) || 0) / (calculateTimeFromHMS(hours1, minutes1, seconds1) || 1)).toFixed(2)} IPH</p>
                    )}
                    {(pickedItems2 && (hours2 || minutes2 || seconds2)) && (
                      <p>In Day: {pickedItems2} items ÷ {calculateTimeFromHMS(hours2, minutes2, seconds2).toFixed(2)} hours = {((parseFloat(pickedItems2) || 0) / (calculateTimeFromHMS(hours2, minutes2, seconds2) || 1)).toFixed(2)} IPH</p>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bulk">
          <div className="space-y-6">
            {/* Save Parameters Card */}
            <Card className="glass-card border-2 border-blue-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-700">
                  <Database className="w-5 h-5" />
                  Save Parameters
                </CardTitle>
                <CardDescription>
                  Set the period information for saving IPH calculation results
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Year</label>
                    <Select value={selectedYear.toString()} onValueChange={(val) => setSelectedYear(parseInt(val))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 3 }, (_, i) => new Date().getFullYear() - 1 + i).map(y => (
                          <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Period</label>
                    <Select value={selectedPeriod.toString()} onValueChange={(val) => setSelectedPeriod(parseInt(val))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 13 }, (_, i) => i + 1).map(p => (
                          <SelectItem key={p} value={p.toString()}>Period {p}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Week</label>
                    <Select value={selectedWeek.toString()} onValueChange={(val) => setSelectedWeek(parseInt(val))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 4 }, (_, i) => i + 1).map(w => (
                          <SelectItem key={w} value={w.toString()}>Week {w}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Notes (Optional)</label>
                  <Input
                    placeholder="e.g., End of week calculation, Performance review data"
                    value={saveNotes}
                    onChange={(e) => setSaveNotes(e.target.value)}
                    className="mt-1"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Data Input Cards */}
            <div className="space-y-6">
              {/* Collapsible Paste Data Section */}
              <Card className="glass-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-blue-600" />
                      Data Input
                    </CardTitle>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setIsPasteDataVisible(!isPasteDataVisible)}
                      className="text-blue-600 hover:bg-blue-50"
                    >
                      {isPasteDataVisible ? 'Hide' : 'Show'} Data Input
                    </Button>
                  </div>
                </CardHeader>
                {isPasteDataVisible && (
                  <CardContent>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
                            <FileText className="w-5 h-5 text-blue-600" />
                            Week to Date Data
                          </h3>
                          <CardDescription className="mb-4">
                            Paste your WTD performance data from the system export
                          </CardDescription>
                        </div>
                        <div className="p-3 bg-blue-50 rounded-lg text-sm">
                          <p className="font-medium mb-1">Expected columns:</p>
                          <p>Name, IPH, Items, Time (Time is expected in decimal hours e.g., 8.75)</p>
                        </div>
                        <Textarea
                          placeholder="Paste WTD data here (tab-separated with headers)..."
                          className="h-32 font-mono text-xs"
                          value={wtdData}
                          onChange={(e) => setWtdData(e.target.value)}
                        />
                        <div className="flex gap-2">
                          <Button onClick={handleParseWtdData} disabled={!wtdData.trim()} className="flex-1">
                            <Upload className="w-4 h-4 mr-2" />
                            Parse WTD Data
                          </Button>
                          <Button variant="outline" onClick={() => handleClearBulkData('wtd')} size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        {wtdParsedData.length > 0 && (
                          <div className="text-sm text-green-600 mb-2">
                            ✓ Parsed {wtdParsedData.length} shoppers from WTD data
                          </div>
                        )}
                        
                        {/* WTD Data Table */}
                        {wtdParsedData.length > 0 && (
                          <div className="border border-gray-200 rounded-lg">
                            <Table>
                              <TableHeader>
                                <TableRow className="bg-gray-50">
                                  <TableHead className="font-semibold py-2">Name</TableHead>
                                  <TableHead className="text-center font-semibold py-2">IPH</TableHead>
                                  <TableHead className="text-center font-semibold py-2">Items</TableHead>
                                  <TableHead className="text-center font-semibold py-2">Time (Hrs)</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {wtdParsedData.map((shopper, index) => (
                                  <TableRow key={index} className="hover:bg-gray-50">
                                    <TableCell className="font-medium py-2">{shopper.name}</TableCell>
                                    <TableCell className="text-center py-2">{shopper.iph.toFixed(2)}</TableCell>
                                    <TableCell className="text-center py-2">{shopper.items}</TableCell>
                                    <TableCell className="text-center py-2">{shopper.timeInHours.toFixed(2)}</TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        )}
                      </div>

                      <div className="space-y-4">
                        <div>
                          <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
                            <FileText className="w-5 h-5 text-green-600" />
                            Day Data
                          </h3>
                          <CardDescription className="mb-4">
                            Paste your daily performance data from the system export
                          </CardDescription>
                        </div>
                        <div className="p-3 bg-green-50 rounded-lg text-sm">
                          <p className="font-medium mb-1">Expected columns:</p>
                          <p>Name, IPH, Items, Time (Time is expected in HH:MM format e.g., 8:45)</p>
                        </div>
                        <Textarea
                          placeholder="Paste Day data here (tab-separated with headers)..."
                          className="h-32 font-mono text-xs"
                          value={dayData}
                          onChange={(e) => setDayData(e.target.value)}
                        />
                        <div className="flex gap-2">
                          <Button onClick={handleParseDayData} disabled={!dayData.trim()} className="flex-1">
                            <Upload className="w-4 h-4 mr-2" />
                            Parse Day Data
                          </Button>
                          <Button variant="outline" onClick={() => handleClearBulkData('day')} size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        {dayParsedData.length > 0 && (
                          <div className="text-sm text-green-600 mb-2">
                            ✓ Parsed {dayParsedData.length} shoppers from Day data
                          </div>
                        )}
                        
                        {/* Day Data Table */}
                        {dayParsedData.length > 0 && (
                          <div className="border border-gray-200 rounded-lg">
                            <Table>
                              <TableHeader>
                                <TableRow className="bg-gray-50">
                                  <TableHead className="font-semibold py-2">Name</TableHead>
                                  <TableHead className="text-center font-semibold py-2">IPH</TableHead>
                                  <TableHead className="text-center font-semibold py-2">Items</TableHead>
                                  <TableHead className="text-center font-semibold py-2">Time (Hrs)</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {dayParsedData.map((shopper, index) => (
                                  <TableRow key={index} className="hover:bg-gray-50">
                                    <TableCell className="font-medium py-2">{shopper.name}</TableCell>
                                    <TableCell className="text-center py-2">{shopper.iph.toFixed(2)}</TableCell>
                                    <TableCell className="text-center py-2">{shopper.items}</TableCell>
                                    <TableCell className="text-center py-2">{shopper.timeInHours.toFixed(2)}</TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-center gap-4">
              <Button
                variant="outline"
                onClick={handleClearAllData}
                className="border-red-200 text-red-600 hover:bg-red-50 px-6 py-2"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All Data
              </Button>
              <Button
                onClick={handleParseAndSave}
                disabled={isSaving || (!wtdData.trim() && !dayData.trim())}
                className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white px-8 py-3 text-lg"
              >
                {isSaving ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                    Parsing & Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-5 h-5 mr-3" />
                    Parse Data and Save
                  </>
                )}
              </Button>
            </div>

            {/* Results Table */}
            {sortedCombinedResults && (
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Combined IPH Results - P{selectedPeriod}W{selectedWeek} {selectedYear}
                  </CardTitle>
                  {/* Moved CardDescription here as a direct child of CardHeader */}
                  <CardDescription className="mt-2">
                    Combined performance analysis for all shoppers (Target: {iphTarget} IPH)
                  </CardDescription>
                  <div className="flex justify-between items-center mt-2">
                    <div className="flex flex-col items-center">
                      <Target className="w-5 h-5 text-green-600 mb-1" />
                      <div className="text-sm font-medium text-gray-600 mb-1 text-center">Shoppers Achieving Target</div>
                      <div className="text-2xl font-bold text-orange-600 mb-2 text-center">
                        {sortedCombinedResults.totals.shoppersAchieving} / {sortedCombinedResults.totals.totalShoppers}
                      </div>
                      <div className="grid grid-cols-2 gap-4 mb-2 text-center">
                        <div>
                          <div className="text-xs text-gray-500">Remaining to Hit Target</div>
                          <div className="text-lg font-bold text-orange-600">
                            {Math.max(0, sortedCombinedResults.totals.totalShoppers - sortedCombinedResults.totals.shoppersAchieving)}
                          </div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-500">Required to Hit 80%</div>
                          <div className="text-lg font-bold text-red-600">
                            {Math.max(0, Math.ceil(sortedCombinedResults.totals.totalShoppers * 0.8) - sortedCombinedResults.totals.shoppersAchieving)}
                          </div>
                        </div>
                      </div>
                      <div className="bg-orange-50 rounded-lg px-3 py-2 text-center">
                        <div className="text-xs text-gray-600 mb-1">Achievement Rate</div>
                        <div className="text-xl font-bold text-orange-600">
                          {sortedCombinedResults.totals.achievementRate.toFixed(2)}%
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 bg-purple-50 rounded-lg p-3 border border-purple-200">
                      <Calculator className="w-4 h-4 text-purple-600" />
                        <div className="flex flex-col gap-2">
                          <label className="text-xs font-medium text-purple-700">Next Shift Calculator</label>
                          <div className="flex gap-2 items-end">
                            <div className="flex flex-col">
                              <label className="text-xs text-purple-600">Target IPH</label>
                              <Input
                                type="number"
                                step="0.1"
                                value={iphTarget}
                                onChange={(e) => setIphTarget(parseFloat(e.target.value) || 85)}
                                className="w-16 h-8 text-xs text-center border-purple-300"
                              />
                            </div>
                            <div className="flex flex-col">
                              <label className="text-xs text-purple-600">Items</label>
                              <Input
                                type="number"
                                value={nextShiftItems}
                                onChange={(e) => setNextShiftItems(e.target.value)}
                                className="w-20 h-8 text-xs text-center border-purple-300"
                                placeholder="Items"
                              />
                            </div>
                            <div className="flex flex-col">
                              <label className="text-xs text-purple-600">Hours</label>
                              <Input
                                type="number"
                                value={nextShiftHours}
                                onChange={(e) => setNextShiftHours(parseInt(e.target.value) || 0)}
                                className="w-14 h-8 text-xs text-center border-purple-300"
                                placeholder="H"
                              />
                            </div>
                            <div className="flex flex-col">
                              <label className="text-xs text-purple-600">Minutes</label>
                              <Input
                                type="number"
                                min="0"
                                max="59"
                                value={nextShiftMinutes}
                                onChange={(e) => setNextShiftMinutes(Math.min(59, Math.max(0, parseInt(e.target.value) || 0)))}
                                className="w-14 h-8 text-xs text-center border-purple-300"
                                placeholder="M"
                              />
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setNextShiftItems('');
                                setNextShiftHours(4);
                                setNextShiftMinutes(0);
                              }}
                              className="h-8 px-2 text-xs border-purple-300 text-purple-600 hover:bg-purple-100"
                            >
                              Reset
                            </Button>
                          </div>
                        </div>
                      </div>
                  </div>
                </CardHeader>
                <CardContent>                  
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="py-2">#</TableHead>
                          <TableHead className="py-2">Shopper</TableHead>
                          <TableHead className="text-center py-2">WTD Items</TableHead>
                          <TableHead className="text-center py-2">WTD Time</TableHead>
                          <TableHead className="text-center py-2">WTD IPH</TableHead>
                          <TableHead className="text-center py-2">Day Items</TableHead>
                          <TableHead className="text-center py-2">Day Time</TableHead>
                          <TableHead className="text-center py-2">Day IPH</TableHead>
                          <TableHead 
                            className="text-center bg-blue-50 cursor-pointer hover:bg-blue-100 py-2"
                            onClick={() => handleCombinedSort('combinedItems')}
                          >
                            <div className="flex items-center justify-center gap-1">
                              Combined Items
                              <div className="flex flex-col">
                                <div className={`w-0 h-0 border-l-2 border-r-2 border-b-2 border-transparent border-b-gray-400 ${combinedSortConfig.key === 'combinedItems' && combinedSortConfig.direction === 'asc' ? 'border-b-blue-600' : ''}`}></div>
                                <div className={`w-0 h-0 border-l-2 border-r-2 border-t-2 border-transparent border-t-gray-400 ${combinedSortConfig.key === 'combinedItems' && combinedSortConfig.direction === 'desc' ? 'border-t-blue-600' : ''}`}></div>
                              </div>
                            </div>
                          </TableHead>
                          <TableHead 
                            className="text-center bg-blue-50 cursor-pointer hover:bg-blue-100 py-2"
                            onClick={() => handleCombinedSort('combinedTime')}
                          >
                            <div className="flex items-center justify-center gap-1">
                              Combined Time
                              <div className="flex flex-col">
                                <div className={`w-0 h-0 border-l-2 border-r-2 border-b-2 border-transparent border-b-gray-400 ${combinedSortConfig.key === 'combinedTime' && combinedSortConfig.direction === 'asc' ? 'border-b-blue-600' : ''}`}></div>
                                <div className={`w-0 h-0 border-l-2 border-r-2 border-t-2 border-transparent border-t-gray-400 ${combinedSortConfig.key === 'combinedTime' && combinedSortConfig.direction === 'desc' ? 'border-t-blue-600' : ''}`}></div>
                              </div>
                            </div>
                          </TableHead>
                          <TableHead 
                            className="text-center bg-blue-50 cursor-pointer hover:bg-blue-100 py-2"
                            onClick={() => handleCombinedSort('combinedIph')}
                          >
                            <div className="flex items-center justify-center gap-1">
                              Combined IPH
                              <div className="flex flex-col">
                                <div className={`w-0 h-0 border-l-2 border-r-2 border-b-2 border-transparent border-b-gray-400 ${combinedSortConfig.key === 'combinedIph' && combinedSortConfig.direction === 'asc' ? 'border-b-blue-600' : ''}`}></div>
                                <div className={`w-0 h-0 border-l-2 border-r-2 border-t-2 border-transparent border-t-gray-400 ${combinedSortConfig.key === 'combinedIph' && combinedSortConfig.direction === 'desc' ? 'border-t-blue-600' : ''}`}></div>
                              </div>
                            </div>
                          </TableHead>
                          <TableHead className="text-center bg-purple-50 py-2">
                            To Hit Target
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {sortedCombinedResults.shoppers.map((shopper, index) => {
                          const actualNextShiftHours = (parseInt(nextShiftHours) || 0) + ((parseInt(nextShiftMinutes) || 0) / 60);
                          const manualItemsInput = nextShiftItems.trim(); // Get the string input
                          const manualItems = parseFloat(manualItemsInput) || 0; // Convert to number, 0 if invalid or empty

                          let nextShiftItemsNeeded, nextShiftIPHNeeded, calculationNote = '', willHitTarget = false;
                          
                          // Only use manual calculation if they haven't hit target yet AND manual input is provided
                          if (shopper.combinedIph < iphTarget && manualItemsInput && actualNextShiftHours > 0) {
                            // Manual calculation: check if manual items + hours hits target
                            const projectedCombinedItems = shopper.combinedItems + manualItems;
                            const projectedCombinedTime = shopper.combinedTime + actualNextShiftHours;
                            const projectedCombinedIPH = projectedCombinedTime > 0 ? projectedCombinedItems / projectedCombinedTime : 0;
                            
                            nextShiftItemsNeeded = manualItems; // Initialize with manual input
                            nextShiftIPHNeeded = actualNextShiftHours > 0 ? manualItems / actualNextShiftHours : 0;
                            willHitTarget = projectedCombinedIPH >= iphTarget;
                            calculationNote = willHitTarget ? ' ✓' : ' ✗';
                            
                            // If they hit target with the manual input, find the minimum items needed and display that
                            if (willHitTarget) {
                              const targetCombinedItems = iphTarget * (shopper.combinedTime + actualNextShiftHours);
                              const minItemsToHitTargetInShift = Math.max(0, Math.round(targetCombinedItems - shopper.combinedItems));
                              nextShiftItemsNeeded = minItemsToHitTargetInShift;
                              nextShiftIPHNeeded = actualNextShiftHours > 0 ? nextShiftItemsNeeded / actualNextShiftHours : 0;
                            }
                          } else {
                            // Auto calculation: what they need to hit target (only relevant if shopper.combinedIph < iphTarget)
                            const targetCombinedItems = iphTarget * (shopper.combinedTime + actualNextShiftHours);
                            nextShiftItemsNeeded = Math.max(0, Math.round(targetCombinedItems - shopper.combinedItems));
                            nextShiftIPHNeeded = actualNextShiftHours > 0 ? nextShiftItemsNeeded / actualNextShiftHours : 0;
                            willHitTarget = false; // Default for auto calculation in this path
                          }

                          // Determine row color - manual calculation only affects those below target
                          const currentlyHitsTarget = shopper.combinedIph >= iphTarget;
                          const rowColorClass = currentlyHitsTarget 
                            ? 'bg-green-50 hover:bg-green-100' // Always green if they hit target
                            : (manualItemsInput && actualNextShiftHours > 0) 
                              ? (willHitTarget ? 'bg-green-50 hover:bg-green-100' : 'bg-red-50 hover:bg-red-100')
                              : 'hover:bg-gray-50';

                          return (
                            <TableRow key={shopper.name} className={`${rowColorClass} py-1`}>
                              <TableCell className="font-medium text-gray-500 py-1">{index + 1}</TableCell>
                              <TableCell className="font-medium py-1">
                                {shopper.name}
                                {shopper.name === 'Elliot Lemons' && (
                                  <div className="text-xs text-red-600 mt-1">
                                    Debug: WTD={shopper.wtdTime.toFixed(3)}h, Day={shopper.dayTime.toFixed(3)}h
                                  </div>
                                )}
                              </TableCell>
                              <TableCell className="text-center py-1">{shopper.wtdItems.toLocaleString()}</TableCell>
                              <TableCell className="text-center py-1">{formatTimeDisplay(shopper.wtdTime)}</TableCell>
                              <TableCell className="text-center py-1">{shopper.wtdIph > 0 ? shopper.wtdIph.toFixed(2) : '-'}</TableCell>
                              <TableCell className="text-center py-1">{shopper.dayItems.toLocaleString()}</TableCell>
                              <TableCell className="text-center py-1">{formatTimeDisplay(shopper.dayTime)}</TableCell>
                              <TableCell className="text-center py-1">{shopper.dayIph > 0 ? shopper.dayIph.toFixed(2) : '-'}</TableCell>
                              <TableCell className="text-center font-bold bg-blue-50 py-1">{shopper.combinedItems.toLocaleString()}</TableCell>
                              <TableCell className="text-center font-bold bg-blue-50 py-1">{formatTimeDisplay(shopper.combinedTime)}</TableCell>
                              <TableCell className="text-center font-bold bg-blue-50 py-1">{shopper.combinedIph.toFixed(2)}</TableCell>
                              <TableCell className="text-center bg-purple-50 py-1">
                                {shopper.combinedIph >= iphTarget ? (
                                  <span className="text-green-600 font-medium text-xs">✓ Already Achieved</span>
                                ) : (
                                  <div className="text-xs text-purple-600">
                                    <span className="font-medium">{Math.round(nextShiftItemsNeeded).toLocaleString()} items</span>
                                    <span className="mx-1">at</span>
                                    <span className="font-medium">{nextShiftIPHNeeded.toFixed(1)} IPH</span>
                                    <span className="mx-1">in</span>
                                    <span className="font-medium">
                                      {actualNextShiftHours >= 1 ? `${Math.floor(actualNextShiftHours)}h` : ''}
                                      {actualNextShiftHours % 1 !== 0 ? ` ${Math.round((actualNextShiftHours % 1) * 60)}m` : (actualNextShiftHours < 1 && actualNextShiftHours > 0) ? `${Math.round(actualNextShiftHours * 60)}m` : ''}
                                    </span>
                                    {calculationNote && (
                                      <span className={`ml-1 font-bold ${willHitTarget ? 'text-green-600' : 'text-red-600'}`}>
                                        {calculationNote}
                                      </span>
                                    )}
                                  </div>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                        <TableRow className="bg-gray-100 font-bold border-t-2">
                          <TableCell className="py-2">TOTAL</TableCell>
                          <TableCell className="py-2"></TableCell>
                          <TableCell className="text-center py-2">
                            {sortedCombinedResults.shoppers.reduce((sum, s) => sum + s.wtdItems, 0).toLocaleString()}
                          </TableCell>
                          <TableCell className="text-center py-2">
                            {formatTimeDisplay(sortedCombinedResults.shoppers.reduce((sum, s) => sum + s.wtdTime, 0))}
                          </TableCell>
                          <TableCell className="text-center py-2">-</TableCell>
                          <TableCell className="text-center py-2">
                            {sortedCombinedResults.shoppers.reduce((sum, s) => sum + s.dayItems, 0).toLocaleString()}
                          </TableCell>
                          <TableCell className="text-center py-2">
                            {formatTimeDisplay(sortedCombinedResults.shoppers.reduce((sum, s) => sum + s.dayTime, 0))}
                          </TableCell>
                          <TableCell className="text-center py-2">-</TableCell>
                          <TableCell className="text-center bg-blue-100 py-2">{sortedCombinedResults.totals.totalItems.toLocaleString()}</TableCell>
                          <TableCell className="text-center bg-blue-100 py-2">{formatTimeDisplay(sortedCombinedResults.totals.totalTime)}</TableCell>
                          <TableCell className="text-center bg-blue-100 py-2">{sortedCombinedResults.totals.overallIph.toFixed(2)}</TableCell>
                          <TableCell className="text-center bg-purple-100 py-2">-</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="converter">
          <Card className="glass-card shadow-xl">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-full flex items-center justify-center mb-4">
                <ArrowRightLeft className="w-8 h-8 text-indigo-600" />
              </div>
              <CardTitle className="text-2xl font-bold text-slate-800">Time Converter</CardTitle>
              <CardDescription className="text-slate-600">
                Convert decimal hours to an hours and minutes format.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 p-6">
              <div className="space-y-2">
                <label htmlFor="decimalHours" className="text-sm font-medium text-slate-700 flex items-center">
                  <Clock className="w-4 h-4 mr-2 text-slate-500" />
                  Decimal Hours
                </label>
                <Input
                  id="decimalHours"
                  type="number"
                  step="0.01"
                  placeholder="e.g., 8.75"
                  value={decimalHoursInput}
                  onChange={(e) => setDecimalHoursInput(e.target.value)}
                  className="input-modern"
                />
              </div>
              
              <div className="flex gap-4">
                <Button onClick={handleResetConverter} variant="outline" className="w-full">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reset
                </Button>
                <Button onClick={handleConvertTime} className="w-full btn-modern bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600">
                  <ArrowRightLeft className="w-4 h-4 mr-2" />
                  Convert
                </Button>
              </div>

              {conversionResult !== null && (
                <div className="mt-6 text-center p-6 bg-slate-50/80 rounded-lg border border-slate-200">
                  <p className="text-sm font-medium text-slate-600">Converted Time</p>
                  <p className="text-4xl font-bold text-indigo-600 tracking-tight mt-2">
                    {conversionResult.hours} <span className="text-2xl font-medium text-slate-500">hours</span> {conversionResult.minutes} <span className="text-2xl font-medium text-slate-500">mins</span>
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}