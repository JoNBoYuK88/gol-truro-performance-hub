import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Calendar, Plus, Trash2, ChevronLeft, ChevronRight, Users, Lock, Unlock, ChevronDown, ChevronUp, Save, ChevronsDown, ChevronsUp } from 'lucide-react';
import { format, addDays, startOfWeek } from 'date-fns';
import { toast } from 'sonner';

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const SHIFTS = ['AM', 'PM', 'Driver Support'];

const calculateShiftHours = (shiftString) => {
  if (!shiftString || !shiftString.includes('-')) return 0;
  const [start, end] = shiftString.split('-');
  const [startHour, startMin] = start.split(':').map(Number);
  const [endHour, endMin] = end.split(':').map(Number);
  const startMinutes = startHour * 60 + startMin;
  const endMinutes = endHour * 60 + endMin;
  return (endMinutes - startMinutes) / 60;
};

const getEmployeeColor = (employeeName, shiftTime = '', slotEmployees = []) => {
  if (hasRedOutline(employeeName)) return 'bg-red-300 border-blue-700';
  if (hasPirateIcon(employeeName, shiftTime, slotEmployees)) return 'bg-purple-300 border-purple-700';
  return 'bg-blue-300 border-blue-700';
};

const hasRedOutline = (employeeName) => {
  const redOutlineNames = ['Mark Larman', 'Ken Collings', 'Simon Dawe', 'Chris Bennison', 'Matt Gill', 'Ross Taylor', 'Elliot Lemon', 'Shaun Richardson', 'Martin Mattocks', 'Ash Carter', 'Jess Forrester', 'Bill James', 'Marcus Coles', 'Dan Corbert', 'Finley Davis', 'Ben Pellowe', 'Stephen Clough', 'Andrew Campbell', 'Dave Bennetts', 'Paul Celentano'];
  return redOutlineNames.includes(employeeName);
};

const hasPirateIcon = (employeeName, shiftTime, slotEmployees = []) => {
  if (!shiftTime) return false;
  
  if (employeeName === 'Ben Pellowe' || employeeName === 'Jamie Bennetts' || employeeName === 'Jex Batram') {
    const hasEarlyShift = shiftTime.startsWith('02:00') || shiftTime.startsWith('03:00');
    if (!hasEarlyShift) return false;
    
    if (employeeName === 'Jex Batram') {
      const hasJamie = slotEmployees.some(emp => 
        emp.name === 'Jamie Bennetts' && emp.shift && (emp.shift.startsWith('02:00') || emp.shift.startsWith('03:00'))
      );
      if (hasJamie) return false;
    }
    return true;
  }
  
  const pirateNames = ['Steven Connor', 'Mark Manship', 'Toby Nankervis', 'Fletcher Lee'];
  if (!pirateNames.includes(employeeName)) return false;
  if (!shiftTime.startsWith('12:00')) return false;
  
  return true;
};

export default function Schedules() {
  const [currentWeek, setCurrentWeek] = useState(startOfWeek(new Date(), { weekStartsOn: 0 }));
  const [scheduleData, setScheduleData] = useState({});
  const [employeePool, setEmployeePool] = useState([]);
  const [newEmployeeName, setNewEmployeeName] = useState('');
  const [showAddEmployee, setShowAddEmployee] = useState(false);
  const [editingShift, setEditingShift] = useState(null);
  const [editingShiftValue, setEditingShiftValue] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [dayVans, setDayVans] = useState({});
  const [isPoolLocked, setIsPoolLocked] = useState(true);
  const [isPoolCollapsed, setIsPoolCollapsed] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [collapsedShifts, setCollapsedShifts] = useState({});

  // Initialize empty schedule structure
  const initializeEmptySchedule = () => {
    const data = {};
    DAYS.forEach((_, dayIndex) => {
      SHIFTS.forEach(shift => {
        data[`${dayIndex}-${shift}`] = [];
      });
    });
    return data;
  };

  // Load employee pool
  const loadEmployeePool = async () => {
    try {
      const employees = await base44.entities.ScheduleEmployee.list();
      setEmployeePool(employees);
    } catch (error) {
      console.error('Error loading employees:', error);
      setEmployeePool([]);
    }
  };

  // Load schedule for current week
  const loadSchedule = async () => {
    try {
      const weekKey = format(currentWeek, 'yyyy-MM-dd');
      const records = await base44.entities.WeekSchedule.filter({ week_start: weekKey });
      
      if (records.length > 0) {
        const record = records[0];
        setScheduleData(record.schedule_data || initializeEmptySchedule());
        setDayVans(record.vans_data || {});
      } else {
        setScheduleData(initializeEmptySchedule());
        setDayVans({});
      }
    } catch (error) {
      console.error('Error loading schedule:', error);
      setScheduleData(initializeEmptySchedule());
      setDayVans({});
    }
  };

  // Load forecast items for the week
  const loadForecastItems = async () => {
    try {
      const weekDates = DAYS.map((_, dayIndex) => format(addDays(currentWeek, dayIndex), 'yyyy-MM-dd'));
      const forecasts = await base44.entities.Forecast.list('-date', 100);
      
      const newDayVans = { ...dayVans };
      weekDates.forEach((date, index) => {
        const forecast = forecasts.find(f => f.date === date);
        if (forecast && forecast.items_forecast) {
          if (!newDayVans[index]) newDayVans[index] = {};
          if (!newDayVans[index].items) {
            newDayVans[index].items = forecast.items_forecast;
          }
        }
      });
      setDayVans(newDayVans);
    } catch (error) {
      console.error('Error loading forecast items:', error);
    }
  };

  // Save schedule to database
  const saveSchedule = async () => {
    setIsSaving(true);
    try {
      const weekKey = format(currentWeek, 'yyyy-MM-dd');
      const existing = await base44.entities.WeekSchedule.filter({ week_start: weekKey });
      
      const data = {
        week_start: weekKey,
        schedule_data: scheduleData,
        vans_data: dayVans
      };
      
      if (existing.length > 0) {
        await base44.entities.WeekSchedule.update(existing[0].id, data);
      } else {
        await base44.entities.WeekSchedule.create(data);
      }
      
      toast.success('Schedule saved successfully!');
    } catch (error) {
      console.error('Error saving schedule:', error);
      toast.error('Failed to save schedule');
    } finally {
      setIsSaving(false);
    }
  };

  // Initialize on mount
  useEffect(() => {
    const initialize = async () => {
      setIsLoading(true);
      await loadEmployeePool();
      await loadSchedule();
      await loadForecastItems();
      setIsLoading(false);
    };
    initialize();
  }, [currentWeek]);

  // Initialize collapsed state - collapse all except today
  useEffect(() => {
    const today = format(new Date(), 'yyyy-MM-dd');
    const collapsed = {};
    DAYS.forEach((_, dayIndex) => {
      const date = addDays(currentWeek, dayIndex);
      const isToday = format(date, 'yyyy-MM-dd') === today;
      SHIFTS.forEach(shift => {
        collapsed[`${dayIndex}-${shift}`] = !isToday;
      });
    });
    setCollapsedShifts(collapsed);
  }, [currentWeek]);

  // Handle drag and drop
  const onDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination) return;
    
    const newData = { ...scheduleData };
    
    // From pool to schedule
    if (source.droppableId === 'employee-pool' && destination.droppableId !== 'employee-pool') {
      const destList = [...(newData[destination.droppableId] || [])];
      const employeeId = result.draggableId.replace('employee-', '');
      const employee = employeePool.find(e => e.id === employeeId);
      if (!employee) return;
      
      const newEntry = {
        id: `${destination.droppableId}-${employee.id}-${Date.now()}`,
        employeeId: employee.id,
        name: employee.name,
        shift: employee.defaultShift || '06:00-14:00'
      };
      
      destList.splice(destination.index, 0, newEntry);
      newData[destination.droppableId] = destList;
      setScheduleData(newData);
      return;
    }
    
    // From schedule to pool (remove)
    if (source.droppableId !== 'employee-pool' && destination.droppableId === 'employee-pool') {
      const sourceList = [...(newData[source.droppableId] || [])];
      sourceList.splice(source.index, 1);
      newData[source.droppableId] = sourceList;
      setScheduleData(newData);
      return;
    }
    
    // Between schedule slots
    if (source.droppableId !== 'employee-pool' && destination.droppableId !== 'employee-pool') {
      const sourceList = [...(newData[source.droppableId] || [])];
      const destList = source.droppableId === destination.droppableId 
        ? sourceList 
        : [...(newData[destination.droppableId] || [])];

      const [removed] = sourceList.splice(source.index, 1);
      destList.splice(destination.index, 0, removed);

      newData[source.droppableId] = sourceList;
      if (source.droppableId !== destination.droppableId) {
        newData[destination.droppableId] = destList;
      }
      setScheduleData(newData);
    }
  };

  const handleAddEmployee = async () => {
    if (!newEmployeeName.trim()) {
      toast.error('Please enter employee name');
      return;
    }
    try {
      const newEmployee = await base44.entities.ScheduleEmployee.create({
        name: newEmployeeName,
        defaultShift: '06:00-14:00'
      });
      setEmployeePool([...employeePool, newEmployee]);
      setNewEmployeeName('');
      setShowAddEmployee(false);
      toast.success('Employee added');
    } catch (error) {
      console.error('Error adding employee:', error);
      toast.error('Failed to add employee');
    }
  };

  const handleUpdateEmployeeShift = async (empId, newShift) => {
    try {
      await base44.entities.ScheduleEmployee.update(empId, { defaultShift: newShift });
      const updatedPool = employeePool.map(emp => 
        emp.id === empId ? { ...emp, defaultShift: newShift } : emp
      );
      setEmployeePool(updatedPool);
    } catch (error) {
      console.error('Error updating employee shift:', error);
      toast.error('Failed to update shift');
    }
  };

  const handleRemoveEmployee = async (empId) => {
    try {
      await base44.entities.ScheduleEmployee.delete(empId);
      setEmployeePool(employeePool.filter(e => e.id !== empId));
      toast.success('Employee removed');
    } catch (error) {
      console.error('Error removing employee:', error);
      toast.error('Failed to remove employee');
    }
  };

  const handleUpdateShift = (slotId, entryId, newShift) => {
    const newData = { ...scheduleData };
    const list = newData[slotId] || [];
    const index = list.findIndex(e => e.id === entryId);
    if (index !== -1) {
      list[index] = { ...list[index], shift: newShift };
      newData[slotId] = list;
      setScheduleData(newData);
    }
  };

  const handleFinishEditingShift = (slotId, entryId) => {
    handleUpdateShift(slotId, entryId, editingShiftValue);
    setEditingShift(null);
    setEditingShiftValue('');
  };

  const handleVanCountChange = (dayIndex, type, value) => {
    const numValue = value === '' ? '' : (parseInt(value) || 0);
    const fieldMap = {
      'am': 'amVans',
      'pm': 'pmVans',
      'items': 'items'
    };
    setDayVans(prev => ({
      ...prev,
      [dayIndex]: {
        ...prev[dayIndex],
        [fieldMap[type]]: numValue
      }
    }));
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6 min-h-screen">
        <div className="flex flex-col items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading schedules...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4 min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/20 to-indigo-50/20">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-2">
        <div>
          <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <Calendar className="w-6 h-6 text-blue-600" />
            Weekly Schedules
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            size="sm" 
            onClick={saveSchedule} 
            disabled={isSaving}
            className="bg-green-600 hover:bg-green-700"
          >
            <Save className="w-4 h-4 mr-1" />
            {isSaving ? 'Saving...' : 'Save Schedule'}
          </Button>
          <Card className="glass-card border border-slate-200">
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setCurrentWeek(addDays(currentWeek, -7))}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button variant="outline" onClick={() => setCurrentWeek(startOfWeek(new Date(), { weekStartsOn: 0 }))}>
                  {format(currentWeek, 'MMM do')} - {format(addDays(currentWeek, 6), 'MMM do')}
                </Button>
                <Button variant="outline" size="sm" onClick={() => setCurrentWeek(addDays(currentWeek, 7))}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="text-center text-xs text-gray-600 font-medium">
        Week of {format(currentWeek, 'MMMM d, yyyy')} - {format(addDays(currentWeek, 6), 'MMMM d, yyyy')}
      </div>

      <DragDropContext onDragEnd={onDragEnd}>
        <div className={`grid gap-4 ${isPoolCollapsed ? 'grid-cols-1 xl:grid-cols-[60px_1fr]' : 'grid-cols-1 xl:grid-cols-[280px_1fr]'}`}>
          <div className="space-y-3">
            <Card className="glass-card">
              {isPoolCollapsed ? (
                <div className="p-2 flex flex-col items-center gap-2">
                  <Button 
                    size="sm" 
                    variant="ghost"
                    onClick={() => setIsPoolCollapsed(false)}
                    className="h-8 w-8 p-0"
                  >
                    <Users className="w-5 h-5 text-blue-600" />
                  </Button>
                </div>
              ) : (
                <>
                  <CardHeader className="pb-1">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm flex items-center gap-1.5">
                        <Users className="w-4 h-4 text-blue-600" />
                        Employee Pool
                      </CardTitle>
                      <div className="flex items-center gap-1">
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => {
                            const allExpanded = {};
                            DAYS.forEach((_, dayIndex) => {
                              SHIFTS.forEach(shift => {
                                allExpanded[`${dayIndex}-${shift}`] = false;
                              });
                            });
                            setCollapsedShifts(allExpanded);
                          }}
                          className="h-6 w-6 p-0"
                          title="Expand All"
                        >
                          <ChevronsDown className="w-3 h-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => {
                            const allCollapsed = {};
                            DAYS.forEach((_, dayIndex) => {
                              SHIFTS.forEach(shift => {
                                allCollapsed[`${dayIndex}-${shift}`] = true;
                              });
                            });
                            setCollapsedShifts(allCollapsed);
                          }}
                          className="h-6 w-6 p-0"
                          title="Collapse All"
                        >
                          <ChevronsUp className="w-3 h-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => setIsPoolCollapsed(true)}
                          className="h-6 w-6 p-0"
                        >
                          <ChevronLeft className="w-3 h-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => setIsPoolLocked(!isPoolLocked)}
                          className="h-6 w-6 p-0"
                        >
                          {isPoolLocked ? <Lock className="w-3 h-3 text-gray-600" /> : <Unlock className="w-3 h-3 text-gray-400" />}
                        </Button>
                        <Button 
                          size="sm" 
                          onClick={() => setShowAddEmployee(!showAddEmployee)}
                          className="bg-blue-600 hover:bg-blue-700 h-6 w-6 p-0"
                          disabled={isPoolLocked}
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-1.5 p-3">
                {showAddEmployee && (
                  <div className="p-1.5 bg-slate-50 rounded-lg space-y-1 border-2 border-dashed border-blue-300">
                    <Input
                      placeholder="Employee name"
                      value={newEmployeeName}
                      onChange={(e) => setNewEmployeeName(e.target.value)}
                      className="h-7 text-xs"
                    />
                    <div className="flex gap-1.5">
                      <Button size="sm" onClick={handleAddEmployee} className="flex-1 h-6 text-xs">Add</Button>
                      <Button size="sm" variant="outline" onClick={() => setShowAddEmployee(false)} className="h-6 text-xs">Cancel</Button>
                    </div>
                  </div>
                )}
                
                <Droppable droppableId="employee-pool">
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={`space-y-1 min-h-[120px] max-h-[calc(100vh-300px)] overflow-y-auto p-1.5 rounded-lg transition-colors ${
                        snapshot.isDraggingOver ? 'bg-blue-50' : 'bg-slate-50'
                      }`}
                    >
                      {[...employeePool].sort((a, b) => a.name.localeCompare(b.name)).map((employee, index) => (
                        <Draggable key={employee.id} draggableId={`employee-${employee.id}`} index={index}>
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                              className={`p-1 rounded shadow-sm border hover:border-blue-400 cursor-move transition-all relative ${getEmployeeColor(employee.name, employee.defaultShift, [])} ${
                                snapshot.isDragging ? 'shadow-lg border-blue-500 rotate-2' : ''
                              }`}
                            >
                              <div className="flex items-center justify-between items-center gap-1 min-h-[14px]">
                                <div className="font-medium text-[10px] text-gray-900 truncate">{employee.name}</div>
                                <div className="flex items-center gap-1">
                                  {hasRedOutline(employee.name) && <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6866d9d13515e74b5479352f/d4a715cf2_Pngtreedeliverytrucksilhouetteicondesign_5895670.png" className="w-10 h-10 flex-shrink-0 absolute -right-0.5 top-1/2 -translate-y-1/2" alt="delivery van" />}
                                  {hasPirateIcon(employee.name, employee.defaultShift, []) && <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6866d9d13515e74b5479352f/2e4599b8e_pirate.png" className="w-5 h-5 flex-shrink-0 absolute right-1 top-1/2 -translate-y-1/2" alt="pirate" />}
                                  {!isPoolLocked && (
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      className="h-4 w-4 text-red-500 hover:text-red-700 p-0"
                                      onClick={() => handleRemoveEmployee(employee.id)}
                                    >
                                      <Trash2 className="w-2.5 h-2.5" />
                                    </Button>
                                  )}
                                </div>
                              </div>
                              <Input
                                type="text"
                                value={employee.defaultShift}
                                onChange={(e) => handleUpdateEmployeeShift(employee.id, e.target.value)}
                                className="text-[10px] h-5 px-1.5 font-medium"
                                placeholder="Default shift"
                                onClick={(e) => e.stopPropagation()}
                                disabled={isPoolLocked}
                              />
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </CardContent>
              </>
              )}
              </Card>
              </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-7 gap-2">
            {DAYS.map((dayName, dayIndex) => {
              const date = addDays(currentWeek, dayIndex);
              const isToday = format(date, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
              
              return (
                <Card key={dayIndex} className={`glass-card ${isToday ? 'ring-2 ring-blue-500' : ''}`}>
                  <CardHeader className="pb-1 pt-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-t-lg">
                    <div className="flex items-center justify-center gap-2 mb-0.5">
                      <div className="flex flex-col items-center">
                        <span className="text-[10px] font-normal opacity-90 text-center">AM</span>
                        <Input
                          type="number"
                          value={dayVans[dayIndex]?.amVans ?? ''}
                          onChange={(e) => handleVanCountChange(dayIndex, 'am', e.target.value)}
                          className="w-10 h-7 text-center text-xs bg-white/20 border-white/30 text-white placeholder:text-white/60 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                          placeholder="0"
                        />
                      </div>
                      <div className="flex flex-col items-center">
                        <span className="text-[10px] font-normal opacity-90 text-center">PM</span>
                        <Input
                          type="number"
                          value={dayVans[dayIndex]?.pmVans ?? ''}
                          onChange={(e) => handleVanCountChange(dayIndex, 'pm', e.target.value)}
                          className="w-10 h-7 text-center text-xs bg-white/20 border-white/30 text-white placeholder:text-white/60 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                          placeholder="0"
                        />
                      </div>
                      <div className="flex flex-col items-center">
                        <span className="text-[10px] font-normal opacity-90 text-center">Items</span>
                        <Input
                          type="number"
                          value={dayVans[dayIndex]?.items ?? ''}
                          onChange={(e) => handleVanCountChange(dayIndex, 'items', e.target.value)}
                          className="w-20 h-7 text-center text-[10px] bg-white/20 border-white/30 text-white placeholder:text-white/60 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                          placeholder="0"
                        />
                      </div>
                    </div>
                    <CardTitle className={`text-sm font-semibold text-center ${isToday ? 'text-yellow-300' : ''}`}>
                      {dayName}
                      <div className="text-[11px] font-normal opacity-90">{format(date, 'MMM d')}</div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-2 space-y-2">
                    {SHIFTS.map(shift => {
                      const dropId = `${dayIndex}-${shift}`;
                      const employees = scheduleData[dropId] || [];

                      // Check for overflow shifts
                      const overflowShifts = [];
                      if (shift === 'AM') {
                        // AM shift shows Driver Support overflow (shifts starting 02:00-10:59)
                        const driverSupportDropId = `${dayIndex}-Driver Support`;
                        const driverSupportEmployees = scheduleData[driverSupportDropId] || [];
                        driverSupportEmployees.forEach(emp => {
                          if (emp.shift) {
                            const startTime = emp.shift.split('-')[0];
                            if (startTime) {
                              const startHour = parseInt(startTime.split(':')[0]);
                              const startMinute = parseInt(startTime.split(':')[1]) || 0;
                              const startTimeInMinutes = startHour * 60 + startMinute;
                              if (startTimeInMinutes >= 2 * 60 && startTimeInMinutes <= 10 * 60 + 59) {
                                overflowShifts.push({ ...emp, isOverflow: true });
                              }
                            }
                          }
                        });
                      } else if (shift === 'PM') {
                        // PM shift shows AM overflow (shifts ending after 12:00)
                        const amDropId = `${dayIndex}-AM`;
                        const amEmployees = scheduleData[amDropId] || [];
                        amEmployees.forEach(emp => {
                          if (emp.shift) {
                            const endTime = emp.shift.split('-')[1];
                            if (endTime) {
                              const endHour = parseInt(endTime.split(':')[0]);
                              const endMinute = parseInt(endTime.split(':')[1]) || 0;
                              const endTimeInMinutes = endHour * 60 + endMinute;
                              if (endTimeInMinutes > 12 * 60) {
                                overflowShifts.push({ ...emp, isOverflow: true });
                              }
                            }
                          }
                        });

                        // PM shift also shows Driver Support overflow (shifts starting 11:00-23:30)
                        const driverSupportDropId = `${dayIndex}-Driver Support`;
                        const driverSupportEmployees = scheduleData[driverSupportDropId] || [];
                        driverSupportEmployees.forEach(emp => {
                          if (emp.shift) {
                            const startTime = emp.shift.split('-')[0];
                            if (startTime) {
                              const startHour = parseInt(startTime.split(':')[0]);
                              const startMinute = parseInt(startTime.split(':')[1]) || 0;
                              const startTimeInMinutes = startHour * 60 + startMinute;
                              if (startTimeInMinutes >= 11 * 60 && startTimeInMinutes <= 23 * 60 + 30) {
                                overflowShifts.push({ ...emp, isOverflow: true });
                              }
                            }
                          }
                        });
                      }

                      const actualEmployeeCount = employees.length;
                      const totalHours = employees.reduce((sum, emp) => sum + calculateShiftHours(emp.shift), 0);
                      const collapseKey = `${dayIndex}-${shift}`;
                      const isCollapsed = collapsedShifts[collapseKey] || false;

                      return (
                        <div key={shift} className="space-y-1">
                          <div className="flex items-center justify-center gap-1">
                            <div className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide px-1 text-center">
                              {shift}
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setCollapsedShifts(prev => ({ ...prev, [collapseKey]: !prev[collapseKey] }))}
                              className="h-4 w-4 p-0"
                            >
                              {isCollapsed ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />}
                            </Button>
                          </div>
                          {!isCollapsed && (
                          <Droppable droppableId={dropId}>
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.droppableProps}
                                className={`min-h-[100px] p-1.5 rounded-lg border-2 border-dashed transition-all ${
                                  snapshot.isDraggingOver 
                                    ? 'border-blue-500 bg-blue-50' 
                                    : 'border-slate-200 bg-slate-50'
                                } ${actualEmployeeCount >= 8 ? 'bg-amber-50 border-amber-300' : ''}`}
                              >
                                <div className="space-y-1">
                                  {employees.map((employee, index) => (
                                    <Draggable key={employee.id} draggableId={employee.id} index={index}>
                                      {(provided, snapshot) => (
                                        <div
                                          ref={provided.innerRef}
                                          {...provided.draggableProps}
                                          {...provided.dragHandleProps}
                                          className={`p-1 rounded shadow-sm border hover:border-blue-400 cursor-move transition-all text-xs relative ${getEmployeeColor(employee.name, employee.shift, employees)} ${
                                            snapshot.isDragging ? 'shadow-md border-blue-500 rotate-1' : ''
                                          }`}
                                        >
                                          <div className="flex items-center justify-between items-center gap-1 min-h-[14px]">
                                            <div className="font-medium text-[10px] text-gray-900 truncate">{employee.name}</div>
                                            {hasRedOutline(employee.name) && <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6866d9d13515e74b5479352f/d4a715cf2_Pngtreedeliverytrucksilhouetteicondesign_5895670.png" className="w-10 h-10 flex-shrink-0 absolute -right-0.5 top-1/2 -translate-y-1/2" alt="delivery van" />}
                                            {hasPirateIcon(employee.name, employee.shift, employees) && <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6866d9d13515e74b5479352f/2e4599b8e_pirate.png" className="w-5 h-5 flex-shrink-0 absolute right-1 top-1/2 -translate-y-1/2" alt="pirate" />}
                                          </div>
                                          {editingShift === employee.id ? (
                                            <input
                                              type="text"
                                              value={editingShiftValue}
                                              onChange={(e) => setEditingShiftValue(e.target.value)}
                                              onBlur={() => handleFinishEditingShift(dropId, employee.id)}
                                              onKeyDown={(e) => {
                                                if (e.key === 'Enter') {
                                                  handleFinishEditingShift(dropId, employee.id);
                                                }
                                              }}
                                              className="text-[9px] w-full border rounded px-1 py-0.5 mt-0.5"
                                              placeholder="e.g., 06:00-14:00"
                                              autoFocus
                                            />
                                          ) : (
                                            <div 
                                              className="text-[10px] text-gray-600 cursor-pointer hover:text-blue-600 font-medium"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                setEditingShiftValue(employee.shift);
                                                setEditingShift(employee.id);
                                              }}
                                            >
                                              {employee.shift}
                                            </div>
                                          )}
                                        </div>
                                      )}
                                    </Draggable>
                                  ))}
                                  {overflowShifts.map((employee, index) => (
                                    <div
                                      key={`overflow-${employee.id}`}
                                      style={{ border: '3px solid #dc2626' }}
                                      className="p-1 rounded shadow-sm cursor-not-allowed transition-all text-xs relative bg-blue-300 opacity-80"
                                    >
                                      <div className="flex items-center justify-between items-center gap-1 min-h-[14px]">
                                        <div className="font-medium text-[10px] text-gray-900 truncate">{employee.name}</div>
                                        {hasRedOutline(employee.name) && <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6866d9d13515e74b5479352f/d4a715cf2_Pngtreedeliverytrucksilhouetteicondesign_5895670.png" className="w-10 h-10 flex-shrink-0 absolute -right-0.5 top-1/2 -translate-y-1/2" alt="delivery van" />}
                                        {hasPirateIcon(employee.name, employee.shift, employees) && <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6866d9d13515e74b5479352f/2e4599b8e_pirate.png" className="w-5 h-5 flex-shrink-0 absolute right-1 top-1/2 -translate-y-1/2" alt="pirate" />}
                                      </div>
                                      <div className="text-[10px] text-gray-600 font-medium">
                                        {employee.shift}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                                {provided.placeholder}
                                {employees.length === 0 && overflowShifts.length === 0 && !snapshot.isDraggingOver && (
                                  <div className="text-center text-xs text-gray-400 py-8">
                                    Drop here
                                  </div>
                                )}
                                <div className="text-[10px] text-gray-400 text-center mt-2">
                                  {actualEmployeeCount} / {actualEmployeeCount + overflowShifts.length}
                                  <span className="ml-1 text-gray-500 font-medium">({totalHours.toFixed(1)}h)</span>
                                </div>
                              </div>
                              )}
                              </Droppable>
                              )}
                              </div>
                              );
                              })}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </DragDropContext>
    </div>
  );
}