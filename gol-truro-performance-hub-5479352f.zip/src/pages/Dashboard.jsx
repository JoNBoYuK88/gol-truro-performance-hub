import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { User } from "@/api/entities";
import { KPIMetric } from "@/api/entities";
import { PeriodConfig } from "@/api/entities";
import { useEditLock } from "../Layout";
import {
  PoundSterling,
  Target,
  TrendingUp,
  ShoppingCart,
  Package,
  Heart,
  MessageSquare,
  Clock,
  CheckCircle,
  Users,
  Edit,
  Save,
  X,
  Trash2,
  FileDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { toast } from "sonner";
import { format } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

import KPICard from "../components/dashboard/KPICard";

const kpiConfig = [
    { name: "Sales", unit: "currency", category: "sales", icon: PoundSterling, greenThreshold: 120000, amberThreshold: 100000, redThreshold: 80000, isEditable: true },
    { name: "Budget", unit: "currency", category: "sales", icon: Target, greenThreshold: 120000, amberThreshold: 100000, redThreshold: 80000, isEditable: true },
    { name: "vs Budget", unit: "currency", category: "sales", icon: TrendingUp, greenThreshold: 0.01, amberThreshold: 0, redThreshold: -0.01, isEditable: true }, // Added vs Budget here
    { name: "Net Sales YOY", unit: "currency", category: "sales", icon: PoundSterling, greenThreshold: 0.01, amberThreshold: 0, redThreshold: -0.01, isEditable: true },
    { name: "Net Sales YOY (%)", unit: "percentage", category: "sales", icon: TrendingUp, greenThreshold: 0.01, amberThreshold: 0, redThreshold: -0.01, isEditable: true },
    { name: "Delivered Orders", unit: "number", category: "operations", icon: ShoppingCart, greenThreshold: 1200, amberThreshold: 1000, redThreshold: 800, isEditable: true },
    { name: "Delivered Items", unit: "items", category: "operations", icon: Package, greenThreshold: 8500, amberThreshold: 7500, redThreshold: 6500, isEditable: true },
    { name: "Ops Score", unit: "percentage", category: "operations", icon: CheckCircle, greenThreshold: 80, amberThreshold: 60, redThreshold: 59.99, isEditable: true },
    { name: "Shoppers Achieving", unit: "percentage", category: "shopper", icon: Users, greenThreshold: 80, amberThreshold: 60, redThreshold: 59.99, isEditable: true },
    { name: "On Time Departures", unit: "percentage", category: "operations", icon: Clock, greenThreshold: 98, amberThreshold: 95, redThreshold: 94.99, isEditable: true },
    { name: "Availability", unit: "percentage", category: "operations", icon: CheckCircle, greenThreshold: 98, amberThreshold: 95, redThreshold: 94.99, isEditable: true },
    { name: "Delivery Without Complaints", unit: "percentage", category: "operations", icon: Clock, greenThreshold: 98, amberThreshold: 96, redThreshold: 95.99, isEditable: true },
    { name: "Secondary Replenishment", unit: "percentage", category: "operations", icon: Package, greenThreshold: 2, amberThreshold: 2.01, redThreshold: 3, isEditable: true },
    { name: "iCare", unit: "percentage", category: "customer", icon: Heart, greenThreshold: 49.5, amberThreshold: 49.4, redThreshold: 49.39, isEditable: true },
];

const fallbackData = {
    "Sales": { value: 125000, target: 120000, previous_value: 115000 },
    "Budget": { value: 120000, target: 120000, previous_value: 118000 },
    "vs Budget": { value: 0, target: 0, previous_value: 0 }, // Added fallback for vs Budget
    "Net Sales YOY": { value: 12500, target: 10000, previous_value: 11800 },
    "Net Sales YOY (%)": { value: 15.5, target: 10, previous_value: 12.3 },
    "Delivered Orders": { value: 1247, target: 1200, previous_value: 1189 },
    "Delivered Items": { value: 8945, target: 8500, previous_value: 8234 },
    "iCare": { value: 92.5, target: 90, previous_value: 89.2 },
    "Delivery Without Complaints": { value: 98.2, target: 99, previous_value: 97.8 },
    "Ops Score": { value: 87.5, target: 85, previous_value: 84.2 },
    "Shoppers Achieving": { value: 78.5, target: 80, previous_value: 76.2 },
    "On Time Departures": { value: 94.2, target: 95, previous_value: 92.8 },
    "Availability": { value: 96.8, target: 95, previous_value: 95.2 },
    "Secondary Replenishment": { value: 89.3, target: 85, previous_value: 87.1 },
};

const summaryKpiConfig = {
    opsScore: { name: "Ops Score", icon: CheckCircle, unit: 'percentage' },
    shoppers: { name: "Shoppers Achieving", icon: Users, unit: 'percentage' },
    otd: { name: "On Time Departures", icon: Clock, unit: 'percentage' },
    availability: { name: "Availability", icon: CheckCircle, unit: 'percentage' },
    dwc: { name: "Delivery Without Complaints", icon: Heart, unit: 'percentage' },
    secReplen: { name: "Secondary Replenishment", icon: Package, unit: 'percentage', higherIsBetter: false },
    iCare: { name: "iCare", icon: Heart, unit: 'percentage' }
};

const salesSummaryConfig = {
    sales: { name: "Sales", icon: PoundSterling, unit: 'currency', aggregation: 'sum' },
    budget: { name: "Budget", icon: Target, unit: 'currency', aggregation: 'sum', isHidden: true },
    vsBudget: { name: "vs Budget", icon: Target, unit: 'currency', isCalculated: false },
    salesYOYValue: { name: "Net Sales YOY", icon: PoundSterling, unit: 'currency', aggregation: 'sum' },
    salesYOY: { name: "Net Sales YOY (%)", icon: TrendingUp, unit: 'percentage', aggregation: 'avg' },
    orders: { name: "Delivered Orders", icon: ShoppingCart, unit: 'number', aggregation: 'sum' },
    items: { name: "Delivered Items", icon: Package, unit: 'number', aggregation: 'sum' }
};

export default function Dashboard() {
  const [kpiData, setKpiData] = useState([]);
  const [dateRange, setDateRange] = useState({ from: new Date(), to: new Date() });
  const [comparisonMode, setComparisonMode] = useState("day");
  
  const [periods, setPeriods] = useState([]);
  const [currentPeriod, setCurrentPeriod] = useState(1);
  const [currentWeek, setCurrentWeek] = useState(1);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [isInitialized, setIsInitialized] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;

  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState({});
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [showClearConfirmDialog, setShowClearConfirmDialog] = useState(false);
  const [showIndividualClearDialog, setShowIndividualClearDialog] = useState(false);
  const [kpiToClear, setKpiToClear] = useState('');
  const [summaryKpiToClear, setSummaryKpiToClear] = useState(null);
  const [showClearSummaryConfirmDialog, setShowClearSummaryConfirmDialog] = useState(false);
  const [showClearAllOpsConfirmDialog, setShowClearAllOpsConfirmDialog] = useState(false);
  const [showClearAllSalesConfirmDialog, setShowClearAllSalesConfirmDialog] = useState(false);

  const [showOpsComparison, setShowOpsComparison] = useState(false);
  const [comparisonYear, setComparisonYear] = useState(new Date().getFullYear() - 1);
  const [opsComparisonData, setOpsComparisonData] = useState({});
  const [showSalesComparison, setShowSalesComparison] = useState(false);
  const [salesComparisonData, setSalesComparisonData] = useState({});

  const [summaryViewMode, setSummaryViewMode] = useState('period');
  const [summaryKpiData, setSummaryKpiData] = useState({});
  const [editedSummaryData, setEditedSummaryData] = useState({});
  const [summaryPeriod, setSummaryPeriod] = useState(1);
  const [summaryQuarter, setSummaryQuarter] = useState(1);

  const [salesSummaryViewMode, setSalesSummaryViewMode] = useState('period');
  const [salesSummaryKpiData, setSalesSummaryKpiData] = useState({});
  const [editedSalesSummaryData, setEditedSalesSummaryData] = useState({});
  const [salesSummaryPeriod, setSalesSummaryPeriod] = useState(1);
  const [salesSummaryQuarter, setSalesSummaryQuarter] = useState(1);
  const [variance, setVariance] = useState(0);

  const debounceTimeoutRef = useRef(null);
  const loadingRef = useRef(false); // NEW: Prevent concurrent loads

  // Helper function to determine current period and week (1 week behind)
  const getCurrentPeriodAndWeek = (periods) => {
    const today = new Date();
    // Normalize today to start of day for accurate date range comparisons
    today.setHours(0, 0, 0, 0); 

    const currentPeriodConfig = periods.find(p => {
      const startDate = new Date(p.start_date);
      startDate.setHours(0, 0, 0, 0); // Normalize start date
      const endDate = new Date(p.end_date);
      endDate.setHours(0, 0, 0, 0); // Normalize end date
      return today >= startDate && today <= endDate;
    });

    if (currentPeriodConfig) {
      const startDate = new Date(currentPeriodConfig.start_date);
      startDate.setHours(0, 0, 0, 0); // Normalize start date for daysDiff calculation

      const daysDiff = Math.floor((today - startDate) / (1000 * 60 * 60 * 24));
      const currentWeekNumber = Math.min(Math.floor(daysDiff / 7) + 1, 4);
      
      // Go back 1 week
      let targetPeriod = currentPeriodConfig.period_number;
      let targetWeek = currentWeekNumber - 1;
      
      // If we're in week 1, go to week 4 of the previous period
      if (targetWeek < 1) {
        targetPeriod = Math.max(1, targetPeriod - 1);
        targetWeek = 4;
      }
      
      return { period: targetPeriod, week: targetWeek };
    }
    
    // Fallback: find the latest period if no current period found (e.g., today is after all configured periods)
    const latestPeriod = periods.reduce((latest, current) => {
      // Handles empty array by returning undefined, which leads to the P1W1 fallback
      if (!latest) return current; 
      return new Date(current.start_date) > new Date(latest.start_date) ? current : latest;
    }, periods[0]); // Initial value is the first element, or undefined if array is empty
    
    // If no current period found, return the last week of the latest period, or default to P1W1
    return latestPeriod ? { period: latestPeriod.period_number, week: 4 } : { period: 1, week: 1 };
  };

  useEffect(() => {
    const initialize = async () => {
      try {
        const user = await User.me();
        setIsAdmin(user && user.role === 'admin');
      } catch (e) {
        console.error("User not logged in or error checking user:", e);
        setIsAdmin(false);
      }
      
      try {
        const periodsData = await PeriodConfig.filter({ year: currentYear }, 'period_number');
        setPeriods(periodsData);
        
        if (periodsData.length > 0) {
          const { period, week } = getCurrentPeriodAndWeek(periodsData);
          setCurrentPeriod(period);
          setCurrentWeek(week);
          setSummaryPeriod(period);
          setSalesSummaryPeriod(period);
          setSummaryQuarter(1);
          setSalesSummaryQuarter(1);
        } else {
          setCurrentPeriod(1);
          setCurrentWeek(1);
          setSummaryPeriod(1);
          setSalesSummaryPeriod(1);
          setSummaryQuarter(1);
          setSalesSummaryQuarter(1);
        }
        
        setIsInitialized(true); // NEW: Mark as initialized
      } catch (error) {
        console.error("Error loading periods:", error);
        setPeriods([]);
        setCurrentPeriod(1);
        setCurrentWeek(1);
        setSummaryPeriod(1);
        setSalesSummaryPeriod(1);
        setSummaryQuarter(1);
        setSalesSummaryQuarter(1);
        setIsInitialized(true); // NEW: Mark as initialized even on error
      }
    };
    initialize();
  }, [currentYear]);

  // Helper function to get periods for a quarter
  const getQuarterPeriods = useCallback((quarter) => {
    const quarterMap = {
      1: [1, 2, 3, 4],
      2: [5, 6, 7], 
      3: [8, 9, 10],
      4: [11, 12, 13]
    };
    return quarterMap[quarter] || [];
  }, []);

  const loadAllData = useCallback(async () => {
    // NEW: Prevent concurrent loads
    if (loadingRef.current) {
      console.log("Load already in progress, skipping...");
      return;
    }
    
    loadingRef.current = true;
    setIsLoading(true);
    
    try {
      const needsComparisonData = showOpsComparison || showSalesComparison;
      const allMetricsPromises = [
        KPIMetric.filter({ year: currentYear }, '-created_date', 2000)
      ];
      if (needsComparisonData) {
        allMetricsPromises.push(KPIMetric.filter({ year: comparisonYear }, '-created_date', 2000));
      }

      const [allMetrics, comparisonYearMetrics] = await Promise.all(allMetricsPromises);

      // Process weekly KPI data
      const weeklyData = allMetrics.filter(m =>
        m.period === currentPeriod &&
        m.week === currentWeek
      );
      setKpiData(weeklyData);

      // Process Ops/Customer summary data (current year)
      let weeklyMetricsForSummary;

      if (summaryViewMode === 'period') {
        weeklyMetricsForSummary = allMetrics.filter(m => m.period === summaryPeriod && m.week != null && m.week > 0);
      } else if (summaryViewMode === 'quarter') {
        const quarterPeriods = getQuarterPeriods(summaryQuarter);
        weeklyMetricsForSummary = allMetrics.filter(m => quarterPeriods.includes(m.period) && m.week != null && m.week > 0);
      } else if (summaryViewMode === 'ytd') {
        // Explicitly filter for ALL weekly data within the current year for the YTD calculation.
        // This ensures it is completely independent of the weekly KPI view's period/week selection.
        weeklyMetricsForSummary = allMetrics.filter(m => m.year === currentYear && m.week !== null && m.week > 0);
      } else {
        // Fallback to prevent errors, though this state should not be reachable with the UI.
        weeklyMetricsForSummary = [];
      }

      const calculatedData = {};
      for (const [key, config] of Object.entries(summaryKpiConfig)) {
        // Calculate average from weekly data for the current period/year
        const relevantMetrics = weeklyMetricsForSummary.filter(m => m.name === config.name);
        let avg = relevantMetrics.length > 0
          ? relevantMetrics.reduce((sum, m) => sum + m.value, 0) / relevantMetrics.length
          : 0;

        // Apply custom rounding for Ops Score in Quarter/YTD view
        if (config.name === "Ops Score" && (summaryViewMode === 'quarter' || summaryViewMode === 'ytd')) {
            const sequence = [44, 52, 60, 68, 76, 84, 92, 100];
            if (avg > 0) { // Only apply rounding if there is a calculated average
                avg = sequence.reduce((prev, curr) => {
                    return (Math.abs(curr - avg) < Math.abs(prev - avg) ? curr : prev);
                });
            }
        }

        // Check for a saved aggregate value (period, quarter, or YTD) to override the calculation
        const savedAggregate = allMetrics.filter(m =>
          m.name === config.name &&
          m.year === currentYear &&
          (summaryViewMode === 'period' ? m.period === summaryPeriod && m.quarter === null && m.week === null : true) && // Explicitly check quarter null
          (summaryViewMode === 'quarter' ? m.quarter === summaryQuarter && m.period === null && m.week === null : true) && // Updated: use summaryQuarter and period null
          (summaryViewMode === 'ytd' ? m.period === null && m.week === null && m.quarter === null : true)
        );

        calculatedData[key] = {
          value: savedAggregate.length > 0 ? savedAggregate[0].value : avg,
          isSaved: savedAggregate.length > 0,
        };
      }
      setSummaryKpiData(calculatedData);

      // Process Ops/Customer COMPARISON data
      if (showOpsComparison && comparisonYearMetrics) {
        let comparisonMetricsForSummary;

        if (summaryViewMode === 'period') {
          comparisonMetricsForSummary = comparisonYearMetrics.filter(m => m.period === summaryPeriod && m.week != null && m.week > 0);
        } else if (summaryViewMode === 'quarter') {
          const quarterPeriods = getQuarterPeriods(summaryQuarter);
          comparisonMetricsForSummary = comparisonYearMetrics.filter(m => quarterPeriods.includes(m.period) && m.week != null && m.week > 0);
        } else { // 'ytd'
          comparisonMetricsForSummary = comparisonYearMetrics.filter(m => m.year === comparisonYear && m.week !== null && m.week > 0);
        }

        const calculatedComparisonData = {};
        for (const [key, config] of Object.entries(summaryKpiConfig)) {
          const relevantMetrics = comparisonMetricsForSummary.filter(m => m.name === config.name);
          let avg = relevantMetrics.length > 0
            ? relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0) / relevantMetrics.length
            : 0;
          
          // Apply custom rounding for Ops Score in Quarter/YTD view for comparison data too
          if (config.name === "Ops Score" && (summaryViewMode === 'quarter' || summaryViewMode === 'ytd')) {
            const sequence = [44, 52, 60, 68, 76, 84, 92, 100];
            if (avg > 0) { // Only apply rounding if there is a calculated average
                avg = sequence.reduce((prev, curr) => {
                    return (Math.abs(curr - avg) < Math.abs(prev - avg) ? curr : prev);
                });
            }
          }

          // Check for a saved aggregate value (period, quarter, or YTD) in comparison data
          const savedAggregate = comparisonYearMetrics.filter(m =>
            m.name === config.name &&
            m.year === comparisonYear && // IMPORTANT: use comparisonYear here
            (summaryViewMode === 'period' ? m.period === summaryPeriod && m.quarter === null && m.week === null : true) &&
            (summaryViewMode === 'quarter' ? m.quarter === summaryQuarter && m.period === null && m.week === null : true) &&
            (summaryViewMode === 'ytd' ? m.period === null && m.week === null && m.quarter === null : true)
          );

          calculatedComparisonData[key] = {
            value: savedAggregate.length > 0 ? savedAggregate[0].value : avg,
          };
        }
        setOpsComparisonData(calculatedComparisonData);
      } else {
        setOpsComparisonData({}); // Clear if toggle is off
      }

      // Process sales summary data (current year)
      let salesMetricsScope;

      if (salesSummaryViewMode === 'period') {
        salesMetricsScope = allMetrics.filter(m => m.period === salesSummaryPeriod && m.week != null && m.week > 0);
      } else if (salesSummaryViewMode === 'quarter') {
        const quarterPeriods = getQuarterPeriods(salesSummaryQuarter);
        salesMetricsScope = allMetrics.filter(m => quarterPeriods.includes(m.period) && m.week != null && m.week > 0);
      } else { // 'ytd'
        salesMetricsScope = allMetrics.filter(m => m.year === currentYear && m.week != null && m.week > 0);
      }
      
      const salesCalculatedData = {};

      // Ensure salesSummaryConfig is properly defined before iteration
      if (salesSummaryConfig && typeof salesSummaryConfig === 'object') {
        // Calculate all aggregated values from weekly data
        for (const [key, config] of Object.entries(salesSummaryConfig)) {
          if (!config || typeof config !== 'object') continue;
          
          // Check for a saved aggregate override first
          let savedAggregate;
          if (salesSummaryViewMode === 'period') {
            savedAggregate = allMetrics.find(m =>
              m.name === config.name &&
              m.year === currentYear &&
              m.period === salesSummaryPeriod &&
              m.week === null &&
              m.quarter === null
            );
          } else if (salesSummaryViewMode === 'quarter') {
            savedAggregate = allMetrics.find(m =>
              m.name === config.name &&
              m.year === currentYear &&
              m.quarter === salesSummaryQuarter &&
              m.period === null &&
              m.week === null
            );
          } else { // YTD
            savedAggregate = allMetrics.find(m =>
              m.name === config.name &&
              m.year === currentYear &&
              m.period === null &&
              m.week === null &&
              m.quarter === null
            );
          }

          if (savedAggregate) {
            salesCalculatedData[key] = { value: savedAggregate.value, isSaved: true };
          } else {
            // Calculate from weekly data
            const relevantMetrics = Array.isArray(salesMetricsScope) ? salesMetricsScope.filter(m => m.name === config.name) : [];
            let calculatedValue = 0;
            
            if (config.name === "Net Sales YOY") {
              calculatedValue = relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0);
            } else {
              if (relevantMetrics.length > 0) {
                if (config.aggregation === 'avg') {
                  calculatedValue = relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0) / relevantMetrics.length;
                } else if (config.aggregation === 'sum') {
                  calculatedValue = relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0);
                } else {
                  calculatedValue = relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0);
                }
              }
            }
            salesCalculatedData[key] = { value: calculatedValue, isSaved: false };
          }
        }
      }

      // Special handling for vs Budget - sum weekly vs Budget values
      let vsBudgetSaved;
      if (salesSummaryViewMode === 'period') {
        vsBudgetSaved = allMetrics.find(m =>
          m.name === 'vs Budget' &&
          m.year === currentYear &&
          m.period === salesSummaryPeriod &&
          m.week === null &&
          m.quarter === null
        );
      } else if (salesSummaryViewMode === 'quarter') {
        vsBudgetSaved = allMetrics.find(m =>
          m.name === 'vs Budget' &&
          m.year === currentYear &&
          m.quarter === salesSummaryQuarter &&
          m.period === null &&
          m.week === null
        );
      } else { // YTD
        vsBudgetSaved = allMetrics.find(m =>
          m.name === 'vs Budget' &&
          m.year === currentYear &&
          m.period === null &&
          m.week === null &&
          m.quarter === null
        );
      }

      // Use saved value if it exists, otherwise sum weekly vs Budget values
      if (vsBudgetSaved) {
        salesCalculatedData['vsBudget'] = { value: vsBudgetSaved.value, isSaved: true };
      } else {
        const weeklyVsBudgetMetrics = Array.isArray(salesMetricsScope) ? salesMetricsScope.filter(m => m.name === 'vs Budget') : [];
        const calculatedVsBudget = weeklyVsBudgetMetrics.reduce((sum, m) => sum + (m.value || 0), 0);
        salesCalculatedData['vsBudget'] = { value: calculatedVsBudget, isSaved: false };
      }

      setSalesSummaryKpiData(salesCalculatedData);
      setVariance(salesCalculatedData['vsBudget']?.value || 0);

      // Process Sales Summary COMPARISON data (NEW BLOCK)
      if (showSalesComparison && comparisonYearMetrics) {
        let comparisonMetricsForSales;

        if (salesSummaryViewMode === 'period') {
          comparisonMetricsForSales = comparisonYearMetrics.filter(m => m.period === salesSummaryPeriod && m.week != null && m.week > 0);
        } else if (salesSummaryViewMode === 'quarter') {
          const quarterPeriods = getQuarterPeriods(salesSummaryQuarter);
          comparisonMetricsForSales = comparisonYearMetrics.filter(m => quarterPeriods.includes(m.period) && m.week != null && m.week > 0);
        } else { // 'ytd'
          comparisonMetricsForSales = comparisonYearMetrics.filter(m => m.year === comparisonYear && m.week !== null && m.week > 0);
        }

        const calculatedSalesComparisonData = {};
        for (const [key, config] of Object.entries(salesSummaryConfig)) {
           if (!config || typeof config !== 'object') continue;

           let savedAggregate;
           if (salesSummaryViewMode === 'period') {
              savedAggregate = comparisonYearMetrics.find(m => m.name === config.name && m.year === comparisonYear && m.period === salesSummaryPeriod && m.week === null && m.quarter === null);
           } else if (salesSummaryViewMode === 'quarter') {
              savedAggregate = comparisonYearMetrics.find(m => m.name === config.name && m.year === comparisonYear && m.quarter === salesSummaryQuarter && m.period === null && m.week === null);
           } else { // YTD
              savedAggregate = comparisonYearMetrics.find(m => m.name === config.name && m.year === comparisonYear && m.period === null && m.week === null && m.quarter === null);
           }

           if (savedAggregate) {
             calculatedSalesComparisonData[key] = { value: savedAggregate.value };
           } else {
             const relevantMetrics = Array.isArray(comparisonMetricsForSales) ? comparisonMetricsForSales.filter(m => m.name === config.name) : [];
             let calculatedValue = 0;
             if (relevantMetrics.length > 0) {
               if (config.aggregation === 'avg') {
                 calculatedValue = relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0) / relevantMetrics.length;
               } else { // 'sum' or default
                 calculatedValue = relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0);
               }
             }
             calculatedSalesComparisonData[key] = { value: calculatedValue };
           }
        }
        
        let vsBudgetSavedComparison;
        if (salesSummaryViewMode === 'period') {
          vsBudgetSavedComparison = comparisonYearMetrics.find(m => m.name === 'vs Budget' && m.year === comparisonYear && m.period === salesSummaryPeriod && m.week === null && m.quarter === null);
        } else if (salesSummaryViewMode === 'quarter') {
          vsBudgetSavedComparison = comparisonYearMetrics.find(m => m.name === 'vs Budget' && m.year === comparisonYear && m.quarter === salesSummaryQuarter && m.period === null && m.week === null);
        } else { // YTD
          vsBudgetSavedComparison = comparisonYearMetrics.find(m => m.name === 'vs Budget' && m.year === comparisonYear && m.period === null && m.week === null && m.quarter === null);
        }

        if (vsBudgetSavedComparison) {
          calculatedSalesComparisonData['vsBudget'] = { value: vsBudgetSavedComparison.value };
        } else {
          const weeklyVsBudgetMetrics = Array.isArray(comparisonMetricsForSales) ? comparisonMetricsForSales.filter(m => m.name === 'vs Budget') : [];
          const calculatedVsBudget = weeklyVsBudgetMetrics.reduce((sum, m) => sum + (m.value || 0), 0);
          calculatedSalesComparisonData['vsBudget'] = { value: calculatedVsBudget };
        }

        setSalesComparisonData(calculatedSalesComparisonData);
      } else {
        setSalesComparisonData({}); // Clear if toggle is off
      }

    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load data. Please refresh the page.");
      setKpiData([]);
      setSummaryKpiData({});
      setSalesSummaryKpiData({});
    } finally {
      setIsLoading(false);
      loadingRef.current = false; // NEW: Release the lock
    }
  }, [currentYear, currentPeriod, currentWeek, summaryViewMode, summaryPeriod, summaryQuarter, salesSummaryViewMode, salesSummaryPeriod, salesSummaryQuarter, showOpsComparison, comparisonYear, getQuarterPeriods, showSalesComparison]);

  useEffect(() => {
    // NEW: Only load data after initialization is complete
    if (!isInitialized) return;
    
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
    }

    debounceTimeoutRef.current = setTimeout(() => {
      loadAllData();
    }, 300); 

    return () => {
      if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
      }
    };
  }, [loadAllData, isInitialized]); // NEW: Added isInitialized dependency

  const getKPIValue = useCallback((name) => {
    const kpi = kpiData.find(k => k.name === name);

    // If in P1 W3 or later, or any period after P1, show empty/null for any metric that has no data, instead of using fallbackData.
    const inClearRange = (currentPeriod === 1 && currentWeek >= 3) || (currentPeriod > 1);

    if (inClearRange && !kpi) {
      return { value: null, target: null, previous_value: null };
    }

    return kpi || fallbackData[name] || { value: null, target: null, previous_value: null };
  }, [kpiData, currentPeriod, currentWeek]);

  const kpiValues = useMemo(() => {
    const values = {};
    kpiConfig.forEach(kpi => {
        values[kpi.name] = getKPIValue(kpi.name);
    });
    return values;
  }, [getKPIValue]);

  const handleEditToggle = () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to edit data.");
      return;
    }
    if (isEditing) {
      const hasWeeklyChanges = Object.keys(editedData).some(key => {
        const originalValue = kpiValues[key]?.value;
        const editedValue = editedData[key];
        // Compare only if editedValue is a number and different from original
        return typeof editedValue === 'number' && editedValue !== originalValue;
      });

      const hasSummaryChanges = Object.keys(editedSummaryData).some(key => {
        const originalValue = summaryKpiData[key]?.value;
        const editedValue = editedSummaryData[key]?.value;
        return typeof editedValue === 'number' && editedValue !== originalValue;
      });

      const hasSalesSummaryChanges = Object.entries(editedSalesSummaryData).some(([key, data]) => {
        const originalValue = salesSummaryKpiData[key]?.value;
        const editedValue = data?.value;
        return typeof editedValue === 'number' && editedValue !== originalValue;
      });

      if (hasWeeklyChanges || hasSummaryChanges || hasSalesSummaryChanges) {
        setShowConfirmDialog(true);
      } else {
        setIsEditing(false);
        setEditedData({});
        setEditedSummaryData({});
        setEditedSalesSummaryData({});
      }
    } else {
      const initialEditableData = {};
      kpiConfig.forEach(kpi => {
        if (kpi.isEditable) {
            // Initialize editedData with current displayed value, or 0 if null/undefined
            initialEditableData[kpi.name] = kpiValues[kpi.name]?.value ?? 0;
        }
      });
      setEditedData(initialEditableData);
      setEditedSummaryData(JSON.parse(JSON.stringify(summaryKpiData)));

      const initialEditableSalesSummaryData = {};
      Object.entries(salesSummaryKpiData).forEach(([key, valueData]) => {
          // Only populate editable fields for Period/Quarter/YTD views
          if (salesSummaryConfig[key] && !salesSummaryConfig[key].isHidden) {
              initialEditableSalesSummaryData[key] = { value: valueData?.value ?? 0 };
          }
      });
      setEditedSalesSummaryData(initialEditableSalesSummaryData);
      setIsEditing(true);
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedData({});
    setEditedSummaryData({});
    setEditedSalesSummaryData({});
    setShowConfirmDialog(false);
  };

  const handleValueChange = (kpiName, value) => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to edit data.");
      return;
    }
    setEditedData(prev => ({ ...prev, [kpiName]: parseFloat(value) || 0 }));
  };

  const handleSummaryValueChange = (kpiKey, value) => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to edit data.");
      return;
    }
    setEditedSummaryData(prev => ({
      ...prev,
      [kpiKey]: { ...prev[kpiKey], value: parseFloat(value) || 0 }
    }));
  };

  const handleSalesSummaryValueChange = (kpiKey, value) => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to edit data.");
      return;
    }
    setEditedSalesSummaryData(prev => ({
      ...prev,
      [kpiKey]: { ...prev[kpiKey], value: parseFloat(value) || 0 }
    }));
  };

  const handleSaveAllChanges = async () => { // Renamed from handleConfirmSave
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to save data.");
      return;
    }
    const upsertPromises = [];
    let hasChanges = false;

    // --- Logic for saving weekly data ---
    for (const [kpiName, editedValue] of Object.entries(editedData)) {
      const config = kpiConfig.find(k => k.name === kpiName);
      if (!config || !config.isEditable) continue;

      const numericValue = parseFloat(editedValue);
      if (isNaN(numericValue)) continue;

      // Find the existing weekly KPI record for the current period/week/year
      const existingKpiRecord = kpiData.find(k => k.name === kpiName && k.period === currentPeriod && k.week === currentWeek && k.year === currentYear);

      if (existingKpiRecord) {
        // Update existing record if value changed
        if (existingKpiRecord.value !== numericValue) {
          hasChanges = true;
          upsertPromises.push(KPIMetric.update(existingKpiRecord.id, { value: numericValue }));
        }
      } else {
        // Create new record only if the entered value is different from the effective (displayed) value
        // The effective value might be null if no data or fallback. So, compare with 0 if it's null.
        const currentEffectiveValue = kpiValues[kpiName]?.value ?? 0; 
        if (numericValue !== currentEffectiveValue) {
          hasChanges = true;
          upsertPromises.push(KPIMetric.create({
            name: kpiName,
            category: config.category,
            value: numericValue,
            unit: config.unit,
            date: format(new Date(), 'yyyy-MM-dd'),
            period: currentPeriod,
            week: currentWeek,
            year: currentYear,
            quarter: null, // Weekly data doesn't have a quarter
            target: config.target || 0,
            red_threshold: config.redThreshold || 0,
            amber_threshold: config.amberThreshold || 0,
            green_threshold: config.greenThreshold || 0
          }));
        }
      }
    }

    // --- Logic for saving Ops/Customer summary data ---
    const changedSummaryData = Object.entries(editedSummaryData).filter(([key, data]) => {
        return data.value !== summaryKpiData[key]?.value;
    });

    for (const [key, data] of changedSummaryData) {
      hasChanges = true;
      const config = summaryKpiConfig[key];
      // Try to find full KPI config for category and thresholds
      const kpiDetails = kpiConfig.find(c => c.name === config.name) || {}; 

      let filter;
      let newRecordTemplate = {
        name: config.name,
        value: data.value,
        unit: config.unit,
        category: kpiDetails.category || 'operations', // Default category
        date: format(new Date(), 'yyyy-MM-dd'),
        year: currentYear,
        target: kpiDetails.target || 0,
        red_threshold: kpiDetails.redThreshold || 0,
        amber_threshold: kpiDetails.amberThreshold || 0,
        green_threshold: kpiDetails.greenThreshold || 0
      };

      if (summaryViewMode === 'period') {
        filter = { name: config.name, period: summaryPeriod, year: currentYear, week: null, quarter: null };
        newRecordTemplate = { ...newRecordTemplate, period: summaryPeriod, week: null, quarter: null };
      } else if (summaryViewMode === 'quarter') {
        filter = { name: config.name, year: currentYear, period: null, week: null, quarter: summaryQuarter };
        newRecordTemplate = { ...newRecordTemplate, quarter: summaryQuarter, period: null, week: null };
      } else { // ytd
        filter = { name: config.name, year: currentYear, period: null, week: null, quarter: null };
        newRecordTemplate = { ...newRecordTemplate, period: null, week: null, quarter: null };
      }

      upsertPromises.push((async () => {
        const existing = await KPIMetric.filter(filter);
        if (existing.length > 0) {
          await KPIMetric.update(existing[0].id, { value: data.value });
        } else {
          await KPIMetric.create(newRecordTemplate);
        }
      })());
    }

    // --- Logic for saving Sales summary data ---
    const changedSalesSummaryData = Object.entries(editedSalesSummaryData).filter(([key, data]) => {
      return data.value !== salesSummaryKpiData[key]?.value;
    });

    for (const [key, data] of changedSalesSummaryData) {
      hasChanges = true;
      const config = salesSummaryConfig[key];
      // Try to find full KPI config for category and thresholds
      const kpiDetails = kpiConfig.find(c => c.name === config.name) || {}; 

      let filter;
      let newRecordTemplate = {
        name: config.name,
        value: data.value,
        unit: config.unit,
        category: kpiDetails.category || 'sales', // Default category
        date: format(new Date(), 'yyyy-MM-dd'),
        year: currentYear,
        target: kpiDetails.target || 0,
        red_threshold: kpiDetails.redThreshold || 0,
        amber_threshold: kpiDetails.amberThreshold || 0,
        green_threshold: kpiDetails.greenThreshold || 0
      };

      if (salesSummaryViewMode === 'period') {
        filter = { name: config.name, period: salesSummaryPeriod, year: currentYear, week: null, quarter: null };
        newRecordTemplate = { ...newRecordTemplate, period: salesSummaryPeriod, week: null, quarter: null };
      } else if (salesSummaryViewMode === 'quarter') {
        filter = { name: config.name, year: currentYear, period: null, week: null, quarter: salesSummaryQuarter };
        newRecordTemplate = { ...newRecordTemplate, quarter: salesSummaryQuarter, period: null, week: null };
      } else { // ytd
        filter = { name: config.name, year: currentYear, period: null, week: null, quarter: null };
        newRecordTemplate = { ...newRecordTemplate, period: null, week: null, quarter: null };
      }

      upsertPromises.push((async () => {
        const existing = await KPIMetric.filter(filter);
        if (existing.length > 0) {
          await KPIMetric.update(existing[0].id, { value: data.value });
        } else {
          await KPIMetric.create(newRecordTemplate);
        }
      })());
    }

    if (!hasChanges) {
      toast.warning("No changes to save.");
      setShowConfirmDialog(false);
      setIsEditing(false);
      setEditedData({});
      setEditedSummaryData({});
      setEditedSalesSummaryData({});
      return;
    }

    setShowConfirmDialog(false);

    try {
      toast.promise(Promise.all(upsertPromises), {
          loading: 'Saving all changes...',
          success: (res) => {
            setTimeout(() => {
              loadAllData();
              setIsEditing(false);
              setEditedData({});
              setEditedSummaryData({});
              setEditedSalesSummaryData({});
            }, 500);
            return 'All data saved successfully!';
          },
          error: 'An error occurred while saving.',
      });
    } catch (error) {
      console.error("Error saving KPI data:", error);
    }
  };

  const handleClearData = async () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to clear data.");
      return;
    }
    setShowClearConfirmDialog(false);

    try {
      // Removed setTimeout(200) delay before filter
      const recordsToDelete = await KPIMetric.filter({
          period: currentPeriod,
          week: currentWeek,
          year: currentYear
      });

      if (recordsToDelete.length === 0) {
          toast.info("There is no data to clear for this week.");
          return;
      }

      // Add delay to avoid rate limiting for multiple deletes
      const deletePromises = recordsToDelete.map((record, index) =>
        new Promise(resolve =>
          setTimeout(() =>
            KPIMetric.delete(record.id).then(resolve),
            index * 100 // Sequential delay reduced from 200ms to 100ms
          )
        )
      );

      toast.promise(Promise.all(deletePromises), {
          loading: `Deleting ${recordsToDelete.length} records...`,
          success: () => {
              setTimeout(() => loadAllData(), 500); // Delay before reloading all data reduced from 1000ms to 500ms
              return "Data for the selected week has been cleared successfully.";
          },
          error: "Failed to clear data. Please try again.",
      });
    } catch (error) {
      toast.error("Failed to clear data. Please try again.");
      console.error("Error in handleClearData:", error);
    }
  };

  const handleIndividualClearData = (kpiName) => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to clear data.");
      return;
    }
    setKpiToClear(kpiName);
    setShowIndividualClearDialog(true);
  };

  const confirmIndividualClear = async () => {
    setShowIndividualClearDialog(false);

    try {
      await new Promise(resolve => setTimeout(resolve, 200)); // Delay before filter
      const recordsToDelete = await KPIMetric.filter({
        name: kpiToClear,
        period: currentPeriod,
        week: currentWeek,
        year: currentYear
      });

      if (recordsToDelete.length === 0) {
        toast.info(`No data found for ${kpiToClear} in this week.`);
        return;
      }

      const deletePromises = recordsToDelete.map((record, index) =>
        new Promise(resolve =>
          setTimeout(() =>
            KPIMetric.delete(record.id).then(resolve),
            index * 200 // Sequential delay
          )
        )
      );

      toast.promise(Promise.all(deletePromises), {
        loading: `Clearing ${recordsToDelete.length} ${kpiToClear} records...`,
        success: () => {
          setTimeout(() => loadAllData(), 1000); // Delay before reloading all data
          return `${kpiToClear} data cleared successfully.`;
        },
        error: () => `Failed to clear ${kpiToClear} data.`,
      });

    } catch (error) {
      console.error(`Error clearing ${kpiToClear} data:`, error);
      toast.error(`Failed to clear ${kpiToClear} data.`);
    } finally {
      setKpiToClear('');
    }
  };

  const handleSummaryValueClear = (kpiName) => { // Renamed from handleSummaryClearData to clarify it's for individual summary KPI
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to clear data.");
      return;
    }
    setSummaryKpiToClear(kpiName);
    setShowClearSummaryConfirmDialog(true); // This dialog is for individual summary KPI clear
  };

  const handleSalesSummaryValueClear = (kpiName) => { // Renamed from handleSalesSummaryClearData to clarify it's for individual sales summary KPI
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to clear data.");
      return;
    }
    setSummaryKpiToClear(kpiName); // Reusing summaryKpiToClear state
    setShowClearSummaryConfirmDialog(true); // This dialog is for individual summary KPI clears
  };

  const confirmSummaryClear = async () => { // This function handles clearing INDIVIDUAL summary KPIs
    if (!summaryKpiToClear) return;

    setShowClearSummaryConfirmDialog(false);

    const nameToClear = summaryKpiToClear;
    let configMatch = null;
    let currentViewMode = null;
    let currentPeriodOrQuarterValue = null;

    // Determine which summary type the KPI belongs to and its current view settings
    // Check in summaryKpiConfig (Ops/Customer)
    for (const [key, config] of Object.entries(summaryKpiConfig)) {
      if (config.name === nameToClear) {
        configMatch = config;
        currentViewMode = summaryViewMode;
        currentPeriodOrQuarterValue = summaryViewMode === 'period' ? summaryPeriod : summaryQuarter; // Get the correct period/quarter value
        break;
      }
    }

    // If not found, check in salesSummaryConfig
    if (!configMatch) {
      for (const [key, config] of Object.entries(salesSummaryConfig)) {
        if (config.name === nameToClear) {
          configMatch = config;
          currentViewMode = salesSummaryViewMode;
          currentPeriodOrQuarterValue = salesSummaryViewMode === 'period' ? salesSummaryPeriod : salesSummaryQuarter; // Get the correct period/quarter value
          break;
        }
      }
    }

    if (!configMatch) {
      toast.info(`KPI not found for '${nameToClear}'.`);
      setSummaryKpiToClear(null); // Clear the state
      return;
    }

    // Construct filter based on current view mode (period, quarter, ytd)
    let filter;
    if (currentViewMode === 'period') {
      filter = { name: nameToClear, period: currentPeriodOrQuarterValue, year: currentYear, week: null, quarter: null };
    } else if (currentViewMode === 'quarter') {
      filter = { name: nameToClear, quarter: currentPeriodOrQuarterValue, year: currentYear, week: null, period: null };
    } else { // ytd
      filter = { name: nameToClear, year: currentYear, period: null, week: null, quarter: null };
    }

    try {
      await new Promise(resolve => setTimeout(resolve, 200)); // Delay before filter
      const recordsToDelete = await KPIMetric.filter(filter);

      if (recordsToDelete.length === 0) {
        toast.info(`No specific summary data found for ${nameToClear} to clear.`);
        setTimeout(() => loadAllData(), 500); // Delay before reloading all data
        return;
      }

      const deletePromises = recordsToDelete.map((record, index) =>
        new Promise(resolve =>
          setTimeout(() =>
            KPIMetric.delete(record.id).then(resolve),
            index * 200 // Sequential delay
          )
        )
      );

      toast.promise(Promise.all(deletePromises), {
        loading: `Clearing summary data for ${nameToClear}...`,
        success: () => {
          setTimeout(() => loadAllData(), 1000); // Delay before reloading all data
          return `${nameToClear} summary data cleared successfully.`;
        },
        error: () => `Failed to clear ${nameToClear} summary data.`,
      });

    } catch (error) {
      toast.error(`Failed to clear ${nameToClear} summary data.`);
      console.error(`Error in confirmSummaryClear for ${nameToClear}:`, error);
    } finally {
      setSummaryKpiToClear(null);
    }
  };

  const handleClearAllOpsReadiness = async () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to clear data.");
      return;
    }
    setShowClearAllOpsConfirmDialog(false);

    try {
      // Get all ops readiness KPIs to clear
      const opsKpiNames = Object.values(summaryKpiConfig).map(config => config.name);
      
      const allRecords = await KPIMetric.filter({ year: currentYear }, '-created_date', 2000);
      const recordsToDelete = allRecords.filter(record => {
        // Must be an ops readiness KPI
        if (!opsKpiNames.includes(record.name)) return false;
        
        // Apply the view mode filter
        if (summaryViewMode === 'period') {
          return record.period === summaryPeriod && record.week === null && record.quarter === null;
        } else if (summaryViewMode === 'quarter') {
          return record.quarter === summaryQuarter && record.week === null && record.period === null;
        } else { // ytd
          return record.week === null && record.quarter === null && record.period === null;
        }
      });

      if (recordsToDelete.length === 0) {
        toast.info("No Ops Readiness data found to clear for this view.");
        return;
      }

      const deletePromises = recordsToDelete.map((record, index) =>
        new Promise(resolve =>
          setTimeout(() =>
            KPIMetric.delete(record.id).then(resolve),
            index * 100
          )
        )
      );

      toast.promise(Promise.all(deletePromises), {
        loading: `Clearing ${recordsToDelete.length} Ops Readiness records...`,
        success: () => {
          setTimeout(() => loadAllData(), 500);
          return "Ops Readiness data cleared successfully.";
        },
        error: "Failed to clear Ops Readiness data.",
      });

    } catch (error) {
      toast.error("Failed to clear Ops Readiness data.");
      console.error("Error in handleClearAllOpsReadiness:", error);
    }
  };

  const handleClearAllSalesSummary = async () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to clear data.");
      return;
    }
    setShowClearAllSalesConfirmDialog(false);

    try {
      // Get all sales summary KPIs to clear
      const salesKpiNames = Object.values(salesSummaryConfig).map(config => config.name);
      
      const allRecords = await KPIMetric.filter({ year: currentYear }, '-created_date', 2000);
      const recordsToDelete = allRecords.filter(record => {
        // Must be a sales summary KPI
        if (!salesKpiNames.includes(record.name)) return false;
        
        // Apply the view mode filter
        if (salesSummaryViewMode === 'period') {
          return record.period === salesSummaryPeriod && record.week === null && record.quarter === null;
        } else if (salesSummaryViewMode === 'quarter') {
          return record.quarter === salesSummaryQuarter && record.week === null && record.period === null;
        } else { // ytd
          return record.week === null && record.quarter === null && record.period === null;
        }
      });

      if (recordsToDelete.length === 0) {
        toast.info("No Sales Summary data found to clear for this view.");
        return;
      }

      const deletePromises = recordsToDelete.map((record, index) =>
        new Promise(resolve =>
          setTimeout(() =>
            KPIMetric.delete(record.id).then(resolve),
            index * 100
          )
        )
      );

      toast.promise(Promise.all(deletePromises), {
        loading: `Clearing ${recordsToDelete.length} Sales Summary records...`,
        success: () => {
          setTimeout(() => loadAllData(), 500);
          return "Sales Summary data cleared successfully.";
        },
        error: "Failed to clear Sales Summary data.",
      });

    } catch (error) {
      toast.error("Failed to clear Sales Summary data.");
      console.error("Error in handleClearAllSalesSummary:", error);
    }
  };

  return (
    <div className="p-6 space-y-6 min-h-screen">
      {isLoading && (
        <div className="fixed inset-0 bg-white bg-opacity-80 flex items-center justify-center z-[9999]">
          <div className="relative flex justify-center items-center">
            <div className="h-10 w-10 rounded-full border-4 border-t-4 border-orange-500 border-opacity-20 animate-spin" style={{ borderTopColor: 'rgb(249, 115, 22)' }}></div>
            <span className="ml-3 text-orange-500 font-semibold">Loading...</span>
          </div>
        </div>
      )}

      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Changes</DialogTitle>
            <DialogDescription>
              You are about to save the following changes. Please confirm.
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-60 overflow-y-auto my-4">
            <ul className="space-y-2">
                {Object.entries(editedData)
                    .filter(([name]) => {
                        const config = kpiConfig.find(k=>k.name===name);
                        // Filter for editable KPIs where the edited value is different from the original,
                        // treating null/undefined original values as 0 for comparison if the edited value is a number.
                        const originalValue = kpiValues[name]?.value ?? 0;
                        const editedValue = editedData[name];
                        return config?.isEditable && typeof editedValue === 'number' && editedValue !== originalValue;
                    })
                    .map(([name, value]) => (
                        <li key={`weekly-${name}`} className="flex justify-between items-center py-2 border-b">
                            <span className="text-gray-600">{name}:</span>
                            <div className="flex items-center gap-2">
                                <span className="text-sm text-gray-500 line-through">{kpiValues[name]?.value ?? 0}</span>
                                <span className="font-bold text-lg text-sainsbury-orange">{value}</span>
                            </div>
                        </li>
                ))}
                {Object.entries(editedSummaryData)
                    .filter(([key, data]) => data.value !== summaryKpiData[key]?.value)
                    .map(([key, data]) => (
                        <li key={`ops-summary-${key}`} className="flex justify-between items-center py-2 border-b">
                            <span className="text-gray-600">{summaryKpiConfig[key].name} ({
                                summaryViewMode === 'period' ? `P${summaryPeriod}` :
                                summaryViewMode === 'quarter' ? `Q${summaryQuarter}` :
                                'YTD'
                            }):</span>
                            <div className="flex items-center gap-2">
                                <span className="text-sm text-gray-500 line-through">{summaryKpiData[key]?.value}</span>
                                <span className="font-bold text-lg text-sainsbury-orange">{data.value}</span>
                            </div>
                        </li>
                ))}
                {Object.entries(editedSalesSummaryData)
                    .filter(([key, data]) => data.value !== salesSummaryKpiData[key]?.value)
                    .map(([key, data]) => (
                        <li key={`sales-summary-${key}`} className="flex justify-between items-center py-2 border-b">
                            <span className="text-gray-600">{salesSummaryConfig[key].name} ({
                                salesSummaryViewMode === 'period' ? `P${salesSummaryPeriod}` :
                                salesSummaryViewMode === 'quarter' ? `Q${salesSummaryQuarter}` :
                                'YTD'
                            }):</span>
                            <div className="flex items-center gap-2">
                                <span className="text-sm text-gray-500 line-through">{salesSummaryKpiData[key]?.value}</span>
                                <span className="font-bold text-lg text-sainsbury-orange">{data.value}</span>
                            </div>
                        </li>
                ))}
            </ul>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCancelEdit}>Cancel</Button>
            <Button onClick={handleSaveAllChanges} className="sainsbury-gradient text-white">Confirm & Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showClearConfirmDialog} onOpenChange={setShowClearConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Are you sure?</DialogTitle>
            <DialogDescription>
              You are about to permanently delete all KPI data for Period {currentPeriod}, Week {currentWeek}, {currentYear}. This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClearConfirmDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleClearData}>Yes, Clear Data</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showIndividualClearDialog} onOpenChange={setShowIndividualClearDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Clear {kpiToClear} Data</DialogTitle>
            <DialogDescription>
              Are you sure you want to clear all {kpiToClear} data for Period {currentPeriod}, Week {currentWeek}, {currentYear}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowIndividualClearDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmIndividualClear}>Clear {kpiToClear}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showClearSummaryConfirmDialog} onOpenChange={setShowClearSummaryConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Clear {summaryKpiToClear} Data</DialogTitle>
            <DialogDescription>
              Are you sure you want to clear the saved summary data for {summaryKpiToClear} for this {
                summaryViewMode === 'period' ? `Period ${summaryPeriod}` :
                summaryViewMode === 'quarter' ? `Quarter ${summaryQuarter}` :
                salesSummaryViewMode === 'period' ? `Period ${salesSummaryPeriod}` :
                salesSummaryViewMode === 'quarter' ? `Quarter ${salesSummaryQuarter}` :
                'Year to Date'
              }? This will cause the value to revert to the calculated average from weekly data (if applicable), or to zero if no calculated average is defined. Note: This action only clears manually saved overrides, not the underlying weekly data.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClearSummaryConfirmDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmSummaryClear}>Clear Summary Data</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="no-print">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-gray-900">Performance Overview</h1>
            {/* The paragraph <p className="text-slate-600">Period {currentPeriod}, {currentYear} | Week ending {weekRange.end}</p> was omitted due to undefined 'weekRange' variable. */}
          </div>
          <div className="flex items-center gap-2">
            <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))}>
              <SelectTrigger className="w-full sm:w-32 hover-glass">
                  <SelectValue />
              </SelectTrigger>
              <SelectContent>
                  {Array.from({ length: 3 }, (_, i) => new Date().getFullYear() + i - 1).map(y => (
                    <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                  ))}
              </SelectContent>
            </Select>
            {canEdit && (
                <>
                    {isEditing && (
                        <Button variant="outline" size="sm" onClick={handleCancelEdit} className="border-slate-200 rounded-lg px-4 py-2">
                            <X className="w-4 h-4 mr-2"/>
                            Cancel
                        </Button>
                    )}
                    <Button size="sm" onClick={handleEditToggle} className="btn-modern">
                        {isEditing ? <><Save className="w-4 h-4 mr-2"/>Save Changes</> : <><Edit className="w-4 h-4 mr-2"/>Edit Mode</>}
                    </Button>
                    {kpiData.length > 0 && !isEditing && (
                        <Button variant="outline" size="sm" onClick={() => setShowClearConfirmDialog(true)} className="border-red-200 text-red-600 hover:bg-red-50 rounded-lg px-4 py-2">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Clear Data
                        </Button>
                    )}
                </>
            )}
            <Button variant="outline" size="sm" onClick={() => window.print()} className="border-slate-200 rounded-lg px-4 py-2">
              <FileDown className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
          </div>
        </div>
      </div>

      <Card className="glass-card">
        <CardHeader className="pb-6">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-6">
              <div className="space-y-2">
                  <CardTitle className="text-xl font-semibold text-slate-800">
                      Weekly KPIs Data
                  </CardTitle>
              </div>
              <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                  <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))}>
                      <SelectTrigger className="w-full sm:w-32 hover-glass">
                          <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                          {Array.from({ length: 13 }, (_, i) => (
                              <SelectItem key={i + 1} value={(i + 1).toString()}>
                                  Period {i + 1}
                              </SelectItem>
                          ))}
                      </SelectContent>
                  </Select>
                  <Select value={currentWeek.toString()} onValueChange={(val) => setCurrentWeek(parseInt(val))}>
                      <SelectTrigger className="w-full sm:w-32 hover-glass">
                          <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                          {Array.from({ length: 4 }, (_, i) => (
                              <SelectItem key={i + 1} value={(i + 1).toString()}>
                                  Week {i + 1}
                              </SelectItem>
                          ))}
                      </SelectContent>
                  </Select>
                   {/* Year Select moved to the main page header */}
              </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
            {/* Sales */}
            <KPICard
              title="Sales"
              value={isEditing ? (editedData.Sales ?? kpiValues.Sales?.value) : kpiValues.Sales?.value}
              target={kpiValues.Sales?.target}
              previousValue={kpiValues.Sales?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Sales", val)}
              unit="currency"
              greenThreshold={120000}
              amberThreshold={100000}
              redThreshold={80000}
              icon={PoundSterling}
              showClearButton={canEdit && !isEditing && (kpiValues.Sales?.value !== null && kpiValues.Sales?.value !== undefined)}
              onClearData={handleIndividualClearData}
            />

            {/* Budget */}
            <KPICard
              title="Budget"
              value={isEditing ? (editedData.Budget ?? kpiValues.Budget?.value) : kpiValues.Budget?.value}
              target={kpiValues.Budget?.target}
              previousValue={kpiValues.Budget?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Budget", val)}
              unit="currency"
              greenThreshold={120000}
              amberThreshold={100000}
              redThreshold={80000}
              icon={Target}
              showClearButton={canEdit && !isEditing && (kpiValues.Budget?.value !== null && kpiValues.Budget?.value !== undefined)}
              onClearData={handleIndividualClearData}
            />

            {/* vs Budget - Now editable */}
            <KPICard
              title="vs Budget"
              value={isEditing ? (editedData["vs Budget"] ?? kpiValues["vs Budget"]?.value) : kpiValues["vs Budget"]?.value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("vs Budget", val)}
              unit="currency"
              greenThreshold={0.01}
              amberThreshold={0}
              redThreshold={-0.01}
              icon={TrendingUp}
              showClearButton={canEdit && !isEditing && (kpiValues["vs Budget"]?.value !== null && kpiValues["vs Budget"]?.value !== undefined)}
              onClearData={() => handleIndividualClearData("vs Budget")}
            />

            {/* Net Sales YOY */}
            <KPICard
              title="Sales YOY"
              value={isEditing ? (editedData["Net Sales YOY"] ?? kpiValues["Net Sales YOY"]?.value) : kpiValues["Net Sales YOY"]?.value}
              target={kpiValues["Net Sales YOY"]?.target}
              previousValue={kpiValues["Net Sales YOY"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Net Sales YOY", val)}
              unit="currency"
              greenThreshold={0.01}
              amberThreshold={0}
              redThreshold={-0.01}
              icon={PoundSterling}
              showClearButton={canEdit && !isEditing && (kpiValues["Net Sales YOY"]?.value !== null && kpiValues["Net Sales YOY"]?.value !== undefined)}
              onClearData={handleIndividualClearData}
            />

            {/* Net Sales YOY (%) */}
            <KPICard
              title="Sales YOY%"
              value={isEditing ? (editedData["Net Sales YOY (%)"] ?? kpiValues["Net Sales YOY (%)"]?.value) : kpiValues["Net Sales YOY (%)"]?.value}
              target={kpiValues["Net Sales YOY (%)"]?.target}
              previousValue={kpiValues["Net Sales YOY (%)"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Net Sales YOY (%)", val)}
              unit="percentage"
              greenThreshold={0.01}
              amberThreshold={0}
              redThreshold={-0.01}
              icon={TrendingUp}
              showClearButton={canEdit && !isEditing && (kpiValues["Net Sales YOY (%)"]?.value !== null && kpiValues["Net Sales YOY (%)"]?.value !== undefined)}
              onClearData={handleIndividualClearData}
            />

            {/* Delivered Orders */}
            <KPICard
              title="Orders"
              value={isEditing ? (editedData["Delivered Orders"] ?? kpiValues["Delivered Orders"]?.value) : kpiValues["Delivered Orders"]?.value}
              target={kpiValues["Delivered Orders"]?.target}
              previousValue={kpiValues["Delivered Orders"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Delivered Orders", val)}
              unit="number"
              greenThreshold={1200}
              amberThreshold={1000}
              redThreshold={800}
              icon={ShoppingCart}
              showClearButton={canEdit && !isEditing && (kpiValues["Delivered Orders"]?.value !== null && kpiValues["Delivered Orders"]?.value !== undefined)}
              onClearData={handleIndividualClearData}
            />

            {/* Delivered Items */}
            <KPICard
              title="Items"
              value={isEditing ? (editedData["Delivered Items"] ?? kpiValues["Delivered Items"]?.value) : kpiValues["Delivered Items"]?.value}
              target={kpiValues["Delivered Items"]?.target}
              previousValue={kpiValues["Delivered Items"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Delivered Items", val)}
              unit="number"
              greenThreshold={8500}
              amberThreshold={7500}
              redThreshold={6500}
              icon={Package}
              showClearButton={canEdit && !isEditing && (kpiValues["Delivered Items"]?.value !== null && kpiValues["Delivered Items"]?.value !== undefined)}
              onClearData={handleIndividualClearData}
            />

            {/* Ops Score */}
            <KPICard
              title="Ops Score"
              value={isEditing ? (editedData["Ops Score"] ?? kpiValues["Ops Score"]?.value) : kpiValues["Ops Score"]?.value}
              target={kpiValues["Ops Score"]?.target}
              previousValue={kpiValues["Ops Score"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Ops Score", val)}
              unit="percentage"
              greenThreshold={80}
              amberThreshold={60}
              redThreshold={59.99}
              icon={CheckCircle}
              showClearButton={canEdit && !isEditing && (kpiValues["Ops Score"]?.value !== null && kpiValues["Ops Score"]?.value !== undefined)}
              onClearData={handleIndividualClearData}
            />

            {/* Shoppers Achieving */}
            <KPICard
              title="Shoppers"
              value={isEditing ? (editedData["Shoppers Achieving"] ?? kpiValues["Shoppers Achieving"]?.value) : kpiValues["Shoppers Achieving"]?.value}
              target={kpiValues["Shoppers Achieving"]?.target}
              previousValue={kpiValues["Shoppers Achieving"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Shoppers Achieving", val)}
              unit="percentage"
              greenThreshold={80}
              amberThreshold={60}
              redThreshold={59.99}
              icon={Users}
              showClearButton={canEdit && !isEditing && (kpiValues["Shoppers Achieving"]?.value !== null && kpiValues["Shoppers Achieving"]?.value !== undefined)}
              onClearData={handleIndividualClearData}
            />

            {/* On Time Departures */}
            <KPICard
              title="OTDept"
              value={isEditing ? (editedData["On Time Departures"] ?? kpiValues["On Time Departures"]?.value) : kpiValues["On Time Departures"]?.value}
              target={kpiValues["On Time Departures"]?.target}
              previousValue={kpiValues["On Time Departures"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("On Time Departures", val)}
              unit="percentage"
              greenThreshold={98}
              amberThreshold={95}
              redThreshold={94.99}
              icon={Clock}
              showClearButton={canEdit && !isEditing && (kpiValues["On Time Departures"]?.value !== null && kpiValues["On Time Departures"]?.value !== undefined)}
              onClearData={() => handleIndividualClearData("On Time Departures")}
            />

            {/* Availability */}
            <KPICard
              title="Availability"
              value={isEditing ? (editedData["Availability"] ?? kpiValues["Availability"]?.value) : kpiValues["Availability"]?.value}
              target={kpiValues["Availability"]?.target}
              previousValue={kpiValues["Availability"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Availability", val)}
              unit="percentage"
              greenThreshold={98}
              amberThreshold={95}
              redThreshold={94.99}
              icon={CheckCircle}
              showClearButton={canEdit && !isEditing && (kpiValues["Availability"]?.value !== null && kpiValues["Availability"]?.value !== undefined)}
              onClearData={handleIndividualClearData}
            />

            {/* Delivery Without Complaints */}
            <KPICard
              title="DWC"
              value={isEditing ? (editedData["Delivery Without Complaints"] ?? kpiValues["Delivery Without Complaints"]?.value) : kpiValues["Delivery Without Complaints"]?.value}
              target={kpiValues["Delivery Without Complaints"]?.target}
              previousValue={kpiValues["Delivery Without Complaints"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Delivery Without Complaints", val)}
              unit="percentage"
              greenThreshold={98}
              amberThreshold={96}
              redThreshold={95.99}
              icon={Clock}
              showClearButton={canEdit && !isEditing && (kpiValues["Delivery Without Complaints"]?.value !== null && kpiValues["Delivery Without Complaints"]?.value !== undefined)}
              onClearData={() => handleIndividualClearData("Delivery Without Complaints")}
            />

            {/* Secondary Replenishment */}
            <KPICard
              title="Sec Replen"
              value={isEditing ? (editedData["Secondary Replenishment"] ?? kpiValues["Secondary Replenishment"]?.value) : kpiValues["Secondary Replenishment"]?.value}
              target={kpiValues["Secondary Replenishment"]?.target}
              previousValue={kpiValues["Secondary Replenishment"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("Secondary Replenishment", val)}
              unit="percentage"
              higherIsBetter={false}
              greenThreshold={2}
              amberThreshold={2.01}
              redThreshold={3}
              icon={Package}
              showClearButton={canEdit && !isEditing && (kpiValues["Secondary Replenishment"]?.value !== null && kpiValues["Secondary Replenishment"]?.value !== undefined)}
              onClearData={() => handleIndividualClearData("Secondary Replenishment")}
            />

            {/* iCare */}
            <KPICard
              title="iCare"
              value={isEditing ? (editedData["iCare"] ?? kpiValues["iCare"]?.value) : kpiValues["iCare"]?.value}
              target={kpiValues["iCare"]?.target}
              previousValue={kpiValues["iCare"]?.previous_value}
              isEditable={true}
              isEditing={isEditing && canEdit}
              onValueChange={(val) => handleValueChange("iCare", val)}
              unit="percentage"
              greenThreshold={49.5}
              amberThreshold={49.4}
              redThreshold={49.39}
              icon={Heart}
              showClearButton={canEdit && !isEditing && (kpiValues["iCare"]?.value !== null && kpiValues["iCare"]?.value !== undefined)}
              onClearData={handleIndividualClearData}
            />
          </div>
        </CardContent>
      </Card>

      <div className="space-y-6">
        <Card className="glass-card">
          <CardHeader className="pb-6">
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-6">
                  <div className="space-y-2">
                      <CardTitle className="text-xl font-semibold text-slate-800">
                          Ops Readiness
                      </CardTitle>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto items-center">
                      <Tabs value={summaryViewMode} onValueChange={setSummaryViewMode} className="w-full sm:w-auto">
                          <TabsList className="grid w-full grid-cols-3">
                              <TabsTrigger value="period">Period</TabsTrigger>
                              <TabsTrigger value="quarter">Quarter</TabsTrigger>
                              <TabsTrigger value="ytd">Year to Date</TabsTrigger>
                          </TabsList>
                      </Tabs>
                      {summaryViewMode === 'period' && (
                          <Select value={summaryPeriod.toString()} onValueChange={(val) => setSummaryPeriod(parseInt(val))}>
                              <SelectTrigger className="w-full sm:w-32 hover-glass">
                                  <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                  {Array.from({ length: 13 }, (_, i) => (
                                      <SelectItem key={i + 1} value={(i + 1).toString()}>
                                          Period {i + 1}
                                      </SelectItem>
                                  ))}
                              </SelectContent>
                          </Select>
                      )}
                      {summaryViewMode === 'quarter' && (
                          <div className="grid grid-cols-2 gap-1 h-10 w-20">
                              <Button
                                  variant={summaryQuarter === 1 ? "default" : "outline"}
                                  size="sm"
                                  className={`h-4 text-xs px-1 ${summaryQuarter === 1 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
                                  onClick={() => setSummaryQuarter(1)}
                              >
                                  Q1
                              </Button>
                              <Button
                                  variant={summaryQuarter === 2 ? "default" : "outline"}
                                  size="sm"
                                  className={`h-4 text-xs px-1 ${summaryQuarter === 2 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
                                  onClick={() => setSummaryQuarter(2)}
                              >
                                  Q2
                              </Button>
                              <Button
                                  variant={summaryQuarter === 3 ? "default" : "outline"}
                                  size="sm"
                                  className={`h-4 text-xs px-1 ${summaryQuarter === 3 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
                                  onClick={() => setSummaryQuarter(3)}
                              >
                                  Q3
                              </Button>
                              <Button
                                  variant={summaryQuarter === 4 ? "default" : "outline"}
                                  size="sm"
                                  className={`h-4 text-xs px-1 ${summaryQuarter === 4 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
                                  onClick={() => setSummaryQuarter(4)}
                              >
                                  Q4
                              </Button>
                          </div>
                      )}
                      <div className="flex items-center space-x-2 pl-4">
                          <Switch
                              id="ops-comparison-toggle"
                              checked={showOpsComparison}
                              onCheckedChange={setShowOpsComparison}
                          />
                          <Label htmlFor="ops-comparison-toggle" className="text-sm font-medium text-slate-600 cursor-pointer">Compare</Label>
                      </div>

                      {showOpsComparison && (
                          <Select value={comparisonYear.toString()} onValueChange={(val) => setComparisonYear(parseInt(val))}>
                              <SelectTrigger className="w-full sm:w-32 hover-glass">
                                  <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                  {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i - 1).map(y => (
                                      <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                                  ))}
                              </SelectContent>
                          </Select>
                      )}
                      {canEdit && !isEditing && (
                          <Button variant="outline" size="sm" onClick={() => setShowClearAllOpsConfirmDialog(true)} className="border-red-200 text-red-600 hover:bg-red-50 rounded-lg px-4 py-2">
                              <Trash2 className="w-4 h-4 mr-2" />
                              Clear Data
                          </Button>
                      )}
                  </div>
              </div>
          </CardHeader>
          <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
                  {Object.entries(summaryKpiConfig).map(([key, config]) => {
                      const fullConfig = kpiConfig.find(c => c.name === config.name) || {};
                      const comparisonValue = showOpsComparison ? opsComparisonData[key]?.value : undefined;

                      // Custom title mapping for specific KPIs
                      let customTitle = config.name;
                      if (config.name === "Ops Score") customTitle = "Score";
                      else if (config.name === "On Time Departures") customTitle = "OTDept";
                      else if (config.name === "Delivery Without Complaints") customTitle = "DWC";
                      else if (config.name === "Secondary Replenishment") customTitle = "Sec Replen";
                      else if (config.name === "Shoppers Achieving") customTitle = "Shoppers";

                      return (
                          <KPICard
                              key={key}
                              title={customTitle}
                              value={isEditing ? editedSummaryData[key]?.value : summaryKpiData[key]?.value}
                              comparisonValue={comparisonValue}
                              comparisonYear={comparisonYear}
                              showComparison={showOpsComparison}
                              isEditable={true}
                              isEditing={isEditing && canEdit}
                              onValueChange={(val) => handleSummaryValueChange(key, val)}
                              unit={config.unit}
                              higherIsBetter={config.higherIsBetter !== false}
                              icon={config.icon}
                              greenThreshold={config.name === "On Time Departures" || config.name === "Availability" ? 98 : fullConfig.greenThreshold}
                              amberThreshold={config.name === "On Time Departures" || config.name === "Availability" ? 95 : fullConfig.amberThreshold}
                              redThreshold={config.name === "On Time Departures" || config.name === "Availability" ? 94.99 : fullConfig.redThreshold}
                              showClearButton={!isEditing && canEdit && (summaryKpiData[key]?.value !== null && summaryKpiData[key]?.value !== undefined)}
                              onClearData={handleSummaryValueClear}
                              clearIdentifier={config.name}
                          />
                      );
                  })}
              </div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader className="pb-6">
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-6">
                  <div className="space-y-2">
                      <CardTitle className="text-xl font-semibold text-slate-800">
                          Sales Summary
                      </CardTitle>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto items-center">
                      <Tabs value={salesSummaryViewMode} onValueChange={setSalesSummaryViewMode} className="w-full sm:w-auto">
                          <TabsList className="grid w-full grid-cols-3">
                              <TabsTrigger value="period">Period</TabsTrigger>
                              <TabsTrigger value="quarter">Quarter</TabsTrigger>
                              <TabsTrigger value="ytd">Year to Date</TabsTrigger>
                          </TabsList>
                      </Tabs>
                      {salesSummaryViewMode === 'period' && (
                          <Select value={salesSummaryPeriod.toString()} onValueChange={(val) => setSalesSummaryPeriod(parseInt(val))}>
                              <SelectTrigger className="w-full sm:w-32 hover-glass">
                                  <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                  {Array.from({ length: 13 }, (_, i) => (
                                      <SelectItem key={i + 1} value={(i + 1).toString()}>
                                          Period {i + 1}
                                      </SelectItem>
                                  ))}
                              </SelectContent>
                          </Select>
                      )}
                      {salesSummaryViewMode === 'quarter' && (
                          <div className="grid grid-cols-2 gap-1 h-10 w-20">
                              <Button
                                  variant={salesSummaryQuarter === 1 ? "default" : "outline"}
                                  size="sm"
                                  className={`h-4 text-xs px-1 ${salesSummaryQuarter === 1 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
                                  onClick={() => setSalesSummaryQuarter(1)}
                              >
                                  Q1
                              </Button>
                              <Button
                                  variant={salesSummaryQuarter === 2 ? "default" : "outline"}
                                  size="sm"
                                  className={`h-4 text-xs px-1 ${salesSummaryQuarter === 2 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
                                  onClick={() => setSalesSummaryQuarter(2)}
                              >
                                  Q2
                              </Button>
                              <Button
                                  variant={salesSummaryQuarter === 3 ? "default" : "outline"}
                                  size="sm"
                                  className={`h-4 text-xs px-1 ${salesSummaryQuarter === 3 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
                                  onClick={() => setSalesSummaryQuarter(3)}
                              >
                                  Q3
                              </Button>
                              <Button
                                  variant={salesSummaryQuarter === 4 ? "default" : "outline"}
                                  size="sm"
                                  className={`h-4 text-xs px-1 ${salesSummaryQuarter === 4 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
                                  onClick={() => setSalesSummaryQuarter(4)}
                              >
                                  Q4
                              </Button>
                          </div>
                      )}
                      {/* NEW COMPARISON CONTROLS */}
                      <div className="flex items-center space-x-2 pl-4">
                          <Switch
                              id="sales-comparison-toggle"
                              checked={showSalesComparison}
                              onCheckedChange={setShowSalesComparison}
                          />
                          <Label htmlFor="sales-comparison-toggle" className="text-sm font-medium text-slate-600 cursor-pointer">Compare</Label>
                      </div>

                      {showSalesComparison && (
                          <Select value={comparisonYear.toString()} onValueChange={(val) => setComparisonYear(parseInt(val))}>
                              <SelectTrigger className="w-full sm:w-32 hover-glass">
                                  <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                  {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i - 1).map(y => (
                                      <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                                  ))}
                              </SelectContent>
                          </Select>
                      )}
                      {canEdit && !isEditing && (
                          <Button variant="outline" size="sm" onClick={() => setShowClearAllSalesConfirmDialog(true)} className="border-red-200 text-red-600 hover:bg-red-50 rounded-lg px-4 py-2">
                              <Trash2 className="w-4 h-4 mr-2" />
                              Clear Data
                          </Button>
                      )}
                  </div>
              </div>
          </CardHeader>
          <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                  {Object.entries(salesSummaryConfig).filter(([,config]) => !config.isHidden).map(([key, config]) => {
                      const fullConfig = kpiConfig.find(c => c.name === config.name) || {};
                      const comparisonValue = showSalesComparison ? salesComparisonData[key]?.value : undefined; // NEW

                      return (
                          <KPICard
                              key={key}
                              title={
                                config.name === "Net Sales YOY" ? "Sales YOY" :
                                config.name === "Net Sales YOY (%)" ? "Sales YOY%" :
                                config.name === "Delivered Orders" ? "Orders" :
                                config.name === "Delivered Items" ? "Items" :
                                config.name
                              }
                              value={isEditing ? (editedSalesSummaryData[key]?.value ?? salesSummaryKpiData[key]?.value ?? null) : (salesSummaryKpiData[key]?.value ?? null)}
                              comparisonValue={comparisonValue} // NEW
                              comparisonYear={comparisonYear} // NEW
                              showComparison={showSalesComparison} // NEW
                              isEditable={true}
                              isEditing={isEditing && canEdit} // Editing now always enabled if canEdit (no "week" view to disable it)
                              onValueChange={(val) => handleSalesSummaryValueChange(key, val)}
                              unit={config.unit}
                              higherIsBetter={config.higherIsBetter !== false}
                              icon={config.icon}
                              greenThreshold={key === 'vsBudget' ? 0.01 : fullConfig.greenThreshold}
                              amberThreshold={key === 'vsBudget' ? 0 : fullConfig.amberThreshold}
                              redThreshold={key === 'vsBudget' ? -0.01 : fullConfig.redThreshold}
                              showClearButton={!isEditing && canEdit && (salesSummaryKpiData[key]?.value !== null && salesSummaryKpiData[key]?.value !== undefined)} // Clear button now always shown if canEdit
                              onClearData={handleSalesSummaryValueClear}
                              clearIdentifier={config.name}
                          />
                      );
                  })}
              </div>
          </CardContent>
        </Card>
      </div>

      {/* New Dialog for clearing ALL Ops Readiness Data */}
      <Dialog open={showClearAllOpsConfirmDialog} onOpenChange={setShowClearAllOpsConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Clear Ops Readiness Data</DialogTitle>
            <DialogDescription>
              Are you sure you want to clear all Ops Readiness data for {
                summaryViewMode === 'period' ? `Period ${summaryPeriod}` :
                summaryViewMode === 'quarter' ? `Quarter ${summaryQuarter}` :
                'Year to Date'
              }? This will permanently delete all saved summary data for this view. Weekly data will remain unaffected.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClearAllOpsConfirmDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleClearAllOpsReadiness}>Clear Ops Readiness Data</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Dialog for clearing ALL Sales Summary Data */}
      <Dialog open={showClearAllSalesConfirmDialog} onOpenChange={setShowClearAllSalesConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Clear Sales Summary Data</DialogTitle>
            <DialogDescription>
              Are you sure you want to clear all Sales Summary data for {
                salesSummaryViewMode === 'period' ? `Period ${salesSummaryPeriod}` :
                salesSummaryViewMode === 'quarter' ? `Quarter ${salesSummaryQuarter}` :
                'Year to Date'
              }? This will permanently delete all saved summary data for this view. Weekly data will remain unaffected.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClearAllSalesConfirmDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleClearAllSalesSummary}>Clear Sales Summary Data</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}