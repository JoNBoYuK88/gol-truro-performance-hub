import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { KPIMetric } from '@/api/entities';
import { useEditLock } from '../Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Target, Save, Edit, X } from 'lucide-react'; // Added Edit, X imports
import { toast } from 'sonner';
import { uniqBy } from 'lodash';

const managedKpis = [
    "Budget", "iCare", "Complaints", "Delivery Without Complaints", 
    "Ops Score", "Shoppers Achieving", "On Time Departures", "Availability", 
    "Secondary Replenishment"
];

export default function KpiSettings() {
  const [kpiDefs, setKpiDefs] = useState([]);
  const [originalKpiDefs, setOriginalKpiDefs] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const checkUserRole = async () => {
        try {
            const currentUser = await User.me();
            setIsAdmin(currentUser && currentUser.role === 'admin');
        } catch (error) {
            console.error('Failed to fetch user role:', error);
            setIsAdmin(false);
        }
    };
    checkUserRole();
    loadKpiDefs();
  }, []);

  const loadKpiDefs = async () => {
    setIsLoading(true);
    try {
      const allKpis = await KPIMetric.list('-date', 500); // Changed limit from 200 to 500
      const uniqueKpis = uniqBy(allKpis, 'name');
      const filteredKpis = uniqueKpis.filter(kpi => managedKpis.includes(kpi.name));
      
      // Ensure all managedKpis are present, initializing with 0 if no data found
      const kpiSettings = managedKpis.map(name => {
          const found = filteredKpis.find(k => k.name === name);
          return {
              name: name,
              red_threshold: found?.red_threshold || 0,
              amber_threshold: found?.amber_threshold || 0,
              green_threshold: found?.green_threshold || 0,
          }
      })
      setKpiDefs(kpiSettings);
      setOriginalKpiDefs(JSON.parse(JSON.stringify(kpiSettings))); // Deep copy for resetting changes

    } catch (error) {
      console.error('Error loading KPI definitions:', error);
      toast.error('Failed to load KPI definitions.');
    }
    setIsLoading(false);
  };

  const handleThresholdChange = (name, field, value) => {
    setKpiDefs(currentDefs =>
      currentDefs.map(def => (def.name === name ? { ...def, [field]: parseFloat(value) || 0 } : def))
    );
  };

  const handleEditToggle = () => {
    if (!canEdit) return;
    if (isEditing) {
        handleSaveChanges(); // If currently in edit mode, this acts as save
    } else {
        setIsEditing(true); // Enter edit mode
    }
  };

  const handleCancelEdit = () => {
      setKpiDefs(JSON.parse(JSON.stringify(originalKpiDefs))); // Reset to original state
      setIsEditing(false);
  };

  const handleSaveChanges = async () => {
    setIsSaving(true);

    const allUpdates = [];
    const changedDefs = kpiDefs.filter((def, index) => 
        JSON.stringify(def) !== JSON.stringify(originalKpiDefs[index])
    );

    if (changedDefs.length === 0) {
        toast.info("No changes to save.");
        setIsSaving(false);
        setIsEditing(false);
        return;
    }

    for (const def of changedDefs) {
        try {
            const recordsToUpdate = await KPIMetric.filter({ name: def.name });
            if (recordsToUpdate.length > 0) {
                recordsToUpdate.forEach(record => {
                    allUpdates.push({
                        id: record.id,
                        payload: {
                            red_threshold: def.red_threshold,
                            amber_threshold: def.amber_threshold,
                            green_threshold: def.green_threshold,
                        },
                        name: def.name
                    });
                });
            }
        } catch (error) {
            console.error(`Failed to fetch records for ${def.name}:`, error);
            toast.error(`Could not fetch data for ${def.name} to update.`);
            setIsSaving(false);
            return;
        }
    }

    if (allUpdates.length === 0) {
        toast.info("No records found to update for the changed KPIs.");
        setIsSaving(false);
        setIsEditing(false);
        return;
    }

    const promiseToSave = async () => {
        let successCount = 0;
        let failCount = 0;

        for (const [index, update] of allUpdates.entries()) {
            try {
                await KPIMetric.update(update.id, update.payload);
                successCount++;
                // Add a small delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 50)); // 50ms delay
            } catch (error) {
                failCount++;
                console.error(`Failed to update threshold for record ${update.id} (${update.name}):`, error);
            }
        }

        if (failCount > 0) {
            throw new Error(`${failCount} updates failed. ${successCount} succeeded.`);
        }
    };

    toast.promise(
        promiseToSave(),
        {
            loading: `Updating thresholds for ${allUpdates.length} records... This may take a moment.`,
            success: 'All thresholds saved successfully!',
            error: (err) => err.message || 'An error occurred while saving thresholds.',
        }
    );

    try {
      await promiseToSave(); // Re-await to catch the final status for logic flow
      setIsEditing(false); 
      await loadKpiDefs();
    } catch(e) {
      // Error is already handled by the toast.
      await loadKpiDefs(); // still reload data to see partial success
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">KPI Threshold Settings</h1>
          <p className="text-gray-600 mt-1">Set Red, Amber, and Green thresholds for key metrics.</p>
        </div>
        {canEdit && ( // Conditionally render buttons if user can edit
            <div className="flex items-center gap-2">
                {isEditing && (
                    <Button variant="outline" size="sm" onClick={handleCancelEdit} disabled={isSaving}>
                        <X className="w-4 h-4 mr-2"/>
                        Cancel
                    </Button>
                )}
                <Button size="sm" onClick={handleEditToggle} disabled={isSaving} className="btn-modern">
                    {isEditing ? <><Save className="w-4 h-4 mr-2"/>Save Changes</> : <><Edit className="w-4 h-4 mr-2"/>Edit Thresholds</>}
                </Button>
            </div>
        )}
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <Target className="w-5 h-5 text-sainsbury-orange" />
            RAG Thresholds
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p>Loading KPI settings...</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>KPI Name</TableHead>
                  <TableHead>Red Threshold (Lower is bad)</TableHead>
                  <TableHead>Amber Threshold</TableHead>
                  <TableHead>Green Threshold (Higher is good)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {kpiDefs.map(def => (
                  <TableRow key={def.name}>
                    <TableCell className="font-medium">{def.name}</TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        className="bg-red-100/50"
                        value={def.red_threshold}
                        onChange={e => handleThresholdChange(def.name, 'red_threshold', e.target.value)}
                        disabled={!canEdit || !isEditing} // Disabled if not editable or not in editing mode
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        className="bg-amber-100/50"
                        value={def.amber_threshold}
                        onChange={e => handleThresholdChange(def.name, 'amber_threshold', e.target.value)}
                        disabled={!canEdit || !isEditing} // Disabled if not editable or not in editing mode
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        className="bg-green-100/50"
                        value={def.green_threshold}
                        onChange={e => handleThresholdChange(def.name, 'green_threshold', e.target.value)}
                        disabled={!canEdit || !isEditing} // Disabled if not editable or not in editing mode
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}