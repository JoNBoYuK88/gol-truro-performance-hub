import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { CustomerComplaint } from "@/api/entities";
import { KPIMetric } from "@/api/entities";
import { PeriodConfig } from "@/api/entities";
import { useEditLock } from "../Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { MessageSquare, Heart, TrendingDown, AlertTriangle, Download, Edit, Save, X, Plus, Trash2, ShoppingCart, Package, FileDown, ShieldCheck, PoundSterling } from "lucide-react";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import KPICard from "../components/dashboard/KPICard";

// Add delay utility function
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Helper function to get periods for a quarter
const getQuarterPeriods = (quarter) => {
    const quarterMap = {
      1: [1, 2, 3, 4],
      2: [5, 6, 7], 
      3: [8, 9, 10],
      4: [11, 12, 13]
    };
    return quarterMap[quarter] || [];
};

const complaintCategoriesConfig = [
    { displayName: "Goodwill & Refunds", key: "goodwill_refunds" },
    { displayName: "DWC", key: "delivery_without_complaints" },
    { displayName: "Availability", key: "availability" },
    { displayName: "Driver Behaviour", key: "driver_behaviour" },
    { displayName: "Early Delivery", key: "early_delivery" },
    { displayName: "Late Delivery Call Received", key: "late_delivery_call" },
    { displayName: "Late Delivery No Call", key: "late_delivery_no_call" },
    { displayName: "Missing items", key: "missing_items" },
    { displayName: "Packing and Damages", key: "packing_damages" },
    { displayName: "Product life", key: "product_life" },
    { displayName: "Refunds", key: "refunds" },
    { displayName: "Special Offers", key: "special_offers" },
    { displayName: "Store Cancelled Delivery", key: "store_cancelled_delivery" },
    { displayName: "Unsuitable Substitution", key: "unsuitable_substitution" },
];

const categoryKeyToNameMap = Object.fromEntries(complaintCategoriesConfig.map(c => [c.key, c.displayName]));

const aggregateComplaints = (complaintsList) => {
    const aggregated = {};
    for (const complaint of complaintsList) {
        if (!aggregated[complaint.category]) {
            aggregated[complaint.category] = { value: 0, amount: 0, category: complaint.category };
        }
        aggregated[complaint.category].value += complaint.value;
        aggregated[complaint.category].amount += (complaint.amount || 0);
    }
    return Object.values(aggregated);
};

export default function CustomerComplaints() {
  const [complaints, setComplaints] = useState([]);
  const [complaintData, setComplaintData] = useState({});
  const [weeklyTrendData, setWeeklyTrendData] = useState([]);
  const [currentPeriod, setCurrentPeriod] = useState(1); // Default initial value
  const [currentWeek, setCurrentWeek] = useState(1);     // Default initial value
  const [currentQuarter, setCurrentQuarter] = useState(1); // New state for quarter
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [complaintViewMode, setComplaintViewMode] = useState('week');
  const [totalGoodwillAmount, setTotalGoodwillAmount] = useState(0);
  const [totalOrders, setTotalOrders] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;
  const [iCareKpi, setICareKpi] = useState(null);
  const [dwcKpi, setDwcKpi] = useState(null);

  // Editing states
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState({});
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [showDeleteConfirmDialog, setShowDeleteConfirmDialog] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState(null);

  // Updated chart colors for better theme consistency
  const chartColors = [
    "#1e293b", "#334155", "#475569", "#64748b", "#94a3b8", "#cbd5e1", // Slate tones
    "#1e40af", "#3b82f6", "#60a5fa", "#93c5fd", // Blue tones
    "#059669", "#10b981", "#34d399", "#6ee7b7"  // Green accents
  ];

  // Helper function to determine current period and week (1 week behind) with rate limiting
  const getCurrentPeriodAndWeek = async () => {
    try {
      await delay(100); // Add small delay before API call
      const periods = await PeriodConfig.filter({ year: currentYear }, 'period_number');
      
      if (periods.length === 0) {
        // Fallback to default if no period configurations exist for the selected year
        return { period: 1, week: 1 };
      }

      const today = new Date();
      // Set time components to 0 to compare dates only
      today.setHours(0, 0, 0, 0); 

      const currentPeriodConfig = periods.find(p => {
        // Parse dates to ensure correct comparison
        const startDate = new Date(p.start_date);
        const endDate = new Date(p.end_date);
        startDate.setHours(0, 0, 0, 0);
        endDate.setHours(0, 0, 0, 0);
        return today >= startDate && today <= endDate;
      });

      if (currentPeriodConfig) {
        const startDate = new Date(currentPeriodConfig.start_date);
        startDate.setHours(0, 0, 0, 0); // Ensure start date comparison is also date-only
        const daysDiff = Math.floor((today - startDate) / (1000 * 60 * 60 * 24));
        // Weeks are 1-indexed and max 4 for a period
        const currentWeekNumber = Math.min(Math.floor(daysDiff / 7) + 1, 4); 
        
        // Go back 1 week
        let targetPeriod = currentPeriodConfig.period_number;
        let targetWeek = currentWeekNumber - 1;
        
        // If we're in week 1, go to week 4 of the previous period
        if (targetWeek < 1) {
          targetPeriod = Math.max(1, targetPeriod - 1); // Ensure period doesn't go below 1
          targetWeek = 4; // Set to the last week of the previous period
        }
        
        // If we crossed into a previous period, ensure it exists for the current year
        const prevPeriodConfig = periods.find(p => p.period_number === targetPeriod);
        if (!prevPeriodConfig) {
            // If the calculated previous period doesn't exist, default to the first period's first week.
            return { period: 1, week: 1 };
        }

        return { period: targetPeriod, week: targetWeek };
      }
      
      // Fallback: If no current period found (e.g., between periods or outside defined range),
      // try to find the latest defined period for the currentYear and show its last week's data.
      if (periods.length > 0) {
        const latestPeriod = periods.reduce((latest, current) => {
          const currentStartDate = new Date(current.start_date);
          const latestStartDate = new Date(latest.start_date);
          return currentStartDate > latestStartDate ? current : latest;
        }, periods[0]); // Ensure periods[0] exists before using
        
        // Return the last week of the latest period as the default "one week behind" view
        return { period: latestPeriod.period_number, week: 4 };
      }

      // Ultimate fallback if no periods found for the currentYear at all
      return { period: 1, week: 1 };
    } catch (error) {
      console.error("Error determining current period:", error);
      // Fallback to default if error occurs
      return { period: 1, week: 1 };
    }
  };

  // Initial setup: Check user role and determine current period/week based on real date
  useEffect(() => {
    const initialize = async () => {
      try {
        const currentUser = await User.me();
        setIsAdmin(currentUser && currentUser.role === 'admin');
      } catch (error) {
        console.log("User not logged in or error checking user:", error);
        setIsAdmin(false);
      }

      try {
        // Add a delay between API calls during initialization
        await delay(200); 
        const { period, week } = await getCurrentPeriodAndWeek();
        setCurrentPeriod(period);
        setCurrentWeek(week);
      } catch (error) {
        console.error("Error in initialization:", error);
        setCurrentPeriod(1);
        setCurrentWeek(1);
      }
    };
    initialize();
  }, []); // Empty dependency array: runs once on component mount

  // Load data whenever current period, week, year, or view mode changes
  useEffect(() => {
    // Only proceed if currentPeriod and currentWeek have been set (i.e., not their default 1,1
    // if the initialization useEffect has already run and potentially updated them)
    // This check is good practice to ensure state is ready before fetching.
    if (currentPeriod && currentWeek && currentYear) {
      // Debounce data loading to prevent excessive calls on rapid filter changes
      const timer = setTimeout(() => {
        loadComplaintsData();
      }, 500); 
      
      return () => clearTimeout(timer); // Cleanup on unmount or re-render
    }
  }, [currentPeriod, currentWeek, currentYear, complaintViewMode, currentQuarter]);

  const loadComplaintsData = async () => {
    try {
      await delay(300); // Add delay before starting API calls
      
      // Fetch all data for the currentYear to handle aggregation across different view modes efficiently
      const allComplaintsForYear = await CustomerComplaint.filter({ year: currentYear }, '-date', 5000); 
      await delay(200); // Delay between large data fetches
      const allKpiMetricsForYear = await KPIMetric.filter({ year: currentYear }, '-date', 5000);
      await delay(200); // Delay after large data fetches
      
      const allWeeklyComplaintData = allComplaintsForYear.filter(c => c.week != null && c.period != null);
      const allWeeklyKpiData = allKpiMetricsForYear.filter(m => m.week != null && m.period != null);
      
      let relevantAggregatedData;
      let dataMap = {};

      if (complaintViewMode === 'week') {
          const weeklyData = allWeeklyComplaintData.filter(c => c.period === currentPeriod && c.week === currentWeek);
          // For 'week' view, we prioritize specific entries if they exist, otherwise aggregate.
          relevantAggregatedData = aggregateComplaints(weeklyData); // For pie chart based on current week
          dataMap = weeklyData.reduce((acc, complaint) => {
              acc[complaint.category] = { id: complaint.id, value: complaint.value, amount: complaint.amount || 0 };
              return acc;
          }, {});
      } else if (complaintViewMode === 'period') {
          const periodSummaryData = allComplaintsForYear.filter(c => c.period === currentPeriod && c.week === null && c.year === currentYear);
          if (periodSummaryData.length > 0) { // If period summary exists, use it
              dataMap = periodSummaryData.reduce((acc, complaint) => {
                  acc[complaint.category] = { id: complaint.id, value: complaint.value, amount: complaint.amount || 0 };
                  return acc;
              }, {});
              relevantAggregatedData = Object.values(dataMap); // For pie chart based on period summary
          } else { // Else, aggregate from weeks within the period
              const weeksInPeriod = allWeeklyComplaintData.filter(c => c.period === currentPeriod && c.year === currentYear);
              relevantAggregatedData = aggregateComplaints(weeksInPeriod); // For pie chart based on aggregated weeks
              dataMap = relevantAggregatedData.reduce((acc, complaint) => {
                  acc[complaint.category] = { id: null, value: complaint.value, amount: complaint.amount || 0 }; // No ID for aggregated data
                  return acc;
              }, {});
          }
      } else if (complaintViewMode === 'quarter') {
          const quarterPeriods = getQuarterPeriods(currentQuarter);
          const quarterData = allWeeklyComplaintData.filter(c => quarterPeriods.includes(c.period) && c.year === currentYear);
          relevantAggregatedData = aggregateComplaints(quarterData);
          dataMap = relevantAggregatedData.reduce((acc, complaint) => {
            acc[complaint.category] = { id: null, value: complaint.value, amount: complaint.amount || 0 };
            return acc;
          }, {});
      } else { // YTD
          const ytdSummaryData = allComplaintsForYear.filter(c => c.period === null && c.week === null && c.year === currentYear);
          if (ytdSummaryData.length > 0) { // If YTD summary exists, use it
              dataMap = ytdSummaryData.reduce((acc, complaint) => {
                  acc[complaint.category] = { id: complaint.id, value: complaint.value, amount: complaint.amount || 0 };
                  return acc;
              }, {});
              relevantAggregatedData = Object.values(dataMap); // For pie chart based on YTD summary
          } else { // Else, aggregate from all weekly data for the year
              relevantAggregatedData = aggregateComplaints(allWeeklyComplaintData.filter(c => c.year === currentYear)); // For pie chart based on aggregated weekly
              dataMap = relevantAggregatedData.reduce((acc, complaint) => {
                  acc[complaint.category] = { id: null, value: complaint.value, amount: complaint.amount || 0 }; // No ID for aggregated data
                  return acc;
              }, {});
          }
      }

      setComplaintData(dataMap);

      // --- Calculate Totals for top cards ---
      const orderMetrics = allKpiMetricsForYear.filter(m => m.name === 'Delivered Orders');
      const itemMetrics = allKpiMetricsForYear.filter(m => m.name === 'Delivered Items');
      const goodwillMetrics = allComplaintsForYear.filter(c => c.category === 'goodwill_refunds');

      let currentTotalOrders = 0;
      let currentTotalItems = 0;
      let currentTotalGoodwill = 0;

      if (complaintViewMode === 'week') {
        currentTotalOrders = allWeeklyKpiData.filter(m => m.name === 'Delivered Orders' && m.period === currentPeriod && m.week === currentWeek && m.year === currentYear).reduce((sum, m) => sum + m.value, 0);
        currentTotalItems = allWeeklyKpiData.filter(m => m.name === 'Delivered Items' && m.period === currentPeriod && m.week === currentWeek && m.year === currentYear).reduce((sum, m) => sum + m.value, 0);
        currentTotalGoodwill = allWeeklyComplaintData.filter(c => c.category === 'goodwill_refunds' && c.period === currentPeriod && c.week === currentWeek && c.year === currentYear).reduce((sum, c) => sum + (c.amount || 0), 0);
      } else if (complaintViewMode === 'period') {
        const periodOrderSummary = orderMetrics.find(m => m.period === currentPeriod && m.week === null && m.year === currentYear);
        currentTotalOrders = periodOrderSummary ? periodOrderSummary.value : allWeeklyKpiData.filter(m => m.name === 'Delivered Orders' && m.period === currentPeriod && m.year === currentYear).reduce((sum, m) => sum + m.value, 0);
        
        const periodItemSummary = itemMetrics.find(m => m.period === currentPeriod && m.week === null && m.year === currentYear);
        currentTotalItems = periodItemSummary ? periodItemSummary.value : allWeeklyKpiData.filter(m => m.name === 'Delivered Items' && m.period === currentPeriod && m.year === currentYear).reduce((sum, m) => sum + m.value, 0);
        
        currentTotalGoodwill = allWeeklyComplaintData.filter(c => c.category === 'goodwill_refunds' && c.period === currentPeriod && c.year === currentYear).reduce((sum, c) => sum + (c.amount || 0), 0);
      } else if (complaintViewMode === 'quarter') {
        const quarterPeriods = getQuarterPeriods(currentQuarter);
        currentTotalOrders = allWeeklyKpiData.filter(m => m.name === 'Delivered Orders' && quarterPeriods.includes(m.period) && m.year === currentYear).reduce((sum, m) => sum + m.value, 0);
        currentTotalItems = allWeeklyKpiData.filter(m => m.name === 'Delivered Items' && quarterPeriods.includes(m.period) && m.year === currentYear).reduce((sum, m) => sum + m.value, 0);
        currentTotalGoodwill = allWeeklyComplaintData.filter(c => c.category === 'goodwill_refunds' && quarterPeriods.includes(c.period) && c.year === currentYear).reduce((sum, c) => sum + (c.amount || 0), 0);
      } else { // YTD
        const ytdOrderSummary = orderMetrics.find(m => m.period === null && m.week === null && m.year === currentYear);
        currentTotalOrders = ytdOrderSummary ? ytdOrderSummary.value : allWeeklyKpiData.filter(m => m.name === 'Delivered Orders' && m.year === currentYear).reduce((sum, m) => sum + m.value, 0);

        const ytdItemSummary = itemMetrics.find(m => m.period === null && m.week === null && m.year === currentYear);
        currentTotalItems = ytdItemSummary ? ytdItemSummary.value : allWeeklyKpiData.filter(m => m.name === 'Delivered Items' && m.year === currentYear).reduce((sum, m) => sum + m.value, 0);

        currentTotalGoodwill = goodwillMetrics.filter(c => c.year === currentYear).reduce((sum, c) => sum + (c.amount || 0), 0);
      }

      setTotalOrders(currentTotalOrders);
      setTotalItems(currentTotalItems);
      setTotalGoodwillAmount(currentTotalGoodwill);

      // --- Fetch iCare & DWC data ---
      let iCareRecords, dwcRecords;
      
      if (complaintViewMode === 'week') {
          await delay(150); // Delay before iCare fetch
          iCareRecords = await KPIMetric.filter({ name: 'iCare', period: currentPeriod, week: currentWeek, year: currentYear });
          await delay(150); // Delay before DWC fetch
          dwcRecords = await KPIMetric.filter({ name: 'Delivery Without Complaints', period: currentPeriod, week: currentWeek, year: currentYear });
      } else if (complaintViewMode === 'period') {
          await delay(150);
          iCareRecords = await KPIMetric.filter({ name: 'iCare', period: currentPeriod, week: null, year: currentYear });
          await delay(150);
          dwcRecords = await KPIMetric.filter({ name: 'Delivery Without Complaints', period: currentPeriod, week: null, year: currentYear });
          
          // If no specific period summary KPI exists, calculate average from weekly
          if (iCareRecords.length === 0) {
            const weeklyiCareRecords = allKpiMetricsForYear.filter(m => m.name === 'iCare' && m.period === currentPeriod && m.week != null && m.week > 0 && m.year === currentYear);
            if (weeklyiCareRecords.length > 0) {
                const avgValue = weeklyiCareRecords.reduce((sum, r) => sum + r.value, 0) / weeklyiCareRecords.length;
                iCareRecords = [{ value: avgValue, target: weeklyiCareRecords[0]?.target }];
            }
          }
          if (dwcRecords.length === 0) {
            const weeklyDwcRecords = allKpiMetricsForYear.filter(m => m.name === 'Delivery Without Complaints' && m.period === currentPeriod && m.week != null && m.week > 0 && m.year === currentYear);
            if (weeklyDwcRecords.length > 0) {
                const avgValue = weeklyDwcRecords.reduce((sum, r) => sum + r.value, 0) / weeklyDwcRecords.length;
                dwcRecords = [{ 
                    value: avgValue, 
                    target: weeklyDwcRecords[0]?.target,
                    green_threshold: weeklyDwcRecords[0]?.green_threshold,
                    amber_threshold: weeklyDwcRecords[0]?.amber_threshold,
                    red_threshold: weeklyDwcRecords[0]?.red_threshold
                }];
            }
          }
      } else if (complaintViewMode === 'quarter') {
          const quarterPeriods = getQuarterPeriods(currentQuarter);
          const weeklyiCareRecords = allKpiMetricsForYear.filter(m => m.name === 'iCare' && quarterPeriods.includes(m.period) && m.week != null && m.week > 0 && m.year === currentYear);
          if (weeklyiCareRecords.length > 0) {
              const avgValue = weeklyiCareRecords.reduce((sum, r) => sum + r.value, 0) / weeklyiCareRecords.length;
              iCareRecords = [{ value: avgValue, target: weeklyiCareRecords[0]?.target }];
          } else {
              iCareRecords = [];
          }
          const weeklyDwcRecords = allKpiMetricsForYear.filter(m => m.name === 'Delivery Without Complaints' && quarterPeriods.includes(m.period) && m.week != null && m.week > 0 && m.year === currentYear);
          if (weeklyDwcRecords.length > 0) {
              const avgValue = weeklyDwcRecords.reduce((sum, r) => sum + r.value, 0) / weeklyDwcRecords.length;
              dwcRecords = [{ value: avgValue, target: weeklyDwcRecords[0]?.target, green_threshold: weeklyDwcRecords[0]?.green_threshold, amber_threshold: weeklyDwcRecords[0]?.amber_threshold, red_threshold: weeklyDwcRecords[0]?.red_threshold }];
          } else {
              dwcRecords = [];
          }
      } else { // YTD
          // First try to get YTD summary records
          await delay(150);
          iCareRecords = await KPIMetric.filter({ name: 'iCare', period: null, week: null, year: currentYear });
          await delay(150);
          dwcRecords = await KPIMetric.filter({ name: 'Delivery Without Complaints', period: null, week: null, year: currentYear });
          
          // If no YTD summary exists, calculate from weekly data
          if (iCareRecords.length === 0) {
              const weeklyiCareRecords = allKpiMetricsForYear.filter(m => m.name === 'iCare' && m.week != null && m.week > 0 && m.year === currentYear);
              if (weeklyiCareRecords.length > 0) {
                  const avgValue = weeklyiCareRecords.reduce((sum, r) => sum + r.value, 0) / weeklyiCareRecords.length;
                  iCareRecords = [{ value: avgValue, target: weeklyiCareRecords[0]?.target }];
              }
          }
          
          if (dwcRecords.length === 0) {
              const weeklyDwcRecords = allKpiMetricsForYear.filter(m => m.name === 'Delivery Without Complaints' && m.week != null && m.week > 0 && m.year === currentYear);
              if (weeklyDwcRecords.length > 0) {
                  const avgValue = weeklyDwcRecords.reduce((sum, r) => sum + r.value, 0) / weeklyDwcRecords.length;
                  dwcRecords = [{ 
                      value: avgValue, 
                      target: weeklyDwcRecords[0]?.target,
                      green_threshold: weeklyDwcRecords[0]?.green_threshold,
                      amber_threshold: weeklyDwcRecords[0]?.amber_threshold,
                      red_threshold: weeklyDwcRecords[0]?.red_threshold
                  }];
              }
          }
      }
      
      setICareKpi(iCareRecords.length > 0 ? iCareRecords[0] : null);
      setDwcKpi(dwcRecords.length > 0 ? dwcRecords[0] : null);
      
      const weeklyRawComplaints = allWeeklyComplaintData.filter(c => c.period === currentPeriod && c.year === currentYear);
      
      // Bar chart data - always show for current period's weeks
      const weeklyTrend = Array.from({length: 4}, (_, i) => i + 1).map(weekNum => {
        const weekComplaints = weeklyRawComplaints.filter(c => c.week === weekNum);
        return {
          week: `W${weekNum}`,
          complaints: weekComplaints.reduce((sum, c) => sum + c.value, 0),
          amount: weekComplaints.reduce((sum, c) => sum + (c.amount || 0), 0)
        };
      });
      setWeeklyTrendData(weeklyTrend);

      // Pie chart data
      const pieData = complaintCategoriesConfig
          .filter(config => config.key !== 'goodwill_refunds' && config.key !== 'delivery_without_complaints')
          .map((config, index) => ({
              name: config.displayName,
              value: dataMap[config.key]?.value || 0,
              color: chartColors[index % chartColors.length] // Use new chartColors
          })).filter(d => d.value > 0);
      setComplaints(pieData); 

    } catch (error) {
      console.error("Error loading complaints data:", error);
      if (error.message && error.message.includes('429')) {
        toast.error("Too many requests. Please wait a moment and try again.");
        // Implement a retry with exponential backoff or simply a longer delay
        setTimeout(() => {
          loadComplaintsData(); // Retry the data load
        }, 3000); // Wait for 3 seconds before retrying
      } else {
        toast.error("Failed to load complaints data.");
      }
      setComplaintData({});
      setWeeklyTrendData([]);
      setComplaints([]);
      setTotalGoodwillAmount(0);
      setTotalOrders(0);
      setTotalItems(0);
      setICareKpi(null);
      setDwcKpi(null);
    } finally {
      // setLoadingState(''); // No longer needed as full-page loader is removed
    }
  };

  const handleEditToggle = () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to edit data.");
      return;
    }

    if (isEditing) {
      const hasChanges = Object.keys(editedData).some(key => {
        const edited = editedData[key];
        const original = complaintData[key] || { value: 0, amount: 0 };
        return edited && (edited.value !== original.value || edited.amount !== original.amount);
      });
      if (hasChanges) {
        setShowConfirmDialog(true);
      } else {
        setIsEditing(false);
        setEditedData({});
        toast.info("No changes detected.");
      }
    } else {
      const initialData = {};
      complaintCategoriesConfig.forEach(config => {
        initialData[config.key] = {
          value: complaintData[config.key]?.value || 0,
          amount: complaintData[config.key]?.amount || 0,
        };
      });
      setEditedData(initialData);
      setIsEditing(true);
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedData({});
    setShowConfirmDialog(false);
  };

  const handleValueChange = (categoryKey, field, value) => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to edit data.");
      return;
    }
    setEditedData(prev => ({
      ...prev,
      [categoryKey]: {
        ...prev[categoryKey],
        [field]: parseFloat(value) || 0
      }
    }));
  };

  const handleConfirmSave = async () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to save data.");
      return;
    }
    const upsertPromises = [];
    
    for (const config of complaintCategoriesConfig) {
        const key = config.key;
        const edited = editedData[key];
        const original = complaintData[key] || { value: 0, amount: 0 };
        
        if (edited && (edited.value !== original.value || edited.amount !== original.amount)) {
            let filter, record;
            const baseRecord = {
                category: key,
                value: edited.value,
                amount: edited.amount,
                date: new Date().toISOString().split('T')[0], // Kept as per original
                year: currentYear // Ensure year is included in the saved record
            };

            switch (complaintViewMode) {
                case 'period':
                    filter = { category: key, period: currentPeriod, week: null, year: currentYear };
                    record = { ...baseRecord, period: currentPeriod, week: null };
                    break;
                case 'quarter':
                    // For quarter view, we don't save to a 'quarter' record type directly.
                    // Data is aggregated from weekly records. If editing, we assume user
                    // wants to adjust weekly data within the quarter. This is complex
                    // and usually not done this way. For simplicity, we'll assume
                    // quarter view editing is not supported directly for saving single records,
                    // or it would require creating a new 'quarterly summary' record type.
                    // For now, disallow direct saving from quarter view if not already implemented.
                    // This section might need specific requirements for saving if 'quarter' records exist.
                    console.warn("Saving directly from 'quarter' view is not supported for individual category edits.");
                    continue; // Skip this category
                case 'ytd':
                    filter = { category: key, period: null, week: null, year: currentYear };
                    record = { ...baseRecord, period: null, week: null };
                    break;
                case 'week':
                default:
                    filter = { category: key, period: currentPeriod, week: currentWeek, year: currentYear };
                    record = { ...baseRecord, period: currentPeriod, week: currentWeek };
                    break;
            }
            if (complaintViewMode !== 'quarter') { // Only push promise if not in quarter view
                upsertPromises.push((async () => {
                    const existing = await CustomerComplaint.filter(filter);
                    await delay(50); // Small delay between individual upsert operations
                    if (existing.length > 0) {
                        await CustomerComplaint.update(existing[0].id, { value: record.value, amount: record.amount });
                    } else {
                        await CustomerComplaint.create(record);
                    }
                })());
            }
        }
    }

    if (upsertPromises.length === 0) {
      toast.warning("No changes to save.");
      setShowConfirmDialog(false);
      setIsEditing(false);
      setEditedData({});
      return;
    }

    try {
      await toast.promise(Promise.all(upsertPromises), {
        loading: 'Saving complaint data...',
        success: 'Complaint data saved successfully!',
        error: 'Failed to save some data.'
      });
      await loadComplaintsData();
    } catch (error) {
      console.error("Error saving complaint data:", error);
    } finally {
      setShowConfirmDialog(false);
      setIsEditing(false);
      setEditedData({});
    }
  };
  
  const handleDeleteClick = (categoryKey) => {
      const data = complaintData[categoryKey];
      // Only allow deletion if there's an existing record for the current view and it has an ID
      if (data && data.id) { 
          setCategoryToDelete({ category: categoryKey, id: data.id });
          setShowDeleteConfirmDialog(true);
      } else {
          toast.info("This category has no data to delete for the current view (no existing record found).");
      }
  };

  const confirmDelete = async () => {
      if (!categoryToDelete || !categoryToDelete.id) return;
      
      try {
          await delay(100); // Delay before delete operation
          await toast.promise(CustomerComplaint.delete(categoryToDelete.id), {
              loading: `Deleting data for ${categoryKeyToNameMap[categoryToDelete.category] || categoryToDelete.category}...`,
              success: 'Data deleted successfully!',
              error: 'Failed to delete data.'
          });
          await loadComplaintsData();
      } catch (error) {
          console.error("Error deleting complaint data:", error);
      } finally {
          setShowDeleteConfirmDialog(false);
          setCategoryToDelete(null);
      }
  };

  const handleDownload = () => {
    toast.info("Download functionality not yet implemented.");
    // Placeholder for actual download logic
  };
  
  const displayedDataForTable = isEditing ? editedData : complaintData;

  // Filter out DWC from total complaints as it's typically a separate KPI, not a direct "complaint" count.
  const totalComplaints = Object.entries(displayedDataForTable).reduce((sum, [key, cat]) => (key === 'delivery_without_complaints') ? sum : sum + (cat?.value || 0), 0);
  
  // Calculate complaints percentage (though this specific KPI card is removed, the calc might be useful elsewhere)
  // const complaintsPercentage = totalOrders > 0 ? (totalComplaints / totalOrders) * 100 : 0;
  
  // Generate array of years for the Year Select dropdown (e.g., current year and 4 previous years)
  const currentYearActual = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYearActual - i);

  // Summary data for new KPICards
  const summaryData = {
    totalComplaints: totalComplaints,
    totalGoodwill: totalGoodwillAmount,
    totalOrders: totalOrders,
    complaintsPercentage: totalOrders > 0 ? (totalComplaints / totalOrders) * 100 : 0,
  };


  return (
    <div className="p-6 space-y-6">
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Save</DialogTitle>
            <DialogDescription>
              Are you sure you want to save the changes to the complaint data? This will update the current view's data.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={handleCancelEdit}>Cancel</Button>
            <Button onClick={handleConfirmSave}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog open={showDeleteConfirmDialog} onOpenChange={setShowDeleteConfirmDialog}>
        <DialogContent>
            <DialogHeader>
                <DialogTitle>Confirm Deletion</DialogTitle>
                <DialogDescription>
                    Are you sure you want to delete the data for <strong>{categoryToDelete && (categoryKeyToNameMap[categoryToDelete.category] || categoryToDelete.category)}</strong> for this {complaintViewMode}? This action cannot be undone.
                </DialogDescription>
            </DialogHeader>
            <DialogFooter>
                <Button variant="outline" onClick={() => setShowDeleteConfirmDialog(false)}>Cancel</Button>
                <Button variant="destructive" onClick={confirmDelete}>Delete</Button>
            </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 no-print">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-gray-900">DWC & iCare</h1>
        </div>
        <div className="flex items-center gap-2">
            <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))}>
              <SelectTrigger className="border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900 w-24">
                <SelectValue placeholder="Select Year" />
              </SelectTrigger>
              <SelectContent>
                {years.map(year => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {isEditing && (
                <Button variant="outline" size="sm" onClick={handleCancelEdit} className="border-slate-200/50 rounded-lg px-4 py-2">
                    <X className="w-4 h-4 mr-2"/>
                    Cancel
                </Button>
            )}
            {canEdit && (
                <Button size="sm" onClick={handleEditToggle} className="btn-modern">
                    {isEditing ? <><Save className="w-4 h-4 mr-2"/>Save Changes</> : <><Edit className="w-4 h-4 mr-2"/>Edit Mode</>}
                </Button>
            )}
            <Button variant="outline" size="sm" onClick={handleDownload} className="border-slate-200/50 rounded-lg px-4 py-2">
                <Download className="w-4 h-4 mr-2" />
                Download
            </Button>
            <Button variant="outline" size="sm" onClick={() => window.print()} className="border-slate-200/50 rounded-lg px-4 py-2">
              <FileDown className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
        </div>
      </div>
      
      <Card className="glass-card no-print">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
              <CardTitle className="text-lg font-semibold text-slate-800 shrink-0">
                  Period & Week Selection
              </CardTitle>
              <div className="flex flex-wrap items-center gap-3 w-full">
                  {/* Year Select moved to header */}

                  <Tabs value={complaintViewMode} onValueChange={setComplaintViewMode} className="w-full sm:w-auto">
                    <TabsList className="grid w-full grid-cols-4">
                      <TabsTrigger value="week">Weekly</TabsTrigger>
                      <TabsTrigger value="period">Period</TabsTrigger>
                      <TabsTrigger value="quarter">Quarterly</TabsTrigger>
                      <TabsTrigger value="ytd">YTD</TabsTrigger>
                    </TabsList>
                  </Tabs>
                  
                  {complaintViewMode === 'week' && (
                    <>
                      <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))}>
                        <SelectTrigger className="border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900 w-28"><SelectValue /></SelectTrigger>
                        <SelectContent>{Array.from({ length: 13 }, (_, i) => ( <SelectItem key={i + 1} value={(i + 1).toString()}>P{i + 1}</SelectItem>))}</SelectContent>
                      </Select>
                      <Select value={currentWeek.toString()} onValueChange={(val) => setCurrentWeek(parseInt(val))}>
                        <SelectTrigger className="border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900 w-24"><SelectValue /></SelectTrigger>
                        <SelectContent>{Array.from({ length: 4 }, (_, i) => ( <SelectItem key={i + 1} value={(i + 1).toString()}>W{i + 1}</SelectItem>))}</SelectContent>
                      </Select>
                    </>
                  )}

                  {complaintViewMode === 'period' && (
                    <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))}>
                      <SelectTrigger className="border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900 w-28"><SelectValue /></SelectTrigger>
                      <SelectContent>{Array.from({ length: 13 }, (_, i) => (<SelectItem key={i + 1} value={(i + 1).toString()}>P{i + 1}</SelectItem>))}</SelectContent>
                    </Select>
                  )}
                  
                  {complaintViewMode === 'quarter' && (
                      <div className="grid grid-cols-2 gap-1 h-10 w-20">
                          <Button variant={currentQuarter === 1 ? 'default' : 'outline'} size="sm" className={`h-4 text-xs px-1 ${currentQuarter === 1 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`} onClick={() => setCurrentQuarter(1)}>Q1</Button>
                          <Button variant={currentQuarter === 2 ? 'default' : 'outline'} size="sm" className={`h-4 text-xs px-1 ${currentQuarter === 2 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`} onClick={() => setCurrentQuarter(2)}>Q2</Button>
                          <Button variant={currentQuarter === 3 ? 'default' : 'outline'} size="sm" className={`h-4 text-xs px-1 ${currentQuarter === 3 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`} onClick={() => setCurrentQuarter(3)}>Q3</Button>
                          <Button variant={currentQuarter === 4 ? 'default' : 'outline'} size="sm" className={`h-4 text-xs px-1 ${currentQuarter === 4 ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`} onClick={() => setCurrentQuarter(4)}>Q4</Button>
                      </div>
                  )}
              </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Total Complaints" value={summaryData.totalComplaints} unit="number" icon={MessageSquare} />
        <KPICard title="Total Goodwill" value={summaryData.totalGoodwill} unit="currency" icon={PoundSterling} />
        <KPICard title="Total Orders" value={summaryData.totalOrders} unit="number" icon={ShoppingCart} />
        <KPICard title="Complaints vs Orders" value={summaryData.complaintsPercentage.toFixed(2)} unit="percentage" icon={TrendingDown} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <KPICard 
          title={<span className="font-bold">iCare Score</span>} 
          value={iCareKpi?.value || 0}
          target={iCareKpi?.target}
          unit="percentage" 
          icon={Heart} 
          greenThreshold={49.5}
          amberThreshold={49.4}
          redThreshold={49.39}
          compact={true}
          className="flex-grow justify-center items-center"
          valueSize="text-5xl"
        />
        <KPICard 
          title={<span className="font-bold">DWC</span>} 
          value={dwcKpi?.value || 0}
          target={dwcKpi?.target}
          unit="percentage" 
          icon={ShieldCheck} 
          greenThreshold={dwcKpi?.green_threshold}
          amberThreshold={dwcKpi?.amber_threshold}
          redThreshold={dwcKpi?.red_threshold}
          higherIsBetter={true}
          compact={true}
          className="flex-grow justify-center items-center"
          valueSize="text-5xl"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="chart-container">
          <CardHeader className="pb-6">
            <div className="space-y-2">
              <CardTitle className="text-xl font-semibold text-slate-800">
                Complaints by Category
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={350}>
              <PieChart>
                <Pie
                  data={complaints}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={120}
                  fill="#8884d8"
                  isAnimationActive={false}
                  paddingAngle={5}
                  dataKey="value"
                  labelLine={false}
                  label={({ cx, cy, midAngle, outerRadius, percent, payload }) => {
                    const RADIAN = Math.PI / 180;
                    const radius = outerRadius + 25;
                    const x = cx + radius * Math.cos(-midAngle * RADIAN);
                    const y = cy + radius * Math.sin(-midAngle * RADIAN);
                    if (percent === 0) return null;
                    return (
                      <text
                        x={x}
                        y={y}
                        fill="black"
                        textAnchor={x > cx ? 'start' : 'end'}
                        dominantBaseline="central"
                        className="text-xs"
                      >
                        {`${payload.name} (${(percent * 100).toFixed(0)}%)`}
                      </text>
                    );
                  }}
                >
                  {complaints.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={chartColors[index % chartColors.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => value.toLocaleString()} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        <Card className="chart-container">
          <CardHeader className="pb-6">
            <div className="space-y-2">
              <CardTitle className="text-xl font-semibold text-slate-800">Weekly Trend - P{currentPeriod}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={350}>
              <BarChart
                data={weeklyTrendData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                isAnimationActive={false}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis yAxisId="left" orientation="left" stroke="#1e293b" label={{ value: 'Count', angle: -90, position: 'insideLeft' }} />
                <YAxis yAxisId="right" orientation="right" stroke="#059669" label={{ value: 'Amount (£)', angle: -90, position: 'insideRight' }} />
                <Tooltip formatter={(value, name) => name === 'Complaints Count' ? value.toLocaleString() : `£${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`} />
                <Legend />
                <Bar yAxisId="left" dataKey="complaints" name="Complaints Count" fill="#475569" />
                <Bar yAxisId="right" dataKey="amount" name="Total Amount" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="table-modern">
        <CardHeader className="pb-6">
          <div className="flex justify-between items-center">
            <div className="space-y-2">
              <CardTitle className="text-xl font-semibold text-slate-800">
                Detailed Breakdown - {complaintViewMode === 'week' ? `P${currentPeriod}W${currentWeek}` : complaintViewMode === 'period' ? `Period ${currentPeriod}` : complaintViewMode === 'quarter' ? `Quarter ${currentQuarter}` : 'YTD'} {currentYear}
              </CardTitle>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-slate-200/50">
                <TableHead className="text-sm font-semibold text-slate-700 px-6 py-4">Category</TableHead>
                <TableHead className="text-sm font-semibold text-slate-700 px-6 py-4">Count</TableHead>
                <TableHead className="text-sm font-semibold text-slate-700 px-6 py-4">Amount (£)</TableHead>
                <TableHead className="text-sm font-semibold text-slate-700 px-6 py-4">Status</TableHead>
                {isEditing && canEdit && <TableHead className="text-sm font-semibold text-slate-700 px-6 py-4">Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {complaintCategoriesConfig.filter(c => c.key !== 'delivery_without_complaints').map((config) => {
                const data = displayedDataForTable[config.key] || { value: 0, amount: 0 };
                
                return (
                  <TableRow key={config.key}>
                    <TableCell className="font-medium text-sm">{config.displayName}</TableCell>
                    <TableCell className="text-sm">
                      {isEditing && canEdit ? (
                        <Input 
                          type="number" 
                          value={data.value} 
                          onChange={(e) => handleValueChange(config.key, 'value', e.target.value)} 
                          className="w-24 text-center text-sm" 
                        />
                      ) : (
                        data.value
                      )}
                    </TableCell>
                    <TableCell className="text-sm">
                      {isEditing && canEdit ? (
                        <div className="flex items-center">
                          <span className="mr-1">£</span>
                          <Input 
                            type="number" 
                            value={data.amount} 
                            onChange={(e) => handleValueChange(config.key, 'amount', e.target.value)} 
                            className="w-24 text-center text-sm" 
                          />
                        </div>
                      ) : (
                        `£${data.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={data.value > 30 ? "destructive" : data.value > 15 ? "secondary" : "default"}
                        className={
                          data.value > 30 ? "bg-red-100 text-red-800 text-xs" :
                          data.value > 15 ? "bg-blue-100 text-blue-800 text-xs" :
                          "bg-green-100 text-green-800 text-xs"
                        }
                      >
                        {data.value > 30 ? "High" : data.value > 15 ? "Medium" : "Low"}
                      </Badge>
                    </TableCell>
                    {isEditing && canEdit && (
                        <TableCell>
                            <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => handleDeleteClick(config.key)}
                                disabled={!complaintData[config.key]?.id} // Disable if no existing ID for current view
                                className="text-red-500 hover:text-red-700 hover:bg-red-100 h-8 w-8"
                            >
                                <Trash2 className="w-4 h-4" />
                            </Button>
                        </TableCell>
                    )}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}