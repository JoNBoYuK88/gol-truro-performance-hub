
import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Network, Edit, Save, X, Trash2, FileDown, RefreshCw, Heart, ChevronDown, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import { User } from '@/api/entities';
import { RegionalPerformance } from '@/api/entities';
import StoreRankings from '../components/regional/StoreRankings';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ExtractDataFromUploadedFile } from "@/api/integrations";
import { Badge } from '@/components/ui/badge'; // Added Badge import

const METRIC_CONFIG = {
    drm: { label: 'DRM' },
    score_percentage: { label: 'Score', higherIsBetter: true, unit: '%', greenThreshold: 80, amberThreshold: 60, redThreshold: 59.99 },
    shoppers_achieved_percentage: { label: 'Shoppers Achieved', higherIsBetter: true, unit: '%', greenThreshold: 80, amberThreshold: 60, redThreshold: 59.99 },
    otdep_percentage: { label: 'OTDep Adj', higherIsBetter: true, unit: '%', greenThreshold: 98, amberThreshold: 95, redThreshold: 94.99 },
    online_availability_percentage: { label: 'Online Availability', higherIsBetter: true, unit: '%', greenThreshold: 97, amberThreshold: 95, redThreshold: 94.99 },
    dwc_percentage: { label: 'DWC', higherIsBetter: true, unit: '%', greenThreshold: 98, amberThreshold: 96, redThreshold: 95.99 },
    secondary_replen_percentage: { label: 'Secondary Replen', higherIsBetter: false, unit: '%', greenThreshold: 2, amberThreshold: 2.99, redThreshold: 3 },
    legacy_otdel_percentage: { label: 'Legacy OTDel', higherIsBetter: true, unit: '%', greenThreshold: 97, amberThreshold: 95, redThreshold: 93 },
    otdel_percentage: { label: 'OTDel', higherIsBetter: true, unit: '%', greenThreshold: 97, amberThreshold: 95, redThreshold: 93 }
};

const ICARE_METRIC_CONFIG = {
    // Removed: test_period: { label: 'TEST Period (Independent)', higherIsBetter: false, unit: '%' },
    // Removed: working_target: { label: 'I Care Target (Working)', higherIsBetter: false, unit: '%' },
    icare_target: { label: 'I Care Target', higherIsBetter: false, unit: '%' },
    icare_score_period: { label: 'I Care Score Period', higherIsBetter: false, unit: '%' },
    icare_score_period_vs_target: { label: 'Period vs Target', higherIsBetter: true, unit: '%' },
    icare_score_ytd: { label: 'I Care Score YTD', higherIsBetter: false, unit: '%' },
    icare_score_ytd_vs_target: { label: 'YTD vs Target', higherIsBetter: true, unit: '%' },
    availability_of_products_pd_vs_ly: { label: 'Period', higherIsBetter: true, unit: '%' },
    availability_of_products_ytd: { label: 'YTD', higherIsBetter: true, unit: '%' },
    collection_available_pd_vs_ly: { label: 'Period', higherIsBetter: true, unit: '%' },
    collection_available_ytd: { label: 'YTD', higherIsBetter: true, unit: '%' },
    condition_of_items_pd_vs_ly: { label: 'Period', higherIsBetter: true, unit: '%' },
    condition_of_items_ytd: { label: 'YTD', higherIsBetter: true, unit: '%' },
    delivery_arriving_pd_vs_ly: { label: 'Period', higherIsBetter: true, unit: '%' },
    delivery_arriving_ytd: { label: 'YTD', higherIsBetter: true, unit: '%' },
    friendliness_pd_vs_ly: { label: 'Period', higherIsBetter: true, unit: '%' },
    friendliness_ytd: { label: 'YTD', higherIsBetter: true, unit: '%' },
    substitution_appropriateness_period: { label: 'Period', higherIsBetter: true, unit: '%' },
    substitution_appropriateness_ytd: { label: 'YTD', higherIsBetter: true, unit: '%' },
    suitability_use_by_dates_period: { label: 'Period', higherIsBetter: true, unit: '%' },
    suitability_use_by_dates_ytd: { label: 'YTD', higherIsBetter: true, unit: '%' }
};

const ICARE_STORE_TEMPLATE = [
    { store_id: 'ALL', store_name: 'Total' },
    { store_id: 655, store_name: 'Taunton' },
    { store_id: 668, store_name: 'Torquay' },
    { store_id: 671, store_name: 'Truro' },
    { store_id: 674, store_name: 'Barnstaple' },
    { store_id: 682, store_name: 'Pinhoe Road' },
    { store_id: 691, store_name: 'Marsh Mills' },
    { store_id: 709, store_name: 'Hankridge Farm' },
    { store_id: 801, store_name: 'Paignton' },
    { store_id: 882, store_name: 'Newton Abbot' },
    { store_id: 2010, store_name: 'Alphington Road' },
    { store_id: 2162, store_name: 'Helston' },
    { store_id: 2283, store_name: 'Penzance' },
];

const ALL_METRIC_CONFIGS = { ...METRIC_CONFIG, ...ICARE_METRIC_CONFIG };

// Global getCellColorClass - might be used elsewhere, keeping it.
const getCellColorClass = (value, config) => {
    // DRM metric doesn't have color thresholds, so return empty string
    if (!config.hasOwnProperty('greenThreshold')) return '';
    
    // Color N/A values with white background
    if (value === null || value === undefined || value === 0) return 'bg-white text-gray-500'; // Note: 0 values are now colored white and treated as N/A in display

    const getIndividualStatus = (val, conf) => {
        if (conf.higherIsBetter) {
            if (val >= conf.greenThreshold) return 'bg-emerald-50 text-emerald-700 border-emerald-200';
            if (val >= conf.amberThreshold) return 'bg-amber-50 text-amber-700 border-amber-200';
            return 'bg-red-50 text-red-700 border-red-200';
        } else {
            if (val <= conf.greenThreshold) return 'bg-emerald-50 text-emerald-700 border-emerald-200';
            if (val <= conf.amberThreshold) return 'bg-amber-50 text-amber-700 border-amber-200';
            return 'bg-red-50 text-red-700 border-red-200';
        }
    };
    
    return getIndividualStatus(value, config);
};

const calculateRankings = (data, sortConfig = { column: 'default', direction: 'desc' }) => {
    if (!data || data.length === 0) return [];

    // Define the default store order
    const storeOrder = [
        'Taunton', 'Torquay', 'Truro', 'Barnstaple',
        'Pinhoe Road', 'Marsh Mills', 'Hankridge Farm',
        'Paignton', 'Newton Abbot', 'Alphington Road',
        'Helston', 'Penzance'
    ];

    // If sorting by a specific column (including store_name, rag_status, or any metric)
    if (sortConfig.column && sortConfig.column !== 'default') {
        const sortedByColumn = [...data]; // Use full data for specific column sort

        sortedByColumn.sort((a, b) => {
            const columnKey = sortConfig.column;
            let valA = a[columnKey];
            let valB = b[columnKey];

            // Custom sorting for 'store_name'
            if (columnKey === 'store_name') {
                const comparison = String(valA || '').localeCompare(String(valB || ''));
                return sortConfig.direction === 'desc' ? -comparison : comparison;
            }

            // Custom sorting for 'rag_status'
            if (columnKey === 'rag_status') {
                // Define order for RAG statuses
                const ragOrder = { 'Green': 1, 'Amber': 2, 'Red': 3, null: 4, undefined: 4, '': 4 };
                const orderA = ragOrder[valA] || 4;
                const orderB = ragOrder[valB] || 4;
                let comparison = orderA - orderB;
                return sortConfig.direction === 'desc' ? -comparison : comparison;
            }

            // Handle null/undefined values for other metrics
            if ((valA === null || valA === undefined) && (valB === null || valB === undefined)) return 0;
            if (valA === null || valA === undefined) return 1; // null A comes after B
            if (valB === null || valB === undefined) return -1; // null B comes before A

            const metricConfig = ALL_METRIC_CONFIGS[columnKey];
            let comparison = valA - valB;

            // Apply higherIsBetter/lowerIsBetter logic if metricConfig exists
            // Note: The new handleSort in PerformanceTableCard just toggles desc/asc.
            // calculateRankings will still apply the metricConfig preference here.
            if (metricConfig && metricConfig.higherIsBetter === false) { // If lower value is better, invert comparison
                comparison *= -1;
            }

            if (sortConfig.direction === 'desc') {
                comparison *= -1; // Reverse for descending
            }
            return comparison;
        });

        // Assign column-specific ranks to all stores
        let rankCounter = 1;
        const resultWithColumnRanks = sortedByColumn.map(store => {
            return { ...store, columnRank: rankCounter++ };
        });
        return resultWithColumnRanks;

    } else {
        // Default order logic (overall average score then predefined store order)
        const newtonAbbot = data.find(store => store.store_id === 882);
        const otherStores = data.filter(store => store.store_id !== 882);

        const RANKING_METRICS = ['shoppers_achieved_percentage', 'otdep_percentage', 'dwc_percentage'];
        
        const storeScores = otherStores.map(store => {
            let totalScore = 0;
            let availableMetrics = 0;

            RANKING_METRICS.forEach(metric => {
                const value = store[metric];
                if (value !== null && value !== undefined && value !== 0) {
                    totalScore += value;
                    availableMetrics++;
                }
            });

            const averageScore = availableMetrics > 0 ? totalScore / availableMetrics : 0;
            
            return {
                ...store,
                averageScore: averageScore
            };
        });

        // Sort by average score (descending) and assign overall ranks
        const sortedStores = storeScores.sort((a, b) => b.averageScore - a.averageScore);
        const rankedStores = sortedStores.map((store, index) => ({
            ...store,
            overallRank: index + 1
        }));

        // Add Newton Abbot back
        let finalResults = [...rankedStores];
        if (newtonAbbot) {
            finalResults.push({
                ...newtonAbbot,
                overallRank: null, // No ranking for Newton Abbot in default overall view
                averageScore: null
            });
        }

        const resultWithOverallRanksAsColumnRanks = finalResults.map(store => ({
            ...store,
            columnRank: store.overallRank // Assign overallRank to columnRank for default view
        }));

        // Sort by the predefined store order (default)
        const finalSortedByDefaultOrder = resultWithOverallRanksAsColumnRanks.sort((a, b) => {
            const orderA = storeOrder.indexOf(a.store_name);
            const orderB = storeOrder.indexOf(b.store_name);
            
            // If store name not found in order array, put it at the end
            const finalOrderA = orderA === -1 ? 999 : orderA;
            const finalOrderB = orderB === -1 ? 999 : orderB;
            
            return finalOrderA - finalOrderB;
        });
        return finalSortedByDefaultOrder;
    }
};

const PerformanceTableCard = ({ 
  title, 
  data, 
  isEditing, 
  editedData, 
  handleValueChange, 
  onClearData, 
  canEdit, 
  metricsToShow = METRIC_CONFIG,
  periodRange,
  onPeriodRangeChange
}) => {
    const [sortConfig, setSortConfig] = useState({ column: 'default', direction: 'desc' });
    const [isCollapsed, setIsCollapsed] = useState(false);
    
    const rankedData = calculateRankings(data, sortConfig);
    
    const handleSort = (column) => {
        if (isEditing) return; // Disable sorting in edit mode
        let direction = 'desc';
        // If clicking the same column, toggle direction
        if (sortConfig.column === column) {
            direction = sortConfig.direction === 'desc' ? 'asc' : 'desc';
        }
        setSortConfig({ column, direction });
    };

    const getSortIcon = (column) => {
        if (sortConfig.column !== column) return null; // No icon if not currently sorted
        return sortConfig.direction === 'asc' ? '↑' : '↓';
    };

    const getRAGClass = (ragStatus) => {
        switch (ragStatus) {
            case 'Green': return 'bg-emerald-100 text-emerald-800 border-emerald-300';
            case 'Amber': return 'bg-amber-100 text-amber-800 border-amber-300';
            case 'Red': return 'bg-red-100 text-red-800 border-red-300';
            default: return 'bg-gray-100 text-gray-800 border-gray-300'; // For N/A or empty
        }
    };

    const getCellColorClass = (value, metric) => {
        // DRM metric doesn't have color thresholds
        if (metric === 'drm') return '';
        // If value is N/A or 0, return no color classes (will be handled by default table cell styling or display value)
        if (value === null || value === undefined || value === 0) return '';
        
        const config = metricsToShow[metric];
        if (!config || config.greenThreshold === undefined) return ''; // Only apply color if thresholds are defined

        const numValue = parseFloat(value);
        if (isNaN(numValue)) return '';

        if (config.higherIsBetter) {
            if (numValue >= config.greenThreshold) return 'bg-emerald-50 text-emerald-900 font-semibold';
            if (numValue >= config.amberThreshold) return 'bg-amber-50 text-amber-900';
            return 'bg-red-50 text-red-900';
        } else { // Lower is better
            if (numValue <= config.greenThreshold) return 'bg-emerald-50 text-emerald-900 font-semibold';
            if (numValue <= config.amberThreshold) return 'bg-amber-50 text-amber-900';
            return 'bg-red-50 text-red-900';
        }
    };
    
    return (
        <Card className="glass-card overflow-hidden mb-4">
            <CardHeader className="flex flex-row justify-between items-start pb-2">
                <div className="flex-1">
                    <div className="flex items-center gap-2">
                        <button
                            onClick={() => setIsCollapsed(!isCollapsed)}
                            className="p-1 hover:bg-gray-100 rounded transition-colors"
                        >
                            {isCollapsed ? (
                                <ChevronRight className="w-4 h-4 text-gray-500" />
                            ) : (
                                <ChevronDown className="w-4 h-4 text-gray-500" />
                            )}
                        </button>
                        <CardTitle className="text-base font-semibold">{title}</CardTitle>
                    </div>
                    <CardDescription className="text-xs ml-6">
                        {isEditing ? "Edit mode: Click values to modify." : "Performance comparison across regional stores."}
                    </CardDescription>
                    {!isCollapsed && (
                        <div className="mt-2 flex items-center gap-2 ml-6">
                            <span className="text-xs text-gray-600">Period</span>
                            {isEditing ? (
                                <>
                                    <Input
                                        type="number"
                                        min="1"
                                        max="13"
                                        value={periodRange?.fromPeriod || ''}
                                        onChange={(e) => onPeriodRangeChange({ ...periodRange, fromPeriod: e.target.value })}
                                        className="w-16 h-6 text-xs text-center border-gray-300"
                                        placeholder="From"
                                    />
                                    <span className="text-xs text-gray-400">to</span>
                                    <Input
                                        type="number"
                                        min="1"
                                        max="13"
                                        value={periodRange?.toPeriod || ''}
                                        onChange={(e) => onPeriodRangeChange({ ...periodRange, toPeriod: e.target.value })}
                                        className="w-16 h-6 text-xs text-center border-gray-300"
                                        placeholder="To"
                                    />
                                </>
                            ) : (
                                <span className="text-xs text-gray-500">
                                    {periodRange?.fromPeriod && periodRange?.toPeriod 
                                        ? `P${periodRange.fromPeriod} - P${periodRange.toPeriod}`
                                        : (periodRange?.fromPeriod ? `P${periodRange.fromPeriod}` : (periodRange?.toPeriod ? `P${periodRange.toPeriod}` : 'Not set'))}
                                </span>
                            )}
                        </div>
                    )}
                </div>
                {!isCollapsed && canEdit && !isEditing && data.length > 0 && (
                    <Button variant="outline" size="sm" onClick={onClearData} className="border-red-200 text-red-600 hover:bg-red-50 rounded-lg px-2 py-1 text-xs h-6">
                        <Trash2 className="w-3 h-3 mr-1" />
                        Clear
                    </Button>
                )}
            </CardHeader>
            {!isCollapsed && (
                <CardContent className="p-2">
                    <div className="overflow-x-auto">
                        <table className="w-full border-collapse text-xs">
                            <thead>
                                <tr className="bg-slate-100 border-b">
                                    <th className="p-1.5 text-left sticky left-0 bg-slate-100 z-10 border-r">
                                        <button onClick={() => handleSort('store_name')} className="font-semibold hover:text-blue-600 flex items-center gap-1">
                                            Store {getSortIcon('store_name')}
                                        </button>
                                    </th>
                                    <th className="p-1.5 text-center">
                                        <button onClick={() => handleSort('rag_status')} className="font-semibold hover:text-blue-600 flex items-center gap-1 mx-auto">
                                            RAG {getSortIcon('rag_status')}
                                        </button>
                                    </th>
                                    {Object.entries(metricsToShow).map(([key, config]) => (
                                        <th key={key} className="p-1.5 text-center border-l">
                                            <button onClick={() => handleSort(key)} className="font-semibold hover:text-blue-600 flex items-center gap-1 mx-auto">
                                                {config.label} {getSortIcon(key)}
                                            </button>
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {rankedData.length > 0 ? (
                                    rankedData.map((store) => {
                                        const edited = editedData[store.id] || {}; // Use store.id for editedData lookup
                                        const currentRagStatus = edited.rag_status !== undefined ? edited.rag_status : store.rag_status;

                                        return (
                                            <tr key={store.id} className="border-b hover:bg-slate-50"> {/* Use store.id for key */}
                                                <td className="p-1.5 font-medium text-left sticky left-0 bg-white z-10 border-r">
                                                    {store.store_name}
                                                    {store.period && store.period.toLowerCase() !== 'annual' && (
                                                        <p className="text-xs text-slate-500 font-normal">{store.period}</p>
                                                    )}
                                                </td>
                                                <td className="p-1.5 text-center">
                                                    {isEditing ? (
                                                        <Select
                                                            value={currentRagStatus || ''} // Use empty string for N/A in Select
                                                            onValueChange={(value) => handleValueChange(store.id, 'rag_status', value === '' ? null : value)} // Pass store.id
                                                        >
                                                            <SelectTrigger className="h-6 text-xs border w-full">
                                                                <SelectValue placeholder="Select RAG" />
                                                            </SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="Green">Green</SelectItem>
                                                                <SelectItem value="Amber">Amber</SelectItem>
                                                                <SelectItem value="Red">Red</SelectItem>
                                                                <SelectItem value={null}>N/A</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                    ) : (
                                                        <Badge className={`${getRAGClass(currentRagStatus)} border px-2 py-0.5 text-xs`}>
                                                            {currentRagStatus || 'N/A'}
                                                        </Badge>
                                                    )}
                                                </td>
                                                {Object.entries(metricsToShow).map(([key, config]) => {
                                                    const currentValue = edited[key] !== undefined ? edited[key] : store[key];
                                                    const displayValue = currentValue !== null && currentValue !== undefined && currentValue !== 0
                                                        ? (config.unit === '%' ? `${currentValue.toFixed(2)}%` : currentValue.toFixed(key === 'drm' ? 0 : 2)) // Format with 2 decimal places for numbers, 0 for DRM
                                                        : (key === 'drm' ? (currentValue === 0 ? '0' : '-') : '-'); // If value is 0 for DRM, display '0', otherwise '-'

                                                    return (
                                                        <td
                                                            key={key}
                                                            className={`p-1.5 text-center border-l ${!isEditing ? getCellColorClass(currentValue, key) : ''}`}
                                                        >
                                                            {isEditing && key !== 'drm' ? ( // DRM is not editable
                                                                <Input
                                                                    type="number"
                                                                    step="0.01"
                                                                    value={currentValue !== null && currentValue !== undefined ? currentValue : ''}
                                                                    onChange={(e) => handleValueChange(store.id, key, e.target.value ? parseFloat(e.target.value) : null)} // Pass store.id
                                                                    className="h-6 text-xs text-center border p-0"
                                                                    placeholder="-"
                                                                />
                                                            ) : (
                                                                <span>{displayValue}</span>
                                                            )}
                                                        </td>
                                                    );
                                                })}
                                            </tr>
                                        );
                                    })
                                ) : (
                                    <tr>
                                        <td colSpan={2 + Object.keys(metricsToShow).length} className="p-4 text-center text-gray-500">
                                            No data available. {isEditing && canEdit ? "Click 'Save Changes' to add new stores." : ""}
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            )}
        </Card>
    );
};

const ICareTableCard = ({ title, data, isEditing, editedData, handleValueChange, onClearData, canEdit, year, setEditedData }) => {
    const [sortConfig, setSortConfig] = useState({ column: 'default', direction: 'asc' });
    const [bulkTargetValue, setBulkTargetValue] = useState(''); // New state for bulk target
    const [isCollapsed, setIsCollapsed] = useState(false); // Not collapsed by default

    // Use the same pattern as PerformanceTableCard: derived data is memoized and incorporates sorting.
    const effectiveData = useMemo(() => {
        // 1. Filter raw data by year
        let currentItems = data.filter(item => item.year === year);

        // 2. If in editing mode, integrate editedData (which can include new template items)
        if (isEditing) {
            const combinedData = {};
            // Add existing items for the year
            currentItems.forEach(item => combinedData[item.id] = item);
            // Override/add from editedData
            Object.values(editedData).filter(item => item.year === year).forEach(item => combinedData[item.id] = item);
            
            // If there's no existing iCare data for this year, and we're editing,
            // ensure the template stores are present as initial editable entries.
            // This case is handled during `handleEditToggle` where `editedData` is initialized.
            // If `editedData` is populated with template items (e.g., from handleEditToggle when no data exists),
            // they will be included via the `Object.values(editedData)` merge above.
            currentItems = Object.values(combinedData);
        }

        // Define a stable order for default sorting (Total first, then by store order)
        const storeOrder = ['Total', 'Taunton', 'Torquay', 'Truro', 'Barnstaple', 'Pinhoe Road', 'Marsh Mills', 'Hankridge Farm', 'Paignton', 'Newton Abbot', 'Alphington Road', 'Helston', 'Penzance'];
        
        // 3. Apply sorting based on sortConfig
        if (sortConfig.column === 'default') {
            currentItems.sort((a, b) => {
                const nameA = a.store_name;
                const nameB = b.store_name;

                const orderA = storeOrder.indexOf(nameA);
                const orderB = storeOrder.indexOf(nameB);

                // Handle names not in the predefined order by putting them at the end
                const finalOrderA = orderA === -1 ? 999 : orderA;
                const finalOrderB = orderB === -1 ? 999 : orderB;
                
                return finalOrderA - finalOrderB;
            });
        } else {
            // Sort by the selected column
            const columnKey = sortConfig.column;
            const metricConfig = ICARE_METRIC_CONFIG[columnKey];

            currentItems.sort((a, b) => {
                const valA = a[columnKey];
                const valB = b[columnKey];

                const isTotalA = a.store_id === 'ALL';
                const isTotalB = b.store_id === 'ALL';

                // Ensure 'Total' row remains at the top when sorting by a column
                if (isTotalA && !isTotalB) return -1;
                if (!isTotalA && isTotalB) return 1;
                if (isTotalA && isTotalB) return 0; // Both are total, maintain original sub-order (if any)

                // Handle null/undefined values for sorting in metric columns. Place them at the end.
                if ((valA === null || valA === undefined) && (valB === null || valB === undefined)) return 0;
                if (valA === null || valA === undefined) return 1; // Null A comes after B
                if (valB === null || valB === undefined) return -1; // Null B comes before A

                let comparison = valA - valB;

                if (metricConfig && metricConfig.higherIsBetter === false) { // If lower value is better, invert comparison
                    comparison *= -1;
                }

                if (sortConfig.direction === 'desc') {
                    comparison *= -1; // Reverse for descending
                }
                return comparison;
            });
        }
        
        return currentItems;
    }, [data, sortConfig, isEditing, editedData, year]);

    const handleSort = (columnKey) => {
        const metricConfig = ICARE_METRIC_CONFIG[columnKey];
        const defaultDirection = (metricConfig && metricConfig.higherIsBetter === false) ? 'asc' : 'desc';

        let newDirection = defaultDirection;
        if (sortConfig.column === columnKey) {
            newDirection = sortConfig.direction === 'asc' ? 'desc' : 'asc';
        }
        setSortConfig({ column: columnKey, direction: newDirection });
    };

    const handleDefaultSort = () => {
        setSortConfig({ column: 'default', direction: 'asc' });
    };

    const getSortIcon = (columnKey) => {
        if (sortConfig.column !== columnKey) {
            return <span className="ml-1 text-gray-400">⇅</span>;
        }
        return sortConfig.direction === 'desc' ? 
            <span className="ml-1 text-blue-600">↓</span> : 
            <span className="ml-1 text-blue-600">↑</span>;
    };

    const formatValue = (val) => {
        if (val === null || val === undefined) return 'N/A';
        
        // For iCare scores, often a negative vs target is shown in parentheses.
        // For 'icare_target' itself, we usually just want the positive value.
        // Let's assume positive is always displayed as value%, and negative as (abs value)%.
        if (val < 0) {
            return `(${Math.abs(val).toFixed(1)}%)`;
        }
        return `${val.toFixed(1)}%`;
    };

    const getCellClass = (value, fieldKey) => {
        if (value === null || value === undefined) return 'text-gray-500';
        
        // iCare Target does not get special background coloring based on its value
        if (fieldKey.includes('_target') && !fieldKey.includes('_vs_target')) { 
            return ''; // No specific class, use default text color
        }

        // For 'vs_target' metrics, coloring based on positive/negative
        if (fieldKey.includes('_vs_target')) {
            if (value > 0) return 'text-emerald-700';
            if (value < 0) return 'text-red-700';
            return 'text-gray-600';
        }
        
        // Standard iCare coloring for score metrics (lower is better, e.g., <50 is good)
        // This specifically targets icare_score_period, icare_score_ytd, and test_period
        // Removed 'test_period' from this condition
        if (fieldKey === 'icare_score_period' || fieldKey === 'icare_score_ytd') {
            if (value <= 49.5) return 'bg-emerald-50 text-emerald-700';
            if (value <= 50.5) return 'bg-amber-50 text-amber-700';
            return 'bg-red-50 text-red-700';
        }

        // For other breakdown metrics (higher is better)
        if (value >= 80) return 'bg-emerald-50 text-emerald-700';
        if (value >= 60) return 'bg-amber-50 text-amber-700';
        return 'bg-red-50 text-red-700';
    };

    const handleBulkSetTargets = () => {
        if (!bulkTargetValue || !isEditing) return;
        
        const targetValue = parseFloat(bulkTargetValue);
        if (isNaN(targetValue)) {
            toast.error('Please enter a valid number for the target.');
            return;
        }

        const updatedData = { ...editedData };
        effectiveData.forEach(item => {
            if (item.store_id !== 'ALL') { // Don't set for Total row
                const currentEditedItem = updatedData[item.id] || item;
                updatedData[item.id] = {
                    ...currentEditedItem,
                    icare_target: targetValue
                };
            }
        });
        
        setEditedData(updatedData);
        setBulkTargetValue('');
        toast.success(`Set iCare target to ${targetValue}% for all stores.`);
    };
    
    const iCareColumns = [
        'icare_target', 
        'icare_score_period', 
        'icare_score_period_vs_target', 
        'icare_score_ytd', 
        'icare_score_ytd_vs_target',
        'availability_of_products_pd_vs_ly', 'availability_of_products_ytd',
        'collection_available_pd_vs_ly', 'collection_available_ytd',
        'condition_of_items_pd_vs_ly', 'condition_of_items_ytd',
        'delivery_arriving_pd_vs_ly', 'delivery_arriving_ytd',
        'friendliness_pd_vs_ly', 'friendliness_ytd',
        'substitution_appropriateness_period', 'substitution_appropriateness_ytd',
        'suitability_use_by_dates_period', 'suitability_use_by_dates_ytd'
    ];
    
    return (
        <Card className="glass-card overflow-hidden mb-4">
            <CardHeader className="flex flex-row justify-between items-center pb-2">
                <div>
                    <div className="flex items-center gap-2">
                        <CardTitle className="text-base font-semibold">iCare {year}</CardTitle>
                        <Button variant="ghost" size="icon" onClick={() => setIsCollapsed(!isCollapsed)} className="h-6 w-6">
                            {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                    </div>
                    {isEditing && !isCollapsed && ( // Only show description if not collapsed
                         <CardDescription className="text-xs">
                            Edit mode: Click values to modify iCare data.
                        </CardDescription>
                    )}
                </div>
                {canEdit && !isEditing && data.length > 0 && (
                    <Button variant="outline" size="sm" onClick={onClearData} className="border-red-200 text-red-600 hover:bg-red-50 rounded-lg px-2 py-1 text-xs h-6">
                        <Trash2 className="w-3 h-3 mr-1" />
                        Clear
                    </Button>
                )}
            </CardHeader>
            {!isCollapsed && (
                <CardContent className="p-2">
                    {isEditing && (
                        <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                            <div className="flex items-center gap-3">
                                <label className="text-sm font-medium text-blue-900">Set Target for All Stores:</label>
                                <Input
                                    type="number"
                                    step="0.1"
                                    value={bulkTargetValue}
                                    onChange={(e) => setBulkTargetValue(e.target.value)}
                                    placeholder="e.g., 50.0"
                                    className="w-32 text-center"
                                />
                                <span className="text-sm text-blue-700">%</span>
                                <Button 
                                    onClick={handleBulkSetTargets}
                                    size="sm"
                                    className="bg-blue-600 hover:bg-blue-700"
                                    disabled={!bulkTargetValue}
                                >
                                    Apply to All
                                </Button>
                            </div>
                        </div>
                    )}
                    
                    {effectiveData.length === 0 ? (
                        <div className="text-center py-8">
                            <Heart className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                            <h3 className="text-sm font-medium text-gray-900 mb-1">No iCare Data Available</h3>
                            <p className="text-xs text-gray-400">Click 'Edit' to manually enter iCare data matching the Sainsbury's report format.</p>
                        </div>
                    ) : (
                    <div className="overflow-x-auto">
                        <Table className="text-xs min-w-full">
                            <TableHeader>
                                <TableRow className="h-16 border-b">
                                    <TableHead rowSpan={2} className="sticky left-0 bg-white z-20 text-xs px-2 py-1 min-w-[120px] max-w-[140px] border-r-2 border-gray-200 align-bottom">
                                        <Button variant="ghost" size="sm" onClick={handleDefaultSort} className="p-0 h-auto font-medium hover:bg-transparent">
                                            Store {sortConfig.column === 'default' && <span className="ml-1 text-blue-600">✓</span>}
                                        </Button>
                                    </TableHead>
                                    
                                    <TableHead className="text-center text-xs px-2 py-1 bg-blue-100 border-l border-gray-300" colSpan="5"> {/* Changed from colSpan="7" to colSpan="5" */}
                                        I CARE SCORE
                                    </TableHead>
                                    
                                    <TableHead className="text-center text-xs px-2 py-1 bg-emerald-100 border-l border-gray-300" colSpan="2">
                                        AVAILABILITY OF PRODUCTS
                                    </TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-purple-100 border-l border-gray-300" colSpan="2">
                                        COLLECTION AVAILABLE WITHIN TIME SLOT
                                    </TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-yellow-100 border-l border-gray-300" colSpan="2">
                                        CONDITION OF ITEMS
                                    </TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-orange-100 border-l border-gray-300" colSpan="2">
                                        DELIVERY ARRIVING WITHIN TIME SLOT
                                    </TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-pink-100 border-l border-gray-300" colSpan="2">
                                        FRIENDLINESS OF COLLEAGUES
                                    </TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-cyan-100 border-l border-gray-300" colSpan="2">
                                        SUBSTITUTION APPROPRIATENESS
                                    </TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-indigo-100 border-l border-gray-300" colSpan="2">
                                        SUITABILITY OF USE BY DATES
                                    </TableHead>
                                </TableRow>
                                <TableRow className="h-8 border-b-2 border-gray-200">
                                    {/* Removed TEST Period (Independent) */}
                                    {/* Removed Target (Working) */}
                                    <TableHead className="text-center text-xs px-2 py-1 bg-blue-100 border-l border-gray-300 cursor-pointer hover:bg-blue-200 w-[100px]" onClick={() => handleSort('icare_target')}>Target {getSortIcon('icare_target')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-blue-100 cursor-pointer hover:bg-blue-200 w-[100px]" onClick={() => handleSort('icare_score_period')}>Period {getSortIcon('icare_score_period')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-blue-100 cursor-pointer hover:bg-blue-200 w-[100px]" onClick={() => handleSort('icare_score_period_vs_target')}>Period vs Target {getSortIcon('icare_score_period_vs_target')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-blue-100 cursor-pointer hover:bg-blue-200 w-[100px]" onClick={() => handleSort('icare_score_ytd')}>YTD {getSortIcon('icare_score_ytd')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-blue-100 border-r-2 border-gray-200 cursor-pointer hover:bg-blue-200 w-[100px]" onClick={() => handleSort('icare_score_ytd_vs_target')}>YTD vs Target {getSortIcon('icare_score_ytd_vs_target')}</TableHead>
                                    
                                    <TableHead className="text-center text-xs px-2 py-1 bg-emerald-100 border-l border-gray-300 cursor-pointer hover:bg-emerald-200 w-[100px]" onClick={() => handleSort('availability_of_products_pd_vs_ly')}>Period {getSortIcon('availability_of_products_pd_vs_ly')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-emerald-100 cursor-pointer hover:bg-emerald-200 w-[100px]" onClick={() => handleSort('availability_of_products_ytd')}>YTD {getSortIcon('availability_of_products_ytd')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-purple-100 border-l border-gray-300 cursor-pointer hover:bg-purple-200 w-[100px]" onClick={() => handleSort('collection_available_pd_vs_ly')}>Period {getSortIcon('collection_available_pd_vs_ly')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-purple-100 cursor-pointer hover:bg-purple-200 w-[100px]" onClick={() => handleSort('collection_available_ytd')}>YTD {getSortIcon('collection_available_ytd')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-yellow-100 border-l border-gray-300 cursor-pointer hover:bg-yellow-200 w-[100px]" onClick={() => handleSort('condition_of_items_pd_vs_ly')}>Period {getSortIcon('condition_of_items_pd_vs_ly')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-yellow-100 cursor-pointer hover:bg-yellow-200 w-[100px]" onClick={() => handleSort('condition_of_items_ytd')}>YTD {getSortIcon('condition_of_items_ytd')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-orange-100 border-l border-gray-300 cursor-pointer hover:bg-orange-200 w-[100px]" onClick={() => handleSort('delivery_arriving_pd_vs_ly')}>Period {getSortIcon('delivery_arriving_pd_vs_ly')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-orange-100 cursor-pointer hover:bg-orange-200 w-[100px]" onClick={() => handleSort('delivery_arriving_ytd')}>YTD {getSortIcon('delivery_arriving_ytd')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-pink-100 border-l border-gray-300 cursor-pointer hover:bg-pink-200 w-[100px]" onClick={() => handleSort('friendliness_pd_vs_ly')}>Period {getSortIcon('friendliness_pd_vs_ly')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-pink-100 cursor-pointer hover:bg-pink-200 w-[100px]" onClick={() => handleSort('friendliness_ytd')}>YTD {getSortIcon('friendliness_ytd')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-cyan-100 border-l border-gray-300 cursor-pointer hover:bg-cyan-200 w-[100px]" onClick={() => handleSort('substitution_appropriateness_period')}>Period {getSortIcon('substitution_appropriateness_period')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-cyan-100 cursor-pointer hover:bg-cyan-200 w-[100px]" onClick={() => handleSort('substitution_appropriateness_ytd')}>YTD {getSortIcon('substitution_appropriateness_ytd')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-indigo-100 border-l border-gray-300 cursor-pointer hover:bg-indigo-200 w-[100px]" onClick={() => handleSort('suitability_use_by_dates_period')}>Period {getSortIcon('suitability_use_by_dates_period')}</TableHead>
                                    <TableHead className="text-center text-xs px-2 py-1 bg-indigo-100 cursor-pointer hover:bg-indigo-200 w-[100px]" onClick={() => handleSort('suitability_use_by_dates_ytd')}>YTD {getSortIcon('suitability_use_by_dates_ytd')}</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {effectiveData.map((item) => {
                                    const currentData = isEditing ? editedData[item.id] || item : item;
                                    const columnsWithLeftBorder = [
                                        'icare_target', // Removed test_period, working_target
                                        'availability_of_products_pd_vs_ly', 'collection_available_pd_vs_ly',
                                        'condition_of_items_pd_vs_ly', 'delivery_arriving_pd_vs_ly',
                                        'friendliness_pd_vs_ly', 'substitution_appropriateness_period',
                                        'suitability_use_by_dates_period'
                                    ];

                                    return (
                                        <TableRow key={item.id} className={`hover:bg-slate-50 h-8 ${item.store_name === 'Total' ? 'bg-gray-100 font-semibold border-b-2 border-gray-300' : ''}`}>
                                            <TableCell className="font-medium sticky left-0 bg-white z-10 px-2 py-1 text-xs border-r-2 border-gray-200 min-w-[120px] max-w-[140px]">
                                                {item.store_name} {item.store_id !== 'ALL' ? `(${item.store_id})` : ''}
                                            </TableCell>
                                            
                                            {iCareColumns.map((columnKey) => (
                                                <TableCell 
                                                    key={columnKey}
                                                    className={`text-center px-2 py-1 text-xs w-[100px] ${getCellClass(currentData[columnKey], columnKey)} 
                                                    ${columnKey === 'icare_score_ytd_vs_target' ? 'border-r-2 border-gray-200' : ''} 
                                                    ${columnsWithLeftBorder.includes(columnKey) ? 'border-l border-gray-300' : ''}
                                                    `}
                                                >
                                                    {isEditing && item.store_id !== 'ALL' ? (
                                                        <Input
                                                            type="number"
                                                            step="0.01"
                                                            value={currentData[columnKey] ?? ''}
                                                            onChange={(e) => handleValueChange(item.id, columnKey, e.target.value)}
                                                            className="text-center text-xs border-0 bg-transparent focus:ring-1 focus:ring-blue-500 w-full h-6 px-1"
                                                        />
                                                    ) : (
                                                        formatValue(currentData[columnKey])
                                                    )}
                                                </TableCell>
                                            ))}
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                    </div>
                    )}
                </CardContent>
            )}
        </Card>
    );
};

// StoreRankings component with collapsible functionality
const CollapsibleStoreRankings = ({ data, viewType, year }) => {
    const [isCollapsed, setIsCollapsed] = useState(true); // Collapsed by default

    // This is the existing logic for StoreRankings, now wrapped in a collapsible card.
    // The previous implementation of StoreRankings was in another file,
    // so this is a representation of how it might be adapted or how its wrapper looks.
    // Assuming the original StoreRankings component renders its full content within CardContent.
    return (
        <Card className="glass-card overflow-hidden">
            <CardHeader className="flex flex-row justify-between items-center pb-2">
                <div className="flex items-center gap-2">
                    <CardTitle className="text-base font-semibold">Top 3 Performing Stores ({viewType} {year})</CardTitle>
                    <Button variant="ghost" size="icon" onClick={() => setIsCollapsed(!isCollapsed)} className="h-6 w-6">
                        {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                </div>
            </CardHeader>
            {!isCollapsed && (
                <CardContent className="p-2">
                    {/* The actual content of the StoreRankings component would go here */}
                    {/* For now, a placeholder assuming StoreRankings outputs directly */}
                    <StoreRankings data={data} viewType={viewType} year={year} />
                </CardContent>
            )}
        </Card>
    );
};


export default function LinkPage() {
    const [performanceData, setPerformanceData] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [year, setYear] = useState(new Date().getFullYear());
    const [canEdit, setCanEdit] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const [editedData, setEditedData] = useState({});
    const [showConfirmDialog, setShowConfirmDialog] = useState(false);
    const [viewToClear, setViewToClear] = useState(null);
    const [isUpdatingNames, setIsUpdatingNames] = useState(false);
    const [showStoreNameUpdateButton, setShowStoreNameUpdateButton] = useState(true);
    const [currentTab, setCurrentTab] = useState('performance');
    const [isUpdatingICare, setIsUpdatingICare] = useState(false);

    // Add period range state for each view type
    const [periodRanges, setPeriodRanges] = useState({
      'YTD': { fromPeriod: '', toPeriod: '' },
      'Mid Year': { fromPeriod: '', toPeriod: '' },
      'Last Year': { fromPeriod: '', toPeriod: '' }
    });

    // yearRef is no longer directly used inside fetchData, but if it was for other purposes outside,
    // it can be kept. For now, removing it as the `year` state is directly used in fetchData dependencies.
    // const yearRef = useRef(year);
    // useEffect(() => {
    //     yearRef.current = year;
    // }, [year]); 

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            const data = await RegionalPerformance.list();
            setPerformanceData(data);
            
            // Load period ranges from existing data for the current selected year
            const newLoadedRanges = {
                'YTD': { fromPeriod: '', toPeriod: '' },
                'Mid Year': { fromPeriod: '', toPeriod: '' },
                'Last Year': { fromPeriod: '', toPeriod: '' }
            };

            const dataForCurrentYear = data.filter(d => d.year === year);

            dataForCurrentYear.forEach(record => {
                // Only extract period ranges for performance view types (not iCare)
                if (record.period && ['YTD', 'Mid Year', 'Last Year'].includes(record.view_type)) {
                    // Extract from PXX-PXX or PXX formats
                    const periodMatch = record.period.match(/P(\d+)(?:-P(\d+))?/);
                    if (periodMatch) {
                        const from = periodMatch[1];
                        const to = periodMatch[2] || from; // If only one P value, 'to' is the same as 'from'
                        // Only update if the range for this view_type is not already populated to avoid overwriting
                        // and ensure it's not from a "Total" or aggregated record, assuming period ranges
                        // are stored consistently across records for a given view_type.
                        if (newLoadedRanges[record.view_type].fromPeriod === '' && newLoadedRanges[record.view_type].toPeriod === '' && record.store_id !== 'ALL') {
                            newLoadedRanges[record.view_type] = { fromPeriod: from, toPeriod: to };
                        }
                    }
                }
            });

            setPeriodRanges(newLoadedRanges);
            
            // Filter out 'iCare' view types when determining available years for the main performance view
            const newAvailableYears = [...new Set(data.filter(d => d.view_type !== 'iCare').map(d => d.year))].sort((a,b) => b-a);
            
            // If the current year is no longer available in the fetched data, set to the latest available.
            // Or if no available years, default to current calendar year.
            if (newAvailableYears.length > 0 && !newAvailableYears.includes(year)) {
                setYear(newAvailableYears[0]);
            } else if (newAvailableYears.length === 0) {
                 setYear(new Date().getFullYear());
            }
        } catch (error) {
            console.error("Failed to fetch performance data:", error);
            toast.error("Failed to load regional performance data.");
        } finally {
            setIsLoading(false);
        }
    }, [setPerformanceData, setPeriodRanges, setYear, year]); // Add `year` to dependencies to re-fetch when year changes

    useEffect(() => {
        const initialize = async () => {
            try {
                const user = await User.me();
                setCanEdit(user && user.role === 'admin');
            } catch (e) {
                setCanEdit(false);
            }
            
            fetchData(); // This will re-run when fetchData's dependencies change (i.e., when `year` changes)
        };
        initialize();
    }, [fetchData]); // Dependency is `fetchData`

    const handleEditToggle = () => {
        if (!canEdit) {
            toast.error("You must be logged in as an administrator to edit data.");
            return;
        }
        
        if (isEditing) {
            const hasChanges = Object.keys(editedData).length > 0;
            if (hasChanges) {
                setShowConfirmDialog(true);
            } else {
                setIsEditing(false);
                setEditedData({});
            }
        } else {
            setIsEditing(true);
            const initialData = {};
            if (currentTab === 'performance') {
                [...ytdData, ...midYearData, ...lastYearData]
                    .filter(d => d.year === year)
                    .forEach(item => {
                        initialData[item.id] = { ...item };
                    });
            } else if (currentTab === 'icare') {
                const dataForYear = iCareData.filter(d => d.year === year);
                if (dataForYear.length > 0) {
                    dataForYear.forEach(item => {
                        initialData[item.id] = { ...item };
                    });
                } else {
                    // Create template records if no iCare data exists for the current year
                    ICARE_STORE_TEMPLATE.forEach((store) => {
                        const tempId = `new_${store.store_id}_${year}`; // Stable ID for template items
                        initialData[tempId] = {
                            id: tempId,
                            ...store,
                            year: year,
                            view_type: 'iCare',
                            period: `P1 ${year}`, // Default period, can be changed if needed
                            // Removed: test_period: null, 
                            // Removed: working_target: null, 
                            icare_target: null,
                            icare_score_period: null,
                            icare_score_period_vs_target: null,
                            icare_score_ytd: null,
                            icare_score_ytd_vs_target: null,
                            availability_of_products_pd_vs_ly: null,
                            availability_of_products_ytd: null,
                            collection_available_pd_vs_ly: null,
                            collection_available_ytd: null,
                            condition_of_items_pd_vs_ly: null,
                            condition_of_items_ytd: null,
                            delivery_arriving_pd_vs_ly: null,
                            delivery_arriving_ytd: null,
                            friendliness_pd_vs_ly: null,
                            friendliness_ytd: null,
                            substitution_appropriateness_period: null,
                            substitution_appropriateness_ytd: null,
                            suitability_use_by_dates_period: null,
                            suitability_use_by_dates_ytd: null
                        };
                    });
                }
            }
            setEditedData(initialData);
        }
    };

    const handleCancelEdit = () => {
        setIsEditing(false);
        setEditedData({});
        setShowConfirmDialog(false);
    };

    const handleValueChange = (id, field, value) => {
        // If value is explicitly set to null (e.g. from Select with N/A option), keep it null.
        // Otherwise, convert empty string to null, or parse to float.
        const finalValue = (value === null || value === '') ? null : parseFloat(value);
        
        setEditedData(prev => ({
            ...prev,
            [id]: {
                ...prev[id],
                [field]: finalValue
            }
        }));
    };

    const handleSaveChanges = async () => {
        setShowConfirmDialog(false);
        
        try {
            const promises = Object.values(editedData).map((data) => {
                // Exclude the 'Total' row from being saved
                if (data.store_id === 'ALL') {
                    return null;
                }

                // Determine the view_type of the current record being saved
                const recordViewType = data.view_type; 
                
                // Add period range data to each record if available, only for PerformanceTableCard's view types
                if (['YTD', 'Mid Year', 'Last Year'].includes(recordViewType)) {
                    const periodRangeData = periodRanges[recordViewType];
                    let periodText = '';

                    if (periodRangeData && (periodRangeData.fromPeriod || periodRangeData.toPeriod)) {
                        const fromP = parseInt(periodRangeData.fromPeriod);
                        const toP = parseInt(periodRangeData.toPeriod);

                        if (!isNaN(fromP) && !isNaN(toP)) {
                            // Ensure fromPeriod is not greater than toPeriod for a valid range
                            if (fromP === toP) {
                                periodText = `P${fromP}`;
                            } else if (fromP > toP) {
                                periodText = `P${toP}-P${fromP}`; // Swap if necessary
                            } else {
                                periodText = `P${fromP}-P${toP}`;
                            }
                        } else if (!isNaN(fromP)) {
                            periodText = `P${fromP}`;
                        } else if (!isNaN(toP)) {
                            periodText = `P${toP}`;
                        }
                    }
                    data.period = periodText || null; // Set to null if inputs are empty
                }
                // For iCare data, the 'period' field is managed differently and does not use these inputs.

                if (String(data.id).startsWith('new_')) {
                    // This is a new record, create it
                    const { id: tempId, ...createData } = data; // Remove temporary id
                    return RegionalPerformance.create(createData);
                } else {
                    // This is an existing record, update it
                    return RegionalPerformance.update(data.id, data);
                }
            }).filter(Boolean); // Filter out null promises

            if (promises.length === 0) {
                toast.info("No changes to save.");
                setIsEditing(false);
                setEditedData({});
                return;
            }

            await Promise.all(promises);
            await fetchData(); // Explicitly call fetchData to refresh data after save
            setIsEditing(false);
            setEditedData({});
            toast.success("All changes saved successfully!");
        } catch (error) {
            console.error("Error saving changes:", error);
            toast.error("Failed to save changes. Please try again.");
        }
    };

    const handleUpdateICareScores = async () => {
        setIsUpdatingICare(true);
        toast.info("Reading iCare data from the PDF and updating records for 2025. This may take a moment...");

        const storeNameMap = {
            'Taunton': 655, 'Torquay': 668, 'Truro': 671, 'Barnstaple': 674,
            'Pinhoe Road': 682, 'Marsh Mills': 691, 'Hankridge Farm': 709, 'Paignton': 801,
            'Newton Abbot': 882, 'Alphington Road': 2010, 'Helston': 2162, 'Penzance': 2283
        };

        // Assuming the file URL is fixed or can be retrieved
        const fileUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6866d9d13515e74b5479352f/5c3d7ed13_YTD.pdf";

        try {
            const extractionResult = await ExtractDataFromUploadedFile({
                file_url: fileUrl,
                json_schema: {
                    type: "object",
                    properties: {
                        stores: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    store_name: { type: "string" },
                                    icare_score_ytd: { type: "number" }
                                },
                                required: ["store_name", "icare_score_ytd"]
                            }
                        }
                    }
                }
            });

            if (extractionResult.status !== 'success' || !extractionResult.output || !extractionResult.output.stores) {
                throw new Error(extractionResult.details || "Failed to extract data from PDF.");
            }

            const iCareExtractedData = extractionResult.output.stores;
            // Filter for iCare records specifically for the target year (e.g., 2025)
            const targetYearForUpdate = 2025; // As per the outline comment: "updating records for 2025"
            const existingICareRecords = await RegionalPerformance.filter({ view_type: 'iCare', year: targetYearForUpdate });

            const updatePromises = [];

            for (const storeData of iCareExtractedData) {
                const storeId = storeNameMap[storeData.store_name];
                if (!storeId) {
                    console.warn(`Store name "${storeData.store_name}" not found in map, skipping.`);
                    continue;
                }

                const existingRecord = existingICareRecords.find(r => r.store_id === storeId);
                const payload = { icare_score_ytd: storeData.icare_score_ytd };

                if (existingRecord) {
                    updatePromises.push(RegionalPerformance.update(existingRecord.id, payload));
                } else {
                    // Create a new record with view_type 'iCare' if it doesn't exist
                    const newRecord = {
                        year: targetYearForUpdate,
                        period: 'YTD', // The PDF is YTD, but the overall view_type is 'iCare'
                        store_id: storeId,
                        store_name: storeData.store_name,
                        view_type: 'iCare',
                        ...payload
                    };
                    updatePromises.push(RegionalPerformance.create(newRecord));
                }
            }
            
            await Promise.all(updatePromises);

            toast.success(`Successfully updated iCare scores for ${updatePromises.length} stores.`);
            await fetchData(); // Explicitly call fetchData to refresh data after iCare update

        } catch (error) {
            console.error("Error updating iCare scores:", error);
            toast.error("An error occurred while updating iCare scores. Please try again.");
        } finally {
            setIsUpdatingICare(false);
        }
    };

    const handleUpdateStoreNames = async () => {
        setIsUpdatingNames(true);
        const storeNameMap = {
            655: 'Taunton',
            668: 'Torquay',
            671: 'Truro',
            674: 'Barnstaple',
            682: 'Pinhoe Road',
            691: 'Marsh Mills',
            709: 'Hankridge Farm',
            801: 'Paignton',
            882: 'Newton Abbot',
            2010: 'Alphington Road',
            2162: 'Helston',
            2283: 'Penzance'
        };

        try {
            // Fetch all records, assuming RegionalPerformance.list(null, 5000) retrieves a large dataset.
            const allRecords = await RegionalPerformance.list(null, 5000); 
            const updates = [];
            for (const record of allRecords) {
                const newName = storeNameMap[record.store_id];
                if (newName && newName !== record.store_name) {
                    updates.push(RegionalPerformance.update(record.id, { store_name: newName }));
                }
            }

            if (updates.length > 0) {
                await Promise.all(updates);
                toast.success(`Successfully updated names for ${updates.length} records.`);
                setShowStoreNameUpdateButton(false);
            } else {
                toast.info("All store names are already up-to-date.");
                setShowStoreNameUpdateButton(false);
            }

            await fetchData(); // Re-fetch data to reflect updated names

        } catch (error) {
            console.error("Error updating store names:", error);
            toast.error("Failed to update store names. Please try again.");
        } finally {
            setIsUpdatingNames(false);
        }
    };

    const handleClearData = async () => {
        if (!viewToClear) return;
        
        try {
            const recordsToDelete = performanceData.filter(d => 
                d.view_type === viewToClear && d.year === year
            );

            if (recordsToDelete.length === 0) {
                toast.info(`No data found to clear for ${viewToClear} view for year ${year}.`);
                setViewToClear(null);
                return;
            }

            const deletePromises = recordsToDelete.map(record => 
                RegionalPerformance.delete(record.id)
            );

            await Promise.all(deletePromises);
            await fetchData();
            toast.success(`Cleared ${recordsToDelete.length} records for ${viewToClear} successfully.`);
        } catch (error) {
            console.error("Error clearing data:", error);
            toast.error(`Failed to clear data for ${viewToClear}. Please try again.`);
        } finally {
            setViewToClear(null);
        }
    };

    const openClearConfirmDialog = (viewType) => {
        setViewToClear(viewType);
    };
    
    const ytdData = useMemo(() => {
        return performanceData.filter(d => d.view_type === 'YTD' && d.year === year);
    }, [performanceData, year]);

    const midYearData = useMemo(() => {
        return performanceData.filter(d => d.view_type === 'Mid Year' && d.year === year);
    }, [performanceData, year]);

    const lastYearData = useMemo(() => {
        return performanceData.filter(d => d.view_type === 'Last Year' && d.year === year);
    }, [performanceData, year]);
    
    const iCareData = useMemo(() => {
        return performanceData.filter(d => d.view_type === 'iCare' && d.year === year);
    }, [performanceData, year]);

    const availableYears = useMemo(() => {
        // Filter out 'iCare' view types for the general year selector, which is primarily for performance data
        const years = [...new Set(performanceData.map(d => d.year))].sort((a, b) => b - a);
        const currentYear = new Date().getFullYear();
        if (!years.includes(currentYear)) {
            years.unshift(currentYear);
        }
        if (years.length === 0) {
            return [currentYear];
        }
        return years;
    }, [performanceData]);

    return (
        <div className="p-3 space-y-3">
            <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Changes</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to save all your changes? This action cannot be undone.
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                        <Button variant="outline" onClick={handleCancelEdit}>Cancel</Button>
                        <Button onClick={handleSaveChanges} className="bg-blue-600 hover:bg-blue-700">Save Changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <Dialog open={!!viewToClear} onOpenChange={() => setViewToClear(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Clear All Data for {viewToClear}</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to permanently delete all {viewToClear} data for {year}? This action cannot be undone.
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setViewToClear(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={handleClearData}>Clear Data</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
                <div>
                    <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                        <Network className="w-6 h-6 text-blue-600"/>
                        Regional Performance LINK
                    </h1>
                    <p className="text-sm text-gray-600">Comparative analysis of performance metrics across stores for {year}.</p>
                </div>
                <div className="flex items-center gap-2">
                    <Select value={year.toString()} onValueChange={(val) => setYear(parseInt(val))}>
                        <SelectTrigger className="w-20 bg-white shadow-sm text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            {availableYears.map(y => <SelectItem key={y} value={y.toString()}>{y}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    {canEdit && (
                        <>
                            <Button 
                                size="sm" 
                                onClick={handleUpdateICareScores} 
                                className="bg-teal-600 hover:bg-teal-700 text-white text-xs h-6 px-2"
                                disabled={isUpdatingICare}
                            >
                                <RefreshCw className={`w-3 h-3 mr-1 ${isUpdatingICare ? 'animate-spin' : ''}`}/>
                                {isUpdatingICare ? 'Updating...' : 'Update iCare Scores'}
                            </Button>
                            {showStoreNameUpdateButton && (
                                <Button 
                                    size="sm" 
                                    onClick={handleUpdateStoreNames} 
                                    className="bg-purple-600 hover:bg-purple-700 text-white text-xs h-6 px-2"
                                    disabled={isUpdatingNames}
                                >
                                    <RefreshCw className={`w-3 h-3 mr-1 ${isUpdatingNames ? 'animate-spin' : ''}`}/>
                                    {isUpdatingNames ? 'Updating...' : 'Update Store Names'}
                                </Button>
                            )}
                            {isEditing && (
                                <Button variant="outline" size="sm" onClick={handleCancelEdit} className="border-slate-200 rounded-lg px-2 py-1 text-xs h-6">
                                    <X className="w-3 h-3 mr-1"/>
                                    Cancel
                                </Button>
                            )}
                            <Button size="sm" onClick={handleEditToggle} className="bg-blue-600 hover:bg-blue-700 text-white text-xs h-6 px-2">
                                {isEditing ? <><Save className="w-3 h-3 mr-1"/>Save</> : <><Edit className="w-3 h-3 mr-1"/>Edit</>}
                            </Button>
                        </>
                    )}
                    <Button variant="outline" size="sm" onClick={() => window.print()} className="border-slate-200/50 rounded-lg px-2 py-1 text-xs h-6">
                      <FileDown className="w-3 h-3 mr-1" />
                      Export
                    </Button>
                </div>
            </div>
            
            <Tabs value={currentTab} onValueChange={setCurrentTab}>
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="performance">Performance Link</TabsTrigger>
                    <TabsTrigger value="icare"><Heart className="w-4 h-4 mr-2" />iCare</TabsTrigger>
                </TabsList>
                <TabsContent value="performance">
                    <div className="space-y-6 mt-4">
                        <PerformanceTableCard 
                            title={`YTD Performance Overview - ${year}`}
                            data={ytdData}
                            isEditing={isEditing && currentTab === 'performance'}
                            editedData={editedData}
                            handleValueChange={handleValueChange}
                            onClearData={() => openClearConfirmDialog('YTD')}
                            canEdit={canEdit}
                            periodRange={periodRanges['YTD']}
                            onPeriodRangeChange={(range) => setPeriodRanges(prev => ({ ...prev, 'YTD': range }))}
                        />
                        {ytdData.length > 0 && (
                            <CollapsibleStoreRankings data={ytdData} viewType="YTD" year={year} />
                        )}

                        <PerformanceTableCard 
                            title={`Mid Year Performance Overview - ${year}`}
                            data={midYearData}
                            isEditing={isEditing && currentTab === 'performance'}
                            editedData={editedData}
                            handleValueChange={handleValueChange}
                            onClearData={() => openClearConfirmDialog('Mid Year')}
                            canEdit={canEdit}
                            periodRange={periodRanges['Mid Year']}
                            onPeriodRangeChange={(range) => setPeriodRanges(prev => ({ ...prev, 'Mid Year': range }))}
                        />
                        {midYearData.length > 0 && (
                            <CollapsibleStoreRankings data={midYearData} viewType="Mid Year" year={year} />
                        )}
                        
                        <PerformanceTableCard 
                            title={`Last Year Performance Overview - ${year}`}
                            data={lastYearData}
                            isEditing={isEditing && currentTab === 'performance'}
                            editedData={editedData}
                            handleValueChange={handleValueChange}
                            onClearData={() => openClearConfirmDialog('Last Year')}
                            canEdit={canEdit}
                            periodRange={periodRanges['Last Year']}
                            onPeriodRangeChange={(range) => setPeriodRanges(prev => ({ ...prev, 'Last Year': range }))}
                        />
                        {lastYearData.length > 0 && (
                            <CollapsibleStoreRankings data={lastYearData} viewType="Last Year" year={year} />
                        )}
                    </div>
                </TabsContent>
                <TabsContent value="icare">
                    <div className="space-y-6 mt-4">
                        <ICareTableCard 
                            title={`Comprehensive iCare Analysis - ${year}`}
                            data={iCareData}
                            isEditing={isEditing && currentTab === 'icare'}
                            editedData={editedData}
                            handleValueChange={handleValueChange}
                            onClearData={() => openClearConfirmDialog('iCare')}
                            canEdit={canEdit}
                            year={year}
                            setEditedData={setEditedData}
                        />
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    );
}
