import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileDown, Code, Database, Palette, Calculator } from 'lucide-react';
import { KPIMetric } from '@/api/entities';
import { ShopperPerformance } from '@/api/entities';
import { CustomerComplaint } from '@/api/entities';
import { PeriodConfig } from '@/api/entities';
import { RegionalPerformance } from '@/api/entities';
import { toast } from 'sonner';

export default function AppExportDocumentation() {
  const [isExporting, setIsExporting] = useState(false);

  const downloadJSON = (data, filename) => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportAllData = async () => {
    setIsExporting(true);
    try {
      const [kpiData, shopperData, complaintData, periodData, regionalData] = await Promise.all([
        KPIMetric.list('-created_date', 2000),
        ShopperPerformance.list('-created_date', 2000),
        CustomerComplaint.list('-created_date', 2000),
        PeriodConfig.list('-created_date', 100),
        RegionalPerformance.list('-created_date', 2000)
      ]);

      const exportPackage = {
        metadata: {
          exportDate: new Date().toISOString(),
          recordCounts: {
            kpiMetrics: kpiData.length,
            shopperPerformance: shopperData.length,
            customerComplaints: complaintData.length,
            periodConfigs: periodData.length,
            regionalPerformance: regionalData.length
          }
        },
        data: {
          kpiMetrics: kpiData,
          shopperPerformance: shopperData,
          customerComplaints: complaintData,
          periodConfigs: periodData,
          regionalPerformance: regionalData
        }
      };

      downloadJSON(exportPackage, `gol-truro-data-export-${new Date().toISOString().split('T')[0]}.json`);
      toast.success('Data exported successfully!');
    } catch (error) {
      toast.error('Failed to export data');
      console.error(error);
    }
    setIsExporting(false);
  };

  const businessLogicSpecs = {
    kpiCalculations: {
      opsScore: {
        description: "Ops Score uses custom rounding in Quarter/YTD view to specific sequence",
        formula: "Average of weekly values, then round to nearest: [44, 52, 60, 68, 76, 84, 92, 100]",
        thresholds: { green: 80, amber: 60, red: "<60" }
      },
      shopperAchievement: {
        description: "Percentage of shoppers achieving IPH target",
        formula: "(Shoppers above target / Total shoppers) * 100",
        thresholds: { green: 80, amber: 60, red: "<60" }
      },
      variance: {
        description: "Week-over-week percentage change",
        formula: "((current - previous) / previous) * 100"
      }
    },
    ragStatus: {
      description: "Red, Amber, Green status based on thresholds",
      logic: "higherIsBetter ? (val >= green ? 'green' : val >= amber ? 'amber' : 'red') : (val <= green ? 'green' : val <= amber ? 'amber' : 'red')"
    },
    aggregations: {
      period: "Average of 4 weeks within period",
      quarter: "Average of periods within quarter (Q1: P1-4, Q2: P5-7, Q3: P8-10, Q4: P11-13)",
      ytd: "Average of all weekly data in financial year"
    }
  };

  const apiEndpoints = {
    baseUrl: "https://api.base44.com/v1/",
    authentication: "Bearer token required in Authorization header",
    entities: {
      kpiMetrics: {
        list: "GET /entities/KPIMetric/list",
        filter: "POST /entities/KPIMetric/filter",
        create: "POST /entities/KPIMetric",
        update: "PUT /entities/KPIMetric/:id",
        delete: "DELETE /entities/KPIMetric/:id"
      },
      shopperPerformance: {
        list: "GET /entities/ShopperPerformance/list",
        filter: "POST /entities/ShopperPerformance/filter"
      }
    }
  };

  const uiSpecs = {
    colorScheme: {
      primary: "#3b82f6",
      success: "#22c55e", 
      warning: "#f59e0b",
      error: "#ef4444",
      ragGreen: "#22c55e",
      ragAmber: "#f59e0b", 
      ragRed: "#ef4444"
    },
    typography: {
      primaryFont: "Inter",
      sizes: {
        title: "24px",
        cardTitle: "18px", 
        value: "32px",
        label: "14px"
      }
    },
    components: {
      kpiCard: {
        description: "Main metric display card",
        features: ["Status color coding", "Trend arrows", "Edit mode", "Comparison mode"],
        dimensions: "Responsive grid, min 200px width"
      },
      dataTable: {
        description: "Sortable data table with edit capabilities",
        features: ["Sort by column", "Inline editing", "RAG status colors", "Bulk actions"]
      }
    },
    screens: {
      dashboard: {
        layout: "Header + 3 card sections (Weekly KPIs, Ops Readiness, Sales Summary)",
        features: ["Edit mode toggle", "Period/week selection", "Year selection", "PDF export"]
      },
      shopperPerformance: {
        layout: "Summary cards + detailed table + modal dialogs",
        features: ["IPH tracking", "WRAP status", "Achievement rates", "Individual shopper details"]
      }
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Native App Development Package</h1>
          <p className="text-gray-600">Complete documentation and data export for iOS/Android development</p>
        </div>
        <Button onClick={exportAllData} disabled={isExporting} className="btn-modern">
          <FileDown className="w-4 h-4 mr-2" />
          {isExporting ? 'Exporting...' : 'Export All Data'}
        </Button>
      </div>

      <Tabs defaultValue="data" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="data">Data Export</TabsTrigger>
          <TabsTrigger value="api">API Docs</TabsTrigger>
          <TabsTrigger value="logic">Business Logic</TabsTrigger>
          <TabsTrigger value="ui">UI/UX Specs</TabsTrigger>
        </TabsList>

        <TabsContent value="data">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                Data Structure & Export
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <h3 className="font-semibold mb-2">Core Entities</h3>
                  <ul className="text-sm space-y-1">
                    <li>• KPIMetric - All performance metrics</li>
                    <li>• ShopperPerformance - Individual shopper data</li>
                    <li>• CustomerComplaint - Complaint tracking</li>
                    <li>• PeriodConfig - Financial period dates</li>
                    <li>• RegionalPerformance - Store comparisons</li>
                  </ul>
                </div>
                <div className="p-4 border rounded-lg">
                  <h3 className="font-semibold mb-2">Data Relationships</h3>
                  <ul className="text-sm space-y-1">
                    <li>• KPIs linked by period/week/year</li>
                    <li>• Shoppers linked to performance</li>
                    <li>• Regional data by store_id</li>
                    <li>• All data filterable by date ranges</li>
                  </ul>
                </div>
              </div>
              
              <div className="p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold mb-2">Export Instructions</h3>
                <p className="text-sm mb-2">Click "Export All Data" to download a complete JSON file containing:</p>
                <ul className="text-sm space-y-1">
                  <li>• All historical data (2000+ records)</li>
                  <li>• Entity schemas and relationships</li>
                  <li>• Metadata with record counts</li>
                  <li>• Sample data for development/testing</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                API Integration Guide
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <pre className="bg-gray-100 p-4 rounded text-sm overflow-x-auto">
{JSON.stringify(apiEndpoints, null, 2)}
                </pre>
                
                <div className="p-4 bg-yellow-50 rounded-lg">
                  <h3 className="font-semibold mb-2">Authentication</h3>
                  <p className="text-sm">Base44 uses JWT bearer tokens. Include in all requests:</p>
                  <code className="text-xs bg-white p-2 rounded block mt-2">
                    Authorization: Bearer YOUR_TOKEN_HERE
                  </code>
                </div>

                <div className="p-4 bg-green-50 rounded-lg">
                  <h3 className="font-semibold mb-2">Key API Patterns</h3>
                  <ul className="text-sm space-y-1">
                    <li>• Use filter() with date ranges for period data</li>
                    <li>• Sort by '-created_date' for newest first</li>
                    <li>• Batch operations for better performance</li>
                    <li>• Handle rate limiting with exponential backoff</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logic">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="w-5 h-5" />
                Business Logic & Calculations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-gray-100 p-4 rounded text-sm overflow-x-auto whitespace-pre-wrap">
{JSON.stringify(businessLogicSpecs, null, 2)}
              </pre>
              
              <div className="mt-4 p-4 bg-red-50 rounded-lg">
                <h3 className="font-semibold mb-2">Critical Business Rules</h3>
                <ul className="text-sm space-y-2">
                  <li>• <strong>Ops Score Rounding:</strong> Only in Quarter/YTD views, use sequence [44,52,60,68,76,84,92,100]</li>
                  <li>• <strong>Period Logic:</strong> P1W3+ shows empty for missing data instead of fallbacks</li>
                  <li>• <strong>Comparison Mode:</strong> Shows year-over-year differences with trend indicators</li>
                  <li>• <strong>Secondary Replen:</strong> Lower is better (inverted RAG logic)</li>
                  <li>• <strong>Financial Year:</strong> Periods 1-13, Quarters: Q1(P1-4), Q2(P5-7), Q3(P8-10), Q4(P11-13)</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ui">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="w-5 h-5" />
                UI/UX Specifications
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="bg-gray-100 p-4 rounded text-sm overflow-x-auto whitespace-pre-wrap">
{JSON.stringify(uiSpecs, null, 2)}
              </pre>
              
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <h3 className="font-semibold mb-2">Mobile Considerations</h3>
                  <ul className="text-sm space-y-1">
                    <li>• Touch-friendly 44px minimum tap targets</li>
                    <li>• Horizontal scrolling for wide tables</li>
                    <li>• Pull-to-refresh for data updates</li>
                    <li>• Offline mode for viewing cached data</li>
                  </ul>
                </div>
                <div className="p-4 border rounded-lg">
                  <h3 className="font-semibold mb-2">Key Interactions</h3>
                  <ul className="text-sm space-y-1">
                    <li>• Long press for context menus</li>
                    <li>• Swipe gestures for navigation</li>
                    <li>• Edit mode toggle for data entry</li>
                    <li>• Confirmation dialogs for destructive actions</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Development Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold mb-2">React Native</h3>
              <p className="text-sm text-gray-600 mb-2">Best for cross-platform</p>
              <ul className="text-xs space-y-1">
                <li>• Reuse existing logic</li>
                <li>• Expo for faster development</li>
                <li>• React Navigation</li>
                <li>• AsyncStorage for offline</li>
              </ul>
            </div>
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold mb-2">Native iOS</h3>
              <p className="text-sm text-gray-600 mb-2">Best performance & features</p>
              <ul className="text-xs space-y-1">
                <li>• SwiftUI for modern UI</li>
                <li>• Core Data for offline storage</li>
                <li>• URLSession for API calls</li>
                <li>• Push notifications</li>
              </ul>
            </div>
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold mb-2">Flutter</h3>
              <p className="text-sm text-gray-600 mb-2">Alternative cross-platform</p>
              <ul className="text-xs space-y-1">
                <li>• Single codebase</li>
                <li>• Great performance</li>
                <li>• Material/Cupertino design</li>
                <li>• SQLite for offline data</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}