import React, { useState, useEffect, useMemo } from 'react';
import { User } from '@/api/entities';
import { Forecast } from '@/api/entities';
import { KPIMetric } from '@/api/entities';
import { PeriodConfig } from '@/api/entities';
import { PeakPlanning } from '@/api/entities';
import { useEditLock } from '../Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableFooter } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowUpDown, Edit, Save, X, FileDown, TrendingUp, TrendingDown } from 'lucide-react';
import { toast } from 'sonner';
import { format, startOfWeek, addDays, parseISO } from 'date-fns';
import { sumBy, groupBy } from 'lodash';

const calculatePeakTotals = (shopperData, agencyData, gaPeakData, isEditing, editedPeakData) => {
  const getEditedValue = (row, field) => {
    if (isEditing && editedPeakData[row.id]) {
      return editedPeakData[row.id][field] ?? row[field] ?? 0;
    }
    return row[field] ?? 0;
  };

  // Shopper totals
  const shopperRequired = shopperData.reduce((sum, row) => sum + getEditedValue(row, 'required'), 0);
  const shopperScheduled = shopperData.reduce((sum, row) => sum + getEditedValue(row, 'scheduled'), 0);
  const shopperHeads = shopperData.reduce((sum, row) => sum + getEditedValue(row, 'heads'), 0);
  const shopperIPH = shopperData.length > 0 ? shopperData.reduce((sum, row) => sum + getEditedValue(row, 'iph'), 0) / shopperData.length : 0;
  const shopperItems = shopperData.reduce((sum, row) => sum + (getEditedValue(row, 'scheduled') * getEditedValue(row, 'iph')), 0);
  const totalAgencyHours = agencyData.reduce((sum, row) => sum + getEditedValue(row, 'scheduled'), 0);
  const shopperTotalVariance = (shopperScheduled + totalAgencyHours) - shopperRequired;

  // GA totals
  const gaRequired = gaPeakData.reduce((sum, row) => sum + getEditedValue(row, 'required'), 0);
  const gaScheduled = gaPeakData.reduce((sum, row) => sum + getEditedValue(row, 'scheduled'), 0);
  const gaAM = gaPeakData.reduce((sum, row) => sum + getEditedValue(row, 'am'), 0);
  const gaPM = gaPeakData.reduce((sum, row) => sum + getEditedValue(row, 'pm'), 0);

  // Agency totals
  const agencyScheduled = agencyData.reduce((sum, row) => sum + getEditedValue(row, 'scheduled'), 0);
  const agencyHeads = agencyData.reduce((sum, row) => sum + getEditedValue(row, 'heads'), 0);

  return {
    shopper: {
      required: shopperRequired,
      scheduled: shopperScheduled,
      variance: shopperScheduled - shopperRequired,
      heads: shopperHeads,
      avgIPH: shopperIPH,
      items: shopperItems,
      agencyHours: totalAgencyHours,
      totalVariance: shopperTotalVariance
    },
    ga: {
      required: gaRequired,
      scheduled: gaScheduled,
      variance: gaScheduled - gaRequired,
      am: gaAM,
      pm: gaPM
    },
    agency: {
      scheduled: agencyScheduled,
      heads: agencyHeads
    }
  };
};

const SortableHeader = ({ children, column, sortConfig, onSort, className }) => {
  const isSorted = sortConfig.key === column;
  return (
    <TableHead onClick={() => onSort(column)} className={className}>
      <div className="flex items-center gap-2 cursor-pointer">
        {children}
        <ArrowUpDown className={`w-4 h-4 ${isSorted ? 'opacity-100' : 'opacity-30'}`} />
      </div>
    </TableHead>
  );
};

// New KPICard component
const KPICard = ({ title, value, description, icon: Icon, valueClass }) => (
  <Card className="glass-card">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      {Icon && <Icon className="h-4 w-4 text-muted-foreground" />}
    </CardHeader>
    <CardContent>
      <div className={`text-2xl font-bold ${valueClass}`}>{value}</div>
      {description && <p className="text-xs text-muted-foreground">{description}</p>}
    </CardContent>
  </Card>
);

export default function ForecastAndLabour() {
  // Daily (items) data states
  const [dailyForecastData, setDailyForecastData] = useState([]);
  const [allYearForecastData, setAllYearForecastData] = useState([]);
  const [editedDailyData, setEditedDailyData] = useState({});

  // Summary (labour) data states
  const [allKpiMetrics, setAllKpiMetrics] = useState([]);
  const [allWeeksSummaries, setAllWeeksSummaries] = useState([]);
  const [allPeriodsSummaries, setAllPeriodsSummaries] = useState([]);
  const [periodicGrandTotal, setPeriodicGrandTotal] = useState({ forecast: 0, actual: 0, worked_hours: 0, chop_chop: 0, variance: 0, variance_percent: 0 });
  const [editedLabourSummary, setEditedLabourSummary] = useState({});

  // Peak Planning data states
  const [shopperPeakData, setShopperPeakData] = useState([]);
  const [gaPeakData, setGaPeakData] = useState([]);
  const [agencyPeakData, setAgencyPeakData] = useState([]);
  const [editedPeakData, setEditedPeakData] = useState({});
  const [peakPlanningStartDate, setPeakPlanningStartDate] = useState('');
  const [peakPlanningEndDate, setPeakPlanningEndDate] = useState('');

  // Common states
  const [periods, setPeriods] = useState([]);
  const [currentPeriod, setCurrentPeriod] = useState(1);
  const [currentWeek, setCurrentWeek] = useState(1);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [sortConfig, setSortConfig] = useState({ key: 'date', direction: 'asc' });
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;

  // Edit mode states
  const [isEditing, setIsEditing] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);

  // New state for daily items view mode
  const [dailyViewMode, setDailyViewMode] = useState('weekly');

  // Helper function to determine current period and week (1 week behind for reporting)
  const getCurrentPeriodAndWeek = (periods, goBackOneWeek = true) => {
    const today = new Date();
    // Normalize today to start of day for accurate comparison
    today.setHours(0, 0, 0, 0);

    const currentPeriodConfig = periods.find(p => {
      // Ensure dates are parsed and normalized correctly for comparison
      const startDate = parseISO(p.start_date);
      startDate.setHours(0, 0, 0, 0); // Normalize startDate
      const endDate = parseISO(p.end_date);
      endDate.setHours(23, 59, 59, 999); // Normalize endDate to end of day for inclusive comparison
      return today >= startDate && today <= endDate;
    });

    let targetPeriod = 1; // Default
    let targetWeek = 1; // Default

    if (currentPeriodConfig) {
      const startDate = parseISO(currentPeriodConfig.start_date);
      startDate.setHours(0, 0, 0, 0); // Normalize startDate for calculation
      const diffTime = today.getTime() - startDate.getTime(); // Milliseconds difference
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24)); // Days difference, 0-indexed from period start
      let currentWeekNumber = Math.min(Math.floor(diffDays / 7) + 1, 4); // Calculate current week number, cap at 4

      targetPeriod = currentPeriodConfig.period_number;
      targetWeek = currentWeekNumber;
      
      // Apply the "1 week behind" logic only if requested
      if (goBackOneWeek) {
        targetWeek = currentWeekNumber - 1;
        
        // If we go back into the previous period
        if (targetWeek < 1) {
          targetPeriod = Math.max(1, targetPeriod - 1); // Go to previous period, minimum is 1
          targetWeek = 4; // Set to the last week of the previous period
        }
      }
    } else {
        // Fallback: find the latest period if no current period found for today's date
        // This usually means today is before the first period or after the last period.
        // In this case, we want to show the last week of the latest available period.
        const latestPeriod = periods.reduce((latest, current) => {
            return new Date(current.start_date) > new Date(latest.start_date) ? current : latest;
        }, periods[0]);

        if (latestPeriod) {
            targetPeriod = latestPeriod.period_number;
            targetWeek = 4; // Default to week 4 of the latest period
        } else {
            // If no periods are defined at all, stick to default 1, 1
            targetPeriod = 1;
            targetWeek = 1;
        }
    }
    
    return { period: targetPeriod, week: targetWeek };
  };

  useEffect(() => {
    const initialize = async () => {
      try {
        const user = await User.me();
        setIsAdmin(user && user.role === 'admin');
      } catch (e) {
        setIsAdmin(false);
      }
      
      // Load periods first to determine current period/week
      try {
        const periodsData = await PeriodConfig.filter({ year: currentYear }, 'period_number');
        setPeriods(periodsData);
        
        if (periodsData.length > 0) {
          const { period, week } = getCurrentPeriodAndWeek(periodsData);
          setCurrentPeriod(period);
          setCurrentWeek(week);
        } else {
            // If no periods are found for the year, default to P1W1
            setCurrentPeriod(1);
            setCurrentWeek(1);
        }
      } catch (error) {
        console.error("Error loading periods:", error);
        setPeriods([]);
        // Default to P1W1 on error
        setCurrentPeriod(1);
        setCurrentWeek(1);
      }
      
      await loadInitialData();
    };
    initialize();
  }, [currentYear]);

  useEffect(() => {
    filterDailyData();
    calculateAllSummaries();
  }, [allYearForecastData, allKpiMetrics, currentPeriod, currentWeek, dailyViewMode, currentYear, isEditing, editedDailyData]);

  useEffect(() => {
    loadPeakPlanningData();
  }, [allYearForecastData, allKpiMetrics, currentPeriod, currentWeek, currentYear, peakPlanningStartDate, peakPlanningEndDate, isEditing, editedDailyData, periods]);

  const getWeekColorClass = (dateStr) => {
    // Determine which week this date belongs to and return a subtle color class
    const date = parseISO(dateStr);
    
    // Calculate week number within the period
    const periodConfig = periods.find(p => p.period_number === currentPeriod);
    if (periodConfig) {
      const periodStart = parseISO(periodConfig.start_date);
      const daysDiff = Math.floor((date - periodStart) / (1000 * 60 * 60 * 24));
      const weekInPeriod = Math.floor(daysDiff / 7) + 1;

      const colors = [
        'bg-blue-50',
        'bg-green-50', 
        'bg-purple-50',
        'bg-amber-50'
      ];
      return colors[(weekInPeriod - 1) % 4] || '';
    }
    return '';
  };

  const loadPeakPlanningData = async () => {
    try {
      let datesToShow = [];
      let filterParams = { year: currentYear };

      // If date range is selected, use it; otherwise use period/week
      if (peakPlanningStartDate && peakPlanningEndDate) {
        const start = parseISO(peakPlanningStartDate);
        const end = parseISO(peakPlanningEndDate);
        const daysDiff = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;
        datesToShow = Array.from({ length: daysDiff }, (_, i) => 
          format(addDays(start, i), 'yyyy-MM-dd')
        );
      } else {
        datesToShow = getWeekDates();
        filterParams.period = currentPeriod;
        filterParams.week = currentWeek;
      }
      
      const peakPlanningData = await PeakPlanning.filter(filterParams, 'date');
      
      // Filter by date range if specified
      const filteredData = peakPlanningStartDate && peakPlanningEndDate
        ? peakPlanningData.filter(p => p.date >= peakPlanningStartDate && p.date <= peakPlanningEndDate)
        : peakPlanningData;
      
      // Ensure all dates are present for shoppers
      const shoppers = datesToShow.map(date => {
        const existing = filteredData.find(p => p.type === 'shoppers' && p.date === date);
        
        // Pull forecast_items from daily forecast data
        const dailyForecast = allYearForecastData.find(d => d.date === date);
        let forecastItems = dailyForecast?.items_forecast || 0;
        
        // If editing and there's an edited value for this date's forecast, use that instead
        if (isEditing && dailyForecast && editedDailyData[dailyForecast.id]) {
          forecastItems = editedDailyData[dailyForecast.id].items_forecast || 0;
        }
        
        return existing ? { ...existing, forecast_items: forecastItems } : {
          id: `new-shopper-${date}`,
          date,
          type: 'shoppers',
          required: 0,
          scheduled: 0,
          heads: 0,
          iph: 55,
          forecast_items: forecastItems,
          period: currentPeriod,
          week: currentWeek,
          year: currentYear
        };
      });
      
      // Ensure all dates are present for GA
      const ga = datesToShow.map(date => {
        const existing = filteredData.find(p => p.type === 'ga' && p.date === date);
        return existing || {
          id: `new-ga-${date}`,
          date,
          type: 'ga',
          required: 0,
          scheduled: 0,
          am: 0,
          pm: 0,
          period: currentPeriod,
          week: currentWeek,
          year: currentYear
        };
        });
      
      // Ensure all dates are present for Agency
      const agency = datesToShow.map(date => {
        const existing = filteredData.find(p => p.type === 'agency' && p.date === date);
        return existing || {
          id: `new-agency-${date}`,
          date,
          type: 'agency',
          required: 0,
          scheduled: 0,
          heads: 0,
          period: currentPeriod,
          week: currentWeek,
          year: currentYear
        };
      });
      
      setShopperPeakData(shoppers);
      setGaPeakData(ga);
      setAgencyPeakData(agency);
    } catch (error) {
      console.error("Error loading peak planning data:", error);
      setShopperPeakData(getDefaultShopperData());
      setGaPeakData(getDefaultGAData());
      setAgencyPeakData(getDefaultAgencyData());
    }
  };

  const loadInitialData = async () => {
    try {
      const [periodsData, forecastData, kpiMetrics] = await Promise.all([
        PeriodConfig.filter({ year: currentYear }, 'period_number'),
        Forecast.filter({ year: currentYear }, '-date', 5000),
        KPIMetric.filter({ year: currentYear }, '-date', 5000)
      ]);
      setPeriods(periodsData);
      setAllYearForecastData(forecastData);
      setAllKpiMetrics(kpiMetrics);
      
      // For peak planning, use current week (not 1 week behind)
      const { period: actualPeriod, week: actualWeek } = getCurrentPeriodAndWeek(periodsData, false);
      
      const peakPlanningData = await PeakPlanning.filter({ 
        year: currentYear, 
        period: actualPeriod, 
        week: actualWeek 
      }, 'date');
      
      // Separate shoppers, GA, and agency data
      const shoppers = peakPlanningData.filter(p => p.type === 'shoppers');
      const ga = peakPlanningData.filter(p => p.type === 'ga');
      const agency = peakPlanningData.filter(p => p.type === 'agency');
      setShopperPeakData(shoppers.length > 0 ? shoppers : getDefaultShopperData());
      setGaPeakData(ga.length > 0 ? ga : getDefaultGAData());
      setAgencyPeakData(agency.length > 0 ? agency : getDefaultAgencyData());
    } catch (error) {
      console.error("Error loading initial data:", error);
      setPeriods([]);
      setAllYearForecastData([]);
      setAllKpiMetrics([]);
      setShopperPeakData(getDefaultShopperData());
      setGaPeakData(getDefaultGAData());
      setAgencyPeakData(getDefaultAgencyData());
    }
  };

  const getDefaultShopperData = () => {
    const weekDates = getWeekDates();
    return weekDates.map(date => ({
      id: `new-shopper-${date}`,
      date,
      type: 'shoppers',
      required: 0,
      scheduled: 0,
      heads: 0,
      iph: 55,
      forecast_items: 0,
      period: currentPeriod,
      week: currentWeek,
      year: currentYear
    }));
  };

  const getDefaultGAData = () => {
    const weekDates = getWeekDates();
    return weekDates.map(date => ({
      id: `new-ga-${date}`,
      date,
      type: 'ga',
      required: 0,
      scheduled: 0,
      am: 0,
      pm: 0,
      period: currentPeriod,
      week: currentWeek,
      year: currentYear
    }));
  };

  const getDefaultAgencyData = () => {
    const weekDates = getWeekDates();
    return weekDates.map(date => ({
      id: `new-agency-${date}`,
      date,
      type: 'agency',
      required: 0,
      scheduled: 0,
      heads: 0,
      period: currentPeriod,
      week: currentWeek,
      year: currentYear
    }));
  };

  const getSummaryForTimeframe = (data, kpiMetrics, periodFilter, weekFilter) => {
    const filteredData = data.filter(d => 
        (periodFilter === null || d.period === periodFilter) && 
        (weekFilter === undefined || d.week === weekFilter)
    );
    
    const forecast = sumBy(filteredData, 'labour_forecast') || 0;
    const actual = sumBy(filteredData, 'labour_actual') || 0;
    const worked_hours = sumBy(filteredData, 'labour_worked_hours') || 0; // Assuming labour_worked_hours exists on daily data
    const chop_chop = sumBy(filteredData, 'labour_chop_chop') || 0;

    // Look for KPI overrides
    const forecastOverride = kpiMetrics.find(k => 
        k.name === 'Labour Forecast' && 
        k.period === periodFilter && 
        (weekFilter === undefined ? k.week === null : k.week === weekFilter) && 
        k.year === currentYear
    );
    const actualOverride = kpiMetrics.find(k => 
        k.name === 'Labour Actual' && 
        k.period === periodFilter && 
        (weekFilter === undefined ? k.week === null : k.week === weekFilter) && 
        k.year === currentYear
    );
    const workedHoursOverride = kpiMetrics.find(k => 
        k.name === 'Labour Worked Hours' && 
        k.period === periodFilter && 
        (weekFilter === undefined ? k.week === null : k.week === weekFilter) && 
        k.year === currentYear
    );
    const chopChopOverride = kpiMetrics.find(k => 
        k.name === 'Labour Chop Chop' && 
        k.period === periodFilter && 
        (weekFilter === undefined ? k.week === null : k.week === weekFilter) && 
        k.year === currentYear
    );

    const finalForecast = forecastOverride ? forecastOverride.value : forecast;
    const finalActual = actualOverride ? actualOverride.value : actual;
    const finalWorkedHours = workedHoursOverride ? workedHoursOverride.value : worked_hours;
    const finalChopChop = chopChopOverride ? chopChopOverride.value : chop_chop; // Use the sum from daily data for baseline if no override

    const variance = finalActual - finalWorkedHours - finalChopChop;
    const variancePercent = finalActual !== 0 ? (variance / finalActual) * 100 : 0;

    return {
        forecast: finalForecast,
        actual: finalActual,
        worked_hours: finalWorkedHours,
        chop_chop: finalChopChop,
        variance,
        variance_percent: variancePercent,
    };
  };

  const calculateAllSummaries = () => {
    // 1. Calculate all weekly summaries for the entire year, applying weekly KPI overrides
    const allWeeklySummariesForYear = [];
    for (let p = 1; p <= 13; p++) {
        for (let w = 1; w <= 4; w++) {
            const summary = getSummaryForTimeframe(allYearForecastData, allKpiMetrics, p, w); // This applies weekly KPI overrides
            allWeeklySummariesForYear.push({ period: p, week: w, ...summary });
        }
    }

    // 2. Set the weekly summaries for the current period's tab
    const currentPeriodWeeklySummaries = allWeeklySummariesForYear.filter(s => s.period === currentPeriod);
    // Remove 'period' key as it's not needed in the weekly table, just 'week'
    setAllWeeksSummaries(currentPeriodWeeklySummaries.map(({ period, ...rest}) => rest)); 

    // 3. Calculate periodic summaries by grouping and summing the weekly ones (baseline), then applying period-level KPI overrides
    const groupedByPeriod = groupBy(allWeeklySummariesForYear, 'period');
    const periodicSummaries = Array.from({ length: 13 }, (_, i) => {
        const periodNum = i + 1;
        const weeksInPeriod = groupedByPeriod[periodNum] || [];
        
        // Sum baseline from weekly (overridden) data for this period
        let forecast = sumBy(weeksInPeriod, 'forecast');
        let actual = sumBy(weeksInPeriod, 'actual');
        let worked_hours = sumBy(weeksInPeriod, 'worked_hours');
        let chop_chop = sumBy(weeksInPeriod, 'chop_chop');
        
        // Now, apply period-level KPI overrides on top of these summed values
        const forecastOverride = allKpiMetrics.find(k => k.name === 'Labour Forecast' && k.period === periodNum && k.week === null && k.year === currentYear);
        const actualOverride = allKpiMetrics.find(k => k.name === 'Labour Actual' && k.period === periodNum && k.week === null && k.year === currentYear);
        const workedHoursOverride = allKpiMetrics.find(k => k.name === 'Labour Worked Hours' && k.period === periodNum && k.week === null && k.year === currentYear);
        const chopChopOverride = allKpiMetrics.find(k => k.name === 'Labour Chop Chop' && k.period === periodNum && k.week === null && k.year === currentYear);

        const finalForecast = forecastOverride ? forecastOverride.value : forecast;
        const finalActual = actualOverride ? actualOverride.value : actual;
        const finalWorkedHours = workedHoursOverride ? workedHoursOverride.value : worked_hours;
        const finalChopChop = chopChopOverride ? chopChopOverride.value : chop_chop;

        const variance = finalActual - finalWorkedHours - finalChopChop;
        const variance_percent = finalActual !== 0 ? (variance / finalActual) * 100 : 0;

        return {
            period: periodNum,
            forecast: finalForecast,
            actual: finalActual,
            worked_hours: finalWorkedHours,
            chop_chop: finalChopChop,
            variance,
            variance_percent,
        };
    });
    setAllPeriodsSummaries(periodicSummaries);
    
    // 4. Calculate grand total for the year from the (overridden) periodic summaries
    const totalForecast = sumBy(periodicSummaries, 'forecast');
    const totalActual = sumBy(periodicSummaries, 'actual');
    const totalWorkedHours = sumBy(periodicSummaries, 'worked_hours');
    const totalChopChop = sumBy(periodicSummaries, 'chop_chop');
    const totalVariance = totalActual - totalWorkedHours - totalChopChop;
    const totalVariancePercent = totalActual !== 0 ? (totalVariance / totalActual) * 100 : 0;
    
    setPeriodicGrandTotal({
      forecast: totalForecast,
      actual: totalActual,
      worked_hours: totalWorkedHours,
      chop_chop: totalChopChop,
      variance: totalVariance,
      variance_percent: totalVariancePercent,
    });
  };

  const getWeekDates = () => {
    const periodConfig = periods.find(p => p.period_number === currentPeriod);
    if (periodConfig && periodConfig.start_date) {
      const periodStart = parseISO(periodConfig.start_date);
      if (!isNaN(periodStart.getTime())) {
        const firstSunday = startOfWeek(periodStart, { weekStartsOn: 0 });
        const weekStartDate = addDays(firstSunday, (currentWeek - 1) * 7);
        return Array.from({ length: 7 }, (_, i) => format(addDays(weekStartDate, i), 'yyyy-MM-dd'));
      }
    }
    // Fallback if period config not found or invalid
    const firstDayOfYear = new Date(currentYear, 0, 1);
    const firstSunday = startOfWeek(firstDayOfYear, { weekStartsOn: 0 });
    const daysToAdd = ((currentPeriod - 1) * 28) + ((currentWeek - 1) * 7);
    const weekStartDate = addDays(firstSunday, daysToAdd);
    return Array.from({ length: 7 }, (_, i) => format(addDays(weekStartDate, i), 'yyyy-MM-dd'));
  };
  
  // Modified filterDailyData to handle all three views
  const filterDailyData = () => {
    if (dailyViewMode === 'weekly') {
      const weekDates = getWeekDates();
      const weekData = weekDates.map(dateStr => {
          const found = allYearForecastData.find(d => d.date === dateStr && d.period === currentPeriod && d.week === currentWeek && d.year === currentYear);
          return found || { 
              id: `new-${dateStr}`, 
              date: dateStr, 
              labour_forecast: 0,
              labour_actual: 0,
              labour_worked_hours: 0,
              labour_chop_chop: 0, 
              items_forecast: 0, 
              items_actual: 0,
              period: currentPeriod, 
              week: currentWeek,
              year: currentYear
          };
      });
      setDailyForecastData(weekData);
    } else if (dailyViewMode === 'periodic') {
        // For 'periodic' view, we use a separate summary table.
        // Clear daily data to avoid rendering the daily table.
        setDailyForecastData([]);
    }
  };

  const handleEditToggle = () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to edit data.");
      return;
    }
    if (isEditing) {
      const hasDailyChanges = Object.keys(editedDailyData).length > 0;
      const hasSummaryChanges = Object.keys(editedLabourSummary).length > 0;
      if (hasDailyChanges || hasSummaryChanges) {
        setShowConfirmDialog(true);
      } else {
        setIsEditing(false);
      }
    } else {
      const initialDailyData = {};
      dailyForecastData.forEach(row => {
        initialDailyData[row.id] = { ...row };
      });
      setEditedDailyData(initialDailyData);

      const initialSummaryData = {};
      allWeeksSummaries.forEach(summary => {
        initialSummaryData[`week-${summary.week}-forecast`] = summary.forecast;
        initialSummaryData[`week-${summary.week}-actual`] = summary.actual;
        initialSummaryData[`week-${summary.week}-worked_hours`] = summary.worked_hours;
        initialSummaryData[`week-${summary.week}-chop_chop`] = summary.chop_chop;
      });
      allPeriodsSummaries.forEach(summary => {
        initialSummaryData[`period-${summary.period}-forecast`] = summary.forecast;
        initialSummaryData[`period-${summary.period}-actual`] = summary.actual;
        initialSummaryData[`period-${summary.period}-worked_hours`] = summary.worked_hours;
        initialSummaryData[`period-${summary.period}-chop_chop`] = summary.chop_chop;
      });
      setEditedLabourSummary(initialSummaryData);

      // Initialize peak planning edited data
      const initialPeakData = {};
      shopperPeakData.forEach(row => {
        initialPeakData[row.id] = { ...row };
      });
      gaPeakData.forEach(row => {
        initialPeakData[row.id] = { ...row };
      });
      agencyPeakData.forEach(row => {
        initialPeakData[row.id] = { ...row };
      });
      setEditedPeakData(initialPeakData);
      
      setIsEditing(true);
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedDailyData({});
    setEditedLabourSummary({});
    setEditedPeakData({});
    setShowConfirmDialog(false);
    filterDailyData(); // Re-filter daily data to revert to original state
    calculateAllSummaries(); // Recalculate summaries to revert to original state
    loadPeakPlanningData(); // Reload peak planning data
  };

  const handleDailyValueChange = (rowId, field, value) => {
    setEditedDailyData(prev => ({
      ...prev,
      [rowId]: {
        ...prev[rowId],
        [field]: parseFloat(value) || 0
      }
    }));
  };

  const handleLabourSummaryChange = (type, id, field, value) => {
    const key = `${type}-${id}-${field}`;
    setEditedLabourSummary(prev => ({
      ...prev,
      [key]: parseFloat(value) || 0
    }));
  };

  const handlePeakDataChange = (rowId, field, value) => {
    setEditedPeakData(prev => ({
      ...prev,
      [rowId]: {
        ...prev[rowId],
        [field]: parseFloat(value) || 0
      }
    }));
  };

  const handleConfirmSave = async () => {
    if (!canEdit) return;
    const promises = [];
    let hasChanges = false;

    // Daily Data Changes
    for (const rowId in editedDailyData) {
        // Find the corresponding original row to compare
        const originalRow = allYearForecastData.find(d => d.id === rowId) || {}; // Use allYearForecastData for original values
        const editedRow = editedDailyData[rowId];
        
        // Check for numeric changes in items_forecast and items_actual
        const currentItemsForecast = parseFloat(originalRow.items_forecast || 0);
        const currentItemsActual = parseFloat(originalRow.items_actual || 0);
        const editedItemsForecast = parseFloat(editedRow.items_forecast || 0);
        const editedItemsActual = parseFloat(editedRow.items_actual || 0);

        // Also check labour fields for potential new entries being filled out
        const currentLabourForecast = parseFloat(originalRow.labour_forecast || 0);
        const currentLabourActual = parseFloat(originalRow.labour_actual || 0);
        const currentLabourWorkedHours = parseFloat(originalRow.labour_worked_hours || 0);
        const currentLabourChopChop = parseFloat(originalRow.labour_chop_chop || 0);
        const editedLabourForecast = parseFloat(editedRow.labour_forecast || 0);
        const editedLabourActual = parseFloat(editedRow.labour_actual || 0);
        const editedLabourWorkedHours = parseFloat(editedRow.labour_worked_hours || 0);
        const editedLabourChopChop = parseFloat(editedRow.labour_chop_chop || 0);


        if (currentItemsForecast !== editedItemsForecast || 
            currentItemsActual !== editedItemsActual ||
            currentLabourForecast !== editedLabourForecast ||
            currentLabourActual !== editedLabourActual ||
            currentLabourWorkedHours !== editedLabourWorkedHours ||
            currentLabourChopChop !== editedLabourChopChop) {
            hasChanges = true;
            // Ensure all necessary fields are present for saving, especially for new records
            const dataToSave = {
                date: editedRow.date,
                labour_forecast: editedLabourForecast,
                labour_actual: editedLabourActual,
                labour_worked_hours: editedLabourWorkedHours,
                labour_chop_chop: editedLabourChopChop,
                items_forecast: editedItemsForecast,
                items_actual: editedItemsActual,
                period: editedRow.period,
                week: editedRow.week,
                year: editedRow.year,
            };

            if (rowId.toString().startsWith('new-')) {
                // If it's a new entry (id starts with 'new-'), create it
                promises.push(Forecast.create(dataToSave));
            } else {
                // Otherwise, update the existing record
                promises.push(Forecast.update(rowId, dataToSave));
            }
        }
    }

    // Labour Summary (KPI Metrics) Changes
    for (const [key, value] of Object.entries(editedLabourSummary)) {
      const [type, id, field] = key.split('-');
      const numId = parseInt(id);

      const kpiNameMap = {
        forecast: 'Labour Forecast',
        actual: 'Labour Actual',
        worked_hours: 'Labour Worked Hours',
        chop_chop: 'Labour Chop Chop'
      };
      const kpiName = kpiNameMap[field];
      if (!kpiName) continue;

      let filter, record;
      let originalValue;

      if (type === 'week') {
        filter = { name: kpiName, period: currentPeriod, week: numId, year: currentYear };
        // Get original value from allWeeksSummaries or allKpiMetrics (override)
        // Note: allWeeksSummaries contains data for currentPeriod only, and doesn't have period key
        const summary = allWeeksSummaries.find(s => s.week === numId); 
        const kpiOverride = allKpiMetrics.find(k => k.name === kpiName && k.period === currentPeriod && k.week === numId && k.year === currentYear);
        originalValue = kpiOverride ? kpiOverride.value : (summary ? summary[field] : 0);

        record = {
          ...filter,
          value,
          date: format(new Date(), 'yyyy-MM-dd'),
          category: 'operations',
          unit: field === 'forecast' || field === 'actual' ? 'currency' : 'number'
        };
      } else if (type === 'period') {
        filter = { name: kpiName, period: numId, week: null, year: currentYear };
        // Get original value from allPeriodsSummaries or allKpiMetrics (override)
        const summary = allPeriodsSummaries.find(s => s.period === numId);
        const kpiOverride = allKpiMetrics.find(k => k.name === kpiName && k.period === numId && k.week === null && k.year === currentYear);
        originalValue = kpiOverride ? kpiOverride.value : (summary ? summary[field] : 0);

        record = {
          ...filter,
          value,
          date: format(new Date(), 'yyyy-MM-dd'),
          category: 'operations',
          unit: field === 'forecast' || field === 'actual' ? 'currency' : 'number'
        };
      }

      // Only add to promises if the value has actually changed
      if (filter && parseFloat(value) !== parseFloat(originalValue)) {
        hasChanges = true;
        promises.push((async () => {
          const existing = await KPIMetric.filter(filter);
          if (existing.length > 0) {
            await KPIMetric.update(existing[0].id, { value });
          } else {
            await KPIMetric.create(record);
          }
        })());
      }
    }

    // Peak Planning Data Changes
    for (const rowId in editedPeakData) {
      const editedRow = editedPeakData[rowId];
      const originalRow = [...shopperPeakData, ...gaPeakData, ...agencyPeakData].find(d => d.id === rowId) || {};
      
      // Check if any field has changed
      const fields = editedRow.type === 'shoppers' 
        ? ['required', 'scheduled', 'heads', 'iph', 'forecast_items']
        : editedRow.type === 'agency'
        ? ['scheduled', 'heads']
        : ['required', 'scheduled', 'am', 'pm'];
      
      const hasRowChanges = fields.some(field => 
        parseFloat(editedRow[field] || 0) !== parseFloat(originalRow[field] || 0)
      );
      
      if (hasRowChanges) {
        hasChanges = true;
        const dataToSave = {
          date: editedRow.date,
          type: editedRow.type,
          period: editedRow.period,
          week: editedRow.week,
          year: editedRow.year,
          required: parseFloat(editedRow.required || 0),
          scheduled: parseFloat(editedRow.scheduled || 0),
          ...(editedRow.type === 'shoppers' 
            ? { 
                heads: parseFloat(editedRow.heads || 0), 
                iph: parseFloat(editedRow.iph || 0),
                forecast_items: parseFloat(editedRow.forecast_items || 0)
              }
            : editedRow.type === 'agency'
            ? { heads: parseFloat(editedRow.heads || 0) }
            : { 
                am: parseFloat(editedRow.am || 0),
                pm: parseFloat(editedRow.pm || 0)
              }
          )
        };

        if (rowId.toString().startsWith('new-')) {
          promises.push(PeakPlanning.create(dataToSave));
        } else {
          promises.push(PeakPlanning.update(rowId, dataToSave));
        }
      }
    }
    
    if (!hasChanges) {
        toast.info("No changes to save.");
        setShowConfirmDialog(false);
        setIsEditing(false);
        return;
    }
    
    setShowConfirmDialog(false);

    toast.promise(Promise.all(promises), {
        loading: 'Saving all changes...',
        success: 'Data saved successfully!',
        error: (err) => {
            console.error("Save error:", err);
            return `Failed to save data: ${err.message || 'Unknown error'}`;
        }
    });

    try {
        await Promise.all(promises);
        await loadInitialData(); // Reload data after successful save
    } catch (error) {
        console.error("Error during save process:", error);
    } finally {
        setIsEditing(false);
        setEditedDailyData({});
        setEditedLabourSummary({});
        setEditedPeakData({});
    }
  };

  const requestSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
    setSortConfig({ key, direction });
  };
  
  const sortedData = useMemo(() => {
    let sortableItems = [...dailyForecastData];
    
    // Always sort by date first to maintain Sunday-Saturday order
    sortableItems.sort((a, b) => {
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      return dateA - dateB;
    });
    
    // Then apply user-requested sorting if any
    if (sortConfig.key !== null && sortConfig.key !== 'date') {
      sortableItems.sort((a, b) => {
        const aValue = typeof a[sortConfig.key] === 'number' ? a[sortConfig.key] : String(a[sortConfig.key]);
        const bValue = typeof b[sortConfig.key] === 'number' ? b[sortConfig.key] : String(b[sortConfig.key]);

        if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    } else if (sortConfig.key === 'date') {
      // If explicitly sorting by date, respect the direction
      if (sortConfig.direction === 'desc') {
        sortableItems.reverse();
      }
    }
    
    return sortableItems;
  }, [dailyForecastData, sortConfig]);

  const dailyTotals = useMemo(() => {
    // When in editing mode, sum from editedDailyData for current view, otherwise from dailyForecastData
    const dataToSum = isEditing 
      ? dailyForecastData.map(row => editedDailyData[row.id] || row)
      : dailyForecastData;

    const totalForecast = sumBy(dataToSum, 'items_forecast');
    const totalActual = sumBy(dataToSum, 'items_actual');
    const totalVariance = totalActual - totalForecast;
    return { totalForecast, totalActual, totalVariance };
  }, [dailyForecastData, editedDailyData, isEditing]);

  const weeklyGrandTotal = useMemo(() => {
    const dataSet = isEditing 
      ? allWeeksSummaries.map(s => ({
          forecast: editedLabourSummary[`week-${s.week}-forecast`] ?? s.forecast,
          actual: editedLabourSummary[`week-${s.week}-actual`] ?? s.actual,
          worked_hours: editedLabourSummary[`week-${s.week}-worked_hours`] ?? s.worked_hours,
          chop_chop: editedLabourSummary[`week-${s.week}-chop_chop`] ?? s.chop_chop,
        }))
      : allWeeksSummaries;

    if (!dataSet || dataSet.length === 0) {
      return { forecast: 0, actual: 0, worked_hours: 0, chop_chop: 0, variance: 0, variance_percent: 0 };
    }
    const forecast = sumBy(dataSet, 'forecast');
    const actual = sumBy(dataSet, 'actual');
    const worked_hours = sumBy(dataSet, 'worked_hours');
    const chop_chop = sumBy(dataSet, 'chop_chop');
    const variance = actual - worked_hours - chop_chop;
    const variance_percent = actual !== 0 ? (variance / actual) * 100 : 0;
    return { forecast, actual, worked_hours, chop_chop, variance, variance_percent };
  }, [allWeeksSummaries, editedLabourSummary, isEditing]);

  const periodicDailyItemsSummary = useMemo(() => {
    const groupedByPeriod = groupBy(allYearForecastData, 'period');
    const summary = Array.from({ length: 13 }, (_, i) => {
        const periodNum = i + 1;
        const periodItems = groupedByPeriod[periodNum] || [];
        const forecast = sumBy(periodItems, 'items_forecast');
        const actual = sumBy(periodItems, 'items_actual');
        const variance = actual - forecast;
        return {
            period: periodNum,
            items_forecast: forecast,
            items_actual: actual,
            variance: variance,
        };
    });
    return summary;
  }, [allYearForecastData]);

  const periodicDailyItemsGrandTotal = useMemo(() => {
    const totalForecast = sumBy(periodicDailyItemsSummary, 'items_forecast');
    const totalActual = sumBy(periodicDailyItemsSummary, 'items_actual');
    const totalVariance = totalActual - totalForecast;
    return { totalForecast, totalActual, totalVariance };
  }, [periodicDailyItemsSummary]);

  const peakPlanningTotals = useMemo(() => {
    return calculatePeakTotals(shopperPeakData, agencyPeakData, gaPeakData, isEditing, editedPeakData);
  }, [shopperPeakData, agencyPeakData, gaPeakData, isEditing, editedPeakData]);

  // New summaryData useMemo for KPI cards
  const summaryData = useMemo(() => {
    const labourVariance = periodicGrandTotal.variance;
    const labourVariancePercent = periodicGrandTotal.variance_percent;
    const itemsVariance = periodicDailyItemsGrandTotal.totalVariance;
    const itemsForecast = periodicDailyItemsGrandTotal.totalForecast;
    const itemsActual = periodicDailyItemsGrandTotal.totalActual;

    return {
      labourVariance,
      labourVariancePercent,
      itemsVariance,
      itemsForecast,
      itemsActual,
    };
  }, [periodicGrandTotal, periodicDailyItemsGrandTotal]);

  return (
    <div className="p-6 space-y-6">
      <style>{`
        @media print {
          @page {
            size: A4 landscape;
            margin: 8mm;
          }
          body.printing-peak * {
            visibility: hidden !important;
          }
          body.printing-peak .peak-planning-section,
          body.printing-peak .peak-planning-section * {
            visibility: visible !important;
          }
          body.printing-peak {
            background: white !important;
          }
          body.printing-peak .peak-planning-section {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            box-shadow: none !important;
            border: none !important;
            border-radius: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
          }
          body.printing-peak .no-print {
            visibility: hidden !important;
            display: none !important;
          }
          body.printing-peak [role="tablist"] {
            display: none !important;
          }
          body.printing-peak [role="tabpanel"] {
            display: block !important;
            margin-bottom: 8px !important;
          }
          body.printing-peak table {
            font-size: 5.5px !important;
            width: 100% !important;
            border-collapse: collapse !important;
            margin-bottom: 4px !important;
            table-layout: fixed !important;
          }
          body.printing-peak th,
          body.printing-peak td {
            padding: 3px 2px !important;
            border: 0.5px solid #999 !important;
            line-height: 1.2 !important;
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
          }
          body.printing-peak th {
            background: #f0f0f0 !important;
            font-weight: 600 !important;
          }
          body.printing-peak thead {
            display: table-header-group;
          }
          body.printing-peak tfoot {
            display: table-footer-group;
            background: #f8f8f8 !important;
          }
          body.printing-peak tr {
            page-break-inside: avoid;
            page-break-after: auto;
          }
          body.printing-peak h2,
          body.printing-peak h3 {
            font-size: 11px !important;
            margin: 4px 0 2px 0 !important;
            font-weight: bold !important;
          }
          body.printing-peak .CardHeader h3::before {
            content: "PEAK PLANNING - ";
            font-weight: bold;
          }
          body.printing-peak .CardContent > div > div[role="tabpanel"]:nth-of-type(1) h3::after {
            content: " Shoppers";
          }
          body.printing-peak .CardContent > div > div[role="tabpanel"]:nth-of-type(2) h3::after {
            content: " GA";
          }
          body.printing-peak .CardContent > div > div[role="tabpanel"]:nth-of-type(3) h3::after {
            content: " Agency";
          }
        }
      `}</style>
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-gray-900">Forecast & Labour Planning</h1>
        </div>
        <div className="flex items-center gap-2">
          <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))}>
              <SelectTrigger className="w-full sm:w-32 hover-glass"><SelectValue /></SelectTrigger>
              <SelectContent>{Array.from({ length: 3 }, (_, i) => new Date().getFullYear() + i - 1).map(y => (<SelectItem key={y} value={y.toString()}>{y}</SelectItem>))}</SelectContent>
            </Select>
          {isEditing && (
            <Button variant="outline" size="sm" onClick={handleCancelEdit} className="border-slate-200 rounded-lg px-4 py-2">
              <X className="w-4 h-4 mr-2"/>
              Cancel
            </Button>
          )}
          {canEdit && (
            <Button size="sm" onClick={handleEditToggle} className="btn-modern">
              {isEditing ? <><Save className="w-4 h-4 mr-2"/>Save Changes</> : <><Edit className="w-4 h-4 mr-2"/>Edit Mode</>}
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={() => window.print()} className="border-slate-200 rounded-lg px-4 py-2">
            <FileDown className="w-4 h-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>

      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4 shadow-xl">
            <h3 className="text-lg font-semibold mb-4">Confirm Changes</h3>
            <p className="text-gray-600 mb-6">Are you sure you want to save your changes?</p>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={handleCancelEdit}>Cancel</Button>
              <Button onClick={handleConfirmSave} className="bg-blue-600 hover:bg-blue-700 text-white">Save Changes</Button>
            </div>
          </div>
        </div>
      )}

      <Card className="glass-card no-print">
        <CardHeader className="pb-6">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-6">
              <div className="space-y-2">
                  <CardTitle className="text-xl font-semibold text-slate-800">
                      Daily Items Data
                  </CardTitle>
              </div>
              <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                  <Tabs value={dailyViewMode} onValueChange={setDailyViewMode} className="w-full sm:w-auto">
                      <TabsList className="grid w-full grid-cols-2">
                          <TabsTrigger value="weekly">Weekly</TabsTrigger>
                          <TabsTrigger value="periodic">Periodic</TabsTrigger>
                      </TabsList>
                  </Tabs>
                  {dailyViewMode === 'weekly' && (
                    <>
                      <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))}>
                          <SelectTrigger className="w-full sm:w-32 hover-glass"><SelectValue /></SelectTrigger>
                          <SelectContent>{Array.from({ length: 13 }, (_, i) => (<SelectItem key={i + 1} value={(i + 1).toString()}>Period {i + 1}</SelectItem>))}</SelectContent>
                      </Select>
                      <Select value={currentWeek.toString()} onValueChange={(val) => setCurrentWeek(parseInt(val))}>
                          <SelectTrigger className="w-full sm:w-32 hover-glass"><SelectValue /></SelectTrigger>
                          <SelectContent>{Array.from({ length: 4 }, (_, i) => (<SelectItem key={i + 1} value={(i + 1).toString()}>Week {i + 1}</SelectItem>))}</SelectContent>
                      </Select>
                    </>
                  )}
              </div>
          </div>
        </CardHeader>
        <CardContent>
          {dailyViewMode === 'periodic' ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Period</TableHead>
                  <TableHead>Forecast</TableHead>
                  <TableHead>Actual</TableHead>
                  <TableHead>Variance</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {periodicDailyItemsSummary.map((row) => (
                   <TableRow key={row.period}>
                      <TableCell className="font-medium">Period {row.period}</TableCell>
                      <TableCell>{row.items_forecast.toLocaleString()}</TableCell>
                      <TableCell>{row.items_actual.toLocaleString()}</TableCell>
                      <TableCell className={row.variance >= 0 ? 'text-green-600' : 'text-red-600'}>
                        {row.variance > 0 ? `+${row.variance.toLocaleString()}` : row.variance.toLocaleString()}
                      </TableCell>
                   </TableRow>
                ))}
              </TableBody>
              <TableFooter>
                <TableRow>
                  <TableCell className="font-bold text-right">Yearly Total</TableCell>
                  <TableCell className="font-bold">{periodicDailyItemsGrandTotal.totalForecast.toLocaleString()}</TableCell>
                  <TableCell className="font-bold">{periodicDailyItemsGrandTotal.totalActual.toLocaleString()}</TableCell>
                  <TableCell className={`font-bold ${periodicDailyItemsGrandTotal.totalVariance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {periodicDailyItemsGrandTotal.totalVariance > 0 ? `+${periodicDailyItemsGrandTotal.totalVariance.toLocaleString()}` : periodicDailyItemsGrandTotal.totalVariance.toLocaleString()}
                  </TableCell>
                </TableRow>
              </TableFooter>
            </Table>
          ) : (
            <Table>
              <TableHeader>
                  <TableRow>
                      <TableHead>Day</TableHead>
                      <SortableHeader column="date" sortConfig={sortConfig} onSort={requestSort}>Date</SortableHeader>
                      <SortableHeader column="items_forecast" sortConfig={sortConfig} onSort={requestSort}>Forecast</SortableHeader>
                      <SortableHeader column="items_actual" sortConfig={sortConfig} onSort={requestSort}>Actual</SortableHeader>
                      <TableHead>Variance</TableHead>
                  </TableRow>
              </TableHeader>
              <TableBody>
                {sortedData.map((row) => {
                  const isRowEditing = isEditing && editedDailyData[row.id];
                  const forecastValue = isRowEditing ? editedDailyData[row.id].items_forecast : row.items_forecast;
                  const actualValue = isRowEditing ? editedDailyData[row.id].items_actual : row.items_actual;
                  const variance = (actualValue || 0) - (forecastValue || 0);

                  return (
                    <TableRow key={row.id}>
                      <TableCell className="font-medium">{format(parseISO(row.date), 'EEEE')}</TableCell>
                      <TableCell>{format(parseISO(row.date), 'dd/MM/yyyy')}</TableCell>
                      <TableCell>
                        {isEditing && canEdit ? 
                          <Input type="number" value={forecastValue} onChange={(e) => handleDailyValueChange(row.id, 'items_forecast', e.target.value)} className="w-24" /> : 
                          forecastValue.toLocaleString()
                        }
                      </TableCell>
                      <TableCell>
                        {isEditing && canEdit ? 
                          <Input type="number" value={actualValue} onChange={(e) => handleDailyValueChange(row.id, 'items_actual', e.target.value)} className="w-24" /> : 
                          actualValue.toLocaleString()
                        }
                      </TableCell>
                      <TableCell className={variance >= 0 ? 'text-green-600' : 'text-red-600'}>{variance > 0 ? `+${variance.toLocaleString()}` : variance.toLocaleString()}</TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
              <TableFooter>
                  <TableRow>
                      <TableCell 
                        colSpan={2} 
                        className="font-bold text-right"
                      >
                        Weekly Total
                      </TableCell>
                      <TableCell className="font-bold">{dailyTotals.totalForecast.toLocaleString()}</TableCell>
                      <TableCell className="font-bold">{dailyTotals.totalActual.toLocaleString()}</TableCell>
                      <TableCell className={`font-bold ${dailyTotals.totalVariance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {dailyTotals.totalVariance > 0 ? `+${dailyTotals.totalVariance.toLocaleString()}` : dailyTotals.totalVariance.toLocaleString()}
                      </TableCell>
                  </TableRow>
              </TableFooter>
            </Table>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <KPICard
          title="Labour Variance (Yearly)"
          value={summaryData.labourVariance.toLocaleString()}
          description={`${summaryData.labourVariancePercent > 0 ? '+' : ''}${summaryData.labourVariancePercent.toFixed(1)}% vs Actual`}
          icon={summaryData.labourVariance >= 0 ? TrendingUp : TrendingDown}
          valueClass={summaryData.labourVariance >= 0 ? 'text-green-600' : 'text-red-600'}
        />
        <KPICard
          title="Items Variance (Yearly)"
          value={summaryData.itemsVariance.toLocaleString()}
          description={`Actual: ${summaryData.itemsActual.toLocaleString()} vs Forecast: ${summaryData.itemsForecast.toLocaleString()}`}
          icon={summaryData.itemsVariance >= 0 ? TrendingUp : TrendingDown}
          valueClass={summaryData.itemsVariance >= 0 ? 'text-green-600' : 'text-red-600'}
        />
        <KPICard
          title="Daily View"
          value={dailyViewMode === 'weekly' ? `P${currentPeriod} W${currentWeek}` : 'Periodic'}
          description={`Showing ${dailyViewMode} view for ${currentYear}`}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-1 gap-4 mt-4">
        <Card className="chart-container">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Labour Summary</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="weekly" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="weekly">Weekly Summary (P{currentPeriod})</TabsTrigger>
                <TabsTrigger value="periodic">Periodic Summary ({currentYear})</TabsTrigger>
              </TabsList>
              <TabsContent value="weekly">
                <Table className="mt-4">
                  <TableHeader>
                    <TableRow>
                      <TableHead>Week</TableHead>
                      <TableHead>Forecast</TableHead>
                      <TableHead>Actual</TableHead>
                      <TableHead>F vs A</TableHead>
                      <TableHead>Worked Hours</TableHead>
                      <TableHead>Chop Chop</TableHead>
                      <TableHead>Variance</TableHead>
                      <TableHead>Variance %</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {allWeeksSummaries.map((summary) => {
                      // When editing, use the value from editedLabourSummary if it exists, otherwise use current summary value
                      const fVal = isEditing ? (editedLabourSummary[`week-${summary.week}-forecast`] ?? summary.forecast) : summary.forecast;
                      const aVal = isEditing ? (editedLabourSummary[`week-${summary.week}-actual`] ?? summary.actual) : summary.actual;
                      const wVal = isEditing ? (editedLabourSummary[`week-${summary.week}-worked_hours`] ?? summary.worked_hours) : summary.worked_hours;
                      const cVal = isEditing ? (editedLabourSummary[`week-${summary.week}-chop_chop`] ?? summary.chop_chop) : summary.chop_chop;
                      const variance = aVal - wVal - cVal;
                      const variancePercent = aVal !== 0 ? (variance / aVal) * 100 : 0;
                      const forecastVsActualVariance = aVal - fVal;
                      
                      return (
                        <TableRow key={summary.week}>
                          <TableCell className="font-medium">Week {summary.week}</TableCell>
                          <TableCell>{isEditing && canEdit ? <Input type="number" value={fVal} onChange={e => handleLabourSummaryChange('week', summary.week, 'forecast', e.target.value)} className="w-24" /> : fVal.toLocaleString()}</TableCell>
                          <TableCell>{isEditing && canEdit ? <Input type="number" value={aVal} onChange={e => handleLabourSummaryChange('week', summary.week, 'actual', e.target.value)} className="w-24" /> : aVal.toLocaleString()}</TableCell>
                          <TableCell className={forecastVsActualVariance >= 0 ? 'text-green-600' : 'text-red-600'}>
                            {forecastVsActualVariance > 0 ? `+${forecastVsActualVariance.toLocaleString()}` : forecastVsActualVariance.toLocaleString()}
                          </TableCell>
                          <TableCell>{isEditing && canEdit ? <Input type="number" value={wVal} onChange={e => handleLabourSummaryChange('week', summary.week, 'worked_hours', e.target.value)} className="w-24" /> : wVal.toLocaleString()}</TableCell>
                          <TableCell>{isEditing && canEdit ? <Input type="number" value={cVal} onChange={e => handleLabourSummaryChange('week', summary.week, 'chop_chop', e.target.value)} className="w-24" /> : cVal.toLocaleString()}</TableCell>
                          <TableCell className={variance >= 0 ? 'text-green-600' : 'text-red-600'}>{variance > 0 ? `+${variance.toLocaleString()}` : variance.toLocaleString()}</TableCell>
                          <TableCell className={variancePercent >= 0 ? 'text-green-600' : 'text-red-600'}>{variancePercent > 0 ? '+' : ''}{variancePercent.toFixed(1)}%</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                  <TableFooter>
                    <TableRow>
                      <TableCell className="font-bold">Period Total</TableCell>
                      <TableCell className="font-bold">{weeklyGrandTotal.forecast.toLocaleString()}</TableCell>
                      <TableCell className="font-bold">{weeklyGrandTotal.actual.toLocaleString()}</TableCell>
                      <TableCell className={`font-bold ${(weeklyGrandTotal.actual - weeklyGrandTotal.forecast) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {(weeklyGrandTotal.actual - weeklyGrandTotal.forecast) > 0 ? '+' : ''}{(weeklyGrandTotal.actual - weeklyGrandTotal.forecast).toLocaleString()}
                      </TableCell>
                      <TableCell className="font-bold">{weeklyGrandTotal.worked_hours.toLocaleString()}</TableCell>
                      <TableCell className="font-bold">{weeklyGrandTotal.chop_chop.toLocaleString()}</TableCell>
                      <TableCell className={`font-bold ${weeklyGrandTotal.variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>{weeklyGrandTotal.variance > 0 ? '+' : ''}{weeklyGrandTotal.variance.toLocaleString()}</TableCell>
                      <TableCell className={`font-bold ${weeklyGrandTotal.variance_percent >= 0 ? 'text-green-600' : 'text-red-600'}`}>{weeklyGrandTotal.variance_percent > 0 ? '+' : ''}{weeklyGrandTotal.variance_percent.toFixed(1)}%</TableCell>
                    </TableRow>
                  </TableFooter>
                </Table>
              </TabsContent>
              <TabsContent value="periodic">
                <Table className="mt-4">
                  <TableHeader>
                    <TableRow>
                      <TableHead>Period</TableHead>
                      <TableHead>Forecast</TableHead>
                      <TableHead>Actual</TableHead>
                      <TableHead>F vs A</TableHead>
                      <TableHead>Worked Hours</TableHead>
                      <TableHead>Chop Chop</TableHead>
                      <TableHead>Variance</TableHead>
                      <TableHead>Variance %</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {allPeriodsSummaries.map((summary) => {
                      // When editing, use the value from editedLabourSummary if it exists, otherwise use current summary value
                      const fVal = isEditing ? (editedLabourSummary[`period-${summary.period}-forecast`] ?? summary.forecast) : summary.forecast;
                      const aVal = isEditing ? (editedLabourSummary[`period-${summary.period}-actual`] ?? summary.actual) : summary.actual;
                      const wVal = isEditing ? (editedLabourSummary[`period-${summary.period}-worked_hours`] ?? summary.worked_hours) : summary.worked_hours;
                      const cVal = isEditing ? (editedLabourSummary[`period-${summary.period}-chop_chop`] ?? summary.chop_chop) : summary.chop_chop;
                      const variance = aVal - wVal - cVal;
                      const variancePercent = aVal !== 0 ? (variance / aVal) * 100 : 0;
                      const forecastVsActualVariance = aVal - fVal;
                      
                      return(
                        <TableRow key={summary.period}>
                          <TableCell className="font-medium">Period {summary.period}</TableCell>
                          <TableCell>{isEditing && canEdit ? <Input type="number" value={fVal} onChange={e => handleLabourSummaryChange('period', summary.period, 'forecast', e.target.value)} className="w-24" /> : fVal.toLocaleString()}</TableCell>
                          <TableCell>{isEditing && canEdit ? <Input type="number" value={aVal} onChange={e => handleLabourSummaryChange('period', summary.period, 'actual', e.target.value)} className="w-24" /> : aVal.toLocaleString()}</TableCell>
                          <TableCell className={forecastVsActualVariance >= 0 ? 'text-green-600' : 'text-red-600'}>
                            {forecastVsActualVariance > 0 ? `+${forecastVsActualVariance.toLocaleString()}` : forecastVsActualVariance.toLocaleString()}
                          </TableCell>
                          <TableCell>{isEditing && canEdit ? <Input type="number" value={wVal} onChange={e => handleLabourSummaryChange('period', summary.period, 'worked_hours', e.target.value)} className="w-24" /> : wVal.toLocaleString()}</TableCell>
                          <TableCell>{isEditing && canEdit ? <Input type="number" value={cVal} onChange={e => handleLabourSummaryChange('period', summary.period, 'chop_chop', e.target.value)} className="w-24" /> : cVal.toLocaleString()}</TableCell>
                          <TableCell className={variance >= 0 ? 'text-green-600' : 'text-red-600'}>{variance > 0 ? `+${variance.toLocaleString()}` : variance.toLocaleString()}</TableCell>
                          <TableCell className={variancePercent >= 0 ? 'text-green-600' : 'text-red-600'}>{variancePercent > 0 ? '+' : ''}{variancePercent.toFixed(1)}%</TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                  <TableFooter>
                    <TableRow>
                      <TableCell className="font-bold">Yearly Total</TableCell>
                      <TableCell className="font-bold">{periodicGrandTotal.forecast.toLocaleString()}</TableCell>
                      <TableCell className="font-bold">{periodicGrandTotal.actual.toLocaleString()}</TableCell>
                      <TableCell className={`font-bold ${(periodicGrandTotal.actual - periodicGrandTotal.forecast) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {(periodicGrandTotal.actual - periodicGrandTotal.forecast) > 0 ? '+' : ''}{(periodicGrandTotal.actual - periodicGrandTotal.forecast).toLocaleString()}
                      </TableCell>
                      <TableCell className="font-bold">{periodicGrandTotal.worked_hours.toLocaleString()}</TableCell>
                      <TableCell className="font-bold">{periodicGrandTotal.chop_chop.toLocaleString()}</TableCell>
                      <TableCell className={`font-bold ${periodicGrandTotal.variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {periodicGrandTotal.variance > 0 ? `+${periodicGrandTotal.variance.toLocaleString()}` : periodicGrandTotal.variance.toLocaleString()}
                      </TableCell>
                      <TableCell className={`font-bold ${periodicGrandTotal.variance_percent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {periodicGrandTotal.variance_percent > 0 ? '+' : ''}{periodicGrandTotal.variance_percent.toFixed(1)}%
                      </TableCell>
                    </TableRow>
                  </TableFooter>
                </Table>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      <Card className="chart-container peak-planning-section">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Peak Planning</CardTitle>
            </div>
            <div className="flex items-center gap-2">
              <Input
                type="date"
                value={peakPlanningStartDate}
                onChange={(e) => setPeakPlanningStartDate(e.target.value)}
                className="w-40 no-print"
                placeholder="Start Date"
              />
              <span className="text-sm text-slate-600 no-print">to</span>
              <Input
                type="date"
                value={peakPlanningEndDate}
                onChange={(e) => setPeakPlanningEndDate(e.target.value)}
                className="w-40 no-print"
                placeholder="End Date"
              />
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => {
                  document.body.classList.add('printing-peak');
                  window.print();
                  setTimeout(() => document.body.classList.remove('printing-peak'), 100);
                }} 
                className="border-slate-200 rounded-lg px-4 py-2 no-print"
              >
                <FileDown className="w-4 h-4 mr-2" />
                Export PDF
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="shoppers" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="shoppers">Shoppers</TabsTrigger>
              <TabsTrigger value="ga">GA</TabsTrigger>
              <TabsTrigger value="agency">Agency</TabsTrigger>
            </TabsList>
            
            <TabsContent value="shoppers">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em', visibility: 'hidden' }}>(RD40)</span>
                        <span>Date</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em', visibility: 'hidden' }}>(RD40)</span>
                        <span>Required</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em', visibility: 'hidden' }}>(RD40)</span>
                        <span>Scheduled</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em', visibility: 'hidden' }}>(RD40)</span>
                        <span>Variance</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em', visibility: 'hidden' }}>(RD40)</span>
                        <span>Heads</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em', visibility: 'hidden' }}>(RD40)</span>
                        <span>IPH</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em' }}>(RD40)</span>
                        <span>Forecast</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em' }}>(IPH x Required)</span>
                        <span>Actual</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em', visibility: 'hidden' }}>(RD40)</span>
                        <span>Variance</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em' }}>(Confirmed)</span>
                        <span>Agency</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-center">
                      <div className="flex flex-col items-center">
                        <span style={{ fontSize: '0.6em', visibility: 'hidden' }}>(RD40)</span>
                        <span>Total Variance</span>
                      </div>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shopperPeakData.map((row, index) => {
                    const isRowEditing = isEditing && editedPeakData[row.id];
                    const requiredVal = isRowEditing ? (editedPeakData[row.id].required ?? 0) : (row.required ?? 0);
                    const scheduledVal = isRowEditing ? (editedPeakData[row.id].scheduled ?? 0) : (row.scheduled ?? 0);
                    const headsVal = isRowEditing ? (editedPeakData[row.id].heads ?? 0) : (row.heads ?? 0);
                    const iphVal = isRowEditing ? (editedPeakData[row.id].iph ?? 0) : (row.iph ?? 0);
                    const variance = scheduledVal - requiredVal;
                    const items = scheduledVal * iphVal;
                    
                    const agencyRow = agencyPeakData[index];
                    const agencyHours = agencyRow ? (agencyRow.scheduled ?? 0) : 0;
                    const totalVariance = (scheduledVal + agencyHours) - requiredVal;
                    
                    const dateObj = parseISO(row.date);
                    const dayOfMonth = dateObj.getDate();
                    const month = dateObj.getMonth();
                    const isChristmas = month === 11 && dayOfMonth === 25;
                    const isBoxingDay = month === 11 && dayOfMonth === 26;
                    
                    if (isChristmas || isBoxingDay) {
                      return (
                        <TableRow key={row.id} className={getWeekColorClass(row.date)}>
                          <TableCell colSpan={11} className="font-medium text-center">
                            {isChristmas ? '🎄 Christmas Day 🎄' : '🎁 Boxing Day 🎁'}
                          </TableCell>
                        </TableRow>
                      );
                    }
                    
                    const forecastItemsVal = isRowEditing ? (editedPeakData[row.id].forecast_items ?? 0) : (row.forecast_items ?? 0);
                    const itemsVariance = items - forecastItemsVal;
                    
                    return (
                      <TableRow key={row.id} className={getWeekColorClass(row.date)}>
                        <TableCell className="font-medium text-center">{format(dateObj, 'EEE dd MMM')}</TableCell>
                        <TableCell className="text-center">
                          {isEditing && canEdit ? 
                            <Input type="number" value={requiredVal} onChange={(e) => handlePeakDataChange(row.id, 'required', e.target.value)} className="w-20 text-center" /> : 
                            requiredVal
                          }
                        </TableCell>
                        <TableCell className="text-center">
                          {isEditing && canEdit ? 
                            <Input type="number" value={scheduledVal} onChange={(e) => handlePeakDataChange(row.id, 'scheduled', e.target.value)} className="w-20 text-center" /> : 
                            scheduledVal
                          }
                        </TableCell>
                        <TableCell className={`text-center ${variance >= 0 ? 'text-green-600 font-medium' : 'text-red-600 font-medium'}`}>
                          {variance >= 0 ? '+' : ''}{variance}
                        </TableCell>
                        <TableCell className="text-center">
                          {isEditing && canEdit ? 
                            <Input type="number" value={headsVal} onChange={(e) => handlePeakDataChange(row.id, 'heads', e.target.value)} className="w-20 text-center" /> : 
                            headsVal
                          }
                        </TableCell>
                        <TableCell className="text-center">
                          {isEditing && canEdit ? 
                            <Input type="number" value={iphVal} onChange={(e) => handlePeakDataChange(row.id, 'iph', e.target.value)} className="w-20 text-center" /> : 
                            iphVal
                          }
                        </TableCell>
                        <TableCell className="text-center text-blue-600 font-medium">
                          {isEditing && canEdit ? 
                            <Input type="number" value={forecastItemsVal} onChange={(e) => handlePeakDataChange(row.id, 'forecast_items', e.target.value)} className="w-24 text-center text-blue-600" /> : 
                            Math.round(forecastItemsVal).toLocaleString()
                          }
                        </TableCell>
                        <TableCell className="font-medium text-center">{Math.round(items).toLocaleString()}</TableCell>
                        <TableCell className={`text-center font-medium ${itemsVariance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {itemsVariance >= 0 ? '+' : ''}{Math.round(itemsVariance).toLocaleString()}
                        </TableCell>
                        <TableCell className="text-center">
                          {agencyHours > 0 ? (
                            <span className="inline-block px-2 py-1 bg-blue-500 text-white font-medium rounded">{agencyHours}</span>
                          ) : (
                            agencyHours
                          )}
                        </TableCell>
                        <TableCell className={`text-center font-medium ${totalVariance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {totalVariance >= 0 ? '+' : ''}{totalVariance}
                        </TableCell>
                      </TableRow>
                    );
                    })}
                    </TableBody>
                    <TableFooter>
                    <TableRow>
                    <TableCell className="font-bold text-center">Total</TableCell>
                    <TableCell className="font-bold text-center">{peakPlanningTotals.shopper.required}</TableCell>
                    <TableCell className="font-bold text-center">{peakPlanningTotals.shopper.scheduled}</TableCell>
                    <TableCell className={`font-bold text-center ${peakPlanningTotals.shopper.variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {peakPlanningTotals.shopper.variance >= 0 ? '+' : ''}{peakPlanningTotals.shopper.variance}
                    </TableCell>
                    <TableCell className="font-bold text-center">{peakPlanningTotals.shopper.heads}</TableCell>
                    <TableCell className="font-bold text-center">{Math.round(peakPlanningTotals.shopper.avgIPH)}</TableCell>
                    <TableCell className="font-bold text-center">{Math.round(peakPlanningTotals.shopper.required * peakPlanningTotals.shopper.avgIPH).toLocaleString()}</TableCell>
                    <TableCell className="font-bold text-center">{Math.round(peakPlanningTotals.shopper.items).toLocaleString()}</TableCell>
                    <TableCell className={`font-bold text-center ${(peakPlanningTotals.shopper.items - (peakPlanningTotals.shopper.required * peakPlanningTotals.shopper.avgIPH)) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {(peakPlanningTotals.shopper.items - (peakPlanningTotals.shopper.required * peakPlanningTotals.shopper.avgIPH)) >= 0 ? '+' : ''}{Math.round(peakPlanningTotals.shopper.items - (peakPlanningTotals.shopper.required * peakPlanningTotals.shopper.avgIPH)).toLocaleString()}
                    </TableCell>
                    <TableCell className="font-bold text-center">
                    {peakPlanningTotals.shopper.agencyHours > 0 ? (
                      <span className="inline-block px-2 py-1 bg-blue-500 text-white font-medium rounded">{peakPlanningTotals.shopper.agencyHours}</span>
                    ) : (
                      peakPlanningTotals.shopper.agencyHours
                    )}
                    </TableCell>
                    <TableCell className={`font-bold text-center ${peakPlanningTotals.shopper.totalVariance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {peakPlanningTotals.shopper.totalVariance >= 0 ? '+' : ''}{peakPlanningTotals.shopper.totalVariance}
                    </TableCell>
                    </TableRow>
                    </TableFooter>
                    </Table>
                    </TabsContent>

                    <TabsContent value="ga">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-center">Date</TableHead>
                    <TableHead className="text-center">Required</TableHead>
                    <TableHead className="text-center">Scheduled</TableHead>
                    <TableHead className="text-center">Variance</TableHead>
                    <TableHead className="text-center">AM</TableHead>
                    <TableHead className="text-center">PM</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {gaPeakData.map((row) => {
                    const isRowEditing = isEditing && editedPeakData[row.id];
                    const requiredVal = isRowEditing ? (editedPeakData[row.id].required ?? 0) : (row.required ?? 0);
                    const scheduledVal = isRowEditing ? (editedPeakData[row.id].scheduled ?? 0) : (row.scheduled ?? 0);
                    const variance = scheduledVal - requiredVal;
                    const amVal = isRowEditing ? (editedPeakData[row.id].am ?? 0) : (row.am ?? 0);
                    const pmVal = isRowEditing ? (editedPeakData[row.id].pm ?? 0) : (row.pm ?? 0);

                    const dateObj = parseISO(row.date);
                    const dayOfMonth = dateObj.getDate();
                    const month = dateObj.getMonth();
                    const isChristmas = month === 11 && dayOfMonth === 25;
                    const isBoxingDay = month === 11 && dayOfMonth === 26;
                    
                    if (isChristmas || isBoxingDay) {
                      return (
                        <TableRow key={row.id} className={getWeekColorClass(row.date)}>
                          <TableCell colSpan={6} className="font-medium text-center">
                            {isChristmas ? '🎄 Christmas Day 🎄' : '🎁 Boxing Day 🎁'}
                          </TableCell>
                        </TableRow>
                      );
                    }

                    return (
                      <TableRow key={row.id} className={getWeekColorClass(row.date)}>
                        <TableCell className="font-medium text-center">{format(dateObj, 'EEE dd MMM')}</TableCell>
                        <TableCell className="text-center">
                          {isEditing && canEdit ? 
                            <Input type="number" value={requiredVal} onChange={(e) => handlePeakDataChange(row.id, 'required', e.target.value)} className="w-20 text-center" /> : 
                            requiredVal
                          }
                        </TableCell>
                        <TableCell className="text-center">
                          {isEditing && canEdit ? 
                            <Input type="number" value={scheduledVal} onChange={(e) => handlePeakDataChange(row.id, 'scheduled', e.target.value)} className="w-20 text-center" /> : 
                            scheduledVal
                          }
                        </TableCell>
                        <TableCell className={`text-center ${variance >= 0 ? 'text-green-600 font-medium' : 'text-red-600 font-medium'}`}>
                          {variance >= 0 ? '+' : ''}{variance}
                        </TableCell>
                        <TableCell className="text-center">
                          {isEditing && canEdit ? 
                            <Input type="number" value={amVal} onChange={(e) => handlePeakDataChange(row.id, 'am', e.target.value)} className="w-20 text-center" /> : 
                            amVal
                          }
                        </TableCell>
                        <TableCell className="text-center">
                          {isEditing && canEdit ? 
                            <Input type="number" value={pmVal} onChange={(e) => handlePeakDataChange(row.id, 'pm', e.target.value)} className="w-20 text-center" /> : 
                            pmVal
                          }
                        </TableCell>
                      </TableRow>
                    );
                    })}
                    </TableBody>
                    <TableFooter>
                    <TableRow>
                    <TableCell className="font-bold text-center">Total</TableCell>
                    <TableCell className="font-bold text-center">{peakPlanningTotals.ga.required}</TableCell>
                    <TableCell className="font-bold text-center">{peakPlanningTotals.ga.scheduled}</TableCell>
                    <TableCell className={`font-bold text-center ${peakPlanningTotals.ga.variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {peakPlanningTotals.ga.variance >= 0 ? '+' : ''}{peakPlanningTotals.ga.variance}
                    </TableCell>
                    <TableCell className="font-bold text-center">{peakPlanningTotals.ga.am}</TableCell>
                    <TableCell className="font-bold text-center">{peakPlanningTotals.ga.pm}</TableCell>
                    </TableRow>
                    </TableFooter>
                    </Table>
                    </TabsContent>

                    <TabsContent value="agency">
                    <Table>
                    <TableHeader>
                    <TableRow>
                    <TableHead className="text-center">Date</TableHead>
                    <TableHead className="text-center">Agency Hours</TableHead>
                    <TableHead className="text-center">Heads</TableHead>
                    </TableRow>
                    </TableHeader>
                    <TableBody>
                    {agencyPeakData.map((row) => {
                    const isRowEditing = isEditing && editedPeakData[row.id];
                    const hoursVal = isRowEditing ? (editedPeakData[row.id].scheduled ?? 0) : (row.scheduled ?? 0);
                    const headsVal = isRowEditing ? (editedPeakData[row.id].heads ?? 0) : (row.heads ?? 0);

                    const dateObj = parseISO(row.date);
                    const dayOfMonth = dateObj.getDate();
                    const month = dateObj.getMonth();
                    const isChristmas = month === 11 && dayOfMonth === 25;
                    const isBoxingDay = month === 11 && dayOfMonth === 26;
                    
                    if (isChristmas || isBoxingDay) {
                      return (
                        <TableRow key={row.id} className={getWeekColorClass(row.date)}>
                          <TableCell colSpan={3} className="font-medium text-center">
                            {isChristmas ? '🎄 Christmas Day 🎄' : '🎁 Boxing Day 🎁'}
                          </TableCell>
                        </TableRow>
                      );
                    }
                    
                    return (
                      <TableRow key={row.id} className={getWeekColorClass(row.date)}>
                        <TableCell className="font-medium text-center">{format(dateObj, 'EEE dd MMM')}</TableCell>
                        <TableCell className="text-center">
                          {isEditing && canEdit ? 
                            <Input type="number" value={hoursVal} onChange={(e) => handlePeakDataChange(row.id, 'scheduled', e.target.value)} className="w-20 text-center" /> : 
                            hoursVal
                          }
                        </TableCell>
                        <TableCell className="text-center">
                          {isEditing && canEdit ? 
                            <Input type="number" value={headsVal} onChange={(e) => handlePeakDataChange(row.id, 'heads', e.target.value)} className="w-20 text-center" /> : 
                            headsVal
                          }
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
                <TableFooter>
                  <TableRow>
                    <TableCell className="font-bold text-center">Total</TableCell>
                    <TableCell className="font-bold text-center">{peakPlanningTotals.agency.scheduled}</TableCell>
                    <TableCell className="font-bold text-center">{peakPlanningTotals.agency.heads}</TableCell>
                  </TableRow>
                </TableFooter>
              </Table>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}