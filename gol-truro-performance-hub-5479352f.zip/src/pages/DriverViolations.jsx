
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Driver } from '@/api/entities';
import { PerformanceMatrixData } from '@/api/entities';
import { User } from '@/api/entities';
import { PeriodConfig } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { AlertTriangle, MessageSquare, Calendar, Filter, Star, Search, Trash2, Image as ImageIcon, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';

import ActionNotesModal from '../components/performance/ActionNotesModal';
import ImagePreviewModal from '../components/performance/ImagePreviewModal';
import PrivateImage from '../components/performance/PrivateImage'; // Import the new component

export default function DriverViolations() {
    const [drivers, setDrivers] = useState([]);
    const [violationData, setViolationData] = useState([]);
    const [filteredViolations, setFilteredViolations] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [canEdit, setCanEdit] = useState(false);
    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
    const [selectedPeriod, setSelectedPeriod] = useState('all');
    const [selectedViolationType, setSelectedViolationType] = useState('all');
    const [selectedActionStatus, setSelectedActionStatus] = useState('all');
    const [searchTerm, setSearchTerm] = useState('');
    
    // Action Notes Modal
    const [isNotesModalOpen, setIsNotesModalOpen] = useState(false);
    const [notesModalData, setNotesModalData] = useState(null);

    // Image Preview Modal
    const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
    const [previewImageUrl, setPreviewImageUrl] = useState(null);

    // Add Violation Modal
    const [isAddViolationModalOpen, setIsAddViolationModalOpen] = useState(false);

    // Add delete confirmation modal state
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [recordToDelete, setRecordToDelete] = useState(null);

    useEffect(() => {
        const checkUserRole = async () => {
            try {
                const currentUser = await User.me();
                setCanEdit(currentUser && currentUser.role === 'admin');
            } catch (error) {
                setCanEdit(false);
            }
        };
        checkUserRole();
    }, []);

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [driverData, performanceData] = await Promise.all([
                Driver.filter({ is_active: true }),
                PerformanceMatrixData.filter({ year: currentYear })
            ]);

            setDrivers(driverData);
            
            // Process performance data to extract violations
            const violations = [];
            performanceData.forEach(record => {
                const driver = driverData.find(d => d.colleague_id === record.shopper_colleague_id);
                if (!driver) return;

                let effectiveDate = record.date; // Fallback to record's creation date
                let latestActionType = null;
                const hasNotes = record.notes && Array.isArray(record.notes) && record.notes.length > 0;
                let latestActionHasImage = false;
                let latestActionImageUri = null;
                let latestActionImageUrl = null; // Add old image url
                let latestActionDate = null;

                if (hasNotes) {
                    // Sort by logged date to find the most recent action
                    const sortedNotes = [...record.notes].sort((a, b) => new Date(b.date) - new Date(a.date));
                    const latestNote = sortedNotes[0];
                    latestActionType = latestNote.action_type;
                    latestActionDate = latestNote.date; // Capture the date of the latest action

                    if (latestNote.image_uri) {
                        latestActionHasImage = true;
                        latestActionImageUri = latestNote.image_uri;
                    } else if (latestNote.image_url) { // Handle old public URLs
                        latestActionHasImage = true;
                        latestActionImageUrl = latestNote.image_url;
                    }
                    
                    // Use the event date from the latest action if it exists and is valid
                    if (latestNote.event_date && latestNote.event_date.trim()) {
                        effectiveDate = latestNote.event_date;
                    }
                }

                // Only include records with actual violations (value > 0)
                if (record.value > 0 && ['DHR', 'Breaks', 'Speeding 10%', 'Speeding 30%', 'Serve Legal Fail', 'Serve Legal Pass', 'Smoother Violation', 'Safer Violation', 'Cleaner Violation'].includes(record.metric_name)) {
                    violations.push({
                        ...record,
                        driverName: driver.name,
                        driverRole: driver.role,
                        hasNotes,
                        latestActionType,
                        latestActionDate,
                        latestActionHasImage,
                        latestActionImageUri,
                        latestActionImageUrl, // Pass old url
                        actionCount: record.notes ? record.notes.length : 0,
                        effectiveDate, // Use this for display
                    });
                }
            });

            setViolationData(violations);
        } catch (error) {
            console.error('Error fetching data:', error);
            toast.error('Failed to load violation data');
        } finally {
            setIsLoading(false);
        }
    }, [currentYear]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const getActionStatusColor = (actionType) => {
        const colors = {
            'final_warning': 'bg-red-100 text-red-800',
            'first_warning': 'bg-amber-100 text-amber-800',
            'irod': 'bg-blue-100 text-blue-800',
            'coaching': 'bg-green-100 text-green-800',
            'dismissed': 'bg-gray-100 text-gray-800',
            'resigned': 'bg-gray-100 text-gray-800',
            'celebrate': 'bg-purple-100 text-purple-800'
        };
        return colors[actionType] || 'bg-gray-100 text-gray-800';
    };

    const getActionStatusLabel = (actionType) => {
        const labels = {
            'final_warning': 'Final Warning',
            'first_warning': 'First Warning',
            'irod': 'IROD',
            'coaching': 'Coaching',
            'dismissed': 'Dismissed',
            'resigned': 'Resigned',
            'celebrate': 'Celebrate'
        };
        return labels[actionType] || 'No Action';
    };

    const getViolationColor = (violationType) => {
        const colors = {
            'Serve Legal Fail': 'bg-red-100 text-red-800',
            'DHR': 'bg-rose-100 text-rose-800',
            'Speeding 30%': 'bg-orange-100 text-orange-800',
            'Speeding 10%': 'bg-sky-100 text-sky-800',
            'Breaks': 'bg-blue-100 text-blue-800',
            'Serve Legal Pass': 'bg-green-100 text-green-800',
            'Smoother Violation': 'bg-purple-100 text-purple-800',
            'Safer Violation': 'bg-indigo-100 text-indigo-800',
            'Cleaner Violation': 'bg-yellow-100 text-yellow-800'
        };
        return colors[violationType] || 'bg-gray-100 text-gray-800';
    };

    const getViolationSeverity = (violationType, value, actionType) => {
        // High severity conditions
        if (actionType === 'final_warning') return 'high';
        if (actionType === 'first_warning') return 'medium-high';
        if (violationType === 'Speeding 30%' && value > 0) return 'medium-high';
        if (violationType === 'Serve Legal Fail' && value > 0) return 'medium-high';
        if (actionType === 'irod') return 'medium';
        if (value >= 3) return 'medium';
        if (actionType === 'coaching') return 'low';
        if (value > 0) return 'low';
        return 'none';
    };

    const getSeverityIcon = (severity) => {
        switch (severity) {
            case 'high': return <Star className="w-3 h-3 text-red-500 fill-red-500" />;
            case 'medium-high': return <Star className="w-3 h-3 text-amber-500 fill-amber-500" />;
            case 'medium': return <Star className="w-3 h-3 text-blue-500 fill-blue-500" />;
            case 'low': return <Star className="w-3 h-3 text-green-500 fill-green-500" />;
            default: return null;
        }
    };

    // Helper function to safely format dates
    const formatSafeDate = (dateStr) => {
        if (!dateStr || typeof dateStr !== 'string' || !dateStr.trim()) {
            return 'Invalid Date';
        }
        
        try {
            // Append 'T00:00:00' to ensure date is parsed in local time, preventing timezone issues
            const date = new Date(dateStr + 'T00:00:00'); 
            if (isNaN(date.getTime())) {
                return 'Invalid Date';
            }
            return format(date, 'MMM d, yyyy');
        } catch (error) {
            console.error('Error formatting date:', dateStr, error);
            return 'Invalid Date';
        }
    };

    // Filter violations based on selected criteria
    useEffect(() => {
        let filtered = [...violationData];

        // Filter by period
        if (selectedPeriod !== 'all') {
            filtered = filtered.filter(v => v.period === parseInt(selectedPeriod));
        }

        // Filter by violation type
        if (selectedViolationType !== 'all') {
            filtered = filtered.filter(v => v.metric_name === selectedViolationType);
        }

        // Filter by action status
        if (selectedActionStatus !== 'all') {
            if (selectedActionStatus === 'none') {
                filtered = filtered.filter(v => !v.latestActionType);
            } else {
                filtered = filtered.filter(v => v.latestActionType === selectedActionStatus);
            }
        }

        // Filter by search term (driver name)
        if (searchTerm.trim()) {
            filtered = filtered.filter(v => 
                v.driverName.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        // Sort by period and week first, then by severity and date
        filtered.sort((a, b) => {
            // First sort by period
            if (a.period !== b.period) {
                return b.period - a.period; // Most recent period first
            }
            
            // Then sort by week within the same period
            if (a.week !== b.week) {
                return b.week - a.week; // Most recent week first
            }
            
            // Then by severity
            const aSeverity = getViolationSeverity(a.metric_name, a.value, a.latestActionType);
            const bSeverity = getViolationSeverity(b.metric_name, b.value, b.latestActionType);
            
            const severityOrder = { 'high': 4, 'medium-high': 3, 'medium': 2, 'low': 1, 'none': 0 };
            const severityDiff = severityOrder[bSeverity] - severityOrder[aSeverity];
            
            if (severityDiff !== 0) return severityDiff;
            
            // Finally by date (most recent first)
            return new Date(b.effectiveDate) - new Date(a.effectiveDate);
        });

        setFilteredViolations(filtered);
    }, [violationData, selectedPeriod, selectedViolationType, selectedActionStatus, searchTerm]);

    const handleAddViolationClick = () => {
        if (!canEdit) {
            toast.error("You must be logged in as an administrator to add violations.");
            return;
        }
        
        // Create a dummy record for the modal to work with
        const dummyRecord = {
            shopper_colleague_id: null, // Will be set in modal
            metric_name: 'DHR', // Default violation type
            value: 0,
            year: currentYear,
            id: null, // Indicates this is for creating new violation
            period: 1, // Default to period 1
            week: 1, // Default to week 1
            date: new Date().toISOString() // Default to current date (this will become effectiveDate if no notes added later)
        };

        setNotesModalData({
            clickedRecord: dummyRecord,
            allRecordsForDriver: [], // Empty since we're creating new
            isViewOnly: false,
            isAddingViolation: true // Special flag for adding violations
        });
        setIsAddViolationModalOpen(true);
    };

    const handleNotesClick = async (violation) => {
        // Fetch all records for this driver for the year to provide full context
        const allRecordsForDriver = await PerformanceMatrixData.filter({
            shopper_colleague_id: violation.shopper_colleague_id,
            year: violation.year,
        });

        setNotesModalData({
            clickedRecord: violation,
            allRecordsForDriver: allRecordsForDriver,
            isViewOnly: false, // Allow editing from violations page
            isAddingViolation: false
        });
        setIsNotesModalOpen(true);
    };

    const handleSaveNotes = async (notesFromModal) => {
        if (!canEdit) {
            toast.error("You are not authorized to save notes.");
            return;
        }
    
        const promises = [];
        const year = currentYear;
    
        // Fetch all period configurations for the year to map dates to periods/weeks
        const allPeriodConfigs = await PeriodConfig.filter({ year });
        const findPeriodForDate = (dateStr) => {
            if (!dateStr) return null;
            const targetDate = new Date(dateStr + 'T00:00:00');
            return allPeriodConfigs.find(p => {
                const start = new Date(p.start_date + 'T00:00:00');
                const end = new Date(p.end_date + 'T00:00:00');
                // Adjust end date to include the entire day
                const adjustedEnd = new Date(end);
                adjustedEnd.setHours(23, 59, 59, 999);
                return targetDate >= start && targetDate <= adjustedEnd;
            });
        };
        
        const newNotes = notesFromModal.filter(n => n.isNew);
        const existingNotesModified = notesFromModal.filter(n => !n.isNew);
    
        // Process new notes to create/update records
        if (newNotes.length > 0) {
            const driverIds = [...new Set(newNotes.map(n => n.selectedDriverId))];
            const allDriverRecords = driverIds.length > 0 ? await PerformanceMatrixData.filter({ 
                shopper_colleague_id: { $in: driverIds },
                year: year 
            }) : [];
    
            for (const note of newNotes) {
                const driverId = note.selectedDriverId;
                if (!driverId) {
                    console.warn("New note is missing selectedDriverId:", note);
                    toast.error(`A new action for ${note.violation} is missing a driver and cannot be saved.`);
                    continue;
                }
    
                const periodConfig = findPeriodForDate(note.event_date);
                if (!periodConfig) {
                    toast.error(`Could not find a valid period for event date ${note.event_date} for driver ${driverId} and violation ${note.violation}. Skipping action.`);
                    continue;
                }
    
                const period = periodConfig.period_number;
                const startDate = new Date(periodConfig.start_date + 'T00:00:00');
                const eventDate = new Date(note.event_date + 'T00:00:00');
                const diffDays = Math.floor((eventDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
                const week = Math.floor(diffDays / 7) + 1; // Weeks are 1-indexed from period start
    
                const noteToSave = {
                    action_type: note.action_type,
                    date: note.date,
                    event_date: note.event_date,
                    by_who: note.by_who,
                    image_uri: note.image_uri || null, // Changed from image_url
                };
                
                const targetRecord = allDriverRecords.find(r =>
                    r.shopper_colleague_id === driverId &&
                    r.metric_name === note.violation &&
                    r.period === period &&
                    r.week === week
                );
    
                if (targetRecord) {
                    const updatedNotes = [...(targetRecord.notes || []), noteToSave];
                    const updateData = { notes: updatedNotes };
                    if (note.auto_increment) {
                        updateData.value = (targetRecord.value || 0) + 1;
                    }
                    promises.push(PerformanceMatrixData.update(targetRecord.id, updateData));
                } else {
                    const initialValue = note.auto_increment ? 1 : 0;
                    const newRecordPayload = {
                        shopper_colleague_id: driverId,
                        metric_name: note.violation,
                        value: initialValue,
                        date: note.event_date || new Date().toISOString().split('T')[0], // Use event_date as record date
                        period: period,
                        week: week,
                        year: year,
                        notes: [noteToSave],
                    };
                    promises.push(PerformanceMatrixData.create(newRecordPayload));
                }
            }
        }
        
        // Process existing notes that were modified
        if (notesModalData?.allRecordsForDriver) {
            const groupedByID = existingNotesModified.reduce((acc, note) => {
                if (!acc[note.sourceRecordId]) acc[note.sourceRecordId] = [];
                const { sourceRecordId, sourceMetricName, sourceLabel, isNew, ...rest } = note; 
                acc[note.sourceRecordId].push(rest);
                return acc;
            }, {});
    
            // Helper to sort notes for consistent comparison, ensuring all properties are considered
            const sortAndStringify = (notes) => {
                if (!notes || notes.length === 0) return '[]';
                // Sort by date to have a consistent order before stringifying
                const sorted = [...notes].sort((a, b) => (new Date(a.date) > new Date(b.date) ? 1 : -1));
                return JSON.stringify(sorted);
            };
    
            for (const record of notesModalData.allRecordsForDriver) {
                const updatedNotesForRecord = groupedByID[record.id] || [];
                const originalNotes = record.notes || [];
    
                // Compare sorted stringified versions to detect any change, including image_uri
                if (sortAndStringify(updatedNotesForRecord) !== sortAndStringify(originalNotes)) {
                    promises.push(PerformanceMatrixData.update(record.id, { notes: updatedNotesForRecord }));
                }
            }
        }
        
        // Execute all promises
        if (promises.length > 0) {
            try {
                await toast.promise(Promise.all(promises), {
                    loading: 'Saving changes...',
                    success: 'Changes saved successfully!',
                    error: (err) => {
                        console.error('Failed to save some changes:', err);
                        return `Failed to save some changes: ${err.message || ''}`;
                    }
                });
                // Refresh the data after successful save
                await fetchData();
            } catch (error) {
                console.error('Error during promise execution for saving changes:', error);
            }
        } else {
            toast.info('No changes to save.');
        }
    
        // Close modals
        setIsNotesModalOpen(false);
        setIsAddViolationModalOpen(false);
        setNotesModalData(null);
    };

    const handleDeleteClick = (violation) => {
        if (!canEdit) {
            toast.error("You must be logged in as an administrator to delete violations.");
            return;
        }
        setRecordToDelete(violation);
        setIsDeleteModalOpen(true);
    };

    const handleImagePreview = (url) => {
        setPreviewImageUrl(url);
        setIsPreviewModalOpen(true);
    };

    const handleConfirmDelete = async () => {
        if (!recordToDelete || !canEdit) return;

        try {
            // First check if the record still exists in the current state
            const recordExists = violationData.find(v => v.id === recordToDelete.id);
            if (!recordExists) {
                toast.error('This violation record no longer exists. It may have already been deleted.');
                // Refresh the data to get current state
                await fetchData();
                return; // Exit here as no delete operation is needed
            }

            await toast.promise(PerformanceMatrixData.delete(recordToDelete.id), {
                loading: 'Deleting violation record...',
                success: 'Violation record deleted successfully!',
                error: (err) => {
                    console.error('Delete error:', err);
                    if (err.message && err.message.includes('Entity not found')) {
                        return 'This record has already been deleted or no longer exists.';
                    }
                    return 'Failed to delete violation record.';
                },
            });
            
            // Refresh the data after successful deletion
            await fetchData();
            
        } catch (error) {
            console.error('Error deleting violation record:', error);
            // Handle the case where the record doesn't exist on the server
            if (error.message && error.message.includes('Entity not found')) {
                toast.info('Record was already deleted on the server. Refreshing data...');
                await fetchData();
            } else {
                toast.error('An unexpected error occurred during deletion.');
            }
        } finally {
            setIsDeleteModalOpen(false);
            setRecordToDelete(null);
        }
    };

    const getStatsSummary = useMemo(() => {
        const stats = {
            totalViolations: filteredViolations.length,
            highSeverity: 0,
            mediumSeverity: 0,
            lowSeverity: 0,
            noAction: 0
        };

        filteredViolations.forEach(v => {
            const severity = getViolationSeverity(v.metric_name, v.value, v.latestActionType);
            if (severity === 'high') stats.highSeverity++;
            else if (severity === 'medium-high' || severity === 'medium') stats.mediumSeverity++;
            else if (severity === 'low') stats.lowSeverity++;
            
            if (!v.latestActionType) stats.noAction++;
        });

        return stats;
    }, [filteredViolations]);

    return (
        <div className="p-6 space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="space-y-2">
                    <h1 className="text-2xl font-bold text-gray-900">Driver Violations Report</h1>
                </div>
                <div className="flex items-center gap-2">
                    {canEdit && (
                        <Button 
                            onClick={handleAddViolationClick}
                            className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white"
                        >
                            <AlertTriangle className="w-4 h-4 mr-2" />
                            Add Violation
                        </Button>
                    )}
                    <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))}>
                        <SelectTrigger className="w-24">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            {[2025, 2024, 2023].map(y => (
                                <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>

            <Card className="glass-card">
                <CardContent>
                    {/* Stats Summary */}
                    <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
                        <div className="bg-slate-50 rounded-lg p-3 text-center">
                            <div className="text-2xl font-bold text-slate-800">{getStatsSummary.totalViolations}</div>
                            <div className="text-xs text-slate-600">Total Violations</div>
                        </div>
                        <div className="bg-red-50 rounded-lg p-3 text-center">
                            <div className="text-2xl font-bold text-red-800">{getStatsSummary.highSeverity}</div>
                            <div className="text-xs text-red-600">High Priority</div>
                        </div>
                        <div className="bg-amber-50 rounded-lg p-3 text-center">
                            <div className="text-2xl font-bold text-amber-800">{getStatsSummary.mediumSeverity}</div>
                            <div className="text-xs text-amber-600">Medium Priority</div>
                        </div>
                        <div className="bg-green-50 rounded-lg p-3 text-center">
                            <div className="text-2xl font-bold text-green-800">{getStatsSummary.lowSeverity}</div>
                            <div className="text-xs text-green-600">Low Priority</div>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-3 text-center">
                            <div className="text-2xl font-bold text-gray-800">{getStatsSummary.noAction}</div>
                            <div className="text-xs text-gray-600">No Action</div>
                        </div>
                    </div>

                    {/* Filters */}
                    <div className="flex flex-wrap gap-3 mb-6 p-4 bg-slate-50 rounded-lg">
                        <div className="flex items-center gap-2">
                            <Filter className="w-4 h-4 text-slate-500" />
                            <span className="text-sm font-medium text-slate-700">Filters:</span>
                        </div>
                        
                        <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                            <SelectTrigger className="w-32">
                                <SelectValue placeholder="Period" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Periods</SelectItem>
                                {Array.from({ length: 13 }, (_, i) => (
                                    <SelectItem key={i + 1} value={(i + 1).toString()}>
                                        Period {i + 1}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>

                        <Select value={selectedViolationType} onValueChange={setSelectedViolationType}>
                            <SelectTrigger className="w-40">
                                <SelectValue placeholder="Violation Type" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Types</SelectItem>
                                <SelectItem value="DHR">DHR</SelectItem>
                                <SelectItem value="Breaks">Breaks</SelectItem>
                                <SelectItem value="Speeding 10%">Speeding 10%</SelectItem>
                                <SelectItem value="Speeding 30%">Speeding 30%</SelectItem>
                                <SelectItem value="Serve Legal Fail">Serve Legal Fail</SelectItem>
                                <SelectItem value="Serve Legal Pass">Serve Legal Pass</SelectItem>
                                <SelectItem value="Smoother Violation">Smoother Violation</SelectItem>
                                <SelectItem value="Safer Violation">Safer Violation</SelectItem>
                                <SelectItem value="Cleaner Violation">Cleaner Violation</SelectItem>
                            </SelectContent>
                        </Select>

                        <Select value={selectedActionStatus} onValueChange={setSelectedActionStatus}>
                            <SelectTrigger className="w-36">
                                <SelectValue placeholder="Action Status" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Actions</SelectItem>
                                <SelectItem value="none">No Action</SelectItem>
                                <SelectItem value="coaching">Coaching</SelectItem>
                                <SelectItem value="irod">IROD</SelectItem>
                                <SelectItem value="first_warning">First Warning</SelectItem>
                                <SelectItem value="final_warning">Final Warning</SelectItem>
                                <SelectItem value="dismissed">Dismissed</SelectItem>
                                <SelectItem value="resigned">Resigned</SelectItem>
                                <SelectItem value="celebrate">Celebrate</SelectItem>
                            </SelectContent>
                        </Select>

                        <div className="flex items-center gap-2">
                            <Search className="w-4 h-4 text-slate-500" />
                            <Input
                                placeholder="Search driver..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="w-40"
                            />
                        </div>
                    </div>

                    {/* Violations Table */}
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Priority</TableHead>
                                    <TableHead>Driver</TableHead>
                                    <TableHead>Role</TableHead>
                                    <TableHead>Violation Type</TableHead>
                                    <TableHead>Count</TableHead>
                                    <TableHead>Period/Week</TableHead>
                                    <TableHead>Violation Date</TableHead>
                                    <TableHead>Action Date</TableHead>
                                    <TableHead>Latest Action</TableHead>
                                    <TableHead>Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {isLoading ? (
                                    Array.from({ length: 10 }).map((_, i) => (
                                        <TableRow key={i}>
                                            {Array.from({ length: 10 }).map((_, j) => (
                                                <TableCell key={j}>
                                                    <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
                                                </TableCell>
                                            ))}
                                        </TableRow>
                                    ))
                                ) : filteredViolations.length > 0 ? (
                                    filteredViolations.map((violation, index) => {
                                        const severity = getViolationSeverity(violation.metric_name, violation.value, violation.latestActionType);
                                        return (
                                            <TableRow key={`${violation.id}-${index}`} className="hover:bg-slate-50">
                                                <TableCell>
                                                    <div className="flex items-center justify-center">
                                                        {getSeverityIcon(severity)}
                                                    </div>
                                                </TableCell>
                                                <TableCell className="font-medium">{violation.driverName}</TableCell>
                                                <TableCell>
                                                    <Badge variant="outline" className="text-xs">
                                                        {violation.driverRole === 'c&c' ? 'C&C' : violation.driverRole?.charAt(0).toUpperCase() + violation.driverRole?.slice(1) || 'Core'}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell>
                                                    <Badge className={`text-xs ${getViolationColor(violation.metric_name)}`}>
                                                        {violation.metric_name}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell>
                                                    <span className="font-bold text-red-600">{violation.value}</span>
                                                </TableCell>
                                                <TableCell>
                                                    <span className="text-sm">P{violation.period} W{violation.week}</span>
                                                </TableCell>
                                                <TableCell>
                                                    <span className="text-sm">{formatSafeDate(violation.effectiveDate)}</span>
                                                </TableCell>
                                                <TableCell>
                                                    <span className="text-sm">
                                                        {violation.latestActionDate ? format(new Date(violation.latestActionDate), 'MMM d, yyyy') : '-'}
                                                    </span>
                                                </TableCell>
                                                <TableCell>
                                                    {violation.latestActionType ? (
                                                        <div className="flex items-center gap-2">
                                                            <Badge className={`text-xs ${getActionStatusColor(violation.latestActionType)}`}>
                                                                {getActionStatusLabel(violation.latestActionType)}
                                                            </Badge>
                                                            {(violation.latestActionImageUri || violation.latestActionImageUrl) && (
                                                                <Button
                                                                    variant="ghost"
                                                                    size="sm"
                                                                    onClick={async () => {
                                                                        if (violation.latestActionImageUri) {
                                                                            // For private images, fetch signed URL first
                                                                            try {
                                                                                const { CreateFileSignedUrl } = await import('@/api/integrations');
                                                                                const { signed_url } = await CreateFileSignedUrl({ file_uri: violation.latestActionImageUri });
                                                                                handleImagePreview(signed_url);
                                                                            } catch (error) {
                                                                                console.error('Failed to get signed URL:', error);
                                                                                toast.error('Failed to load image');
                                                                            }
                                                                        } else if (violation.latestActionImageUrl) {
                                                                            handleImagePreview(violation.latestActionImageUrl);
                                                                        }
                                                                    }}
                                                                    className="h-6 w-6 p-0 text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                                                                    title="View evidence image"
                                                                >
                                                                    <ImageIcon className="w-4 h-4" />
                                                                </Button>
                                                            )}
                                                        </div>
                                                    ) : (
                                                        <Badge variant="outline" className="text-xs text-gray-600">
                                                            No Action
                                                        </Badge>
                                                    )}
                                                </TableCell>
                                                <TableCell>
                                                    <div className="flex items-center gap-1">
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            onClick={() => handleNotesClick(violation)}
                                                            className="text-blue-600 hover:text-blue-800 relative"
                                                            title="View/Edit Actions"
                                                        >
                                                            <MessageSquare className="w-4 h-4" />
                                                            {violation.hasNotes && (
                                                                <span className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 rounded-full"></span>
                                                            )}
                                                        </Button>
                                                        {canEdit && (
                                                            <>
                                                                <Button
                                                                    variant="ghost"
                                                                    size="sm"
                                                                    onClick={() => handleNotesClick(violation)}
                                                                    className="text-green-600 hover:text-green-800"
                                                                    title="Add Action/Upload Image"
                                                                >
                                                                    <Upload className="w-4 h-4" />
                                                                </Button>
                                                                <Button
                                                                    variant="ghost"
                                                                    size="sm"
                                                                    onClick={() => handleDeleteClick(violation)}
                                                                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                                                                    title="Delete Violation"
                                                                >
                                                                    <Trash2 className="w-4 h-4" />
                                                                </Button>
                                                            </>
                                                        )}
                                                    </div>
                                                </TableCell>
                                            </TableRow>
                                        );
                                    })
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={10} className="text-center py-8 text-slate-500">
                                            No violations found matching the current filters.
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            {/* Action Notes Modal for existing violations */}
            <ActionNotesModal
                isOpen={isNotesModalOpen}
                onClose={() => setIsNotesModalOpen(false)}
                notesData={notesModalData}
                onSave={handleSaveNotes}
                driverName={notesModalData ? notesModalData.clickedRecord.driverName : ''}
                canEdit={canEdit}
                isViewOnly={false}
                isAddingViolation={false} // Explicitly false for existing
            />

            {/* Add Violation Modal */}
            <ActionNotesModal
                isOpen={isAddViolationModalOpen}
                onClose={() => setIsAddViolationModalOpen(false)}
                notesData={notesModalData}
                onSave={handleSaveNotes}
                driverName="Select Driver" // Placeholder for new violation
                canEdit={canEdit}
                isViewOnly={false}
                isAddingViolation={true} // Explicitly true for adding
            />

            <ImagePreviewModal
                isOpen={isPreviewModalOpen}
                onClose={() => setIsPreviewModalOpen(false)}
                imageUrl={previewImageUrl}
            />

            {/* Delete Confirmation Modal */}
            <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
                <DialogContent className="bg-white border border-gray-200 shadow-xl">
                    <DialogHeader>
                        <DialogTitle className="text-gray-900 text-xl font-semibold flex items-center gap-2">
                            <Trash2 className="w-5 h-5 text-red-600" />
                            Delete Violation Record
                        </DialogTitle>
                        <DialogDescription className="text-gray-600">
                            Are you sure you want to delete this violation record? This action cannot be undone.
                        </DialogDescription>
                    </DialogHeader>
                    
                    {recordToDelete && (
                        <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                            <div className="space-y-2 text-sm">
                                <p><strong>Driver:</strong> {recordToDelete.driverName}</p>
                                <p><strong>Violation:</strong> {recordToDelete.metric_name}</p>
                                <p><strong>Count:</strong> {recordToDelete.value}</p>
                                <p><strong>Period/Week:</strong> P{recordToDelete.period} W{recordToDelete.week}</p>
                                <p><strong>Date:</strong> {formatSafeDate(recordToDelete.effectiveDate)}</p>
                                {recordToDelete.hasNotes && (
                                    <p className="text-amber-700 font-medium">⚠️ This record has action notes that will also be deleted.</p>
                                )}
                            </div>
                        </div>
                    )}
                    
                    <DialogFooter>
                        <Button 
                            variant="outline" 
                            onClick={() => setIsDeleteModalOpen(false)}
                            className="border-gray-300 text-gray-700"
                        >
                            Cancel
                        </Button>
                        <Button 
                            onClick={handleConfirmDelete}
                            className="bg-red-600 hover:bg-red-700 text-white"
                        >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Record
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
