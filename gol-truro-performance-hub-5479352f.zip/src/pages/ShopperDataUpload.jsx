import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { ShopperPerformance } from '@/api/entities';
import { Shopper } from '@/api/entities';
import { PeriodConfig } from '@/api/entities';
import { useEditLock } from '../Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Upload, FileText, CheckCircle, AlertCircle, Trash2, Save, ClipboardPaste, Users, Edit, Plus, X, ArrowRight, RotateCw } from 'lucide-react';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"; // Added Tabs import

const requiredHeaders = [
    "Colleague ID", "Name", "Items Per Hour", "Picked Items", "Total Shift Time(Mins)",
    "Non-Shop/Walk Time(Mins)", "Shop/Walk Time(Mins)", "Skipped Items", "Date"
];

const headerMapping = {
    "Colleague ID": "colleague_id",
    "Name": "name",
    "Items Per Hour": "iph",
    "Picked Items": "picked_items",
    "Total Shift Time(Mins)": "total_shift_time",
    "Non-Shop/Walk Time(Mins)": "non_shop_walk_time",
    "Shop/Walk Time(Mins)": "shop_walk_time",
    "Skipped Items": "skipped_items",
    "Date": "date"
};

const validRoles = ["shopper", "new", "new_sd_shopper", "sd_shopper", "ga", "driver", "manager", "quit", "store_support", "boom"];

export default function ShopperDataUpload() {
  const [pastedData, setPastedData] = useState("");
  const [parsedData, setParsedData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedPeriod, setSelectedPeriod] = useState(1);
  const [selectedWeek, setSelectedWeek] = useState(1);

  // New states for file upload functionality
  const [selectedFile, setSelectedFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false); // For file processing itself
  const [errors, setErrors] = useState([]); // For file processing errors

  // Shopper management states
  const [shoppers, setShoppers] = useState([]);
  const [editedShoppers, setEditedShoppers] = useState([]);
  const [showAddShopperDialog, setShowAddShopperDialog] = useState(false);
  const [newShopper, setNewShopper] = useState({ colleague_id: '', name: '', role: 'shopper', wrap_status: false });
  const [shopperPastedData, setShopperPastedData] = useState("");
  const [showShopperReviewDialog, setShowShopperReviewDialog] = useState(false);
  const [preparedShoppers, setPreparedShoppers] = useState({ toCreate: [], toUpdate: [] });

  // Helper function to determine current period and week (1 week behind)
  const getCurrentPeriodAndWeek = (periods) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0); 

    const currentPeriodConfig = periods.find(p => {
      const startDate = new Date(p.start_date);
      startDate.setHours(0, 0, 0, 0);
      const endDate = new Date(p.end_date);
      endDate.setHours(0, 0, 0, 0);
      return today >= startDate && today <= endDate;
    });

    if (currentPeriodConfig) {
      const startDate = new Date(currentPeriodConfig.start_date);
      startDate.setHours(0, 0, 0, 0);

      const daysDiff = Math.floor((today - startDate) / (1000 * 60 * 60 * 24));
      const currentWeekNumber = Math.min(Math.floor(daysDiff / 7) + 1, 4);
      
      // Go back 1 week
      let targetPeriod = currentPeriodConfig.period_number;
      let targetWeek = currentWeekNumber - 1;
      
      // If we're in week 1, go to week 4 of the previous period
      if (targetWeek < 1) {
        targetPeriod = Math.max(1, targetPeriod - 1);
        targetWeek = 4;
      }
      
      return { period: targetPeriod, week: targetWeek };
    }
    
    // If no current period found (e.g., between periods or future date),
    // find the latest available period and default to its last week
    const latestPeriod = periods.reduce((latest, current) => {
      if (!latest) return current; 
      return new Date(current.start_date) > new Date(latest.start_date) ? current : latest;
    }, periods[0]);
    
    return latestPeriod ? { period: latestPeriod.period_number, week: 4 } : { period: 1, week: 1 };
  };

  useEffect(() => {
    const checkUserRole = async () => {
        setIsAuthLoading(true);
        try {
            const currentUser = await User.me();
            setIsAdmin(currentUser && currentUser.role === 'admin');
        } catch (error) {
            setIsAdmin(false);
        } finally {
            setIsAuthLoading(false);
        }
    };
    
    const initializePeriodAndWeek = async () => {
      try {
        const periodsData = await PeriodConfig.filter({ year: selectedYear }, 'period_number');
        
        if (periodsData.length > 0) {
          const { period, week } = getCurrentPeriodAndWeek(periodsData);
          setSelectedPeriod(period);
          setSelectedWeek(week);
        }
      } catch (error) {
        console.error("Error loading periods for upload defaults:", error);
      }
    };

    checkUserRole();
    initializePeriodAndWeek();
    loadShoppers();
  }, [selectedYear]);

  const loadShoppers = async () => {
    try {
      const data = await Shopper.list('-created_date', 1000); // Increased limit to 1000
      setShoppers(data);
      setEditedShoppers(JSON.parse(JSON.stringify(data))); // Initialize editable state
    } catch (error) {
      console.error("Error loading shoppers:", error);
      toast.error("Failed to load shoppers data.");
    }
  };

  const handleResetChanges = () => {
    setEditedShoppers(JSON.parse(JSON.stringify(shoppers)));
    toast.info("Your changes have been reset.");
  };

  const handleParseData = () => {
    if (!pastedData.trim()) {
      toast.error("Please paste data into the text area before parsing.");
      return;
    }
    // Clear file related states if parsing pasted data
    setSelectedFile(null);
    setErrors([]);
    parsePastedText(pastedData);
  };

  const parsePastedText = (text) => {
    const lines = text.trim().split('\n');
    if (lines.length === 0) {
        setParsedData([]);
        return;
    }

    const headers = lines[0].split('\t').map(h => h.trim().replace(/"/g, ''));
    
    const missingHeaders = requiredHeaders.filter(h => !headers.includes(h));
    if (missingHeaders.length > 0) {
      toast.error(`Pasted data is missing required headers: ${missingHeaders.join(', ')}`);
      setParsedData([]);
      return;
    }

    const data = [];
    for (let i = 1; i < lines.length; i++) {
      if (lines[i].trim()) {
        const values = lines[i].split('\t').map(v => v.trim().replace(/"/g, ''));
        const row = {};
        headers.forEach((header, index) => {
          row[header] = values[index] || '';
        });
        data.push(row);
      }
    }
    
    setParsedData(data);
    toast.success("Pasted data parsed successfully. Review the data below.");
  };

  const handleFileChange = (event) => {
    if (event.target.files && event.target.files[0]) {
      setSelectedFile(event.target.files[0]);
      setErrors([]); // Clear errors on new file selection
    } else {
      setSelectedFile(null);
    }
  };

  const handleFileUpload = async () => {
    if (!selectedFile) {
      toast.warning("Please select a file to upload.");
      return;
    }
    setIsProcessing(true);
    setErrors([]); // Clear previous errors
    setPastedData(""); // Clear pasted data if switching to file upload

    try {
      // Placeholder for actual file upload and data extraction logic.
      // In a real application, this would involve sending `selectedFile` to a backend
      // API endpoint which then processes the file and returns the structured data.
      // Example:
      // const formData = new FormData();
      // formData.append('file', selectedFile);
      // const response = await fetch('/api/upload-and-extract', {
      //   method: 'POST',
      //   body: formData,
      // });
      // const extractResult = await response.json();

      // MOCKING `extractResult` for compilation and demonstration purposes.
      // In a real scenario, this would be replaced by actual API call result.
      const mockExtractResult = await new Promise(resolve => setTimeout(() => {
        if (selectedFile.name.toLowerCase().includes("error")) {
          resolve({ status: 'error', details: 'Simulated file processing error from backend.' });
        } else if (selectedFile.name.toLowerCase().includes("empty")) {
          resolve({ status: 'success', output: { shopper_data: [] } });
        } else {
          // Simulate successful extraction with some dummy data for demonstration
          // This dummy data needs to match `requiredHeaders` structure for display
          resolve({
            status: 'success',
            output: {
              shopper_data: [
                {
                  "Colleague ID": "F001", "Name": "Alice Smith", "Items Per Hour": "55.2",
                  "Picked Items": "120", "Total Shift Time(Mins)": "180",
                  "Non-Shop/Walk Time(Mins)": "15", "Shop/Walk Time(Mins)": "165",
                  "Skipped Items": "3", "Date": "05/01/2024"
                },
                {
                  "Colleague ID": "F002", "Name": "Bob Johnson", "Items Per Hour": "62.0",
                  "Picked Items": "155", "Total Shift Time(Mins)": "240",
                  "Non-Shop/Walk Time(Mins)": "20", "Shop/Walk Time(Mins)": "220",
                  "Skipped Items": "1", "Date": "05/01/2024"
                },
                {
                  "Colleague ID": "F003", "Name": "Charlie Brown", "Items Per Hour": "48.7",
                  "Picked Items": "90", "Total Shift Time(Mins)": "150",
                  "Non-Shop/Walk Time(Mins)": "12", "Shop/Walk Time(Mins)": "138",
                  "Skipped Items": "0", "Date": "05/01/2024"
                }
              ]
            }
          });
        }
      }, 1500)); // Simulate network delay

      const extractResult = mockExtractResult;

      if (extractResult.status === 'success' && extractResult.output && extractResult.output.shopper_data) {
        setParsedData(extractResult.output.shopper_data);
        toast.success("File processed successfully. Review the data below.");
      } else {
        console.error("Extraction failed:", extractResult.details);
        toast.error(`Data extraction failed: ${extractResult.details || "Unknown error"}`);
        setErrors(prev => [...prev, `Data extraction failed: ${extractResult.details || "Unknown error"}`]);
      }
    } catch (error) {
      console.error('Error processing file:', error);
      let errorMessage = 'An error occurred during file processing. Please try again.';
      if (error instanceof Error) { // Ensure it's an Error object for .message
        if (error.message && (error.message.includes('500') || error.message.includes('timeout') || error.message.includes('544'))) {
            errorMessage = 'A server error occurred during file upload. Please try again in a few moments.';
        } else if (error.message) {
            errorMessage = `Error processing file: ${error.message}`;
        }
      }
      toast.error(errorMessage);
      setErrors(prev => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleUpload = async () => {
    if (parsedData.length === 0) {
        toast.warning("No data to upload.");
        return;
    }
    setIsLoading(true);

    const recordsToCreate = parsedData.map(row => {
        const record = {};
        for (const key in headerMapping) {
            const newKey = headerMapping[key];
            let value = row[key]; // Use the original header key from the parsed row
            if (newKey !== 'name' && newKey !== 'colleague_id' && newKey !== 'date') {
                // Remove commas for thousands separators before parsing
                value = parseFloat(String(value).replace(/,/g, '')) || 0;
            }
            if (newKey === 'date') {
                const parts = value.split('/');
                if (parts.length === 3) {
                    value = `${parts[2]}-${parts[1]}-${parts[0]}`;
                }
            }
            record[newKey] = value;
        }
        // Override period, week, and year with selected values
        record.period = selectedPeriod;
        record.week = selectedWeek;
        record.year = selectedYear;
        return record;
    });

    try {
        await toast.promise(ShopperPerformance.bulkCreate(recordsToCreate), {
            loading: `Uploading ${recordsToCreate.length} records...`,
            success: 'All shopper performance records uploaded successfully!',
            error: 'An error occurred during the bulk upload.',
        });
        setPastedData("");
        setParsedData([]);
        setSelectedFile(null); // Clear selected file after successful upload
        setErrors([]); // Clear errors after successful upload
    } catch (error) {
        console.error("Bulk create failed:", error);
    } finally {
        setIsLoading(false);
    }
  };

  const handleClear = () => {
      setPastedData("");
      setParsedData([]);
      setSelectedFile(null); // Clear selected file
      setErrors([]); // Clear errors
  };

  const handleShopperChange = (id, field, value) => {
    setEditedShoppers(prev => 
      prev.map(shopper => 
        shopper.id === id ? { ...shopper, [field]: value } : shopper
      )
    );
  };

  const handleSaveChanges = async () => {
    if (!canEdit) return;

    // Check for duplicate colleague_ids in edited data
    const colleagueIds = editedShoppers.map(s => s.colleague_id);
    const duplicates = colleagueIds.filter((id, index) => colleagueIds.indexOf(id) !== index);
    if (duplicates.length > 0) {
      toast.error(`Duplicate Colleague IDs found: ${[...new Set(duplicates)].join(', ')}. Please fix before saving.`);
      return;
    }

    const updatesToSend = [];
    editedShoppers.forEach(editedShopper => {
      const originalShopper = shoppers.find(s => s.id === editedShopper.id);
      if (!originalShopper) return;

      const hasChanged = 
        editedShopper.colleague_id !== originalShopper.colleague_id ||
        editedShopper.name !== originalShopper.name ||
        editedShopper.role !== originalShopper.role ||
        editedShopper.wrap_status !== originalShopper.wrap_status;

      if (hasChanged) {
        updatesToSend.push(Shopper.update(editedShopper.id, {
          colleague_id: editedShopper.colleague_id,
          name: editedShopper.name,
          role: editedShopper.role,
          wrap_status: editedShopper.wrap_status
        }));
      }
    });

    if (updatesToSend.length === 0) {
      toast.info("No changes to save.");
      return;
    }

    try {
      await toast.promise(Promise.all(updatesToSend), {
        loading: 'Saving shopper changes...',
        success: () => {
          loadShoppers();
          return "Shoppers updated successfully!";
        },
        error: 'Failed to update shoppers.',
      });
    } catch (error) {
      console.error("Error updating shoppers:", error);
    }
  };

  const handleAddShopper = async () => {
    if (!newShopper.colleague_id || !newShopper.name) {
      toast.error("Colleague ID and Name are required.");
      return;
    }

    // Check for duplicate colleague_id
    const isDuplicate = shoppers.some(s => s.colleague_id === newShopper.colleague_id);
    if (isDuplicate) {
      toast.error("A shopper with this Colleague ID already exists.");
      return;
    }

    try {
      await toast.promise(Shopper.create(newShopper), {
        loading: 'Adding new shopper...',
        success: 'Shopper added successfully!',
        error: 'Failed to add shopper.',
      });
      setShowAddShopperDialog(false);
      setNewShopper({ colleague_id: '', name: '', role: 'shopper', wrap_status: false });
      loadShoppers();
    } catch (error) {
      console.error("Error adding shopper:", error);
    }
  };

  const handleParseShopperData = () => {
    if (!shopperPastedData.trim()) {
      toast.error("Paste data before parsing.");
      return;
    }
    const lines = shopperPastedData.trim().split('\n');
    const toCreate = [];
    const toUpdate = [];
    const seenIds = new Set();

    lines.forEach(line => {
      if (!line.trim()) return;
      const [colleague_id, name, role, wrap] = line.split('\t').map(s => s.trim());

      if (!colleague_id || !name) {
        toast.warning(`Skipping invalid line: ${line}`);
        return;
      }

      // Check for duplicates within pasted data
      if (seenIds.has(colleague_id)) {
        toast.warning(`Duplicate Colleague ID in pasted data: ${colleague_id}. Skipping duplicate.`);
        return;
      }
      seenIds.add(colleague_id);

      const roleToSet = role && validRoles.includes(role.toLowerCase()) ? role.toLowerCase() : 'shopper';
      const wrapStatusToSet = wrap && wrap.toLowerCase() === 'yes';
      const existingShopper = shoppers.find(s => s.colleague_id === colleague_id);
      
      if (existingShopper) {
        toUpdate.push({ ...existingShopper, name, role: roleToSet, wrap_status: wrapStatusToSet });
      } else {
        toCreate.push({ colleague_id, name, role: roleToSet, wrap_status: wrapStatusToSet });
      }
    });

    setPreparedShoppers({ toCreate, toUpdate });
    setShowShopperReviewDialog(true);
  };

  const handleConfirmShopperBulkSave = async () => {
    const { toCreate, toUpdate } = preparedShoppers;
    const promises = [];

    if (toCreate.length > 0) {
      promises.push(Shopper.bulkCreate(toCreate));
    }

    if (toUpdate.length > 0) {
      toUpdate.forEach(shopper => {
        promises.push(Shopper.update(shopper.id, { name: shopper.name, role: shopper.role, wrap_status: shopper.wrap_status }));
      });
    }
    
    if (promises.length === 0) {
      toast.info("No shopper changes to save.");
      return;
    }

    try {
      await toast.promise(Promise.all(promises), {
        loading: 'Saving all shopper changes...',
        success: 'Shoppers updated successfully!',
        error: 'Error saving shopper data.',
      });
      
      setShowShopperReviewDialog(false);
      setShopperPastedData("");
      setPreparedShoppers({ toCreate: [], toUpdate: [] });
      loadShoppers();
    } catch (error) {
      console.error("Error saving bulk shoppers:", error);
    }
  };

  const handleRemoveDuplicates = async () => {
    const colleagueIdMap = new Map();
    const duplicatesToDelete = [];

    // Group by colleague_id, keep the first occurrence
    shoppers.forEach(shopper => {
      if (!colleagueIdMap.has(shopper.colleague_id)) {
        colleagueIdMap.set(shopper.colleague_id, shopper);
      } else {
        duplicatesToDelete.push(shopper);
      }
    });

    if (duplicatesToDelete.length === 0) {
      toast.info("No duplicate shoppers found.");
      return;
    }

    try {
      await toast.promise(
        Promise.all(duplicatesToDelete.map(s => Shopper.delete(s.id))),
        {
          loading: `Removing ${duplicatesToDelete.length} duplicate shopper(s)...`,
          success: `Successfully removed ${duplicatesToDelete.length} duplicate(s)!`,
          error: 'Failed to remove duplicates.',
        }
      );
      loadShoppers();
    } catch (error) {
      console.error("Error removing duplicates:", error);
    }
  };

  if (isAuthLoading) {
    return (
      <div className="p-6 space-y-6 min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }



  return (
    <div className="p-6 space-y-6 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Shopper Data Upload</h1>
          <p className="text-gray-600 mt-1">Upload weekly shopper performance data from CSV files.</p>
        </div>
      </div>

      <Tabs defaultValue="upload" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="upload">Performance Data Upload</TabsTrigger>
          <TabsTrigger value="shoppers">Shopper Management</TabsTrigger>
        </TabsList>
        <TabsContent value="upload">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle>Performance Data Upload</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-sm text-gray-600 mb-4">Select the year, period, and week for the data upload. Then, copy the data from your spreadsheet (including the header row) and paste it into the text box below. Alternatively, upload a data file.</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                        <label className="text-sm font-medium text-gray-700">Year</label>
                        <Select value={selectedYear.toString()} onValueChange={(val) => setSelectedYear(parseInt(val))}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                            {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - 2 + i).map(y => (
                                <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                            ))}
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <label className="text-sm font-medium text-gray-700">Period</label>
                        <Select value={selectedPeriod.toString()} onValueChange={(val) => setSelectedPeriod(parseInt(val))}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                            {Array.from({ length: 13 }, (_, i) => i + 1).map(p => (
                                <SelectItem key={p} value={p.toString()}>Period {p}</SelectItem>
                            ))}
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <label className="text-sm font-medium text-gray-700">Week</label>
                        <Select value={selectedWeek.toString()} onValueChange={(val) => setSelectedWeek(parseInt(val))}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                            {Array.from({ length: 4 }, (_, i) => i + 1).map(w => (
                                <SelectItem key={w} value={w.toString()}>Week {w}</SelectItem>
                            ))}
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                {/* NEW: File Upload Section */}
                <div className="mb-4 p-4 border rounded-md bg-gray-50">
                    <h3 className="text-md font-semibold mb-2 flex items-center">
                        <Upload className="w-5 h-5 mr-2 text-blue-600" /> Upload Data File
                    </h3>
                    <p className="text-sm text-gray-600 mb-3">
                        Choose a tab-separated values (TSV) or Excel file to upload for automatic parsing.
                    </p>
                    <div className="flex items-center gap-2">
                        <Input
                            type="file"
                            accept=".tsv,.txt,.csv,.xlsx" // Common file types
                            onChange={handleFileChange}
                            className="flex-grow"
                        />
                        <Button 
                            onClick={handleFileUpload} 
                            disabled={!selectedFile || isProcessing}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-4 py-2"
                        >
                            {isProcessing ? (
                                <>
                                    <RotateCw className="w-4 h-4 mr-2 animate-spin" /> Processing...
                                </>
                            ) : (
                                <>
                                    <Upload className="w-4 h-4 mr-2" /> Upload
                                </>
                            )}
                        </Button>
                    </div>
                    {selectedFile && (
                        <p className="text-sm text-gray-500 mt-2">Selected: {selectedFile.name}</p>
                    )}
                    {errors.length > 0 && (
                        <div className="mt-3 space-y-2">
                            {errors.map((err, index) => (
                                <p key={index} className="text-sm text-red-600 flex items-center">
                                    <AlertCircle className="w-4 h-4 mr-2" /> {err}
                                </p>
                            ))}
                        </div>
                    )}
                </div>

                <div className="relative mb-4">
                  <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-2 text-xs text-gray-400 uppercase font-medium">Or Paste Data</span>
                  <hr className="border-gray-200" />
                </div>

                <Textarea
                  placeholder={`Paste your data here...\n\nRequired columns: "Colleague ID", "Name", "Items Per Hour", "Picked Items", "Total Shift Time(Mins)", "Non-Shop/Walk Time(Mins)", "Shop/Walk Time(Mins)", "Skipped Items", "Date"`}
                  className="h-60 w-full font-mono text-sm"
                  value={pastedData}
                  onChange={(e) => setPastedData(e.target.value)}
                />
              <div className="mt-4 flex justify-between">
                    <Button 
                        onClick={handleParseData} 
                        disabled={!pastedData.trim()}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2"
                    >
                        <ClipboardPaste className="w-4 h-4 mr-2" />
                        Parse Data
                    </Button>
                    <Button 
                        variant="destructive" 
                        onClick={handleClear} 
                        size="sm" 
                        disabled={!pastedData && parsedData.length === 0 && !selectedFile && errors.length === 0}
                        className="bg-red-600 hover:bg-red-700 text-white font-medium px-4 py-2"
                    >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Clear
                    </Button>
                </div>
            </CardContent>
          </Card>
          
          {parsedData.length > 0 && (
            <Card className="glass-card mt-6">
              <CardHeader>
                <CardTitle>Review & Confirm Upload</CardTitle>
                <div className="flex justify-between items-center mt-2">
                    <p className="text-sm text-gray-600">{parsedData.length} records found. Please review all data before uploading.</p>
                    <Button 
                        onClick={handleUpload} 
                        disabled={isLoading} 
                        className="bg-green-600 hover:bg-green-700 text-white font-medium px-6 py-2"
                    >
                        <Save className="w-4 h-4 mr-2" />
                        {isLoading ? 'Uploading...' : 'Confirm & Upload Data'}
                    </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto max-h-96 overflow-y-auto border rounded-lg">
                  <Table>
                    <TableHeader className="bg-slate-100 sticky top-0">
                      <TableRow>
                        {Object.keys(headerMapping).map(headerKey => (
                          <TableHead key={headerKey} className="font-semibold text-slate-700 py-3 px-4 border-b">
                            {headerKey}
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {parsedData.map((row, index) => (
                        <TableRow key={index} className={`hover:bg-slate-50 ${index % 2 === 0 ? 'bg-white' : 'bg-slate-25'}`}>
                          {Object.keys(headerMapping).map(headerKey => (
                            <TableCell key={headerKey} className="py-3 px-4 text-sm border-b border-slate-200">
                              <div className="font-medium">
                                {headerKey === 'Picked Items' || headerKey === 'Total Shift Time(Mins)' || headerKey === 'Non-Shop/Walk Time(Mins)' || headerKey === 'Shop/Walk Time(Mins)' || headerKey === 'Skipped Items' 
                                  ? Number(row[headerKey]).toLocaleString() 
                                  : row[headerKey]
                                }
                              </div>
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="shoppers">
          <Card className="glass-card">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Shopper Management
                  </CardTitle>
                </div>
                <div className="flex gap-3">
                  {canEdit && (
                    <>
                      <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={handleRemoveDuplicates}
                          className="border-red-300 text-red-700 hover:bg-red-50 font-medium px-4 py-2"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Remove Duplicates
                      </Button>
                      <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={handleResetChanges}
                          className="border-gray-300 text-gray-700 hover:bg-gray-50 font-medium px-4 py-2"
                      >
                        <RotateCw className="w-4 h-4 mr-2" />
                        Reset Changes
                      </Button>
                      <Button 
                          size="sm" 
                          onClick={handleSaveChanges}
                          className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-4 py-2"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Save All Changes
                      </Button>
                      <Button 
                          size="sm" 
                          onClick={() => setShowAddShopperDialog(true)}
                          className="bg-green-600 hover:bg-green-700 text-white font-medium px-4 py-2"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Shopper
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6 border-b pb-6">
                <h3 className="text-lg font-medium mb-2">Bulk Add/Update Shoppers</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Paste data from a spreadsheet with columns: Colleague ID, Name, Role, WRAP (Yes/No). Columns must be separated by tabs.
                </p>
                <Textarea
                  placeholder={`Paste shopper data here...\n\nExample:\n12345\tJohn Doe\tshopper\tNo\n67890\tJane Smith\tnew_sd_shopper\tYes`}
                  className="h-40 w-full font-mono text-sm"
                  value={shopperPastedData}
                  onChange={(e) => setShopperPastedData(e.target.value)}
                />
                <div className="mt-4 flex justify-start">
                  <Button 
                      onClick={handleParseShopperData} 
                      disabled={!shopperPastedData.trim() || !canEdit}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2"
                  >
                    <ClipboardPaste className="w-4 h-4 mr-2" />
                    Parse & Review Shopper Data
                  </Button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Colleague ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>WRAP</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[...editedShoppers].sort((a, b) => a.name.localeCompare(b.name)).map((shopper) => (
                      <TableRow key={shopper.id}>
                        <TableCell>
                          <Input
                            value={shopper.colleague_id || ''}
                            onChange={(e) => handleShopperChange(shopper.id, 'colleague_id', e.target.value)}
                            className="w-full"
                            disabled={!canEdit}
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            value={shopper.name || ''}
                            onChange={(e) => handleShopperChange(shopper.id, 'name', e.target.value)}
                            className="w-full"
                            disabled={!canEdit}
                          />
                        </TableCell>
                        <TableCell>
                          <Select
                            value={shopper.role || 'shopper'}
                            onValueChange={(value) => handleShopperChange(shopper.id, 'role', value)}
                            disabled={!canEdit}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="shopper">Shopper</SelectItem>
                              <SelectItem value="sd_shopper">SD Shopper</SelectItem>
                              <SelectItem value="ga">GA</SelectItem>
                              <SelectItem value="driver">Driver</SelectItem>
                              <SelectItem value="manager">Manager</SelectItem>
                              <SelectItem value="quit">Quit</SelectItem>
                              <SelectItem value="store_support">Store Support</SelectItem>
                              <SelectItem value="boom">Boom</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            shopper.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {shopper.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Select
                            value={String(shopper.wrap_status)}
                            onValueChange={(value) => handleShopperChange(shopper.id, 'wrap_status', value === 'true')}
                            disabled={!canEdit}
                          >
                            <SelectTrigger className="w-24">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="false">No</SelectItem>
                              <SelectItem value="true">Yes</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showAddShopperDialog} onOpenChange={setShowAddShopperDialog}>
        <DialogContent className="bg-white border border-gray-200 shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-gray-900 text-xl font-semibold">Add New Shopper</DialogTitle>
            <DialogDescription className="text-gray-600">
              Enter the details for the new shopper.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Colleague ID</label>
              <Input
                value={newShopper.colleague_id}
                onChange={(e) => setNewShopper({...newShopper, colleague_id: e.target.value})}
                placeholder="Enter colleague ID"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Name</label>
              <Input
                value={newShopper.name}
                onChange={(e) => setNewShopper({...newShopper, name: e.target.value})}
                placeholder="Enter full name"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Role</label>
              <Select
                value={newShopper.role}
                onValueChange={(value) => setNewShopper({...newShopper, role: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="shopper">Shopper</SelectItem>
                  <SelectItem value="sd_shopper">SD Shopper</SelectItem>
                  <SelectItem value="ga">GA</SelectItem>
                  <SelectItem value="driver">Driver</SelectItem>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="quit">Quit</SelectItem>
                  <SelectItem value="store_support">Store Support</SelectItem>
                  <SelectItem value="boom">Boom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">WRAP Status</label>
              <Select
                value={String(newShopper.wrap_status)}
                onValueChange={(value) => setNewShopper({...newShopper, wrap_status: value === 'true'})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="false">No</SelectItem>
                  <SelectItem value="true">Yes</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddShopperDialog(false)} className="border-gray-300 text-gray-700">
              Cancel
            </Button>
            <Button onClick={handleAddShopper} className="bg-blue-600 hover:bg-blue-700 text-white">
              Add Shopper
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog open={showShopperReviewDialog} onOpenChange={setShowShopperReviewDialog}>
        <DialogContent className="max-w-3xl bg-white border border-gray-200 shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-gray-900 text-xl font-semibold">Review Shopper Changes</DialogTitle>
            <DialogDescription className="text-gray-600">
              Review the shoppers to be created and updated.
            </DialogDescription>
          </DialogHeader>
          <div className="grid md:grid-cols-2 gap-6 max-h-[60vh] overflow-y-auto p-1">
            <div>
              <h4 className="font-semibold mb-2 text-green-600">New Shoppers to Add ({preparedShoppers.toCreate.length})</h4>
              <div className="space-y-2">
                {preparedShoppers.toCreate.length > 0 ? preparedShoppers.toCreate.map(s => (
                  <div key={s.colleague_id} className="text-sm p-2 bg-green-50 rounded-md">
                    <p><b>ID:</b> {s.colleague_id}</p>
                    <p><b>Name:</b> {s.name}</p>
                    <p><b>Role:</b> {s.role}</p>
                    <p><b>WRAP:</b> <span className={s.wrap_status ? 'font-bold text-red-600' : 'font-bold text-green-600'}>{s.wrap_status ? 'Yes' : 'No'}</span></p>
                  </div>
                )) : <p className="text-sm text-gray-500">No new shoppers.</p>}
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-blue-600">Shoppers to Update ({preparedShoppers.toUpdate.length})</h4>
              <div className="space-y-2">
                {preparedShoppers.toUpdate.length > 0 ? preparedShoppers.toUpdate.map(s => (
                  <div key={s.id} className="text-sm p-2 bg-blue-50 rounded-md">
                    <p><b>ID:</b> {s.colleague_id}</p>
                    <p><b>Name:</b> {s.name}</p>
                    <p><b>Role:</b> {s.role}</p>
                    <p><b>WRAP:</b> <span className={s.wrap_status ? 'font-bold text-red-600' : 'font-bold text-green-600'}>{s.wrap_status ? 'Yes' : 'No'}</span></p>
                  </div>
                )) : <p className="text-sm text-gray-500">No shoppers to update.</p>}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowShopperReviewDialog(false)} className="border-gray-300 text-gray-700">Cancel</Button>
            <Button onClick={handleConfirmShopperBulkSave} className="bg-blue-600 hover:bg-blue-700 text-white">Confirm & Save All</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}