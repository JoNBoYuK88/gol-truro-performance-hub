import React, { useState, useEffect, useMemo } from 'react';
import { User } from '@/api/entities';
import { Driver } from '@/api/entities';
import { useEditLock } from '../Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Edit, Save, X, Users, ArrowUpDown, ShieldCheck, ShieldX, BadgeCheck, Award, UserPlus, TrafficCone, Navigation, Truck } from 'lucide-react';

const StatusBadge = ({ value, children }) => {
    return (
        <Badge variant={value ? "default" : "destructive"} className={`cursor-default ${value ? 'bg-green-100 text-green-800 border-green-200' : 'bg-red-100 text-red-800 border-red-200'}`}>
            {value ? <ShieldCheck className="w-3.5 h-3.5 mr-1" /> : <ShieldX className="w-3.5 h-3.5 mr-1" />}
            {children}
        </Badge>
    );
};

const StatCard = ({ title, value, icon: Icon, totalDrivers, shunterCount }) => {
    let textColor = '';
    const nonShunterTotal = totalDrivers - shunterCount;

    if (title === 'DBS' || title === 'MN') {
        // Special logic for DBS and MN: green if match non-shunter total, red if not.
        if (nonShunterTotal > 0) {
            textColor = value === nonShunterTotal ? 'text-green-600' : 'text-red-600';
        }
    } else if (title !== 'Total Drivers' && title !== 'Shunter') {
        // Original logic for other cards: green if match total drivers.
        if (totalDrivers > 0 && value === totalDrivers) {
            textColor = 'text-green-600';
        }
    }
    
    return (
        <Card className="glass-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
                <Icon className="h-4 w-4 text-gray-400" />
            </CardHeader>
            <CardContent>
                <div className={`text-2xl font-bold ${textColor}`}>
                    {value}
                </div>
            </CardContent>
        </Card>
    );
};

export default function SimsTtcMasternautPage() {
    const [drivers, setDrivers] = useState([]);
    const [editedDrivers, setEditedDrivers] = useState({});
    const { canEdit: unlockCanEdit } = useEditLock();
    const [isAdmin, setIsAdmin] = useState(false);
    const canEdit = isAdmin || unlockCanEdit;
    const [isEditing, setIsEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [sortConfig, setSortConfig] = useState({ key: 'name', direction: 'asc' });
    const [filters, setFilters] = useState({ role: 'all', driving_status: 'all' });

    useEffect(() => {
        const initialize = async () => {
            setIsLoading(true);
            try {
                const currentUser = await User.me();
                setIsAdmin(currentUser && currentUser.role === 'admin');
            } catch (error) {
                setIsAdmin(false);
            }
            await loadDrivers();
            setIsLoading(false);
        };
        initialize();
    }, []);

    const loadDrivers = async () => {
        try {
            const data = await Driver.list('-created_date', 500);
            setDrivers(data);
        } catch (error) {
            console.error("Error loading drivers:", error);
            toast.error("Failed to load driver data.");
        }
    };

    const handleEditToggle = () => {
        if (!canEdit) {
            toast.error("You don't have permission to edit.");
            return;
        }
        if (isEditing) {
            setEditedDrivers({}); // Discard changes
        }
        setIsEditing(!isEditing);
    };

    const handleDriverChange = (driverId, field, value) => {
        setEditedDrivers(prev => ({
            ...prev,
            [driverId]: { ...prev[driverId], [field]: value }
        }));
    };

    const handleSaveChanges = async () => {
        if (!canEdit) return;

        const updates = Object.entries(editedDrivers).map(([driverId, changes]) => {
            const originalDriver = drivers.find(d => d.id === driverId);
            return Driver.update(driverId, { ...originalDriver, ...changes });
        });

        if (updates.length === 0) {
            toast.info("No changes to save.");
            setIsEditing(false);
            return;
        }

        try {
            await toast.promise(Promise.all(updates), {
                loading: 'Saving driver updates...',
                success: (results) => {
                    loadDrivers();
                    setIsEditing(false);
                    setEditedDrivers({});
                    return `${results.length} driver(s) updated successfully!`;
                },
                error: 'Failed to update drivers.',
            });
        } catch (error) {
            console.error("Error updating drivers:", error);
        }
    };
    
    const sortedAndFilteredDrivers = useMemo(() => {
        let filtered = [...drivers];

        if (filters.role !== 'all') {
            filtered = filtered.filter(d => d.role === filters.role);
        }
        if (filters.driving_status !== 'all') {
            filtered = filtered.filter(d => d.driving_status === filters.driving_status);
        }

        return filtered.sort((a, b) => {
            const aValue = a[sortConfig.key];
            const bValue = b[sortConfig.key];

            // Handle boolean values for sorting
            if (typeof aValue === 'boolean' && typeof bValue === 'boolean') {
                if (aValue === bValue) return 0;
                return sortConfig.direction === 'asc' ? (aValue ? -1 : 1) : (aValue ? 1 : -1);
            }

            if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
            if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
        });
    }, [drivers, sortConfig, filters]);
    
    const stats = useMemo(() => {
        if (!drivers || drivers.length === 0) {
            return { total: 0, sims: 0, dbs: 0, ttc: 0, mn: 0, shunters: 0, mentors: 0, backups: 0 };
        }
        return {
            total: drivers.length,
            sims: drivers.filter(d => d.is_in_sims).length,
            dbs: drivers.filter(d => d.dbs_approved).length,
            ttc: drivers.filter(d => d.is_on_ttc).length,
            mn: drivers.filter(d => d.is_on_masternaut).length,
            shunters: drivers.filter(d => d.role === 'shunter').length,
            mentors: drivers.filter(d => d.is_driver_mentor).length,
            backups: drivers.filter(d => d.role === 'backup').length
        };
    }, [drivers]);

    const requestSort = (key) => {
        let direction = 'asc';
        if (sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    if (isLoading) {
        return <div className="p-6">Loading...</div>;
    }

    return (
        <div className="p-6 space-y-6 min-h-screen">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="space-y-2">
                    <h1 className="text-2xl font-bold text-gray-900">SIMS, TTC & Masternaut</h1>
                </div>
                {canEdit && (
                    <div className="flex gap-2">
                        {isEditing && <Button variant="destructive" onClick={handleEditToggle}><X className="w-4 h-4 mr-2" />Cancel</Button>}
                        <Button onClick={isEditing ? handleSaveChanges : handleEditToggle} className="btn-modern">
                            {isEditing ? <><Save className="w-4 h-4 mr-2" />Save Changes</> : <><Edit className="w-4 h-4 mr-2" />Edit Mode</>}
                        </Button>
                    </div>
                )}
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-4">
                <StatCard title="Total Drivers" value={stats.total} icon={Users} totalDrivers={stats.total} shunterCount={stats.shunters} />
                <StatCard title="SIMS" value={stats.sims} icon={ShieldCheck} totalDrivers={stats.total} shunterCount={stats.shunters} />
                <StatCard title="DBS" value={stats.dbs} icon={BadgeCheck} totalDrivers={stats.total} shunterCount={stats.shunters} />
                <StatCard title="TTC" value={stats.ttc} icon={TrafficCone} totalDrivers={stats.total} shunterCount={stats.shunters} />
                <StatCard title="MN" value={stats.mn} icon={Navigation} totalDrivers={stats.total} shunterCount={stats.shunters} />
                <StatCard title="Shunter" value={stats.shunters} icon={Truck} totalDrivers={stats.total} shunterCount={stats.shunters} />
                <StatCard title="Mentor" value={stats.mentors} icon={Award} totalDrivers={stats.total} shunterCount={stats.shunters} />
                <StatCard title="Backup" value={stats.backups} icon={UserPlus} totalDrivers={stats.total} shunterCount={stats.shunters} />
            </div>
            
            <Card className="glass-card">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle className="flex items-center gap-2"><Users className="w-5 h-5" />Driver List</CardTitle>
                        <div className="flex items-center gap-3">
                            <Select value={filters.role} onValueChange={value => setFilters(f => ({...f, role: value}))}>
                                <SelectTrigger className="w-36"><SelectValue placeholder="Driver Type" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Driver Types</SelectItem>
                                    <SelectItem value="core">Core</SelectItem>
                                    <SelectItem value="backup">Backup</SelectItem>
                                    <SelectItem value="c&c">C&C</SelectItem>
                                    <SelectItem value="shunter">Shunter</SelectItem>
                                </SelectContent>
                            </Select>
                            <Select value={filters.driving_status} onValueChange={value => setFilters(f => ({...f, driving_status: value}))}>
                                <SelectTrigger className="w-40"><SelectValue placeholder="Driving Status" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Active">Active</SelectItem>
                                    <SelectItem value="Suspended">Suspended</SelectItem>
                                    <SelectItem value="Training">Training</SelectItem>
                                    <SelectItem value="Leaver">Leaver</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead onClick={() => requestSort('name')} className="cursor-pointer">Name <ArrowUpDown className="w-4 h-4 inline" /></TableHead>
                                    <TableHead onClick={() => requestSort('role')} className="cursor-pointer">Role <ArrowUpDown className="w-4 h-4 inline" /></TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead onClick={() => requestSort('is_in_sims')} className="cursor-pointer">SIMS <ArrowUpDown className="w-4 h-4 inline" /></TableHead>
                                    <TableHead onClick={() => requestSort('dbs_approved')} className="cursor-pointer">DBS <ArrowUpDown className="w-4 h-4 inline" /></TableHead>
                                    <TableHead onClick={() => requestSort('is_on_ttc')} className="cursor-pointer">TTC <ArrowUpDown className="w-4 h-4 inline" /></TableHead>
                                    <TableHead onClick={() => requestSort('is_on_masternaut')} className="cursor-pointer">MN <ArrowUpDown className="w-4 h-4 inline" /></TableHead>
                                    <TableHead onClick={() => requestSort('is_driver_mentor')} className="cursor-pointer">Mentor <ArrowUpDown className="w-4 h-4 inline" /></TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {sortedAndFilteredDrivers.map(driver => {
                                    const currentData = { ...driver, ...(editedDrivers[driver.id] || {}) };
                                    return (
                                        <TableRow key={driver.id}>
                                            <TableCell className="font-medium">{driver.name}</TableCell>
                                            <TableCell>
                                                {isEditing ? (
                                                    <Select value={currentData.role || 'core'} onValueChange={val => handleDriverChange(driver.id, 'role', val)}>
                                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="core">Core</SelectItem>
                                                            <SelectItem value="backup">Backup</SelectItem>
                                                            <SelectItem value="c&c">C&C</SelectItem>
                                                            <SelectItem value="shunter">Shunter</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                ) : (
                                                    <span className={`inline-block px-2 py-1 rounded text-xs font-medium ${
                                                        driver.role === 'core' ? 'bg-blue-100 text-blue-800' :
                                                        driver.role === 'backup' ? 'bg-green-100 text-green-800' :
                                                        driver.role === 'c&c' ? 'bg-purple-100 text-purple-800' :
                                                        driver.role === 'shunter' ? 'bg-orange-100 text-orange-800' :
                                                        'bg-gray-100 text-gray-800'
                                                    }`}>
                                                        {driver.role === 'c&c' ? 'C&C' : driver.role?.charAt(0).toUpperCase() + driver.role?.slice(1)}
                                                    </span>
                                                )}
                                            </TableCell>
                                            <TableCell>
                                                {isEditing ? (
                                                    <Select value={currentData.driving_status} onValueChange={val => handleDriverChange(driver.id, 'driving_status', val)}>
                                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="Active">Active</SelectItem>
                                                            <SelectItem value="Suspended">Suspended</SelectItem>
                                                            <SelectItem value="Training">Training</SelectItem>
                                                            <SelectItem value="Leaver">Leaver</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                ) : (
                                                    <Badge variant={currentData.driving_status === 'Active' ? 'default' : 'secondary'} className={currentData.driving_status === 'Active' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}>
                                                        {currentData.driving_status}
                                                    </Badge>
                                                )}
                                            </TableCell>
                                            <TableCell>
                                                {isEditing ? (
                                                    <Checkbox checked={currentData.is_in_sims} onCheckedChange={val => handleDriverChange(driver.id, 'is_in_sims', val)} />
                                                ) : (
                                                    <StatusBadge value={currentData.is_in_sims} />
                                                )}
                                            </TableCell>
                                            <TableCell>
                                                {isEditing ? (
                                                    <Checkbox checked={currentData.dbs_approved} onCheckedChange={val => handleDriverChange(driver.id, 'dbs_approved', val)} />
                                                ) : (
                                                    <StatusBadge value={currentData.dbs_approved} />
                                                )}
                                            </TableCell>
                                            <TableCell>
                                                {isEditing ? (
                                                    <Checkbox checked={currentData.is_on_ttc} onCheckedChange={val => handleDriverChange(driver.id, 'is_on_ttc', val)} />
                                                ) : (
                                                    <StatusBadge value={currentData.is_on_ttc} />
                                                )}
                                            </TableCell>
                                            <TableCell>
                                                {isEditing ? (
                                                    <Checkbox checked={currentData.is_on_masternaut} onCheckedChange={val => handleDriverChange(driver.id, 'is_on_masternaut', val)} />
                                                ) : (
                                                    <StatusBadge value={currentData.is_on_masternaut} />
                                                )}
                                            </TableCell>
                                            <TableCell>
                                                {isEditing ? (
                                                    <Checkbox checked={currentData.is_driver_mentor} onCheckedChange={val => handleDriverChange(driver.id, 'is_driver_mentor', val)} />
                                                ) : (
                                                    <StatusBadge value={currentData.is_driver_mentor} />
                                                )}
                                            </TableCell>
                                        </TableRow>
                                    )
                                })}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}