import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { DamageReport } from '@/api/entities';
import { AppConfig } from '@/api/entities';
import PrintableTracker from '../components/tracker/PrintableTracker';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import { Loader2, ArrowLeft, CheckCircle, FileWarning, Download } from 'lucide-react';
import { toast } from "sonner";

export default function PrintAllTrackers() {
    const [reports, setReports] = useState([]);
    const [overlayPositions, setOverlayPositions] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isExporting, setIsExporting] = useState(false);
    const [exportFinished, setExportFinished] = useState(false);
    const [currentExportCount, setCurrentExportCount] = useState(0);
    const [error, setError] = useState(null);

    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const period = parseInt(searchParams.get('period'));
    const year = parseInt(searchParams.get('year'));

    useEffect(() => {
        const fetchData = async () => {
            if (!period || !year) {
                setError("Period and year parameters are missing.");
                setIsLoading(false);
                return;
            }

            try {
                const [reportData, configData] = await Promise.all([
                    DamageReport.filter({ period, year }, 'van_registration'),
                    AppConfig.filter({ key: 'damageTrackerOverlayPositions' })
                ]);
                
                if (reportData.length === 0) {
                    setError(`No damage reports found for Period ${period}, ${year}.`);
                } else {
                    setReports(reportData);
                }

                if (configData && configData.length > 0 && configData[0].value) {
                    let parsedValue = typeof configData[0].value === 'string' 
                        ? JSON.parse(configData[0].value) 
                        : configData[0].value;
                    setOverlayPositions(parsedValue);
                } else {
                    // Provide default positions if none are configured
                    setOverlayPositions({
                      vanReg: { top: '2.4%', left: '25%', width: '15%', height: '3.8%' },
                      period: { top: '2.4%', left: '46%', width: '5.5%', height: '3.8%' },
                      exteriorCleanDate: { top: '29%', left: '80%', width: '15%', height: '4%' },
                      cabCleanDate: { top: '51%', left: '80%', width: '15%', height: '4%' },
                      boxCleanDate: { top: '73%', left: '80%', width: '15%', height: '4%' }
                    });
                }
            } catch (e) {
                console.error("Failed to fetch data for exporting:", e);
                setError("An error occurred while fetching the tracker data.");
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, [period, year]);

    const handleExportAllIndividually = async () => {
        if (reports.length === 0) {
            toast.info("No reports to export.");
            return;
        }

        setIsExporting(true);
        toast.info(
            `Starting export of ${reports.length} reports. This may take a moment...`,
            { duration: 8000 }
        );
        
        try {
            const html2canvasModule = await import('html2canvas');
            const html2canvas = html2canvasModule.default;
            
            const today = new Date();
            const day = String(today.getDate()).padStart(2, '0');
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const yearFull = today.getFullYear();
            const todaysDate = `${day}${month}${String(yearFull).slice(-2)}`;
            
            for (let i = 0; i < reports.length; i++) {
                const report = reports[i];
                setCurrentExportCount(i + 1);

                // Add a robust delay before processing each item
                await new Promise(resolve => setTimeout(resolve, 500));
                
                const element = document.getElementById(`printable-tracker-${report.van_registration}`);
                if (!element) {
                    console.warn(`Could not find element for ${report.van_registration}. It might not have rendered correctly.`);
                    toast.warning(`Skipped report for ${report.van_registration}: element not found.`);
                    continue;
                }
                
                const canvas = await html2canvas(element, {
                    backgroundColor: '#ffffff',
                    scale: 2, // High-quality export
                    useCORS: true,
                    logging: false,
                });
                
                const link = document.createElement('a');
                link.download = `${report.van_registration}_P${period}_${year}_${todaysDate}.png`;
                link.href = canvas.toDataURL('image/png', 0.95);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
            
            toast.success(`Successfully exported ${reports.length} damage tracker images!`);
            setExportFinished(true);

        } catch (err) {
            console.error("Error during export:", err);
            toast.error(`Export failed: ${err.message}`);
        } finally {
            setIsExporting(false);
        }
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-screen bg-slate-50">
                <div className="text-center">
                    <Loader2 className="w-12 h-12 text-blue-500 animate-spin mx-auto mb-4" />
                    <h2 className="text-xl font-semibold text-slate-700">Loading Tracker Data...</h2>
                    <p className="text-slate-500">Please wait while we fetch the reports for P{period}, {year}.</p>
                </div>
            </div>
        );
    }
    
    if (isExporting) {
        return (
             <div className="flex items-center justify-center h-screen bg-slate-50">
                <div className="text-center">
                    <Loader2 className="w-12 h-12 text-blue-500 animate-spin mx-auto mb-4" />
                    <h2 className="text-xl font-semibold text-slate-700">Exporting Images...</h2>
                    <p className="text-slate-500">
                        Processing {currentExportCount} of {reports.length}. Please stay on this page.
                    </p>
                    <div className="w-full bg-gray-200 rounded-full h-2.5 mt-4">
                      <div 
                        className="bg-blue-600 h-2.5 rounded-full transition-all duration-500" 
                        style={{ width: `${(currentExportCount / reports.length) * 100}%` }}
                      ></div>
                    </div>
                </div>
            </div>
        )
    }
    
    if (error) {
        return (
            <div className="flex items-center justify-center h-screen bg-red-50">
                <div className="text-center p-8 bg-white rounded-lg shadow-lg max-w-lg">
                    <FileWarning className="w-16 h-16 text-red-500 mx-auto mb-4"/>
                    <h2 className="text-2xl font-bold text-red-800">Error Loading Data</h2>
                    <p className="text-red-600 mt-2 mb-6">{error}</p>
                    <Button asChild>
                        <Link to={createPageUrl(`PeriodDamageTracker`)}>
                            <ArrowLeft className="w-4 h-4 mr-2" />
                            Return to Damage Tracker
                        </Link>
                    </Button>
                </div>
            </div>
        );
    }

    if (exportFinished) {
        return (
            <div className="flex items-center justify-center h-screen bg-green-50">
                <div className="text-center p-8 bg-white rounded-lg shadow-lg max-w-lg">
                    <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4"/>
                    <h2 className="text-2xl font-bold text-green-800">Export Complete!</h2>
                    <p className="text-green-600 mt-2 mb-6">
                        {reports.length} tracker images have been downloaded.
                    </p>
                    <Button asChild>
                        <Link to={createPageUrl(`PeriodDamageTracker`)}>
                            <ArrowLeft className="w-4 h-4 mr-2" />
                            Return to Damage Tracker
                        </Link>
                    </Button>
                </div>
            </div>
        );
    }
    
    return (
        <div className="bg-slate-50 min-h-screen">
             <header className="p-4 bg-white shadow-md flex justify-between items-center sticky top-0 z-10">
                <h1 className="text-xl font-bold">
                    Export All Trackers (P{period}, {year})
                </h1>
                <Button asChild variant="outline">
                    <Link to={createPageUrl(`PeriodDamageTracker`)}>
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Cancel and Go Back
                    </Link>
                </Button>
            </header>
            <main className="flex flex-col items-center justify-center p-8">
                <div className="text-center p-8 bg-white rounded-lg shadow-lg max-w-2xl">
                    <Download className="w-16 h-16 text-blue-500 mx-auto mb-4"/>
                    <h2 className="text-2xl font-bold text-slate-800">Ready to Export</h2>
                    <p className="text-slate-600 mt-2 mb-6">
                        Found {reports.length} damage reports. They will be exported as individual image files, one after the other.
                    </p>
                    <Button size="lg" onClick={handleExportAllIndividually} className="bg-blue-600 hover:bg-blue-700">
                        <Download className="w-5 h-5 mr-2" />
                        Export All (Individual Files)
                    </Button>
                </div>
            </main>
            
            {/* Hidden container to render all trackers for export */}
            <div style={{ position: 'absolute', top: '-9999px', left: '-9999px' }}>
                {reports.length > 0 && overlayPositions && (
                    reports.map((report) => (
                        <div key={report.id} id={`printable-tracker-${report.van_registration}`} style={{ width: '800px', height: '600px', backgroundColor: 'white' }}>
                            <PrintableTracker 
                                report={report} 
                                overlayPositions={overlayPositions} 
                            />
                        </div>
                    ))
                )}
            </div>
        </div>
    );
}