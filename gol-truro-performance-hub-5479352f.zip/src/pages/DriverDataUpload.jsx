import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Driver } from '@/api/entities';
import { useEditLock } from '../Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, Users, Edit, Plus, X, Save, RotateCw, ClipboardPaste, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function DriverDataUpload() {
  const [drivers, setDrivers] = useState([]);
  const [editedDrivers, setEditedDrivers] = useState([]);
  const [showAddDriverDialog, setShowAddDriverDialog] = useState(false);
  const [newDriver, setNewDriver] = useState({ colleague_id: '', name: '', role: 'core' });
  const [driverPastedData, setDriverPastedData] = useState("");
  const [showDriverReviewDialog, setShowDriverReviewReviewDialog] = useState(false);
  const [preparedDrivers, setPreparedDrivers] = useState({ toCreate: [], toUpdate: [] });
  const [simsDataPasted, setSimsDataPasted] = useState("");
  const [showSimsReviewDialog, setShowSimsReviewDialog] = useState(false);
  const [preparedSimsUpdates, setPreparedSimsUpdates] = useState({ updates: [], notFound: [] });
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [driverToDelete, setDriverToDelete] = useState(null);

  useEffect(() => {
    const checkUserRole = async () => {
        setIsAuthLoading(true);
        try {
            const currentUser = await User.me();
            setIsAdmin(currentUser && currentUser.role === 'admin');
        } catch (error) {
            setIsAdmin(false);
        } finally {
            setIsAuthLoading(false);
        }
    };
    
    checkUserRole();
    loadDrivers();
  }, []);

  const loadDrivers = async () => {
    try {
      const data = await Driver.list('-created_date', 200);
      setDrivers(data);
      setEditedDrivers(JSON.parse(JSON.stringify(data)));
    } catch (error) {
      console.error("Error loading drivers:", error);
      toast.error("Failed to load drivers data.");
    }
  };

  const handleResetChanges = () => {
    setEditedDrivers(JSON.parse(JSON.stringify(drivers)));
    toast.info("Your changes have been reset.");
  };

  const handleDriverChange = (id, field, value) => {
    setEditedDrivers(prev => 
      prev.map(driver => 
        driver.id === id ? { ...driver, [field]: value } : driver
      )
    );
  };

  const handleSaveChanges = async () => {
    if (!canEdit) return;

    const updatesToSend = [];
    editedDrivers.forEach(editedDriver => {
      const originalDriver = drivers.find(d => d.id === editedDriver.id);
      if (!originalDriver) return;

      const hasChanged = 
        editedDriver.colleague_id !== originalDriver.colleague_id ||
        editedDriver.name !== originalDriver.name ||
        editedDriver.role !== originalDriver.role;

      if (hasChanged) {
        updatesToSend.push(Driver.update(editedDriver.id, {
          colleague_id: editedDriver.colleague_id,
          name: editedDriver.name,
          role: editedDriver.role
        }));
      }
    });

    if (updatesToSend.length === 0) {
      toast.info("No changes to save.");
      return;
    }

    try {
      await toast.promise(Promise.all(updatesToSend), {
        loading: 'Saving driver changes...',
        success: () => {
          loadDrivers();
          return "Drivers updated successfully!";
        },
        error: 'Failed to update drivers.',
      });
    } catch (error) {
      console.error("Error updating drivers:", error);
    }
  };

  const handleAddDriver = async () => {
    if (!newDriver.colleague_id || !newDriver.name) {
      toast.error("Colleague ID and Name are required.");
      return;
    }

    try {
      await toast.promise(Driver.create(newDriver), {
        loading: 'Adding new driver...',
        success: 'Driver added successfully!',
        error: 'Failed to add driver.',
      });
      setShowAddDriverDialog(false);
      setNewDriver({ colleague_id: '', name: '', role: 'core' });
      loadDrivers();
    } catch (error) {
      console.error("Error adding driver:", error);
    }
  };

  const handleDeleteDriver = async () => {
    if (!driverToDelete || !canEdit) return;

    try {
        await toast.promise(Driver.delete(driverToDelete.id), {
            loading: 'Deleting driver...',
            success: 'Driver deleted successfully!',
            error: 'Failed to delete driver.',
        });
        setShowDeleteDialog(false);
        setDriverToDelete(null);
        await loadDrivers(); // Reload the list
    } catch (error) {
        console.error("Error deleting driver:", error);
        toast.error("An error occurred while deleting the driver.");
    }
  };

  const openDeleteDialog = (driver) => {
    setDriverToDelete(driver);
    setShowDeleteDialog(true);
  };

  const handleParseDriverData = () => {
    if (!driverPastedData.trim()) {
      toast.error("Paste data before parsing.");
      return;
    }
    const lines = driverPastedData.trim().split('\n');
    const toCreate = [];
    const toUpdate = [];

    lines.forEach(line => {
      if (!line.trim()) return;
      
      const parts = line.split('\t').map(s => s.trim());
      let colleague_id, name, role = 'core';
      
      if (parts.length === 1) {
        name = parts[0];
        colleague_id = parts[0]; 
      } else if (parts.length === 2) {
        colleague_id = parts[0];
        name = parts[1];
      } else if (parts.length >= 3) {
        colleague_id = parts[0];
        name = parts[1];
        const roleInput = parts[2].toLowerCase();
        if (['core', 'backup', 'c&c', 'shunter'].includes(roleInput)) {
          role = roleInput;
        } else {
            console.warn(`Invalid role "${roleInput}" for driver "${name}". Defaulting to 'core'.`);
        }
      } else {
        toast.warning(`Skipping invalid line: ${line}`);
        return;
      }

      if (!name) {
        toast.warning(`Skipping invalid line: ${line}`);
        return;
      }

      const existingDriver = drivers.find(d => d.colleague_id === colleague_id || d.name.toLowerCase() === name.toLowerCase());
      
      if (existingDriver) {
        toUpdate.push({ ...existingDriver, colleague_id: existingDriver.colleague_id, name: name, role: role });
      } else {
        toCreate.push({ colleague_id, name, role });
      }
    });

    setPreparedDrivers({ toCreate, toUpdate });
    setShowDriverReviewReviewDialog(true);
  };

  const handleConfirmDriverBulkSave = async () => {
    const { toCreate, toUpdate } = preparedDrivers;
    const promises = [];

    if (toCreate.length > 0) {
      promises.push(Driver.bulkCreate(toCreate));
    }

    if (toUpdate.length > 0) {
      toUpdate.forEach(driver => {
        promises.push(Driver.update(driver.id, { name: driver.name, role: driver.role }));
      });
    }
    
    if (promises.length === 0) {
      toast.info("No driver changes to save.");
      return;
    }

    try {
      await toast.promise(Promise.all(promises), {
        loading: 'Saving all driver changes...',
        success: 'Drivers updated successfully!',
        error: 'Error saving driver data.',
      });
      
      setShowDriverReviewReviewDialog(false);
      setDriverPastedData("");
      setPreparedDrivers({ toCreate: [], toUpdate: [] });
      loadDrivers();
    } catch (error) {
      console.error("Error saving bulk drivers:", error);
    }
  };

  const toBoolean = (value) => {
    if (typeof value === 'string') {
        const lowerValue = value.toLowerCase().trim();
        return lowerValue === 'yes' || lowerValue === 'true' || lowerValue === '1';
    }
    return !!value;
  };

  const handleParseSimsData = () => {
    if (!simsDataPasted.trim()) {
        toast.error("Please paste data before parsing.");
        return;
    }

    const lines = simsDataPasted.trim().split('\n');
    const headerLine = lines[0].toLowerCase().split('\t').map(h => h.trim().replace(/"/g, ''));
    
    const headerMapping = {
        name: ['name', 'driver name', 'colleague'],
        is_in_sims: ['sims'],
        dbs_approved: ['dbs', 'dbs approved'],
        is_driver_mentor: ['mentor', 'driver mentor'],
        is_on_ttc: ['ttc'],
        is_on_masternaut: ['masternaut', 'mn'],
        driving_status: ['driving status', 'status'],
        role: ['role', 'driver type']
    };

    const fieldMap = {};
    for (const [field, possibleHeaders] of Object.entries(headerMapping)) {
        const index = headerLine.findIndex(h => possibleHeaders.includes(h));
        if (index !== -1) {
            fieldMap[field] = index;
        }
    }

    if (fieldMap.name === undefined) {
        toast.error("Pasted data must contain a 'Name' column.");
        return;
    }

    const updates = [];
    const notFound = [];
    const dataRows = lines.slice(1);

    for (const row of dataRows) {
        if (!row.trim()) continue;
        const values = row.split('\t').map(v => v.trim().replace(/"/g, ''));
        const driverName = values[fieldMap.name];

        const driver = drivers.find(d => d.name.toLowerCase() === driverName.toLowerCase());

        if (driver) {
            const payload = {};
            let hasChange = false;
            
            for (const [field, index] of Object.entries(fieldMap)) {
                if (field === 'name') continue;
                
                if (index !== undefined && values[index] !== undefined && values[index] !== '') {
                    if (field === 'driving_status') {
                        const statusValue = values[index].charAt(0).toUpperCase() + values[index].slice(1).toLowerCase();
                        const validStatuses = ["Active", "Suspended", "Training", "Leaver"];
                        if (validStatuses.includes(statusValue) && driver[field] !== statusValue) {
                            payload[field] = statusValue;
                            hasChange = true;
                        }
                    } else if (field === 'role') {
                        const roleValue = values[index].toLowerCase();
                        const validRoles = ["core", "backup", "c&c", "shunter"];
                        if (validRoles.includes(roleValue) && driver[field] !== roleValue) {
                            payload[field] = roleValue;
                            hasChange = true;
                        }
                    }
                    else {
                        const boolValue = toBoolean(values[index]);
                        if (driver[field] !== boolValue) {
                            payload[field] = boolValue;
                            hasChange = true;
                        }
                    }
                }
            }
            
            if (hasChange) {
                updates.push({ driverId: driver.id, name: driver.name, payload });
            }
        } else {
            notFound.push(driverName);
        }
    }

    setPreparedSimsUpdates({ updates, notFound });
    setShowSimsReviewDialog(true);
  };

  const handleConfirmSimsBulkUpdate = async () => {
    if (preparedSimsUpdates.updates.length === 0) {
        toast.info("No new updates to perform.");
        setShowSimsReviewDialog(false);
        return;
    }

    const updatePromises = preparedSimsUpdates.updates.map(update =>
        Driver.update(update.driverId, update.payload)
    );

    try {
        await toast.promise(Promise.all(updatePromises), {
            loading: 'Applying bulk SIMS updates...',
            success: `${preparedSimsUpdates.updates.length} driver(s) updated successfully!`,
            error: 'An error occurred during the bulk update.',
        });
        
        await loadDrivers();
    } catch (error) {
        console.error("Bulk SIMS update failed:", error);
    } finally {
        setShowSimsReviewDialog(false);
        setPreparedSimsUpdates({ updates: [], notFound: [] });
        setSimsDataPasted("");
    }
  };

  if (isAuthLoading) {
    return (
      <div className="p-6 space-y-6 min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }



  return (
    <div className="p-6 space-y-6 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Driver Management</h1>
          <p className="text-gray-600 mt-1">Manage driver roster and statuses.</p>
        </div>
        {canEdit && (
          <div className="flex items-center gap-2">
            <Button 
                variant="outline" 
                size="sm" 
                onClick={handleResetChanges}
                className="border-gray-300 text-gray-700 hover:bg-gray-50 font-medium px-4 py-2"
            >
              <RotateCw className="w-4 h-4 mr-2" />
              Reset Changes
            </Button>
            <Button 
                size="sm" 
                onClick={handleSaveChanges}
                className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-4 py-2"
            >
              <Save className="w-4 h-4 mr-2" />
              Save All Changes
            </Button>
            <Button 
                size="sm" 
                onClick={() => setShowAddDriverDialog(true)}
                className="bg-green-600 hover:bg-green-700 text-white font-medium px-4 py-2"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Driver
            </Button>
          </div>
        )}
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Driver Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-6 border-b pb-6">
            <h3 className="text-lg font-medium mb-2">Bulk Add/Update Drivers</h3>
            <p className="text-sm text-gray-600 mb-4">
              Paste driver names from a spreadsheet. You can paste ID and Name (tab-separated), or ID, Name, and Role (Core/Backup/C&C/Shunter).
            </p>
            <Textarea
              placeholder={`Paste driver data here...\n\nFormat 1 (Names only):\nJohn Doe\nJane Smith\n\nFormat 2 (ID + Name):\n12345\tJohn Doe\n67890\tJane Smith\n\nFormat 3 (ID + Name + Role):\n12345\tJohn Doe\tCore\n67890\tJane Smith\tBackup\n11223\tPeter Pan\tShunter`}
              className="h-40 w-full font-mono text-sm"
              value={driverPastedData}
              onChange={(e) => setDriverPastedData(e.target.value)}
            />
            <div className="mt-4 flex justify-start">
              <Button 
                  onClick={handleParseDriverData} 
                  disabled={!driverPastedData.trim() || !canEdit}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2"
              >
                <ClipboardPaste className="w-4 h-4 mr-2" />
                Parse & Review Driver Data
              </Button>
            </div>
          </div>
          
          {/* New SIMS, TTC & MN Bulk Update Section */}
          <div className="mb-6 border-b pb-6">
            <h3 className="text-lg font-medium mb-2">Bulk Update SIMS, TTC & MN Data</h3>
            <p className="text-sm text-gray-600 mb-4">
              Copy data from a spreadsheet (including headers) to update multiple drivers at once. Required column: 'Name'. Optional columns: 'SIMS', 'DBS', 'Mentor', 'TTC', 'Masternaut', 'Driving Status', 'Role'.
            </p>
            <Textarea
              placeholder="Paste SIMS/TTC/MN data here..."
              className="h-40 w-full font-mono text-sm"
              value={simsDataPasted}
              onChange={(e) => setSimsDataPasted(e.target.value)}
              disabled={!canEdit}
            />
            <div className="mt-4 flex justify-between items-center">
              <Button 
                  onClick={handleParseSimsData} 
                  disabled={!simsDataPasted.trim() || !canEdit}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2"
              >
                <ClipboardPaste className="w-4 h-4 mr-2" />
                Parse & Review SIMS Data
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setSimsDataPasted("")} disabled={!simsDataPasted.trim()}>
                <Trash2 className="w-4 h-4 mr-2" /> Clear
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Colleague ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {editedDrivers.map((driver) => (
                  <TableRow key={driver.id}>
                    <TableCell>
                      <Input
                        value={driver.colleague_id || ''}
                        onChange={(e) => handleDriverChange(driver.id, 'colleague_id', e.target.value)}
                        className="w-full"
                        disabled={!canEdit}
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        value={driver.name || ''}
                        onChange={(e) => handleDriverChange(driver.id, 'name', e.target.value)}
                        className="w-full"
                        disabled={!canEdit}
                      />
                    </TableCell>
                    <TableCell>
                      <Select
                        value={driver.role || 'core'}
                        onValueChange={(value) => handleDriverChange(driver.id, 'role', value)}
                        disabled={!canEdit}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="core">Core</SelectItem>
                          <SelectItem value="backup">Backup</SelectItem>
                          <SelectItem value="c&c">C&C</SelectItem>
                          <SelectItem value="shunter">Shunter</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        driver.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {driver.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </TableCell>
                    <TableCell>
                      {canEdit && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openDeleteDialog(driver)}
                          className="text-red-600 hover:bg-red-50 hover:text-red-700"
                          title="Delete Driver"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={showAddDriverDialog} onOpenChange={setShowAddDriverDialog}>
        <DialogContent className="bg-white border border-gray-200 shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-gray-900 text-xl font-semibold">Add New Driver</DialogTitle>
            <DialogDescription className="text-gray-600">
              Enter the details for the new driver.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Colleague ID</label>
              <Input
                value={newDriver.colleague_id}
                onChange={(e) => setNewDriver({...newDriver, colleague_id: e.target.value})}
                placeholder="Enter colleague ID"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Name</label>
              <Input
                value={newDriver.name}
                onChange={(e) => setNewDriver({...newDriver, name: e.target.value})}
                placeholder="Enter full name"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Role</label>
              <Select
                value={newDriver.role}
                onValueChange={(value) => setNewDriver({...newDriver, role: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="core">Core</SelectItem>
                  <SelectItem value="backup">Backup</SelectItem>
                  <SelectItem value="c&c">C&C</SelectItem>
                  <SelectItem value="shunter">Shunter</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDriverDialog(false)} className="border-gray-300 text-gray-700">
              Cancel
            </Button>
            <Button onClick={handleAddDriver} className="bg-blue-600 hover:bg-blue-700 text-white">
              Add Driver
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog open={showDriverReviewDialog} onOpenChange={setShowDriverReviewReviewDialog}>
        <DialogContent className="max-w-3xl bg-white border border-gray-200 shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-gray-900 text-xl font-semibold">Review Driver Changes</DialogTitle>
            <DialogDescription className="text-gray-600">
              Review the drivers to be created and updated.
            </DialogDescription>
          </DialogHeader>
          <div className="grid md:grid-cols-2 gap-6 max-h-[60vh] overflow-y-auto p-1">
            <div>
              <h4 className="font-semibold mb-2 text-green-600">New Drivers to Add ({preparedDrivers.toCreate.length})</h4>
              <div className="space-y-2">
                {preparedDrivers.toCreate.length > 0 ? preparedDrivers.toCreate.map(d => (
                  <div key={d.colleague_id} className="text-sm p-2 bg-green-50 rounded-md">
                    <p><b>ID:</b> {d.colleague_id}</p>
                    <p><b>Name:</b> {d.name}</p>
                    <p><b>Role:</b> {d.role}</p>
                  </div>
                )) : <p className="text-sm text-gray-500">No new drivers.</p>}
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-blue-600">Drivers to Update ({preparedDrivers.toUpdate.length})</h4>
              <div className="space-y-2">
                {preparedDrivers.toUpdate.length > 0 ? preparedDrivers.toUpdate.map(d => (
                  <div key={d.id} className="text-sm p-2 bg-blue-50 rounded-md">
                    <p><b>ID:</b> {d.colleague_id}</p>
                    <p><b>Name:</b> {d.name}</p>
                    <p><b>Role:</b> {d.role}</p>
                  </div>
                )) : <p className="text-sm text-gray-500">No drivers to update.</p>}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDriverReviewReviewDialog(false)} className="border-gray-300 text-gray-700">Cancel</Button>
            <Button onClick={handleConfirmDriverBulkSave} className="bg-blue-600 hover:bg-blue-700 text-white">Confirm & Save All</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showSimsReviewDialog} onOpenChange={setShowSimsReviewDialog}>
        <DialogContent className="max-w-3xl bg-white border border-gray-200 shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-gray-900 text-xl font-semibold">Review SIMS, TTC & MN Updates</DialogTitle>
            <DialogDescription className="text-gray-600">
              Review the changes to be applied. No changes will be made for drivers who already match the data.
            </DialogDescription>
          </DialogHeader>
          <div className="grid md:grid-cols-2 gap-6 max-h-[60vh] overflow-y-auto p-1">
            <div>
              <h4 className="font-semibold mb-2 text-blue-600">Drivers to Update ({preparedSimsUpdates.updates.length})</h4>
              {preparedSimsUpdates.updates.length > 0 ? (
                <div className="space-y-2">
                  {preparedSimsUpdates.updates.map(update => (
                    <div key={update.driverId} className="text-sm p-2 bg-blue-50 rounded-md border border-blue-100">
                      <p className="font-bold">{update.name}</p>
                      <ul className="list-disc pl-5 mt-1">
                        {Object.entries(update.payload).map(([key, value]) => (
                          <li key={key}>
                            <span className="capitalize">{key.replace(/_/g, ' ')}:</span>
                            <span className="font-medium ml-2">{String(value)}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              ) : <p className="text-sm text-gray-500">No new updates found.</p>}
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-red-600">Drivers Not Found ({preparedSimsUpdates.notFound.length})</h4>
              {preparedSimsUpdates.notFound.length > 0 ? (
                <div className="space-y-2">
                  {preparedSimsUpdates.notFound.map((name, index) => (
                    <div key={index} className="text-sm p-2 bg-red-50 rounded-md border border-red-100">
                      {name}
                    </div>
                  ))}
                </div>
              ) : <p className="text-sm text-gray-500">All drivers were found.</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSimsReviewDialog(false)}>Cancel</Button>
            <Button onClick={handleConfirmSimsBulkUpdate} disabled={preparedSimsUpdates.updates.length === 0}>
              Confirm & Save {preparedSimsUpdates.updates.length} Updates
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="bg-white border border-gray-200 shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-gray-900 text-xl font-semibold">Confirm Deletion</DialogTitle>
            <DialogDescription className="text-gray-600">
                Are you sure you want to delete the driver "{driverToDelete?.name}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)} className="border-gray-300 text-gray-700">
                Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteDriver} className="bg-red-600 hover:bg-red-700 text-white">
                <Trash2 className="w-4 h-4 mr-2" />
                Delete Driver
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}