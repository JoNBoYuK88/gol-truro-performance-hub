import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { PeriodConfig } from "@/api/entities";
import { useEditLock } from "../Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Calendar, Edit, Save, X, Trash2, Plus, FileDown } from "lucide-react";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function PeriodSettings() {
  const [periods, setPeriods] = useState([]);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [isLoading, setIsLoading] = useState(true);
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;

  const [isEditing, setIsEditing] = useState(false);
  const [editedPeriods, setEditedPeriods] = useState([]);

  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [periodToDelete, setPeriodToDelete] = useState(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newPeriod, setNewPeriod] = useState({
    period_number: 1,
    start_date: '',
    end_date: '',
    year: new Date().getFullYear(),
    is_active: false
  });

  useEffect(() => {
    const checkUserRoleAndLoadData = async () => {
        setIsLoading(true);
        try {
            const currentUser = await User.me();
            setIsAdmin(currentUser && currentUser.role === 'admin');
            await loadPeriods();
        } catch (error) {
            setIsAdmin(false);
            setPeriods([]);
        } finally {
            setIsLoading(false);
        }
    };
    checkUserRoleAndLoadData();
  }, [currentYear]);

  const loadPeriods = async () => {
    try {
      const data = await PeriodConfig.filter({ year: currentYear }, 'period_number');
      setPeriods(data);
    } catch (error) {
      console.error("Error loading periods:", error);
      toast.error("Failed to load period data.");
      setPeriods([]);
    }
  };

  const handleEditToggle = () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to edit data.");
      return;
    }
    if (isEditing) {
        handleSave();
    } else {
        setEditedPeriods(JSON.parse(JSON.stringify(periods)));
        setIsEditing(true);
    }
  };

  const handleCancelEdit = () => {
      setIsEditing(false);
      setEditedPeriods([]);
      toast.info("Edit mode cancelled. Changes were not saved.");
  };

  const handleInputChange = (id, field, value) => {
    if (!canEdit || !isEditing) return;
    setEditedPeriods(prev => prev.map(p => (p.id === id ? { ...p, [field]: value } : p)));
  };

  const handleSave = async () => {
    if (!canEdit) return;

    for (const editedPeriod of editedPeriods) {
        if (!editedPeriod.start_date || !editedPeriod.end_date) {
            toast.error(`Start and End dates are required for Period ${editedPeriod.period_number}. Please correct before saving.`);
            return;
        }
    }

    const updatesToSend = [];
    editedPeriods.forEach(editedPeriod => {
        const originalPeriod = periods.find(p => p.id === editedPeriod.id);
        if (!originalPeriod) return; 

        const hasChanged =
            editedPeriod.start_date !== originalPeriod.start_date ||
            editedPeriod.end_date !== originalPeriod.end_date ||
            editedPeriod.is_active !== originalPeriod.is_active;

        if (hasChanged) {
            updatesToSend.push(PeriodConfig.update(editedPeriod.id, {
                start_date: editedPeriod.start_date,
                end_date: editedPeriod.end_date,
                is_active: editedPeriod.is_active
            }));
        }
    });

    if (updatesToSend.length === 0) {
        toast.info("No changes detected to save.");
        setIsEditing(false);
        setEditedPeriods([]);
        return;
    }

    toast.promise(Promise.all(updatesToSend), {
        loading: 'Saving all period changes...',
        success: () => {
            loadPeriods();
            setIsEditing(false);
            setEditedPeriods([]);
            return "All changes saved successfully!";
        },
        error: (err) => {
            console.error("Error updating periods:", err);
            const errorMessage = err.response && err.response.data && err.response.data.message
                ? `Failed to save changes: ${err.response.data.message}`
                : "Failed to save some changes. Please check your data and try again.";
            return errorMessage;
        },
    });
  };

  const handleDelete = (period) => {
    if (!canEdit) return;
    setPeriodToDelete(period);
    setShowDeleteDialog(true);
  };

  const confirmDelete = async () => {
    if (!canEdit || !periodToDelete) return;

    try {
      await PeriodConfig.delete(periodToDelete.id);
      toast.success("Period deleted successfully!");
      loadPeriods();
    } catch (error) {
      console.error("Error deleting period:", error);
      toast.error("Failed to delete period.");
    } finally {
      setShowDeleteDialog(false);
      setPeriodToDelete(null);
    }
  };

  const handleAddPeriod = async () => {
    if (!canEdit) return;

    if (!newPeriod.period_number || !newPeriod.start_date || !newPeriod.end_date || !newPeriod.year) {
      toast.error("All fields are required to add a new period.");
      return;
    }

    try {
      const periodToAdd = {
        ...newPeriod,
        period_number: parseInt(newPeriod.period_number),
        year: parseInt(newPeriod.year)
      };

      await PeriodConfig.create(periodToAdd);
      toast.success("Period added successfully!");
      setShowAddDialog(false);
      setNewPeriod({
        period_number: 1,
        start_date: '',
        end_date: '',
        year: currentYear,
        is_active: false
      });
      loadPeriods();
    } catch (error) {
      console.error("Error adding period:", error);
      if (error.response && error.response.data && error.response.data.message) {
        toast.error(error.response.data.message);
      } else {
        toast.error("Failed to add period.");
      }
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6 min-h-screen">
        <div className="flex flex-col items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading period settings...</p>
        </div>
      </div>
    );
  }



  const dataToDisplay = isEditing ? editedPeriods : periods;

  return (
    <div className="p-6 space-y-6 min-h-screen">
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete Period {periodToDelete?.period_number} for year {periodToDelete?.year}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDelete}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Period</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Period Number</label>
              <Input
                type="number"
                value={newPeriod.period_number}
                onChange={(e) => setNewPeriod(prev => ({ ...prev, period_number: parseInt(e.target.value) || '' }))}
                placeholder="e.g., 1"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Start Date</label>
              <Input
                type="date"
                value={newPeriod.start_date}
                onChange={(e) => setNewPeriod(prev => ({ ...prev, start_date: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">End Date</label>
              <Input
                type="date"
                value={newPeriod.end_date}
                onChange={(e) => setNewPeriod(prev => ({ ...prev, end_date: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Year</label>
              <Input
                type="number"
                value={newPeriod.year}
                onChange={(e) => setNewPeriod(prev => ({ ...prev, year: parseInt(e.target.value) || '' }))}
                placeholder="e.g., 2024"
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="is_active_new"
                checked={newPeriod.is_active}
                onChange={(e) => setNewPeriod(prev => ({ ...prev, is_active: e.target.checked }))}
                className="h-4 w-4 text-blue-600 focus:ring-blue-600 border-gray-300 rounded"
              />
              <label htmlFor="is_active_new" className="text-sm font-medium">Is Active</label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
            <Button onClick={handleAddPeriod}>Add Period</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 no-print">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Manage Financial Periods</h1>
          <p className="text-gray-600 mt-1">Configure the start and end dates for each financial period.</p>
        </div>
        <div className="flex items-center gap-2">
            {canEdit && (
                <>
                    {isEditing && (
                        <Button variant="outline" size="sm" onClick={handleCancelEdit}>
                            <X className="w-4 h-4 mr-2"/>
                            Cancel
                        </Button>
                    )}
                    <Button
                        size="sm"
                        onClick={handleEditToggle}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                        {isEditing ? <><Save className="w-4 h-4 mr-2"/>Save Changes</> : <><Edit className="w-4 h-4 mr-2"/>Edit Mode</>}
                    </Button>
                </>
            )}
          <Button size="sm" onClick={() => setShowAddDialog(true)} className="bg-blue-600 hover:bg-blue-700 text-white" disabled={isEditing}>
            <Plus className="w-4 h-4 mr-2" />
            Add Period
          </Button>
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <FileDown className="w-4 h-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              Financial Periods for {currentYear}
            </CardTitle>
            <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))} disabled={isEditing}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() + i - 2).map(y => (
                  <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Period</TableHead>
                <TableHead>Start Date</TableHead>
                <TableHead>End Date</TableHead>
                <TableHead>Year</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dataToDisplay && dataToDisplay.map((period) => (
                <TableRow key={period.id || `period-${period.period_number}`}>
                  <TableCell className="font-medium">Period {period.period_number}</TableCell>
                  <TableCell>
                    {isEditing ? (
                      <Input
                        type="date"
                        value={period.start_date || ''}
                        onChange={(e) => handleInputChange(period.id, 'start_date', e.target.value)}
                        disabled={!isEditing}
                      />
                    ) : (
                      period.start_date ? new Date(period.start_date + 'T00:00:00').toLocaleDateString() : '—'
                    )}
                  </TableCell>
                  <TableCell>
                    {isEditing ? (
                      <Input
                        type="date"
                        value={period.end_date || ''}
                        onChange={(e) => handleInputChange(period.id, 'end_date', e.target.value)}
                        disabled={!isEditing}
                      />
                    ) : (
                      period.end_date ? new Date(period.end_date + 'T00:00:00').toLocaleDateString() : '—'
                    )}
                  </TableCell>
                  <TableCell>{period.year}</TableCell>
                  <TableCell>
                    {isEditing ? (
                      <Select
                        value={period.is_active ? "active" : "inactive"}
                        onValueChange={(val) => handleInputChange(period.id, 'is_active', val === 'active')}
                        disabled={!isEditing}
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        period.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {period.is_active ? 'Active' : 'Inactive'}
                      </span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-red-600"
                        onClick={() => handleDelete(period)}
                        disabled={isEditing}
                    >
                        <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}