import React, { useState, useEffect, useCallback, memo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Loader2, AlertTriangle, CheckCircle, BarChart, ShoppingCart, PoundSterling, Shield, MessageSquare, Wrench, Users, Target, Package, Presentation, FileDown, Image, X, TrendingUp, TrendingDown, Minus, Save } from 'lucide-react';
import { PeriodConfig } from '@/api/entities';
import { WormReview } from '@/api/entities'; // Keeping existing entity import
import { KPIMetric } from '@/api/entities';
import { CustomerComplaint } from '@/api/entities';
import { DeliveryCostReportData } from '@/api/entities';
import { Forecast } from '@/api/entities';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { UploadFile } from "@/api/integrations";
import { toast } from "sonner";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart as RechartsBarChart, Bar, XAxis, YAxis, Legend } from 'recharts'; // Renamed BarChart from recharts to avoid conflict with lucide-react
import { Toggle } from '@/components/ui/toggle'; // New import from outline
import { User } from '@/api/entities'; // New import from outline

import PresentationSlides from "../components/presentation/PresentationSlides";

const MetricBox = ({ icon: Icon, title, data, colorClass, unit = '' }) => {
    // data is expected to be an object { value: any, isSaved?: boolean }
    const value = data?.value;
    const isSaved = data?.isSaved;

    const formattedValue = () => {
        if (value === null || value === undefined || value === 'No data') return 'No data';
        
        const numericVal = parseFloat(value);
        if (isNaN(numericVal)) return String(value); // Ensure it's a string if not a number

        switch (unit) {
            case 'currency':
                const sign = numericVal < 0 ? '-' : '';
                const absoluteVal = Math.abs(numericVal);
                return `${sign}£${absoluteVal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
            case 'percentage':
                 if (title === "Ops Score") return `${numericVal.toFixed(0)}%`;
                 if (title === "iCare Score") return `${numericVal.toFixed(1)}%`;
                 if (title === "Sec Replen") return `${numericVal.toFixed(3)}%`;
                 if (title === "Sales YOY%") return `${numericVal.toFixed(1)}%`; // Added condition for Sales YOY%
                 return `${numericVal.toFixed(2)}%`;
            case 'number':
                return numericVal.toLocaleString();
            default:
                return String(value);
        }
    };

    return (
        <div className={`p-4 rounded-lg flex flex-col items-center justify-center text-center ${colorClass} relative`}>
             {isSaved && (
                <div className="absolute top-2 right-2" title="This is a manually saved value, not a calculation.">
                    <Save className="w-3.5 h-3.5 text-slate-500" />
                </div>
            )}
            <div className="flex items-center justify-center gap-2">
                <h3 className="text-sm font-semibold text-slate-600">{title}</h3>
                {Icon && <Icon className="w-5 h-5" />} {/* Added icon rendering back */}
            </div>
            <p className="text-2xl font-bold mt-1">
                {formattedValue()}
            </p>
        </div>
    );
};

const SalesSummaryCard = memo(({ salesData, labourData }) => {
    if (!salesData || !labourData) {
        return (
            <Card className="bg-white/80 backdrop-blur-sm border-[3px] border-slate-400 flex flex-col shadow-none rounded-none">
                <CardHeader><CardTitle className="text-base font-semibold text-slate-700">Sales & Labour Summary</CardTitle></CardHeader>
                <CardContent><p className="text-slate-500 text-center py-8">No data available for this period.</p></CardContent>
            </Card>
        );
    }
    
    return (
        <Card className="bg-white/80 backdrop-blur-sm border-[3px] border-slate-400 flex flex-col shadow-none rounded-none">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base font-semibold text-slate-700">Sales & Labour Summary</CardTitle>
                <BarChart className="w-5 h-5 text-green-500" />
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    {/* Sales Metrics - New Order */}
                    <MetricBox icon={PoundSterling} title="Sales" data={salesData.sales} unit="currency" colorClass='bg-slate-100 text-slate-800' />
                    <MetricBox icon={PoundSterling} title="vs Last Year" data={salesData.vsLastYear} unit="currency" colorClass={salesData.vsLastYear?.value >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'} />
                    <MetricBox icon={PoundSterling} title="vs Budget" data={salesData.vsBudget} unit="currency" colorClass={salesData.vsBudget?.value >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'} />
                    <MetricBox icon={BarChart} title="Sales YOY%" data={salesData.salesYOY} unit="percentage" colorClass={salesData.salesYOY?.value >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'} />
                    <MetricBox icon={ShoppingCart} title="Orders" data={salesData.orders} unit="number" colorClass='bg-slate-100 text-slate-800' />
                    <MetricBox icon={ShoppingCart} title="Items" data={salesData.items} unit="number" colorClass='bg-slate-100 text-slate-800' />
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-4 mt-4">
                    {/* Labour Metrics - New Order */}
                    <MetricBox icon={Target} title="Labour Forecast" data={{ value: labourData?.labour_forecast }} unit="number" colorClass="bg-slate-100 text-slate-800" />
                    <MetricBox icon={CheckCircle} title="Labour Actual" data={{ value: labourData?.labour_actual }} unit="number" colorClass="bg-slate-100 text-slate-800" />
                    <MetricBox icon={BarChart} title="F vs A" data={{ value: labourData ? (labourData.labour_actual - labourData.labour_forecast) : null }} unit="number" colorClass={labourData && (labourData.labour_actual - labourData.labour_forecast) >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'} />
                    <MetricBox icon={Users} title="Worked Hours" data={{ value: labourData?.labour_worked_hours }} unit="number" colorClass="bg-blue-100 text-blue-800" />
                    <MetricBox icon={BarChart} title="Labour Variance" data={{ value: labourData?.labour_variance }} unit="number" colorClass={labourData && labourData.labour_variance >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'} />
                    <MetricBox icon={Package} title="Items Actual" data={{ value: labourData?.items_actual }} unit="number" colorClass="bg-slate-100 text-slate-800" />
                    <MetricBox icon={BarChart} title="Items Variance" data={{ value: labourData?.items_variance }} unit="number" colorClass={labourData && labourData.items_variance >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'} />
                </div>
            </CardContent>
        </Card>
    );
});


const OpsAndCustomerCard = memo(({ opsData, dwc, iCare }) => {
    if (!opsData && !dwc && !iCare) {
        return (
            <Card className="bg-white/80 backdrop-blur-sm border-[3px] border-slate-400 flex flex-col shadow-none rounded-none">
                <CardHeader><CardTitle className="text-base font-semibold text-slate-700">Ops & Customer Metrics</CardTitle></CardHeader>
                <CardContent><p className="text-slate-500 text-center py-8">No data available for this period.</p></CardContent>
            </Card>
        );
    }
    
    const opsScore = opsData?.['Ops Score'];
    const shoppersAchieving = opsData?.['Shoppers Achieving'];
    const onTimeDepartures = opsData?.['On Time Departures'];
    const availability = opsData?.['Availability'];
    const dwcValue = opsData?.['Delivery Without Complaints']; // From opsData, not dwc directly
    const secReplen = opsData?.['Secondary Replenishment'];
    const iCareScore = iCare?.score;

    return (
        <Card className="bg-white/80 backdrop-blur-sm border-[3px] border-slate-400 flex flex-col shadow-none rounded-none">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base font-semibold text-slate-700">Ops & Customer Metrics</CardTitle>
                <Shield className="w-5 h-5 text-blue-500" />
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
                    <MetricBox icon={CheckCircle} title="Ops Score" data={{ value: opsScore }} unit="percentage" colorClass={opsScore != null ? (opsScore >= 80 ? 'bg-green-100 text-green-800' : opsScore >= 60 ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800') : 'bg-slate-100 text-slate-800'} />
                    <MetricBox icon={CheckCircle} title="Shoppers" data={{ value: shoppersAchieving }} unit="percentage" colorClass={shoppersAchieving != null ? (shoppersAchieving >= 80 ? 'bg-green-100 text-green-800' : shoppersAchieving >= 60 ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800') : 'bg-slate-100 text-slate-800'} />
                    <MetricBox icon={CheckCircle} title="OTDept" data={{ value: onTimeDepartures }} unit="percentage" colorClass={onTimeDepartures != null ? (onTimeDepartures >= 98 ? 'bg-green-100 text-green-800' : onTimeDepartures >= 95 ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800') : 'bg-slate-100 text-slate-800'} />
                    <MetricBox icon={CheckCircle} title="Availability" data={{ value: availability }} unit="percentage" colorClass={availability != null ? (availability >= 97 ? 'bg-green-100 text-green-800' : availability >= 95 ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800') : 'bg-slate-100 text-slate-800'} />
                    <MetricBox icon={AlertTriangle} title="DWC" data={{ value: dwcValue }} unit="percentage" colorClass={dwcValue != null ? (dwcValue >= 98 ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800') : 'bg-slate-100 text-slate-800'} />
                    <MetricBox icon={AlertTriangle} title="Sec Replen" data={{ value: secReplen }} unit="percentage" colorClass={secReplen != null ? (secReplen <= 2 ? 'bg-green-100 text-green-800' : secReplen <= 2.5 ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800') : 'bg-slate-100 text-slate-800'} />
                    <MetricBox icon={CheckCircle} title="iCare Score" data={{ value: iCareScore }} unit="percentage" colorClass={iCareScore != null ? (iCareScore >= 49.5 ? 'bg-green-100 text-green-800' : iCareScore >= 49.4 ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800') : 'bg-slate-100 text-slate-800'} />
                    <MetricBox icon={PoundSterling} title="Goodwill & Refunds" data={{ value: dwc ? (dwc['goodwill_refunds'] || 0) : 'No data' }} unit="currency" colorClass='bg-slate-100 text-slate-800' />
                </div>
            </CardContent>
        </Card>
    );
});

export default function PeriodResults() {
    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
    const [currentPeriod, setCurrentPeriod] = useState(1);
    const [isYearToDate, setIsYearToDate] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [isPresentationMode, setIsPresentationMode] = useState(false);
    const [backgroundImage, setBackgroundImage] = useState(null);

    const [opsReadinessData, setOpsReadinessData] = useState(null);
    const [salesSummaryData, setSalesSummaryData] = useState(null);
    const [dwcData, setDwcData] = useState(null);
    const [iCareData, setICareData] = useState(null);
    const [costReportData, setCostReportData] = useState(null);
    const [accidentReportData, setAccidentReportData] = useState([]);
    const [finesReportData, setFinesReportData] = useState([]);
    const [damageBreakdownData, setDamageBreakdownData] = useState([]);
    const [labourData, setLabourData] = useState(null);
    const [complaintsChartData, setComplaintsChartData] = useState([]);

    useEffect(() => {
        const savedBg = localStorage.getItem('periodResultsExportBg');
        if (savedBg) {
            setBackgroundImage(savedBg);
        }

        const initializeDefaultPeriod = async () => {
            try {
                const today = new Date();
                const currentYearValue = today.getFullYear();
                const periodsData = await PeriodConfig.filter({ year: currentYearValue });

                if (periodsData && periodsData.length > 0) {
                    const currentPeriodConfig = periodsData.find(p => {
                        const startDate = new Date(p.start_date);
                        const endDate = new Date(p.end_date);
                        today.setHours(0, 0, 0, 0);
                        startDate.setHours(0, 0, 0, 0);
                        endDate.setHours(0, 0, 0, 0);
                        return today >= startDate && today <= endDate;
                    });

                    if (currentPeriodConfig) {
                        // FIXED: Show the actual current period, not previous period
                        setCurrentYear(currentYearValue);
                        setCurrentPeriod(currentPeriodConfig.period_number);
                    } else {
                        const latestPeriod = [...periodsData].sort((a, b) => b.period_number - a.period_number)[0];
                        if (latestPeriod) {
                            setCurrentYear(currentYearValue);
                            setCurrentPeriod(latestPeriod.period_number);
                        } else {
                            setCurrentPeriod(1);
                        }
                    }
                } else {
                    setCurrentPeriod(1);
                }
            } catch (error) {
                console.error("Failed to set default period:", error);
                setCurrentPeriod(1);
            }
        };
        initializeDefaultPeriod();
    }, []);

    const loadPeriodData = useCallback(async () => {
        if ((!currentPeriod && !isYearToDate) || !currentYear) return;
        setIsLoading(true);

        try {
            // Log for debugging
            console.log('Loading data for:', { year: currentYear, period: isYearToDate ? 'YTD' : currentPeriod, isYearToDate });
            
            const [allMetrics, complaints, costReportsData, periodForecastDataFromPromiseAll] = await Promise.all([
                KPIMetric.filter({ year: currentYear }, '-created_date', 5000),
                isYearToDate 
                    ? CustomerComplaint.filter({ year: currentYear })
                    : CustomerComplaint.filter({ year: currentYear, period: currentPeriod }),
                isYearToDate 
                    ? DeliveryCostReportData.filter({ year: currentYear })
                    : DeliveryCostReportData.filter({ year: currentYear, period: currentPeriod }),
                isYearToDate 
                    ? Forecast.filter({ year: currentYear })
                    : Forecast.filter({ year: currentYear, period: currentPeriod })
            ]);

            console.log('Period Data Debug:', {
                year: currentYear,
                period: isYearToDate ? 'YTD' : currentPeriod,
                isYearToDate,
                allMetrics: allMetrics.length,
                complaints: complaints.length,
                costReports: costReportsData.length,
                forecasts: periodForecastDataFromPromiseAll.length,
                costReportsDetails: costReportsData.map(cr => ({ period: cr.period, year: cr.year }))
            });

            const weeklyMetricsForPeriod = isYearToDate 
                ? allMetrics.filter(m => m.week != null && m.week > 0)
                : allMetrics.filter(m => m.period === currentPeriod && m.week != null && m.week > 0);
            
            console.log('Weekly metrics for period (filtered for YTD/period):', weeklyMetricsForPeriod.length);

            const summaryKpiConfig = {
                opsScore: { name: "Ops Score", unit: 'percentage' },
                shoppers: { name: "Shoppers Achieving", unit: 'percentage' },
                otd: { name: "On Time Departures", unit: 'percentage' },
                availability: { name: "Availability", unit: 'percentage' },
                dwc: { name: "Delivery Without Complaints", unit: 'percentage', higherIsBetter: true },
                secReplen: { name: "Secondary Replenishment", unit: 'percentage', higherIsBetter: false },
                iCare: { name: "iCare", unit: 'percentage' }
            };

            const opsCalculatedData = {};
            for (const [key, config] of Object.entries(summaryKpiConfig)) {
                if (isYearToDate) {
                    const relevantWeeklyMetrics = weeklyMetricsForPeriod.filter(m => m.name === config.name);
                    const avg = relevantWeeklyMetrics.length > 0
                        ? relevantWeeklyMetrics.reduce((sum, m) => sum + (m.value || 0), 0) / relevantWeeklyMetrics.length
                        : null;
                    opsCalculatedData[config.name] = avg;
                } else {
                    const savedAggregate = allMetrics.find(m =>
                        m.name === config.name &&
                        m.year === currentYear &&
                        m.period === currentPeriod &&
                        m.quarter === null &&
                        m.week === null
                    );

                    if (savedAggregate) {
                        opsCalculatedData[config.name] = savedAggregate.value;
                    } else {
                        const relevantWeeklyMetrics = weeklyMetricsForPeriod.filter(m => m.name === config.name);
                        const avg = relevantWeeklyMetrics.length > 0
                            ? relevantWeeklyMetrics.reduce((sum, m) => sum + (m.value || 0), 0) / relevantWeeklyMetrics.length
                            : null;
                        opsCalculatedData[config.name] = avg;
                    }
                }
            }
            setOpsReadinessData(opsCalculatedData);

            console.log('Complaints data:', complaints);
            console.log('Forecast data:', periodForecastDataFromPromiseAll);

            // --- Sales Summary Data ---
            const salesSummaryConfig = {
                sales: { name: "Sales", unit: 'currency', aggregation: 'sum' },
                budget: { name: "Budget", unit: 'currency', aggregation: 'sum' }, // Kept for calculation, not displayed
                vsBudget: { name: "vs Budget", unit: 'currency', isCalculated: true },
                vsLastYear: { name: "Net Sales YOY", unit: 'currency', aggregation: 'sum' }, // Added for new metric
                salesYOY: { name: "Net Sales YOY (%)", unit: 'percentage', aggregation: 'avg' },
                orders: { name: "Delivered Orders", unit: 'number', aggregation: 'sum' },
                items: { name: "Delivered Items", unit: 'number', aggregation: 'sum' }
            };

            const salesCalculatedData = {};

            if (isYearToDate) {
                // YTD Sales calculations
                for (const [key, config] of Object.entries(salesSummaryConfig)) {
                    if (config.isCalculated) {
                        // vsBudget is calculated after sales and budget are determined
                        continue;
                    }

                    const relevantMetrics = weeklyMetricsForPeriod.filter(m => m.name === config.name);
                    let value = null;
                    if (relevantMetrics.length > 0) {
                        if (config.aggregation === 'avg') {
                            value = relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0) / relevantMetrics.length;
                        } else { // 'sum'
                            value = relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0);
                        }
                    }
                    salesCalculatedData[key] = { value: value, isSaved: false };
                }
                
                // Check for saved vs Budget aggregate for YTD
                const savedVsBudgetYTD = allMetrics.find(m =>
                    m.name === 'vs Budget' &&
                    m.year === currentYear &&
                    m.period === null &&
                    m.quarter === null &&
                    m.week === null
                );
                
                if (savedVsBudgetYTD) {
                    salesCalculatedData['vsBudget'] = { value: savedVsBudgetYTD.value, isSaved: true };
                } else {
                    // Sum weekly vs Budget values for YTD
                    const weeklyVsBudget = weeklyMetricsForPeriod.filter(m => m.name === 'vs Budget');
                    const vsBudgetSum = weeklyVsBudget.reduce((sum, m) => sum + (m.value || 0), 0);
                    salesCalculatedData['vsBudget'] = { value: vsBudgetSum, isSaved: false };
                }
            } else {
                // Single Period Sales calculations
                for (const [key, config] of Object.entries(salesSummaryConfig)) {
                    if (config.isCalculated) {
                        // vsBudget is calculated after sales and budget are determined
                        continue;
                    }

                    const savedAggregate = allMetrics.find(m =>
                        m.name === config.name &&
                        m.year === currentYear &&
                        m.period === currentPeriod &&
                        m.quarter === null &&
                        m.week === null
                    );

                    if (savedAggregate) {
                        salesCalculatedData[key] = { value: savedAggregate.value, isSaved: true };
                    } else {
                        const relevantMetrics = weeklyMetricsForPeriod.filter(m => m.name === config.name);
                        let value = null;
                        if (relevantMetrics.length > 0) {
                            if (config.aggregation === 'avg') {
                                value = relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0) / relevantMetrics.length;
                            } else { // 'sum'
                                value = relevantMetrics.reduce((sum, m) => sum + (m.value || 0), 0);
                            }
                        }
                        salesCalculatedData[key] = { value: value, isSaved: false };
                    }
                }
                
                // Check for saved vs Budget aggregate for the period
                const savedVsBudgetPeriod = allMetrics.find(m =>
                    m.name === 'vs Budget' &&
                    m.year === currentYear &&
                    m.period === currentPeriod &&
                    m.quarter === null &&
                    m.week === null
                );
                
                if (savedVsBudgetPeriod) {
                    salesCalculatedData['vsBudget'] = { value: savedVsBudgetPeriod.value, isSaved: true };
                } else {
                    // Sum weekly vs Budget values for this period
                    const weeklyVsBudget = weeklyMetricsForPeriod.filter(m => m.name === 'vs Budget');
                    const vsBudgetSum = weeklyVsBudget.reduce((sum, m) => sum + (m.value || 0), 0);
                    salesCalculatedData['vsBudget'] = { value: vsBudgetSum, isSaved: false };
                }
            }
            setSalesSummaryData(salesCalculatedData);

            // Aggregate complaints data
            const complaintCategoriesConfig = [
                { displayName: "Availability", key: "availability" },
                { displayName: "Driver Behaviour", key: "driver_behaviour" },
                { displayName: "Early Delivery", key: "early_delivery" },
                { displayName: "Late Delivery Call Received", key: "late_delivery_call" },
                { displayName: "Late Delivery No Call", key: "late_delivery_no_call" },
                { displayName: "Missing items", key: "missing_items" },
                { displayName: "Packing and Damages", key: "packing_damages" },
                { displayName: "Product life", key: "product_life" },
                { displayName: "Refunds", key: "refunds" },
                { displayName: "Special Offers", key: "special_offers" },
                { displayName: "Store Cancelled Delivery", key: "store_cancelled_delivery" },
                { displayName: "Unsuitable Substitution", key: "unsuitable_substitution" },
                { displayName: "Other", key: "other" },
            ];

            const chartColors = [
                "#1e293b", "#334155", "#475569", "#64748b", "#94a3b8", "#cbd5e1",
                "#1e40af", "#3b82f6", "#60a5fa", "#93c5fd",
                "#059669", "#10b981", "#34d399", "#6ee7b7", "#f97316"
            ];

            const aggregatedComplaints = complaints.reduce((acc, complaint) => {
                const categoryKey = complaint.category;
                const config = complaintCategoriesConfig.find(c => c.key === categoryKey);
                const displayName = config ? config.displayName : 'Other';
                
                if (!acc[displayName]) {
                    acc[displayName] = { value: 0 };
                }
                acc[displayName].value += (complaint.value || 0);
                return acc;
            }, {});

            const pieData = complaintCategoriesConfig
                .map((config, index) => ({
                    name: config.displayName,
                    value: aggregatedComplaints[config.displayName]?.value || 0,
                    color: chartColors[index % chartColors.length]
                }))
                .filter(d => d.value > 0);

            const otherComplaintsValue = Object.entries(aggregatedComplaints)
                .filter(([key, _]) => !complaintCategoriesConfig.some(c => c.displayName === key))
                .reduce((sum, [_, data]) => sum + data.value, 0);

            if (otherComplaintsValue > 0 && !pieData.some(d => d.name === 'Other')) {
                pieData.push({
                    name: 'Other',
                    value: otherComplaintsValue,
                    color: chartColors[complaintCategoriesConfig.length % chartColors.length]
                });
            }

            setComplaintsChartData(pieData);

            const dwcData = {
                delivery_without_complaints: opsCalculatedData['Delivery Without Complaints'],
                goodwill_refunds: complaints
                    .filter(c => c.category === 'goodwill_refunds' || c.category === 'refunds')
                    .reduce((sum, c) => sum + (c.amount || c.value || 0), 0)
            };
            setDwcData(dwcData);
            setICareData({ score: opsCalculatedData['iCare'] });

            // Handle forecast data for labour summary
            const allYearForecastData = await Forecast.filter({ year: currentYear }, '-date', 5000);
            
            const relevantForecastData = isYearToDate 
                ? allYearForecastData 
                : allYearForecastData.filter(f => f.period === currentPeriod);
            
            const relevantMetrics = isYearToDate 
                ? allMetrics 
                : allMetrics.filter(m => m.period === currentPeriod);

            if (isYearToDate) {
                const getSummedMetricValue = (metricName, forecastKey) => {
                    const ytdOverride = allMetrics.find(m =>
                        m.name === metricName &&
                        m.year === currentYear &&
                        m.period === null &&
                        m.week === null &&
                        m.quarter === null
                    );
                    if (ytdOverride) return ytdOverride.value;

                    const periodAggregates = allMetrics.filter(m =>
                        m.name === metricName &&
                        m.year === currentYear &&
                        m.period !== null &&
                        m.week === null
                    );
                    if (periodAggregates.length > 0) {
                        return periodAggregates.reduce((sum, m) => sum + (m.value || 0), 0);
                    }

                    const weeklyAggregates = allMetrics.filter(m =>
                        m.name === metricName &&
                        m.year === currentYear &&
                        m.week !== null &&
                        m.week > 0
                    );
                    if (weeklyAggregates.length > 0) {
                         return weeklyAggregates.reduce((sum, m) => sum + (m.value || 0), 0);
                    }

                    return allYearForecastData.reduce((sum, f) => sum + (f[forecastKey] || 0), 0);
                };

                const totalForecast = getSummedMetricValue('Labour Forecast', 'labour_forecast');
                const totalActual = getSummedMetricValue('Labour Actual', 'labour_actual');
                const totalWorkedHours = getSummedMetricValue('Labour Worked Hours', 'labour_worked_hours');
                const totalChopChop = getSummedMetricValue('Labour Chop Chop', 'labour_chop_chop');
                const totalItemsForecast = getSummedMetricValue('Items Forecast', 'items_forecast');
                const totalItemsActual = getSummedMetricValue('Items Actual', 'items_actual');
                
                const labourVariance = totalActual - totalWorkedHours - totalChopChop;
                const itemsVariance = totalItemsActual - totalItemsForecast;

                setLabourData({
                    labour_forecast: totalForecast,
                    labour_actual: totalActual,
                    labour_chop_chop: totalChopChop,
                    labour_variance: labourVariance,
                    items_forecast: totalItemsForecast,
                    items_actual: totalItemsActual,
                    items_variance: itemsVariance,
                    labour_worked_hours: totalWorkedHours,
                });
            } else {
                const weeklySummaries = Array.from({ length: 4 }, (_, i) => {
                    const week = i + 1;
                    const weeklyData = relevantForecastData.filter(d => d.week === week);

                    const getWeeklyValue = (name, dataKey) => {
                        const base = weeklyData.reduce((sum, d) => sum + (d[dataKey] || 0), 0);
                        const override = relevantMetrics.find(m => m.name === name && m.week === week);
                        return override ? override.value : base;
                    };

                    return {
                        forecast: getWeeklyValue('Labour Forecast', 'labour_forecast'),
                        actual: getWeeklyValue('Labour Actual', 'labour_actual'),
                        worked_hours: getWeeklyValue('Labour Worked Hours', 'labour_worked_hours'),
                        chop_chop: getWeeklyValue('Labour Chop Chop', 'labour_chop_chop'),
                    };
                });

                const periodBaseline = weeklySummaries.reduce((totals, week) => {
                    totals.forecast += week.forecast;
                    totals.actual += week.actual;
                    totals.worked_hours += week.worked_hours;
                    totals.chop_chop += week.chop_chop;
                    return totals;
                }, { forecast: 0, actual: 0, worked_hours: 0, chop_chop: 0 });

                const getPeriodOverride = (name) => relevantMetrics.find(m => m.name === name && m.week === null);

                const finalLabourForecast = getPeriodOverride('Labour Forecast')?.value ?? periodBaseline.forecast;
                const finalLabourActual = getPeriodOverride('Labour Actual')?.value ?? periodBaseline.actual;
                const finalWorkedHours = getPeriodOverride('Labour Worked Hours')?.value ?? periodBaseline.worked_hours;
                const finalChopChop = getPeriodOverride('Labour Chop Chop')?.value ?? periodBaseline.chop_chop;

                const itemsForecast = relevantForecastData.reduce((sum, f) => sum + (f.items_forecast || 0), 0);
                const itemsActual = relevantForecastData.reduce((sum, f) => sum + (f.items_actual || 0), 0);
                
                const labourVariance = finalLabourActual - finalWorkedHours - finalChopChop;
                const itemsVariance = itemsActual - itemsForecast;

                setLabourData({
                    labour_forecast: finalLabourForecast,
                    labour_actual: finalLabourActual,
                    labour_chop_chop: finalChopChop,
                    labour_variance: labourVariance,
                    items_forecast: itemsForecast,
                    items_actual: itemsActual,
                    items_variance: itemsVariance,
                    labour_worked_hours: finalWorkedHours,
                });
            }

            // Handle cost report data - aggregate if YTD
            if (costReportsData.length > 0) {
                if (isYearToDate) {
                    const aggregatedCostData = {
                        orders: { budget: 0, actual: 0 },
                        damage: { budget: 0, actual: 0 },
                        accidents: { budget: 0, actual: 0 },
                        fines: { budget: 0, actual: 0 },
                        equipment: { budget: 0, actual: 0 }
                    };
                    
                    let allAccidents = [];
                    let allFines = [];
                    let allDamage = [];
                    
                    costReportsData.forEach(report => {
                        if (report.cost_data) {
                            Object.keys(aggregatedCostData).forEach(key => {
                                if (report.cost_data[key]) {
                                    aggregatedCostData[key].budget += report.cost_data[key].budget || 0;
                                    aggregatedCostData[key].actual += report.cost_data[key].actual || 0;
                                }
                            });
                        }
                        
                        if (report.accident_breakdown) {
                            allAccidents = [...allAccidents, ...report.accident_breakdown];
                        }
                        if (report.fines_breakdown) {
                            allFines = [...allFines, ...report.fines_breakdown];
                        }
                        if (report.damage_breakdown) {
                            allDamage = [...allDamage, ...report.damage_breakdown];
                        }
                    });
                    
                    setCostReportData(aggregatedCostData);
                    setAccidentReportData(allAccidents);
                    setFinesReportData(allFines);
                    setDamageBreakdownData(allDamage);
                } else {
                    // Single period logic
                    const report = costReportsData[0];
                    setCostReportData(report.cost_data || {});
                    setAccidentReportData(report.accident_breakdown || []);
                    setFinesReportData(report.fines_breakdown || []);
                    setDamageBreakdownData(report.damage_breakdown || []);
                }
            } else {
                setCostReportData(null);
                setAccidentReportData([]);
                setFinesReportData([]);
                setDamageBreakdownData([]);
            }
        } catch (error) {
            console.error("Failed to load period results:", error);
            setOpsReadinessData(null);
            setSalesSummaryData(null);
            setDwcData(null);
            setICareData(null);
            setCostReportData(null);
            setAccidentReportData([]);
            setFinesReportData([]);
            setDamageBreakdownData([]);
            setLabourData(null);
        } finally {
            setIsLoading(false);
        }
    }, [currentYear, currentPeriod, isYearToDate]);

    useEffect(() => {
        loadPeriodData();
    }, [loadPeriodData]);

    const renderCard = (title, icon, data, contentRenderer) => (
        <Card className="bg-white/80 backdrop-blur-sm border-[3px] border-slate-400 flex flex-col shadow-none rounded-none">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base font-semibold text-slate-700">{title}</CardTitle>
                {icon}
            </CardHeader>
            <CardContent className="flex-grow">
                {contentRenderer(data)}
            </CardContent>
        </Card>
    );

    const renderCostReport = () => renderCard("Cost Report Summary", <Wrench className="w-5 h-5 text-red-500" />, costReportData, (data) => {
        if (!data) return <p className="text-sm text-slate-500 text-center py-8">No data available for this period.</p>;
        
        const creditFromDamage = damageBreakdownData
            .filter(item => item.avoidable === 'Credit')
            .reduce((sum, item) => sum + (item.total_cost || 0), 0);
            
        const avoidableCost = damageBreakdownData
            .filter(item => item.avoidable === 'Yes')
            .reduce((sum, item) => sum + (item.total_cost || 0), 0);
            
        const finesBudget = data?.fines?.budget || 0;
        const finesActualFromData = data?.fines?.actual || 0;
        const finesActualFromBreakdown = finesReportData ? finesReportData.reduce((sum, item) => sum + (item.cost || 0), 0) : 0;
        const finesActual = finesActualFromData > 0 ? finesActualFromData : finesActualFromBreakdown;
        
        const totalBudget = (data?.damage?.budget || 0) + (data?.accidents?.budget || 0);
        const totalActual = (data?.damage?.actual || 0) + (data?.accidents?.actual || 0);
        const totalVariance = totalActual - totalBudget;
        
        return (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
                <MetricBox icon={PoundSterling} title="Total Cost" data={{ value: totalActual }} unit="currency" colorClass="bg-slate-100 text-slate-800" />
                <MetricBox icon={BarChart} title="Variance" data={{ value: totalVariance }} unit="currency" colorClass={totalVariance > 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'} />
                <MetricBox icon={AlertTriangle} title="Avoidable Cost" data={{ value: avoidableCost }} unit="currency" colorClass="bg-red-100 text-red-800" />
                <MetricBox icon={PoundSterling} title="Credit" data={{ value: creditFromDamage }} unit="currency" colorClass="bg-green-100 text-green-800" />
                <MetricBox icon={AlertTriangle} title="Accidents" data={{ value: accidentReportData?.length || 0 }} unit="number" colorClass="bg-orange-100 text-orange-800" />
                <MetricBox icon={AlertTriangle} title="Fines" data={{ value: finesReportData?.length || 0 }} unit="number" colorClass="bg-red-100 text-red-800" />
                <MetricBox icon={PoundSterling} title="Fines Cost" data={{ value: finesActual }} unit="currency" colorClass="bg-red-100 text-red-800" />
            </div>
        );
    });

    // renderLabourSummary and renderSalesSummary are replaced by SalesSummaryCard
    
    const renderComplaintsChart = () => renderCard("Complaints by Category", <MessageSquare className="w-5 h-5 text-orange-500" />, complaintsChartData, (data) => {
        if (!data || data.length === 0) {
            return <p className="text-sm text-slate-500 text-center py-8">No complaint data for this period.</p>;
        }
        return (
            <div style={{ height: '300px' }} className="mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={data}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      fill="#8884d8"
                      paddingAngle={5}
                      dataKey="value"
                      labelLine={false}
                      label={({ cx, cy, midAngle, outerRadius, percent, payload }) => {
                        const RADIAN = Math.PI / 180;
                        const radius = outerRadius + 25;
                        const x = cx + radius * Math.cos(-midAngle * RADIAN);
                        const y = cy + radius * Math.sin(-midAngle * RADIAN);
                        if (percent === 0) return null;
                        return (
                          <text
                            x={x}
                            y={y}
                            fill="black"
                            textAnchor={x > cx ? 'start' : 'end'}
                            dominantBaseline="central"
                            className="text-xs"
                          >
                            {`${payload.name} ${(percent * 100).toFixed(0)}%`}
                          </text>
                        );
                      }}
                    >
                      {data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => value.toLocaleString()} />
                  </PieChart>
                </ResponsiveContainer>
            </div>
        );
    });

    const renderComplaintBreakdown = () => renderCard(`Detailed Breakdown - ${isYearToDate ? 'Year to Date' : `Period ${currentPeriod}`}`, <MessageSquare className="w-5 h-5 text-orange-500" />, complaintsChartData, (data) => {
        const complaintCategoriesConfig = [
            { displayName: "Availability", key: "availability" },
            { displayName: "Driver Behaviour", key: "driver_behaviour" },
            { displayName: "Early Delivery", key: "early_delivery" },
            { displayName: "Late Delivery Call Received", key: "late_delivery_call" },
            { displayName: "Late Delivery No Call", key: "late_delivery_no_call" },
            { displayName: "Missing items", key: "missing_items" },
            { displayName: "Packing and Damages", key: "packing_damages" },
            { displayName: "Product life", key: "product_life" },
            { displayName: "Refunds", key: "refunds" },
            { displayName: "Special Offers", key: "special_offers" },
            { displayName: "Store Cancelled Delivery", key: "store_cancelled_delivery" },
            { displayName: "Unsuitable Substitution", key: "unsuitable_substitution" },
        ];

        const dataLookup = data.reduce((acc, item) => {
            acc[item.name] = item.value;
            return acc;
        }, {});

        return (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {complaintCategoriesConfig.map((config) => {
                    const value = dataLookup[config.displayName] || 0;
                    const colorClass = value > 30 ? 'bg-red-100 text-red-800' : 
                                     value > 15 ? 'bg-amber-100 text-amber-800' : 
                                     'bg-green-100 text-green-800';
                    
                    return (
                        <MetricBox 
                            key={config.key}
                            title={config.displayName} 
                            data={{ value: value }} 
                            unit="number" 
                            colorClass={colorClass}
                        />
                    );
                })}
            </div>
        );
    });

    const renderDamageBreakdown = () => renderCard(`Damage Breakdown - ${isYearToDate ? 'Year to Date' : `Period ${currentPeriod}`}`, <AlertTriangle className="w-5 h-5 text-red-500" />, damageBreakdownData, (data) => {
        if (!data || data.length === 0) {
            return <p className="text-sm text-slate-500 text-center py-8">No damage data for this period.</p>;
        }

        const filteredData = data.filter(item => 
            !item.van_reg || !item.van_reg.toLowerCase().includes('riy-parts')
        );

        if (filteredData.length === 0) {
            return <p className="text-sm text-slate-500 text-center py-8">No relevant damage data for this period.</p>;
        }

        return (
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-24">Van Reg</TableHead>
                            <TableHead>Defect Reported</TableHead>
                            <TableHead>Recharge Text</TableHead>
                            <TableHead className="w-20">Cost Type</TableHead>
                            <TableHead className="w-20">Challenge</TableHead>
                            <TableHead className="w-24">Cost</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredData.map((item, index) => (
                            <TableRow key={index}>
                                <TableCell className="font-medium">
                                    {item.van_reg || '—'}
                                </TableCell>
                                <TableCell className="max-w-xs">
                                    <div className="break-words whitespace-pre-wrap text-sm">
                                        {item.defect_reported || '—'}
                                    </div>
                                </TableCell>
                                <TableCell className="max-w-xs">
                                    <div className="break-words whitespace-pre-wrap text-sm">
                                        {item.recharge_text || '—'}
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                                        item.avoidable === 'Yes' ? 'bg-red-100 text-red-800' : 
                                        item.avoidable === 'Credit' ? 'bg-green-100 text-green-800' :
                                        item.avoidable === 'Defect Found at Service' ? 'bg-orange-100 text-orange-800' :
                                        'bg-blue-100 text-blue-800'
                                    }`}>
                                        {item.avoidable === 'Defect Found at Service' ? 'Defect' : item.avoidable || 'No'}
                                    </span>
                                </TableCell>
                                <TableCell>
                                    <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                                        item.challenged === 'Yes' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-800'
                                    }`}>
                                        {item.challenged || 'No'}
                                    </span>
                                </TableCell>
                                <TableCell className="font-medium">
                                    {item.total_cost ? `£${item.total_cost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        );
    });

    const renderFinesReport = () => renderCard(`Fines Report - ${isYearToDate ? 'Year to Date' : `Period ${currentPeriod}`}`, <AlertTriangle className="w-5 h-5 text-red-500" />, finesReportData, (data) => {
        if (!data || data.length === 0) {
            return <p className="text-sm text-slate-500 text-center py-8">No fines data for this period.</p>;
        }

        return (
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>PCN</TableHead>
                            <TableHead>Van Reg</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Cause</TableHead>
                            <TableHead>Location</TableHead>
                            <TableHead>Cost</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {data.map((item, index) => (
                            <TableRow key={index}>
                                <TableCell className="font-medium">{item.pcn || '—'}</TableCell>
                                <TableCell>{item.van_reg || '—'}</TableCell>
                                <TableCell>{item.date_of_ticket ? new Date(item.date_of_ticket + 'T00:00:00').toLocaleDateString() : '—'}</TableCell>
                                <TableCell>{item.cause || '—'}</TableCell>
                                <TableCell>{item.location || '—'}</TableCell>
                                <TableCell className="font-medium">
                                    {item.cost ? `£${item.cost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        );
    });
    
    const renderAccidentReport = () => renderCard(`Accident Report - ${isYearToDate ? 'Year to Date' : `Period ${currentPeriod}`}`, <AlertTriangle className="w-5 h-5 text-orange-500" />, accidentReportData, (data) => {
        if (!data || data.length === 0) {
            return <p className="text-sm text-slate-500 text-center py-8">No accident data for this period.</p>;
        }

        return (
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Claim Ref</TableHead>
                            <TableHead>Van Reg</TableHead>
                            <TableHead>Date of Loss</TableHead>
                            <TableHead>Cause</TableHead>
                            <TableHead>SIMS #</TableHead>
                            <TableHead>Cost (P&L)</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {data.map((item, index) => (
                            <TableRow key={index}>
                                <TableCell className="font-medium">{item.claim_reference || '—'}</TableCell>
                                <TableCell>{item.van_reg || '—'}</TableCell>
                                <TableCell>{item.date_of_loss ? new Date(item.date_of_loss + 'T00:00:00').toLocaleDateString() : '—'}</TableCell>
                                <TableCell>{item.claim_cause || '—'}</TableCell>
                                <TableCell>{item.sims_incident_number || '—'}</TableCell>
                                <TableCell className="font-medium">
                                    {item.p_and_l ? `£${item.p_and_l.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        );
    });

    const renderAvoidableDamageReport = () => renderCard("Avoidable Damage Report", <AlertTriangle className="w-5 h-5 text-red-500" />, damageBreakdownData, (data) => {
        const avoidableData = data.filter(item => item.avoidable === 'Yes');

        if (!avoidableData || avoidableData.length === 0) {
            return <p className="text-sm text-slate-500 text-center py-8">No avoidable damage recorded for this period.</p>;
        }

        return (
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Van Reg</TableHead>
                            <TableHead>Defect</TableHead>
                            <TableHead>Cost</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {avoidableData.map((item, index) => (
                            <TableRow key={index}>
                                <TableCell className="font-medium">{item.van_reg || '—'}</TableCell>
                                <TableCell className="max-w-xs">
                                    <div className="break-words whitespace-pre-wrap text-sm">
                                        {item.defect_reported || '—'}
                                    </div>
                                </TableCell>
                                <TableCell className="font-medium">
                                    {item.total_cost ? `£${item.total_cost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        );
    });

    const renderComplaintsSummary = () => renderCard(`Complaints Summary - ${isYearToDate ? 'Year to Date' : `Period ${currentPeriod}`}`, <MessageSquare className="w-5 h-5 text-orange-500" />, { complaintsChartData, dwcData, salesSummaryData }, (data) => {
        const { complaintsChartData: complaints, dwcData, salesSummaryData: sales } = data;
        
        const totalComplaints = complaints ? complaints.reduce((sum, item) => sum + (item.value || 0), 0) : 0;
        const totalGoodwill = dwcData ? (dwcData['goodwill_refunds'] || 0) : 0;
        const totalOrders = sales ? (sales['orders']?.value || 0) : 0; // Correctly get total orders
        const totalItems = sales ? (sales['items']?.value || 0) : 0; // Correctly get total items
        const complaintsVsOrders = totalOrders > 0 ? ((totalComplaints / totalOrders) * 100) : 0;

        return (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4"> {/* Changed grid layout to md:grid-cols-5 */}
                <MetricBox 
                    title="Total Complaints" 
                    data={{ value: totalComplaints }} 
                    unit="number" 
                    colorClass={totalComplaints > 100 ? 'bg-red-100 text-red-800' : totalComplaints > 50 ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-800'}
                />
                <MetricBox 
                    title="Total Goodwill" 
                    data={{ value: totalGoodwill }} 
                    unit="currency" 
                    colorClass="bg-orange-100 text-orange-800"
                />
                <MetricBox 
                    title="Total Orders" // New MetricBox for Total Orders
                    data={{ value: totalOrders }} 
                    unit="number" 
                    colorClass="bg-blue-100 text-blue-800"
                />
                <MetricBox 
                    title="Total Items" // Renamed from "Total Orders" to "Total Items"
                    data={{ value: totalItems }} 
                    unit="number" 
                    colorClass="bg-blue-100 text-blue-800"
                />
                <MetricBox 
                    title="Complaints vs Orders" 
                    data={{ value: complaintsVsOrders }} 
                    unit="percentage" 
                    colorClass={complaintsVsOrders > 2 ? 'bg-red-100 text-red-800' : complaintsVsOrders > 1 ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-800'}
                />
            </div>
        );
    });

    if (isPresentationMode) {
        return (
            <PresentationSlides 
                title="Period Results"
                period={currentPeriod}
                year={currentYear}
                salesData={salesSummaryData}
                opsData={opsReadinessData}
                labourData={labourData}
                costData={costReportData}
                onBack={() => setIsPresentationMode(false)}
            />
        );
    }

    const handleExportImage = () => {
        const printWindow = window.open('', '_blank');
        
        const creditFromDamage = damageBreakdownData
            .filter(item => item.avoidable === 'Credit')
            .reduce((sum, item) => sum + (item.total_cost || 0), 0);
        const avoidableCost = damageBreakdownData
            .filter(item => item.avoidable === 'Yes')
            .reduce((sum, item) => sum + (item.total_cost || 0), 0);
        const finesActualFromData = costReportData?.fines?.actual || 0;
        const finesActualFromBreakdown = finesReportData ? finesReportData.reduce((sum, item) => sum + (item.cost || 0), 0) : 0;
        const finesActual = finesActualFromData > 0 ? finesActualFromData : finesActualFromBreakdown;
        const totalActualCost = (costReportData?.damage?.actual || 0) + (costReportData?.accidents?.actual || 0);
        const totalBudgetCost = (costReportData?.damage?.budget || 0) + (costReportData?.accidents?.budget || 0);
        const totalVarianceCost = totalActualCost - totalBudgetCost;
        const accidentsCount = accidentReportData?.length || 0;
        const finesCount = finesReportData?.length || 0;

        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Period ${isYearToDate ? 'Year to Date' : currentPeriod} Results - ${currentYear}</title>
                <style>
                    @page {
                        size: A4 landscape;
                        margin: 10mm;
                    }
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                        margin: 0;
                        padding: 0;
                        background: #f8fafc;
                        color: #1e293b;
                        line-height: 1.4;
                    }
                    @media print {
                        body {
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                    }
                    .content-wrapper {
                        padding: 15px;
                    }
                    .header {
                        text-align: center;
                        margin-bottom: 20px;
                        border-bottom: 2px solid #e2e8f0;
                        padding-bottom: 15px;
                    }
                    .header h1 {
                        margin: 0 0 5px 0;
                        font-size: 28px;
                        font-weight: bold;
                        color: #1e293b;
                    }
                    .header p {
                        margin: 0;
                        font-size: 16px;
                        color: #64748b;
                    }
                    .section {
                        margin-bottom: 20px;
                        break-inside: avoid;
                    }
                    .section-title {
                        font-size: 18px;
                        font-weight: bold;
                        margin-bottom: 12px;
                        color: #1e293b;
                        border-left: 4px solid #3b82f6;
                        padding-left: 10px;
                    }
                    .metrics-grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
                        gap: 12px;
                        margin-bottom: 15px;
                    }
                    .metric-box {
                        background: #f8fafc;
                        border: 1px solid #e2e8f0;
                        border-radius: 8px;
                        padding: 12px;
                        text-align: center;
                        break-inside: avoid;
                        position: relative; /* Added for Save icon positioning */
                    }
                    .metric-title {
                        font-size: 11px;
                        font-weight: 600;
                        color: #64748b;
                        margin-bottom: 6px;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                    }
                    .metric-value {
                        font-size: 22px;
                        font-weight: bold;
                        color: #1e293b;
                        margin: 0;
                    }
                    .status-green { background: #f0fdf4; border-color: #22c55e; }
                    .status-green .metric-value { color: #15803d; }
                    .status-amber { background: #fffbeb; border-color: #f59e0b; }
                    .status-amber .metric-value { color: #d97706; }
                    .status-red { background: #fef2f2; border-color: #ef4444; }
                    .status-red .metric-value { color: #dc2626; }
                    .save-icon {
                        position: absolute;
                        top: 5px;
                        right: 5px;
                        width: 12px;
                        height: 12px;
                        color: #94a3b8;
                    }
                </style>
                ${backgroundImage ? `
                <style>
                    body {
                        background-image: url('${backgroundImage}');
                        background-size: cover;
                        background-position: center;
                        background-repeat: no-repeat;
                    }
                    .content-wrapper {
                        background-color: rgba(255, 255, 255, 0.92);
                        border-radius: 12px;
                        padding: 15px;
                        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                        min-height: calc(210mm - 20mm);
                        min-width: calc(297mm - 20mm);
                    }
                </style>
                ` : ''}
            </head>
            <body>
                <div class="content-wrapper">
                    <div class="header">
                        <h1>Period Results</h1>
                        <p>Period ${isYearToDate ? 'Year to Date' : currentPeriod}, ${currentYear}</p>
                    </div>

                    ${salesSummaryData ? `
                    <div class="section">
                        <div class="section-title">Sales Summary</div>
                        <div class="metrics-grid">
                            <div class="metric-box ${salesSummaryData.sales?.isSaved ? 'has-save-icon' : ''}">
                                <div class="metric-title">Sales</div>
                                <div class="metric-value">£${(salesSummaryData.sales?.value || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</div>
                                ${salesSummaryData.sales?.isSaved ? '<svg class="save-icon" fill="currentColor" viewBox="0 0 24 24"><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>' : ''}
                            </div>
                            <div class="metric-box ${salesSummaryData.vsLastYear?.value != null ? ((salesSummaryData.vsLastYear?.value || 0) >= 0 ? 'status-green' : 'status-red') : ''}">
                                <div class="metric-title">vs Last Year</div>
                                <div class="metric-value">£${(salesSummaryData.vsLastYear?.value || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</div>
                                ${salesSummaryData.vsLastYear?.isSaved ? '<svg class="save-icon" fill="currentColor" viewBox="0 0 24 24"><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>' : ''}
                            </div>
                            <div class="metric-box ${salesSummaryData.vsBudget?.value != null ? ((salesSummaryData.vsBudget?.value || 0) >= 0 ? 'status-green' : 'status-red') : ''}">
                                <div class="metric-title">vs Budget</div>
                                <div class="metric-value">£${(salesSummaryData.vsBudget?.value || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</div>
                            </div>
                            <div class="metric-box ${salesSummaryData.salesYOY?.value != null ? ((salesSummaryData.salesYOY?.value || 0) >= 0 ? 'status-green' : 'status-red') : ''}">
                                <div class="metric-title">Sales YOY%</div>
                                <div class="metric-value">${(salesSummaryData.salesYOY?.value || 0).toFixed(1)}%</div>
                            </div>
                            <div class="metric-box ${salesSummaryData.orders?.isSaved ? 'has-save-icon' : ''}">
                                <div class="metric-title">Orders</div>
                                <div class="metric-value">${(salesSummaryData.orders?.value || 0).toLocaleString()}</div>
                                ${salesSummaryData.orders?.isSaved ? '<svg class="save-icon" fill="currentColor" viewBox="0 0 24 24"><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>' : ''}
                            </div>
                            <div class="metric-box ${salesSummaryData.items?.isSaved ? 'has-save-icon' : ''}">
                                <div class="metric-title">Items</div>
                                <div class="metric-value">${(salesSummaryData.items?.value || 0).toLocaleString()}</div>
                                ${salesSummaryData.items?.isSaved ? '<svg class="save-icon" fill="currentColor" viewBox="0 0 24 24"><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>' : ''}
                            </div>
                        </div>
                    </div>
                    ` : ''}

                    ${opsReadinessData ? `
                    <div class="section">
                        <div class="section-title">Operations & Customer Metrics</div>
                        <div class="metrics-grid">
                            <div class="metric-box ${opsReadinessData['Ops Score'] != null ? (opsReadinessData['Ops Score'] >= 80 ? 'status-green' : opsReadinessData['Ops Score'] >= 60 ? 'status-amber' : 'status-red') : ''}">
                                <div class="metric-title">Ops Score</div>
                                <div class="metric-value">${(opsReadinessData['Ops Score'] || 0).toFixed(0)}%</div>
                            </div>
                            <div class="metric-box ${opsReadinessData['Shoppers Achieving'] != null ? (opsReadinessData['Shoppers Achieving'] >= 80 ? 'status-green' : opsReadinessData['Shoppers Achieving'] >= 60 ? 'status-amber' : 'status-red') : ''}">
                                <div class="metric-title">Shoppers</div>
                                <div class="metric-value">${(opsReadinessData['Shoppers Achieving'] || 0).toFixed(0)}%</div>
                            </div>
                            <div class="metric-box ${opsReadinessData['On Time Departures'] != null ? (opsReadinessData['On Time Departures'] >= 98 ? 'status-green' : opsReadinessData['On Time Departures'] >= 95 ? 'status-amber' : 'status-red') : ''}">
                                <div class="metric-title">OT Departures</div>
                                <div class="metric-value">${(opsReadinessData['On Time Departures'] || 0).toFixed(1)}%</div>
                            </div>
                            <div class="metric-box ${opsReadinessData['Availability'] != null ? (opsReadinessData['Availability'] >= 97 ? 'status-green' : opsReadinessData['Availability'] >= 95 ? 'status-amber' : 'status-red') : ''}">
                                <div class="metric-title">Availability</div>
                                <div class="metric-value">${(opsReadinessData['Availability'] || 0).toFixed(1)}%</div>
                            </div>
                            <div class="metric-box ${opsReadinessData['Delivery Without Complaints'] != null ? (opsReadinessData['Delivery Without Complaints'] >= 98 ? 'status-green' : 'status-amber') : ''}">
                                <div class="metric-title">DWC</div>
                                <div class="metric-value">${(opsReadinessData['Delivery Without Complaints'] || 0).toFixed(1)}%</div>
                            </div>
                            <div class="metric-box ${opsReadinessData['Secondary Replenishment'] != null ? (opsReadinessData['Secondary Replenishment'] <= 2 ? 'status-green' : opsReadinessData['Secondary Replenishment'] <= 2.5 ? 'status-amber' : 'status-red') : ''}">
                                <div class="metric-title">Sec Replen</div>
                                <div class="metric-value">${(opsReadinessData['Secondary Replenishment'] || 0).toFixed(3)}%</div>
                            </div>
                            <div class="metric-box ${opsReadinessData['iCare'] != null ? (opsReadinessData['iCare'] >= 49.5 ? 'status-green' : opsReadinessData['iCare'] >= 49.4 ? 'status-amber' : 'status-red') : ''}">
                                <div class="metric-title">iCare Score</div>
                                <div class="metric-value">${(opsReadinessData['iCare'] || 0).toFixed(1)}%</div>
                            </div>
                        </div>
                    </div>
                    ` : ''}

                    ${labourData ? `
                    <div class="section">
                        <div class="section-title">Labour Summary</div>
                        <div class="metrics-grid">
                            <div class="metric-box">
                                <div class="metric-title">Labour Forecast</div>
                                <div class="metric-value">${(labourData.labour_forecast || 0).toLocaleString()}</div>
                            </div>
                            <div class="metric-box">
                                <div class="metric-title">Labour Actual</div>
                                <div class="metric-value">${(labourData.labour_actual || 0).toLocaleString()}</div>
                            </div>
                            <div class="metric-box ${(labourData.labour_actual - labourData.labour_forecast) >= 0 ? 'status-green' : 'status-red'}">
                                <div class="metric-title">F vs A</div>
                                <div class="metric-value">${(labourData.labour_actual - labourData.labour_forecast || 0).toLocaleString()}</div>
                            </div>
                            <div class="metric-box">
                                <div class="metric-title">Worked Hours</div>
                                <div class="metric-value">${(labourData.labour_worked_hours || 0).toLocaleString()}</div>
                            </div>
                            <div class="metric-box ${(labourData.labour_variance || 0) >= 0 ? 'status-green' : 'status-red'}">
                                <div class="metric-title">Labour Variance</div>
                                <div class="metric-value">${(labourData.labour_variance || 0).toLocaleString()}</div>
                            </div>
                            <div class="metric-box">
                                <div class="metric-title">Items Actual</div>
                                <div class="metric-value">${(labourData.items_actual || 0).toLocaleString()}</div>
                            </div>
                            <div class="metric-box ${(labourData.items_variance || 0) >= 0 ? 'status-green' : 'status-red'}">
                                <div class="metric-title">Items Variance</div>
                                <div class="metric-value">${(labourData.items_variance || 0).toLocaleString()}</div>
                            </div>
                        </div>
                    </div>
                    ` : ''}
                    
                    ${costReportData ? `
                    <div class="section">
                        <div class="section-title">Cost Report Summary</div>
                        <div class="metrics-grid">
                            <div class="metric-box">
                                <div class="metric-title">Total Cost</div>
                                <div class="metric-value">£${(totalActualCost || 0).toLocaleString()}</div>
                            </div>
                            <div class="metric-box ${totalVarianceCost > 0 ? 'status-red' : 'status-green'}">
                                <div class="metric-title">Variance</div>
                                <div class="metric-value">£${(totalVarianceCost || 0).toLocaleString()}</div>
                            </div>
                            <div class="metric-box status-red">
                                <div class="metric-title">Avoidable Cost</div>
                                <div class="metric-value">£${(avoidableCost || 0).toLocaleString()}</div>
                            </div>
                            <div class="metric-box status-green">
                                <div class="metric-title">Credit</div>
                                <div class="metric-value">£${(creditFromDamage || 0).toLocaleString()}</div>
                            </div>
                            <div class="metric-box">
                                <div class="metric-title">Accidents</div>
                                <div class="metric-value">${accidentsCount}</div>
                            </div>
                            <div class="metric-box">
                                <div class="metric-title">Fines</div>
                                <div class="metric-value">${finesCount}</div>
                            </div>
                            <div class="metric-box status-red">
                                <div class="metric-title">Fines Cost</div>
                                <div class="metric-value">£${(finesActual || 0).toLocaleString()}</div>
                            </div>
                        </div>
                    </div>
                    ` : ''}
                </div>
                <script>
                    window.onload = function() {
                        setTimeout(function() {
                            window.print();
                        }, 500);
                    };
                </script>
            </body>
            </html>
        `);
        
        printWindow.document.close();
    };

    const handleBackgroundImageUpload = async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        if (!file.type.startsWith('image/')) {
            toast.error('Please upload a valid image file.');
            return;
        }

        toast.info("Uploading background image...");
        try {
            const { file_url } = await UploadFile({ file });
            setBackgroundImage(file_url);
            localStorage.setItem('periodResultsExportBg', file_url);
            toast.success("Export background updated!");
        } catch (error) {
            console.error("Background upload failed:", error);
            toast.error("Failed to upload background image.");
        }
    };

    const removeBackgroundImage = () => {
        setBackgroundImage(null);
        localStorage.removeItem('periodResultsExportBg');
        toast.info("Export background removed.");
    };

    return (
        <div className="p-4 md:p-6 space-y-6 min-h-screen bg-slate-50/50">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Period Results</h1>
                    {isYearToDate && (
                        <p className="text-lg text-blue-600 font-medium mt-1">Year-to-Date View</p>
                    )}
                </div>
                <div className="flex items-center gap-2">
                    <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))}>
                        <SelectTrigger className="w-28 bg-white shadow-sm"><SelectValue /></SelectTrigger>
                        <SelectContent>{Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i).map(y => <SelectItem key={y} value={y.toString()}>{y}</SelectItem>)}</SelectContent>
                    </Select>
                    
                    <Button 
                        variant={isYearToDate ? "default" : "outline"} 
                        size="sm" 
                        onClick={() => setIsYearToDate(!isYearToDate)}
                        className={isYearToDate ? "bg-blue-600 hover:bg-blue-700 text-white" : "bg-white shadow-sm"}
                    >
                        {isYearToDate ? "YTD" : "Period"}
                    </Button>
                    
                    {!isYearToDate && (
                        <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))}>
                            <SelectTrigger className="w-32 bg-white shadow-sm"><SelectValue placeholder="Period" /></SelectTrigger>
                            <SelectContent>{Array.from({ length: 13 }, (_, i) => i + 1).map(p => <SelectItem key={p} value={p.toString()}>Period {p}</SelectItem>)}</SelectContent>
                        </Select>
                    )}
                    
                    <input
                        type="file"
                        id="bg-upload-input"
                        className="hidden"
                        accept="image/*"
                        onChange={handleBackgroundImageUpload}
                    />
                    <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => document.getElementById('bg-upload-input').click()} 
                        className="bg-white shadow-sm"
                        title="Set Export Background"
                    >
                        <Image className="w-4 h-4 mr-2" />
                        Set BG
                    </Button>
                    {backgroundImage && (
                        <Button 
                            variant="destructive" 
                            size="sm" 
                            onClick={removeBackgroundImage}
                            className="shadow-sm"
                            title="Remove Export Background"
                        >
                            <X className="w-4 h-4" />
                        </Button>
                    )}
                    <Button variant="outline" size="sm" onClick={handleExportImage} className="bg-white shadow-sm">
                        <FileDown className="w-4 h-4 mr-2" />
                        Export A4
                    </Button>
                </div>
            </div>

            {isLoading ? (
                <div className="flex justify-center items-center h-96"><Loader2 className="w-8 h-8 animate-spin text-gray-500" /></div>
            ) : (
                <div className="space-y-6">
                    <SalesSummaryCard salesData={salesSummaryData} labourData={labourData} />
                    <OpsAndCustomerCard opsData={opsReadinessData} dwc={dwcData} iCare={iCareData} />
                    {renderCostReport()}
                    {renderComplaintsChart()}
                    {renderComplaintsSummary()}
                    {renderComplaintBreakdown()}
                    {renderDamageBreakdown()}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {renderAvoidableDamageReport()}
                        {renderFinesReport()}
                        {renderAccidentReport()}
                    </div>
                </div>
            )}
        </div>
    );
}