import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Driver } from '@/api/entities';
import { PerformanceMatrixData } from '@/api/entities';
import { User } from '@/api/entities';
import { PeriodConfig } from '@/api/entities';
import { useEditLock } from '../Layout';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ClipboardList, Edit, Save, X, Trash2, ArrowUpDown, MessageSquare, Star, Calendar } from 'lucide-react';
import { toast } from 'sonner';

import DriverDetailModal from "../components/performance/DriverDetailModal";
import ActionNotesModal from "../components/performance/ActionNotesModal";

const SortableHeader = ({ children, sortKey, sortConfig, onSort, className }) => {
    const isSorted = sortConfig.key === sortKey;
    const isDesc = isSorted && sortConfig.direction === 'desc';

    return (
        <TableHead onClick={() => onSort(sortKey)} className={`cursor-pointer hover:bg-slate-50 ${className}`}>
            <div className="flex items-center gap-2">
                {children}
                <ArrowUpDown className={`w-4 h-4 transition-opacity ${isSorted ? 'opacity-100' : 'opacity-30'} ${isDesc ? 'rotate-180' : ''}`} />
            </div>
        </TableHead>
    );
};

export default function PerformanceMatrix() {
    const [drivers, setDrivers] = useState([]);
    const [matrixData, setMatrixData] = useState(new Map());
    const [ytdMatrixData, setYtdMatrixData] = useState(new Map()); // New: YTD data
    const [isLoading, setIsLoading] = useState(true);
    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
    const [currentPeriod, setCurrentPeriod] = useState(1);
    const { canEdit: unlockCanEdit } = useEditLock();
    const [isAdmin, setIsAdmin] = useState(false);
    const canEdit = isAdmin || unlockCanEdit;
    const [isEditing, setIsEditing] = useState(false);
    const [editedData, setEditedData] = useState(new Map()); // Ensure this is initialized as a Map
    const [showConfirmDialog, setShowConfirmDialog] = useState(false);
    const [showClearPeriodDialog, setShowClearPeriodDialog] = useState(false);
    const [sortConfig, setSortConfig] = useState({ key: null, direction: 'desc' });
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedDriver, setSelectedDriver] = useState(null);
    const [isNotesModalOpen, setIsNotesModalOpen] = useState(false);
    const [notesModalData, setNotesModalData] = useState(null); // Changed: Stores data for the notes modal
    const [driverActionStatus, setDriverActionStatus] = useState(new Map());
    const [ytdDriverActionStatus, setYtdDriverActionStatus] = useState(new Map()); // New: YTD action status - FIX: Removed 'new' before useState
    const [activeTab, setActiveTab] = useState("period"); // New: Active tab state

    useEffect(() => {
        const checkUserRole = async () => {
            try {
                const currentUser = await User.me();
                setIsAdmin(currentUser && currentUser.role === 'admin');
            } catch (error) {
                setIsAdmin(false);
            }
        };
        checkUserRole();

        const setDefaultPeriod = async () => {
            setIsLoading(true);
            try {
                const lastWeekDate = new Date();
                lastWeekDate.setDate(lastWeekDate.getDate() - 7);
                const yearOfLastWeek = lastWeekDate.getFullYear();

                // Fetch period configs for relevant years to handle year-end crossover
                const periodConfigs = await PeriodConfig.filter({
                    year: { $in: [yearOfLastWeek - 1, yearOfLastWeek, yearOfLastWeek + 1] }
                });

                if (!periodConfigs || periodConfigs.length === 0) {
                    throw new Error("No period configurations found in settings.");
                }

                const targetPeriodConfig = periodConfigs.find(p => {
                    const startDate = new Date(p.start_date + 'T00:00:00Z');
                    const endDate = new Date(p.end_date + 'T23:59:59Z');
                    return lastWeekDate >= startDate && lastWeekDate <= endDate;
                });

                if (targetPeriodConfig) {
                    setCurrentYear(targetPeriodConfig.year);
                    setCurrentPeriod(targetPeriodConfig.period_number);
                } else {
                    throw new Error("Could not find a period configuration for last week. Please check period settings.");
                }

            } catch (error) {
                console.error("Error setting default period:", error);
                toast.error(error.message || "Could not set default period from settings.");

                // Improved fallback logic
                const now = new Date();
                const currentMonth = now.getMonth() + 1; // 1-12
                let financialYear = now.getFullYear();
                let currentPeriodNumber;

                // Sainsbury's financial year runs March to February
                // Period 1 = March, Period 2 = April, etc.
                if (currentMonth >= 3) {
                    currentPeriodNumber = currentMonth - 2;
                } else {
                    currentPeriodNumber = currentMonth + 10;
                    financialYear -= 1; // If current month is Jan/Feb, it belongs to the previous financial year
                }

                // Default to previous period
                let defaultPeriod = currentPeriodNumber > 1 ? currentPeriodNumber - 1 : 13;
                let defaultYear = financialYear;

                if (defaultPeriod === 13) {
                    defaultYear = financialYear - 1; // If current period is 1, previous is 13 of previous financial year
                }

                setCurrentPeriod(defaultPeriod);
                setCurrentYear(defaultYear);
            } finally {
                setIsLoading(false);
            }
        };

        setDefaultPeriod();

    }, []);

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            // Fetch all active drivers, then filter out shunters on the client-side for reliability
            const allActiveDrivers = await Driver.filter({ is_active: true });
            const driverData = allActiveDrivers.filter(d => d.role !== 'shunter');
            console.log("Filtered drivers (shunters removed):", driverData);

            // Get all data for the current period (all weeks 1-4)
            const periodMatrixRecords = await PerformanceMatrixData.filter({
                year: currentYear,
                period: currentPeriod,
            });
            console.log("Period matrix records:", periodMatrixRecords);

            // Get all data for the current year (YTD)
            const ytdMatrixRecords = await PerformanceMatrixData.filter({
                year: currentYear,
            });
            console.log("YTD matrix records:", ytdMatrixRecords);

            setDrivers(driverData);

            // Process period data by week for the current period
            const dataMap = new Map();
            (periodMatrixRecords).forEach(record => { // Removed || [] as filter should return array
                if (!dataMap.has(record.shopper_colleague_id)) {
                    dataMap.set(record.shopper_colleague_id, new Map());
                }

                // Store the entire record object, not just the value
                const metricKey = `${record.metric_name}_W${record.week}`;
                dataMap.get(record.shopper_colleague_id).set(metricKey, record);
            });

            // Process YTD data - aggregate by driver and metric
            const ytdDataMap = new Map();
            (ytdMatrixRecords).forEach(record => { // Removed || [] as filter should return array
                if (!ytdDataMap.has(record.shopper_colleague_id)) {
                    ytdDataMap.set(record.shopper_colleague_id, new Map());
                }

                const metricKey = record.metric_name;
                let existingData = ytdDataMap.get(record.shopper_colleague_id).get(metricKey);

                if (!existingData) {
                    existingData = {
                        shopper_colleague_id: record.shopper_colleague_id,
                        metric_name: record.metric_name,
                        value: record.value,
                        total_value_sum: record.value, // Used for averaging percentages
                        value_count: 1, // Used for averaging percentages
                        notes: record.notes ? [...record.notes] : [], // Initialize notes array
                        // The id for YTD aggregated records is synthetic, not a real DB ID
                        // We set it to null or leave undefined as it's not updatable directly
                        id: null,
                        year: currentYear // Add year for fetching context
                    };
                    ytdDataMap.get(record.shopper_colleague_id).set(metricKey, existingData);
                } else {
                    // For percentage metrics (Smoother, Safer, Cleaner), calculate average
                    // For count metrics (DHR, Breaks, etc.), sum the values
                    if (['Smoother', 'Safer', 'Cleaner'].includes(record.metric_name)) {
                        existingData.total_value_sum += record.value;
                        existingData.value_count += 1;
                        existingData.value = existingData.total_value_sum / existingData.value_count;
                    } else {
                        existingData.value += record.value;
                    }

                    // Combine notes from all periods/weeks for YTD
                    if (record.notes && Array.isArray(record.notes)) {
                        // Ensure unique notes if necessary, or just concat
                        existingData.notes = [...existingData.notes, ...record.notes];
                    }
                }
            });

            console.log("Processed period data map:", dataMap);
            console.log("Processed YTD data map:", ytdDataMap);
            setMatrixData(dataMap);
            setYtdMatrixData(ytdDataMap); // Set YTD data
            computeDriverActionStatus(driverData, dataMap);
            computeYtdDriverActionStatus(driverData, ytdDataMap); // Compute YTD action status

        } catch (error) {
            console.error("Failed to fetch performance matrix data:", error);
            toast.error("Failed to load performance data.");
        } finally {
            setIsLoading(false);
        }
    }, [currentYear, currentPeriod]);

    const computeDriverActionStatus = (drivers, matrixData) => {
        const statusMap = new Map();
        const severity = {
            'final_warning': 4,
            'first_warning': 3,
            'irod': 2,
            'coaching': 1
        };

        drivers.forEach(driver => {
            let maxSeverity = 0;
            const driverData = matrixData.get(driver.colleague_id);
            if (driverData) {
                for (const record of driverData.values()) {
                    if (record && record.notes && Array.isArray(record.notes) && record.notes.length > 0) {
                        record.notes.forEach(note => {
                            if(note && note.action_type) { // Added null check for note
                                const noteSeverity = severity[note.action_type] || 0;
                                if (noteSeverity > maxSeverity) {
                                    maxSeverity = noteSeverity;
                                }
                            }
                        });
                    }
                }
            }

            let status = null;
            if (maxSeverity === 4) status = 'red';
            else if (maxSeverity === 3) status = 'amber';
            else if (maxSeverity === 2) status = 'blue';
            else if (maxSeverity === 1) status = 'green';

            statusMap.set(driver.colleague_id, status);
        });

        setDriverActionStatus(statusMap);
    };

    // New: Compute action status for YTD data
    const computeYtdDriverActionStatus = (drivers, ytdMatrixData) => {
        const statusMap = new Map();
        const severity = {
            'final_warning': 4,
            'first_warning': 3,
            'irod': 2,
            'coaching': 1
        };

        drivers.forEach(driver => {
            let maxSeverity = 0;
            const driverData = ytdMatrixData.get(driver.colleague_id);
            if (driverData) {
                for (const record of driverData.values()) {
                    // For YTD, notes are aggregated. Check the aggregated notes array.
                    if (record && record.notes && Array.isArray(record.notes) && record.notes.length > 0) {
                        record.notes.forEach(note => {
                            if(note && note.action_type) {
                                const noteSeverity = severity[note.action_type] || 0;
                                if (noteSeverity > maxSeverity) {
                                    maxSeverity = noteSeverity;
                                }
                            }
                        });
                    }
                }
            }

            let status = null;
            if (maxSeverity === 4) status = 'red';
            else if (maxSeverity === 3) status = 'amber';
            else if (maxSeverity === 2) status = 'blue';
            else if (maxSeverity === 1) status = 'green';

            statusMap.set(driver.colleague_id, status);
        });

        setYtdDriverActionStatus(statusMap);
    };

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const handleDriverNameClick = async (driver) => {
        try {
            const performanceRecords = await PerformanceMatrixData.filter({
                shopper_colleague_id: driver.colleague_id,
                year: currentYear
            });
            setSelectedDriver({ name: driver.name, performanceRecords: performanceRecords || [] });
            setIsModalOpen(true);
        } catch (error) {
            toast.error("Failed to load driver's yearly data.");
            console.error("Error fetching driver details:", error);
        }
    };

    const getPeriodicViolationTotal = (driverId, metricName) => {
        let total = 0;
        for (let week = 1; week <= 4; week++) {
            total += getWeeklyValue(driverId, metricName, week);
        }
        return total;
    }

    const getPeriodicRecord = (driverId, metricName) => {
        const driverData = matrixData.get(driverId);
        if (!driverData) return null;

        // Find the record from the latest week that has data
        for (let week = 4; week >= 1; week--) {
            const record = driverData.get(`${metricName}_W${week}`);
            if (record !== undefined && record !== null) {
                return record;
            }
        }
        return null;
    };

    const getPeriodicScore = (driverId, metricName) => {
        // If editing, check editedData first for this periodic metric
        const editKey = `${driverId}-${metricName}`;
        if (isEditing && editedData.has(editKey)) {
            return editedData.get(editKey);
        }

        // Find the score from the latest week that has data
        return getPeriodicRecord(driverId, metricName)?.value || 0;
    };

    const getWeeklyValue = (driverId, metricName, week) => {
        const editKey = `${driverId}-${metricName}_W${week}`;
        if (isEditing && editedData.has(editKey)) {
            return editedData.get(editKey);
        }
        // Access the value property from the stored record
        return matrixData.get(driverId)?.get(`${metricName}_W${week}`)?.value || 0;
    };

    // New: Functions for YTD view
    const getYtdRecord = (driverId, metricName) => {
        const driverData = ytdMatrixData.get(driverId);
        if (!driverData) return null;
        return driverData.get(metricName) || null;
    };

    const getYtdScore = (driverId, metricName) => {
        return getYtdRecord(driverId, metricName)?.value || 0;
    };

    const getValue = (driverId, key) => {
        if (activeTab === "ytd") {
            // YTD view - all metrics are treated as aggregated values
            // Serve Legal metrics might be "Serve Legal Fail" or "Serve Legal Pass"
            // Other metrics are like "Smoother", "Safer", "Cleaner", "DHR", "Breaks", "Speeding 10%", "Speeding 30%", "Masternaut", "Smoother Violation", "Safer Violation", "Cleaner Violation"
            return getYtdScore(driverId, key);
        }

        // Period view (existing logic)
        // Handle periodic scores (Smoother, Safer, Cleaner, Serve Legal Fail, Serve Legal Pass)
        if (['Smoother', 'Safer', 'Cleaner', 'Serve Legal Fail', 'Serve Legal Pass'].includes(key)) {
            return getPeriodicScore(driverId, key);
        }

        // Handle weekly values
        if (key.includes('_W')) {
            const [metricName, weekPart] = key.split('_W');
            const week = parseInt(weekPart);
            return getWeeklyValue(driverId, metricName, week);
        }

        return 0;
    };

    const handleSort = (sortKey) => {
        let direction = 'desc';
        if (sortConfig.key === sortKey && sortConfig.direction === 'desc') {
            direction = 'asc';
        }
        setSortConfig({ key: sortKey, direction });
    };

    const sortedDrivers = useMemo(() => {
        let sortableDrivers = [...drivers];

        if (sortConfig.key) { // If a sort key is applied by the user
            if (sortConfig.key === 'name') {
                sortableDrivers.sort((a, b) => {
                    const aValue = a.name || '';
                    const bValue = b.name || '';
                    return sortConfig.direction === 'asc'
                        ? aValue.localeCompare(bValue)
                        : bValue.localeCompare(aValue);
                });
            } else { // Sort by metric value
                sortableDrivers.sort((a, b) => {
                    const aValue = getValue(a.colleague_id, sortConfig.key) || 0;
                    const bValue = getValue(b.colleague_id, sortConfig.key) || 0;

                    return sortConfig.direction === 'asc'
                        ? aValue - bValue
                        : bValue - aValue;
                });
            }
        } else { // Default sort logic - prioritize drivers with speeding or breaks violations
            sortableDrivers.sort((a, b) => {
                // Check if driver has any speeding 10%, speeding 30%, or breaks violations
                const aHasViolations = ['Speeding 10%', 'Speeding 30%', 'Breaks', 'Masternaut', 'Smoother Violation', 'Safer Violation', 'Cleaner Violation'].some(metric => {
                    if (activeTab === "ytd") {
                        return getYtdScore(a.colleague_id, metric) > 0;
                    } else {
                        return [1, 2, 3, 4].some(week => {
                            const value = getWeeklyValue(a.colleague_id, metric, week);
                            return value > 0;
                        });
                    }
                });

                const bHasViolations = ['Speeding 10%', 'Speeding 30%', 'Breaks', 'Masternaut', 'Smoother Violation', 'Safer Violation', 'Cleaner Violation'].some(metric => {
                    if (activeTab === "ytd") {
                        return getYtdScore(b.colleague_id, metric) > 0;
                    } else {
                        return [1, 2, 3, 4].some(week => {
                            const value = getWeeklyValue(b.colleague_id, metric, week);
                            return value > 0;
                        });
                    }
                });

                if (aHasViolations !== bHasViolations) {
                    return aHasViolations ? -1 : 1; // drivers with violations first
                }

                // If both have violations or both don't have violations, sort by name
                return a.name.localeCompare(b.name);
            });
        }

        return sortableDrivers;
    }, [drivers, sortConfig, matrixData, ytdMatrixData, editedData, isEditing, activeTab]);

    const totals = useMemo(() => {
        if (isLoading || sortedDrivers.length === 0) {
            return null;
        }

        const initialTotals = {
            smoother: { sum: 0, count: 0 },
            safer: { sum: 0, count: 0 },
            cleaner: { sum: 0, count: 0 },
            dhr: 0,
            breaks: 0,
            masternaut: 0,
            speeding10: 0,
            speeding30: 0,
            serveLegalFail: 0,
            serveLegalPass: 0,
            // YTD-specific totals
            smoother_violation: 0,
            safer_violation: 0,
            cleaner_violation: 0,
            // Weekly totals for period view (only these remain)
            dhr_w1: 0, dhr_w2: 0, dhr_w3: 0, dhr_w4: 0,
            breaks_w1: 0, breaks_w2: 0, breaks_w3: 0, breaks_w4: 0,
            speeding10_w1: 0, speeding10_w2: 0, speeding10_w3: 0, speeding10_w4: 0,
            speeding30_w1: 0, speeding30_w2: 0, speeding30_w3: 0, speeding30_w4: 0,
        };

        const calculatedTotals = sortedDrivers.reduce((acc, driver) => {
            if (activeTab === 'ytd') {
                const smootherVal = getYtdScore(driver.colleague_id, 'Smoother');
                if (smootherVal > 0) { acc.smoother.sum += smootherVal; acc.smoother.count++; }

                const saferVal = getYtdScore(driver.colleague_id, 'Safer');
                if (saferVal > 0) { acc.safer.sum += saferVal; acc.safer.count++; }

                const cleanerVal = getYtdScore(driver.colleague_id, 'Cleaner');
                if (cleanerVal > 0) { acc.cleaner.sum += cleanerVal; acc.cleaner.count++; }

                acc.dhr += getYtdScore(driver.colleague_id, 'DHR');
                acc.breaks += getYtdScore(driver.colleague_id, 'Breaks');
                acc.masternaut += getYtdScore(driver.colleague_id, 'Masternaut');
                acc.speeding10 += getYtdScore(driver.colleague_id, 'Speeding 10%');
                acc.speeding30 += getYtdScore(driver.colleague_id, 'Speeding 30%');
                acc.serveLegalFail += getYtdScore(driver.colleague_id, 'Serve Legal Fail');
                acc.serveLegalPass += getYtdScore(driver.colleague_id, 'Serve Legal Pass');
                acc.smoother_violation += getYtdScore(driver.colleague_id, 'Smoother Violation');
                acc.safer_violation += getYtdScore(driver.colleague_id, 'Safer Violation');
                acc.cleaner_violation += getYtdScore(driver.colleague_id, 'Cleaner Violation');
            } else { // activeTab === 'period'
                const smootherVal = getPeriodicScore(driver.colleague_id, 'Smoother');
                if (smootherVal > 0) { acc.smoother.sum += smootherVal; acc.smoother.count++; }

                const saferVal = getPeriodicScore(driver.colleague_id, 'Safer');
                if (saferVal > 0) { acc.safer.sum += saferVal; acc.safer.count++; }

                const cleanerVal = getPeriodicScore(driver.colleague_id, 'Cleaner');
                if (cleanerVal > 0) { acc.cleaner.sum += cleanerVal; acc.cleaner.count++; }

                for (let i = 1; i <= 4; i++) {
                    acc[`dhr_w${i}`] += getWeeklyValue(driver.colleague_id, 'DHR', i);
                    acc[`breaks_w${i}`] += getWeeklyValue(driver.colleague_id, 'Breaks', i);
                    acc[`speeding10_w${i}`] += getWeeklyValue(driver.colleague_id, 'Speeding 10%', i);
                    acc[`speeding30_w${i}`] += getWeeklyValue(driver.colleague_id, 'Speeding 30%', i);
                }

                acc.serveLegalFail += getPeriodicScore(driver.colleague_id, 'Serve Legal Fail');
                acc.serveLegalPass += getPeriodicScore(driver.colleague_id, 'Serve Legal Pass');
            }
            return acc;
        }, initialTotals);

        // Calculate averages
        const finalTotals = {
            avgSmoother: calculatedTotals.smoother.count > 0 ? (calculatedTotals.smoother.sum / calculatedTotals.smoother.count) : 0,
            avgSafer: calculatedTotals.safer.count > 0 ? (calculatedTotals.safer.sum / calculatedTotals.safer.count) : 0,
            avgCleaner: calculatedTotals.cleaner.count > 0 ? (calculatedTotals.cleaner.sum / calculatedTotals.cleaner.count) : 0,
            ...calculatedTotals
        };

        return finalTotals;
    }, [sortedDrivers, matrixData, ytdMatrixData, activeTab, isLoading, isEditing, editedData]);

    const handleEditToggle = () => {
        if (!canEdit) {
            toast.error("You must be logged in as an administrator to edit data.");
            return;
        }
        if (activeTab === "ytd") {
            toast.info("Editing is only available in 'Period View'.");
            return;
        }

        if (isEditing) {
            if (editedData && editedData.size > 0) {
                setShowConfirmDialog(true);
            } else {
                setIsEditing(false);
            }
        } else {
            setEditedData(new Map());
            setIsEditing(true);
        }
    };

    const handleCancelEdit = () => {
        setIsEditing(false);
        setEditedData(new Map());
        setShowConfirmDialog(false);
    };

    const handleValueChange = (key, value) => {
        const numericValue = parseFloat(value) || 0;
        setEditedData(prev => {
            const newMap = new Map(prev || new Map()); // Ensure prev is always a Map
            newMap.set(key, numericValue);
            return newMap;
        });
    };

    const handleSaveChanges = async () => {
        if (!canEdit) return;
        if (activeTab === "ytd") return; // Should not happen if edit button is hidden

        const allExistingRecords = await PerformanceMatrixData.filter({
            year: currentYear,
            period: currentPeriod,
        });

        const existingRecordsMap = new Map();
        (allExistingRecords || []).forEach(rec => { // Removed || [] as filter should return array
            const mapKey = `${rec.shopper_colleague_id}-${rec.metric_name}_W${rec.week}`;
            existingRecordsMap.set(mapKey, rec);
        });

        const upsertPromises = [];
        const editedDataEntries = Array.from((editedData || new Map()).entries()); // Ensure editedData is always a Map

        for (const [key, value] of editedDataEntries) {
            // Check if it's a weekly or periodic metric based on the key format
            if (key.includes('_W')) { // It's a weekly metric (e.g., DHR_W1, Masternaut_W1, Smoother Violation_W1)
                const [driverId, metricWithWeek] = key.split('-');
                const [metricName, weekPart] = metricWithWeek.split('_W');
                const week = parseInt(weekPart);

                const existingRecord = existingRecordsMap.get(key); // Key includes _Wweek

                if (existingRecord) {
                    if (existingRecord.value !== value) {
                        upsertPromises.push(PerformanceMatrixData.update(existingRecord.id, { value }));
                    }
                } else {
                    upsertPromises.push(PerformanceMatrixData.create({
                        shopper_colleague_id: driverId,
                        metric_name: metricName,
                        value,
                        date: new Date().toISOString().split('T')[0],
                        period: currentPeriod,
                        week,
                        year: currentYear
                    }));
                }
            } else { // It's a periodic metric (e.g., Smoother, Safer, Cleaner, Serve Legal Fail, Serve Legal Pass)
                const [driverId, metricName] = key.split('-');
                const week = 4; // Always save/update the latest week (W4) for periodic scores
                const recordKey = `${driverId}-${metricName}_W${week}`; // Construct the key as it's stored in DB (metric_name_Wweek)
                const existingRecord = existingRecordsMap.get(recordKey);

                if (existingRecord) {
                    if (existingRecord.value !== value) {
                        upsertPromises.push(PerformanceMatrixData.update(existingRecord.id, { value }));
                    }
                } else {
                    upsertPromises.push(PerformanceMatrixData.create({
                        shopper_colleague_id: driverId,
                        metric_name: metricName,
                        value,
                        date: new Date().toISOString().split('T')[0],
                        period: currentPeriod,
                        week, // Always save to week 4 for periodic scores
                        year: currentYear
                    }));
                }
            }
        }

        if (upsertPromises.length === 0) {
            toast.info("No changes to save.");
            setIsEditing(false);
            setEditedData(new Map());
            setShowConfirmDialog(false);
            return;
        }

        try {
            await toast.promise(Promise.all(upsertPromises), {
                loading: 'Saving changes...',
                success: 'Changes saved successfully!',
                error: 'Failed to save changes.'
            });
            await fetchData();
        } catch (error) {
            console.error('Error saving changes:', error);
        } finally {
            setIsEditing(false);
            setEditedData(new Map());
            setShowConfirmDialog(false);
        }
    };

    const handleClearPeriodData = async () => {
        if (!canEdit) {
            toast.error("You must be logged in as an administrator to clear data.");
            return;
        }
        if (activeTab === "ytd") {
            toast.error("Data can only be cleared from the 'Period View'.");
            return;
        }
        setShowClearPeriodDialog(false);

        try {
            const recordsToDelete = await PerformanceMatrixData.filter({
                period: currentPeriod,
                year: currentYear
            });

            if (recordsToDelete.length === 0) { // Removed || [] as filter should return array
                toast.info("There is no data to clear for this period.");
                return;
            }

            const deleteSequentially = async () => {
                for (const record of recordsToDelete) {
                    await PerformanceMatrixData.delete(record.id);
                    // Add a small delay between each request to avoid rate limiting
                    await new Promise(resolve => setTimeout(resolve, 100));
                }
            };

            await toast.promise(deleteSequentially(), {
                loading: `Deleting ${recordsToDelete.length} records...`,
                success: () => {
                    fetchData();
                    return `All data for Period ${currentPeriod} has been cleared successfully.`;
                },
                error: "Failed to clear period data. Please try again.",
            });
        } catch (error) {
            toast.error("Failed to clear period data. Please try again.");
            console.error("Error in handleClearPeriodData:", error);
        }
    };

    const handleNotesClick = async (record) => {
        // This function now handles both Period and YTD records.
        // YTD records don't have an `id`, Period records do.
        if (!record || !record.shopper_colleague_id || !record.metric_name || !record.year) {
            toast.error("Cannot load notes, missing required information.");
            return;
        }

        const isYtdRecord = !record.id;

        // Fetch ALL records for the driver for the year to build a complete history.
        const allRecordsForDriver = await PerformanceMatrixData.filter({
            shopper_colleague_id: record.shopper_colleague_id,
            year: record.year,
        });

        setNotesModalData({
            clickedRecord: record, // The specific record that was clicked.
            allRecordsForDriver: allRecordsForDriver, // All records for the view.
            isViewOnly: isYtdRecord, // YTD records are view only.
        });
        setIsNotesModalOpen(true);
    };

    const handleSaveNotes = async (notesFromModal) => {
        if (!canEdit) {
            toast.error("You are not authorized to save notes.");
            return;
        }

        const driverId = notesModalData.clickedRecord.shopper_colleague_id;
        const year = notesModalData.clickedRecord.year;

        const promises = [];

        // Fetch all period configurations for the year to map dates to periods/weeks
        const allPeriodConfigs = await PeriodConfig.filter({ year });
        const findPeriodForDate = (dateStr) => {
            if (!dateStr) return null;
            const targetDate = new Date(dateStr + 'T00:00:00');
            return allPeriodConfigs.find(p => {
                const start = new Date(p.start_date + 'T00:00:00');
                const end = new Date(p.end_date + 'T23:59:59'); // Include end of day
                return targetDate >= start && targetDate <= end;
            });
        };

        const newNotes = notesFromModal.filter(n => n.isNew);
        const existingNotes = notesFromModal.filter(n => !n.isNew);

        // Process new notes to create/update records
        if (newNotes.length > 0) {
            // Re-fetch all driver records for the year to ensure we have the most up-to-date state
            const allDriverRecordsCurrent = await PerformanceMatrixData.filter({ shopper_colleague_id: driverId, year: year });

            // Create a map for efficient lookup of existing records
            const existingRecordsMap = new Map(allDriverRecordsCurrent.map(rec => [
                `${rec.shopper_colleague_id}-${rec.metric_name}-${rec.period}-${rec.week}`, rec
            ]));

            for (const note of newNotes) {
                const periodConfig = findPeriodForDate(note.event_date);
                if (!periodConfig) {
                    toast.error(`Could not find a valid period for event date ${note.event_date}. Skipping this action.`);
                    continue;
                }

                const period = periodConfig.period_number;
                const startDate = new Date(periodConfig.start_date + 'T00:00:00');
                const eventDate = new Date(note.event_date + 'T00:00:00');
                const diffDays = Math.floor((eventDate - startDate) / (1000 * 60 * 60 * 24));
                const week = Math.floor(diffDays / 7) + 1;

                // Prepare note object for storage, removing temporary modal-specific properties
                const noteToSave = {
                    action_type: note.action_type,
                    date: new Date().toISOString().split('T')[0],
                    event_date: note.event_date,
                    by_who: note.by_who,
                };

                const recordLookupKey = `${driverId}-${note.violation}-${period}-${week}`;
                const targetRecord = existingRecordsMap.get(recordLookupKey);

                if (targetRecord) {
                    // Record already exists, append new note and optionally increment value
                    const updatedNotes = [...(targetRecord.notes || []), noteToSave];
                    const updateData = { notes: updatedNotes };

                    // If auto-increment is enabled, increment the violation count
                    if (note.auto_increment) {
                        updateData.value = (targetRecord.value || 0) + 1;
                    }

                    promises.push(PerformanceMatrixData.update(targetRecord.id, updateData));
                    // Update the map to reflect the change
                    existingRecordsMap.set(recordLookupKey, { ...targetRecord, ...updateData });
                } else {
                    // Record does not exist, create a new one
                    const initialValue = note.auto_increment ? 1 : 0;
                    const newRecordPayload = {
                        shopper_colleague_id: driverId,
                        metric_name: note.violation,
                        value: initialValue,
                        date: new Date().toISOString().split('T')[0],
                        period: period,
                        week: week,
                        year: year,
                        notes: [noteToSave],
                    };
                    promises.push(PerformanceMatrixData.create(newRecordPayload));
                    // Note: We don't update existingRecordsMap with newly created records
                    // as they won't be targeted by subsequent newNotes in this loop,
                    // and subsequent logic will use the original allDriverRecords for comparison.
                    // The fetchData() after saving will fully refresh.
                }
            }
        }

        // Process edits/deletions on existing notes
        const groupedByID = existingNotes.reduce((acc, note) => {
            if (!acc[note.sourceRecordId]) acc[note.sourceRecordId] = [];
            const { sourceRecordId, sourceMetricName, sourceLabel, isNew, ...rest } = note;
            acc[note.sourceRecordId].push(rest);
            return acc;
        }, {});

        for (const record of notesModalData.allRecordsForDriver) {
            const newNotesForRecord = groupedByID[record.id] || [];
            const originalNotes = record.notes || [];

            // Sort notes for consistent comparison
            const sortNotes = (notes) => [...notes].sort((a, b) => {
                const aKey = `${a.event_date || ''}${a.action_type || ''}${a.by_who || ''}`;
                const bKey = `${b.event_date || ''}${b.action_type || ''}${b.by_who || ''}`;
                return aKey.localeCompare(bKey);
            });

            if (JSON.stringify(sortNotes(newNotesForRecord)) !== JSON.stringify(sortNotes(originalNotes))) {
                promises.push(PerformanceMatrixData.update(record.id, { notes: newNotesForRecord }));
            }
        }

        if (promises.length === 0) {
            toast.info("No changes to save.");
            setIsNotesModalOpen(false);
            setNotesModalData(null);
            return;
        }

        try {
            await toast.promise(Promise.all(promises), {
                loading: 'Saving changes...',
                success: 'Changes saved successfully!',
                error: 'Failed to save some changes.'
            });
            await fetchData(); // Refresh data on the main page
        } catch (error) {
            console.error('Error saving changes:', error);
        } finally {
            setIsNotesModalOpen(false);
            setNotesModalData(null);
        }
    };

    const getPercentageColor = (value, metricType) => {
        let greenThreshold, amberLow, redThreshold;

        // Ensure metricType is lowercase for comparison
        const lowerMetricType = metricType.toLowerCase();

        if (lowerMetricType === 'smoother') {
            greenThreshold = 60;
            amberLow = 40.1;
            redThreshold = 40;
        } else if (lowerMetricType === 'safer') {
            greenThreshold = 98;
            amberLow = 96;
            redThreshold = 95.9;
        } else if (lowerMetricType === 'cleaner') {
            greenThreshold = 95;
            amberLow = 90;
            redThreshold = 89.9;
        } else {
            return ''; // For non-percentage metrics or unknown types
        }

        if (value >= greenThreshold) return 'bg-green-100 text-green-800';
        if (value >= amberLow) return 'bg-amber-100 text-amber-800';
        if (value <= redThreshold) return 'bg-red-100 text-red-800';
        return 'bg-amber-100 text-amber-800'; // Fallback to amber if none matched
    };

    const getPeriodicScoreDisplay = (driverId, metricName) => {
        let record, value;

        if (activeTab === "ytd") {
            record = getYtdRecord(driverId, metricName);
            value = getYtdScore(driverId, metricName);
        } else {
            record = getPeriodicRecord(driverId, metricName);
            value = getPeriodicScore(driverId, metricName);
        }

        const metricType = metricName.toLowerCase();

        // Calculate corresponding violation metric data
        const violationMetric = `${metricName} Violation`;
        const violationValue = activeTab === "ytd" ?
            getYtdScore(driverId, violationMetric) :
            getPeriodicViolationTotal(driverId, violationMetric);

        if (isEditing && activeTab !== "ytd") { // Only allow editing in period view
            const editKey = `${driverId}-${metricName}`; // Key for periodic metrics in editedData
            const editValue = editedData.has(editKey) ? editedData.get(editKey) : value;
            return (
                <Input
                    type="number"
                    step="0.1" // Percentage values
                    value={editValue}
                    onChange={(e) => handleValueChange(editKey, e.target.value)}
                    className="w-16 h-7 text-xs text-center"
                />
            );
        }

        if (value === 0) { // Removed || value === null as value should always be a number
            return null; // Return nothing to make the cell blank
        }

        const colorClass = getPercentageColor(value, metricType);
        const content = (
            <span className={`inline-block px-2 py-1 rounded text-xs font-medium ${colorClass}`}>
                {`${Number(value).toFixed(1)}%`}
            </span>
        );
        
        const hasNotes = record?.notes && Array.isArray(record.notes) && record.notes.length > 0;
        const hasViolations = violationValue > 0;
        const showBubble = hasNotes || hasViolations;

        if (activeTab === "ytd" && record) {
            const ytdContent = (
                 <span className="relative flex items-center justify-center">
                    {content}
                    {showBubble && (
                        <MessageSquare className="absolute -top-1 -right-1.5 w-3.5 h-3.5 text-blue-600 fill-blue-200" />
                    )}
                 </span>
            );
            return (
                <button
                    onClick={() => handleNotesClick(record)}
                    aria-label={`View notes for ${metricName}`}
                    title={`Click to view year-to-date notes for ${metricName}`}
                    className="relative"
                >
                    {ytdContent}
                </button>
            );
        }
        
        // Period view button for notes
        if (!isEditing && activeTab !== "ytd" && record?.id) {
            return (
                <button
                    onClick={() => handleNotesClick(record)}
                    className="relative"
                    aria-label={`View notes for ${metricName}`}
                    title={canEdit ? `Click to edit notes for ${metricName}` : `Click to view notes for ${metricName}`}
                >
                    <span className="relative">
                        {content}
                        {showBubble && (
                            <MessageSquare className="absolute -top-1 -right-1.5 w-3.5 h-3.5 text-blue-600 fill-blue-200" />
                        )}
                    </span>
                </button>
            );
        }
        
        // Fallback for non-clickable content
        if (showBubble) {
             return (
                <span className="relative">
                    {content}
                    <MessageSquare className="absolute -top-1 -right-1.5 w-3.5 h-3.5 text-blue-600 fill-blue-200" />
                </span>
            );
        }

        return content;
    };

    const getPeriodicCountDisplay = (driverId, metricName) => {
        let record, value;

        if (activeTab === "ytd") {
            record = getYtdRecord(driverId, metricName);
            value = getYtdScore(driverId, metricName);
        } else {
            record = getPeriodicRecord(driverId, metricName);
            value = getPeriodicScore(driverId, metricName);
        }

        if (isEditing && activeTab !== "ytd") { // Only allow editing in period view
            const editKey = `${driverId}-${metricName}`;
            const editValue = editedData.has(editKey) ? editedData.get(editKey) : value;
            return (
                <Input
                    type="number"
                    step="1"
                    value={editValue}
                    onChange={(e) => handleValueChange(editKey, e.target.value)}
                    className="w-16 h-7 text-xs text-center"
                />
            );
        }

        if (value > 0) {
            const content = (
                <span className="inline-block px-2 py-1 rounded text-xs font-bold bg-red-100 text-red-800">
                    {Math.round(value)} {/* Round to nearest whole number for counts */}
                </span>
            );

            if (activeTab === "ytd" && record && record.notes && Array.isArray(record.notes) && record.notes.length > 0) {
                const ytdContent = (
                     <span className="relative flex items-center justify-center">
                        {content}
                        <MessageSquare className="absolute -top-1 -right-1.5 w-3.5 h-3.5 text-blue-600 fill-blue-200" />
                     </span>
                );
                return (
                    <button
                        onClick={() => handleNotesClick(record)}
                        aria-label={`View notes for ${metricName}`}
                        title={`Click to view year-to-date notes for ${metricName}`}
                        className="relative"
                    >
                        {ytdContent}
                    </button>
                )
            }

            // Add button for notes - viewable by everyone, editable only by admins
            if (!isEditing && activeTab !== "ytd" && record?.id) {
                return (
                    <button
                        onClick={() => handleNotesClick(record)}
                        className="relative"
                        aria-label={`View notes for ${metricName}`}
                        title={canEdit ? `Click to edit notes for ${metricName}` : `Click to view notes for ${metricName}`}
                    >
                        {content}
                        {record.notes && Array.isArray(record.notes) && record.notes.length > 0 && (
                            // Display message icon if notes exist
                            <MessageSquare className="absolute -top-1 -right-1.5 w-3.5 h-3.5 text-blue-600 fill-blue-200" />
                        )}
                    </button>
                );
            }
            return content;
        }

        return null; // Return nothing if value is 0 or less
    };

    const getWeeklyValueDisplay = (driverId, metricName, week) => {
        if (activeTab === "ytd") {
            return null; // Don't show weekly values in YTD tab
        }

        // Retrieve the full record object from matrixData
        const record = matrixData.get(driverId)?.get(`${metricName}_W${week}`);
        const value = getWeeklyValue(driverId, metricName, week);

        if (isEditing) {
            const editKey = `${driverId}-${metricName}_W${week}`; // Key for weekly metrics in editedData
            return (
                <Input
                    type="number"
                    step="1" // Non-percentage values
                    value={value}
                    onChange={(e) => handleValueChange(editKey, e.target.value)}
                    className="w-12 h-7 text-xs text-center"
                />
            );
        }

        if (value > 0) {
            const content = (
                <span className="inline-block px-2 py-1 rounded text-xs font-bold bg-red-100 text-red-800">
                    {value}
                </span>
            );

            // Enable notes button for any weekly metric with a score - viewable by everyone
            if (!isEditing && record?.id) { // Ensure record has an ID for notes
                return (
                    <button
                        onClick={() => handleNotesClick(record)}
                        className="relative"
                        aria-label={`View notes for ${metricName} Week ${week}`}
                        title={canEdit ? `Click to edit notes for ${metricName} Week ${week}` : `Click to view notes for ${metricName} Week ${week}`}
                    >
                        {content}
                        {record.notes && Array.isArray(record.notes) && record.notes.length > 0 && (
                            // Display message icon if notes exist
                            <MessageSquare className="absolute -top-1 -right-1.5 w-3.5 h-3.5 text-blue-600 fill-blue-200" />
                        )}
                    </button>
                );
            }
            return content;
        }

        return null; // Return nothing if value is 0 or less
    };

    // New: Determines which action status map to use based on the active tab
    const getCurrentActionStatus = useCallback(() => {
        return activeTab === "ytd" ? ytdDriverActionStatus : driverActionStatus;
    }, [activeTab, ytdDriverActionStatus, driverActionStatus]);

    // New: Render table headers dynamically based on active tab
    const renderTableHeaders = () => {
        if (activeTab === "period") {
            return (
                <>
                    <TableRow className="border-slate-200/50">
                        <SortableHeader sortKey="name" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 sticky left-0 bg-white z-10 px-2 py-2 text-xs">
                            Name
                        </SortableHeader>
                        <TableHead className="font-semibold text-slate-700 text-center px-2 py-2 text-xs">
                            Role
                        </TableHead>
                        <SortableHeader sortKey="Smoother" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                            Smoother
                        </SortableHeader>
                        <SortableHeader sortKey="Safer" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                            Safer
                        </SortableHeader>
                        <SortableHeader sortKey="Cleaner" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l border-r px-2 py-2 text-xs">
                            Cleaner
                        </SortableHeader>
                        <TableHead className="font-semibold text-slate-700 text-center border-r px-2 py-2 text-xs" colSpan={4}>DHR</TableHead>
                        <TableHead className="font-semibold text-slate-700 text-center border-r px-2 py-2 text-xs" colSpan={4}>Breaks</TableHead>
                        <TableHead className="font-semibold text-slate-700 text-center border-r px-2 py-2 text-xs" colSpan={4}>Speeding 10%</TableHead>
                        <TableHead className="font-semibold text-slate-700 text-center border-r px-2 py-2 text-xs" colSpan={4}>Speeding 30%</TableHead>
                        <TableHead className="font-semibold text-slate-700 text-center border-r px-2 py-2 text-xs" colSpan={2}>Serve Legal</TableHead>
                    </TableRow>
                    <TableRow className="border-slate-200/50">
                        <TableHead className="sticky left-0 bg-white z-10 px-2 py-1"></TableHead>
                        <TableHead className="px-2 py-1"></TableHead>
                        <TableHead className="text-center text-xs border-l px-2 py-1">Period</TableHead>
                        <TableHead className="text-center text-xs border-l px-2 py-1">Period</TableHead>
                        <TableHead className="text-center text-xs border-l border-r px-2 py-1">Period</TableHead>

                        {/* DHR weeks */}
                        <SortableHeader sortKey="DHR_W1" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W1</SortableHeader>
                        <SortableHeader sortKey="DHR_W2" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W2</SortableHeader>
                        <SortableHeader sortKey="DHR_W3" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W3</SortableHeader>
                        <SortableHeader sortKey="DHR_W4" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W4</SortableHeader>

                        {/* Breaks weeks */}
                        <SortableHeader sortKey="Breaks_W1" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W1</SortableHeader>
                        <SortableHeader sortKey="Breaks_W2" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W2</SortableHeader>
                        <SortableHeader sortKey="Breaks_W3" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W3</SortableHeader>
                        <SortableHeader sortKey="Breaks_W4" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W4</SortableHeader>

                        {/* Speeding 10% - 4 weeks */}
                        <SortableHeader sortKey="Speeding 10%_W1" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W1</SortableHeader>
                        <SortableHeader sortKey="Speeding 10%_W2" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W2</SortableHeader>
                        <SortableHeader sortKey="Speeding 10%_W3" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W3</SortableHeader>
                        <SortableHeader sortKey="Speeding 10%_W4" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W4</SortableHeader>

                        {/* Speeding 30% - 4 weeks */}
                        <SortableHeader sortKey="Speeding 30%_W1" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W1</SortableHeader>
                        <SortableHeader sortKey="Speeding 30%_W2" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W2</SortableHeader>
                        <SortableHeader sortKey="Speeding 30%_W3" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">W3</SortableHeader>
                        <SortableHeader sortKey="Speeding 30%_W4" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l border-r px-2 py-1">W4</SortableHeader>

                        {/* Serve Legal Fail & Pass Periodic */}
                        <SortableHeader sortKey="Serve Legal Fail" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l px-2 py-1">Fail</SortableHeader>
                        <SortableHeader sortKey="Serve Legal Pass" sortConfig={sortConfig} onSort={handleSort} className="text-center text-xs border-l border-r px-2 py-1">Pass</SortableHeader>
                    </TableRow>
                </>
            );
        } else { // YTD Headers
            return (
                <TableRow className="border-slate-200/50">
                    <SortableHeader sortKey="name" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 sticky left-0 bg-white z-10 px-2 py-2 text-xs">
                        Name
                    </SortableHeader>
                    <TableHead className="font-semibold text-slate-700 text-center px-2 py-2 text-xs">
                        Role
                    </TableHead>
                    <SortableHeader sortKey="Smoother" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        Smoother
                    </SortableHeader>
                    <SortableHeader sortKey="Safer" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        Safer
                    </SortableHeader>
                    <SortableHeader sortKey="Cleaner" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l border-r px-2 py-2 text-xs">
                        Cleaner
                    </SortableHeader>
                    <SortableHeader sortKey="Smoother Violation" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        Smoother
                    </SortableHeader>
                    <SortableHeader sortKey="Safer Violation" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        Safer
                    </SortableHeader>
                    <SortableHeader sortKey="Cleaner Violation" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        Cleaner
                    </SortableHeader>
                    <SortableHeader sortKey="Masternaut" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        Masternaut
                    </SortableHeader>
                    <SortableHeader sortKey="DHR" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        DHR
                    </SortableHeader>
                    <SortableHeader sortKey="Breaks" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        Breaks
                    </SortableHeader>
                    <SortableHeader sortKey="Speeding 10%" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        Speeding 10%
                    </SortableHeader>
                    <SortableHeader sortKey="Speeding 30%" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        Speeding 30%
                    </SortableHeader>
                    <SortableHeader sortKey="Serve Legal Fail" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l px-2 py-2 text-xs">
                        Serve Legal Fail
                    </SortableHeader>
                    <SortableHeader sortKey="Serve Legal Pass" sortConfig={sortConfig} onSort={handleSort} className="font-semibold text-slate-700 text-center border-l border-r px-2 py-2 text-xs">
                        Serve Legal Pass
                    </SortableHeader>
                </TableRow>
            );
        }
    };

    // New: Render table content dynamically based on active tab
    const renderTableContent = () => {
        const currentActionStatus = getCurrentActionStatus();

        return (
            <TableBody>
                {isLoading ? (
                    Array.from({ length: 10 }).map((_, i) => (
                        <TableRow key={i}>
                            <TableCell className="sticky left-0 bg-white z-10 px-2 py-1"><div className="h-4 bg-gray-200 rounded animate-pulse"></div></TableCell>
                            <TableCell className="px-2 py-1"><div className="h-4 bg-gray-200 rounded animate-pulse"></div></TableCell> {/* Added for Role column */}
                            {Array.from({ length: activeTab === "ytd" ? 13 : 23 }).map((_, j) => ( // 13 for YTD, 23 for Period
                                <TableCell key={j} className="px-2 py-1"><div className="h-4 bg-gray-200 rounded animate-pulse mx-auto w-8"></div></TableCell>
                            ))}
                        </TableRow>
                    ))
                ) : (
                    sortedDrivers.map(driver => (
                        <TableRow key={driver.id} className="border-b border-slate-100 hover:bg-slate-50">
                            <TableCell className="font-medium text-slate-900 sticky left-0 bg-white z-10 px-2 py-1 text-xs">
                                <div className="flex items-center gap-1.5">
                                    <span
                                        className="cursor-pointer hover:text-blue-600 hover:underline"
                                        onClick={() => handleDriverNameClick(driver)}
                                    >
                                        {driver.name}
                                    </span>
                                    {currentActionStatus.get(driver.colleague_id) === 'red' && <Star className="w-2.5 h-2.5 text-red-500 fill-red-500" />}
                                    {currentActionStatus.get(driver.colleague_id) === 'amber' && <Star className="w-2.5 h-2.5 text-amber-500 fill-amber-500" />}
                                    {currentActionStatus.get(driver.colleague_id) === 'blue' && <Star className="w-2.5 h-2.5 text-blue-500 fill-blue-500" />}
                                    {currentActionStatus.get(driver.colleague_id) === 'green' && <Star className="w-2.5 h-2.5 text-green-500 fill-green-500" />}
                                </div>
                            </TableCell>

                            {/* Role Column */}
                            <TableCell className="text-center text-xs px-2 py-1">
                                {driver.role ? (
                                    <span className={`inline-block px-2 py-1 rounded text-xs font-medium ${
                                        driver.role === 'core' ? 'bg-blue-100 text-blue-800' :
                                        driver.role === 'backup' ? 'bg-green-100 text-green-800' :
                                        driver.role === 'c&c' ? 'bg-purple-100 text-purple-800' :
                                        'bg-gray-100 text-gray-800'
                                    }`}>
                                        {driver.role === 'c&c' ? 'C&C' : driver.role.charAt(0).toUpperCase() + driver.role.slice(1)}
                                    </span>
                                ) : (
                                    <span className="inline-block px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-800">
                                        Core
                                    </span>
                                )}
                            </TableCell>

                            {/* Smoother - Periodic/YTD Score */}
                            <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                {getPeriodicScoreDisplay(driver.colleague_id, 'Smoother')}
                            </TableCell>

                            {/* Safer - Periodic/YTD Score */}
                            <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                {getPeriodicScoreDisplay(driver.colleague_id, 'Safer')}
                            </TableCell>

                            {/* Cleaner - Periodic/YTD Score */}
                            <TableCell className="text-center text-xs border-l border-slate-100 border-r px-2 py-1">
                                {getPeriodicScoreDisplay(driver.colleague_id, 'Cleaner')}
                            </TableCell>

                            {activeTab === "period" ? (
                                <>
                                    {/* DHR - 4 weeks */}
                                    {[1, 2, 3, 4].map(week => (
                                        <TableCell key={`dhr-${week}`} className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                            {getWeeklyValueDisplay(driver.colleague_id, 'DHR', week)}
                                        </TableCell>
                                    ))}

                                    {/* Breaks - 4 weeks */}
                                    {[1, 2, 3, 4].map(week => (
                                        <TableCell key={`breaks-${week}`} className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                            {getWeeklyValueDisplay(driver.colleague_id, 'Breaks', week)}
                                        </TableCell>
                                    ))}

                                    {/* Speeding 10% - 4 weeks */}
                                    {[1, 2, 3, 4].map(week => (
                                        <TableCell key={`speeding10-${week}`} className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                            {getWeeklyValueDisplay(driver.colleague_id, 'Speeding 10%', week)}
                                        </TableCell>
                                    ))}

                                    {/* Speeding 30% - 4 weeks */}
                                    {[1, 2, 3, 4].map(week => (
                                        <TableCell key={`speeding30-${week}`} className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                            {getWeeklyValueDisplay(driver.colleague_id, 'Speeding 30%', week)}
                                        </TableCell>
                                    ))}
                                </>
                            ) : (
                                <>
                                    {/* YTD aggregated columns */}
                                    <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                        {getPeriodicCountDisplay(driver.colleague_id, 'Smoother Violation')}
                                    </TableCell>
                                    <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                        {getPeriodicCountDisplay(driver.colleague_id, 'Safer Violation')}
                                    </TableCell>
                                    <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                        {getPeriodicCountDisplay(driver.colleague_id, 'Cleaner Violation')}
                                    </TableCell>
                                    <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                        {getPeriodicCountDisplay(driver.colleague_id, 'Masternaut')}
                                    </TableCell>
                                    <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                        {getPeriodicCountDisplay(driver.colleague_id, 'DHR')}
                                    </TableCell>
                                    <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                        {getPeriodicCountDisplay(driver.colleague_id, 'Breaks')}
                                    </TableCell>
                                    <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                        {getPeriodicCountDisplay(driver.colleague_id, 'Speeding 10%')}
                                    </TableCell>
                                    <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                        {getPeriodicCountDisplay(driver.colleague_id, 'Speeding 30%')}
                                    </TableCell>
                                </>
                            )}

                            {/* Serve Legal - Periodic/YTD */}
                            <TableCell className="text-center text-xs border-l border-slate-100 px-2 py-1">
                                {getPeriodicCountDisplay(driver.colleague_id, 'Serve Legal Fail')}
                            </TableCell>
                            <TableCell className="text-center text-xs border-l border-slate-100 border-r px-2 py-1">
                                {getPeriodicCountDisplay(driver.colleague_id, 'Serve Legal Pass')}
                            </TableCell>
                        </TableRow>
                    ))
                )}
                {drivers.length === 0 && !isLoading && (
                    <TableRow>
                        <TableCell colSpan={activeTab === "ytd" ? 15 : 23} className="text-center py-10 text-slate-50"> {/* Colspan adjusted for new columns */}
                            No active drivers found. Please add drivers in the "Driver Management" page.
                        </TableCell>
                    </TableRow>
                )}
            </TableBody>
        );
    };

    return (
        <div className="p-6 space-y-6">
            <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Changes</DialogTitle>
                        <DialogDescription>
                            You have made {(editedData || new Map()).size} changes. Do you want to save them?
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                        <Button variant="outline" onClick={handleCancelEdit}>Cancel</Button>
                        <Button onClick={handleSaveChanges}>Save Changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <Dialog open={showClearPeriodDialog} onOpenChange={setShowClearPeriodDialog}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Clear Period Data</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to permanently delete ALL performance data for Period {currentPeriod}, {currentYear}? This includes all weeks (1-4) and all drivers. This action cannot be undone.
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setShowClearPeriodDialog(false)}>Cancel</Button>
                        <Button variant="destructive" onClick={handleClearPeriodData}>Clear All Period Data</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Action Notes Modal - now passing more data */}
            <ActionNotesModal
                isOpen={isNotesModalOpen}
                onClose={() => setIsNotesModalOpen(false)}
                notesData={notesModalData}
                onSave={handleSaveNotes}
                driverName={notesModalData ? drivers.find(d => d.colleague_id === notesModalData.clickedRecord.shopper_colleague_id)?.name : ''}
                canEdit={canEdit}
                isViewOnly={notesModalData?.isViewOnly}
            />

            <DriverDetailModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                driverData={selectedDriver}
            />

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="space-y-2">
                    <h1 className="text-2xl font-bold text-gray-900">Driver Performance Matrix</h1>
                </div>
                <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                    <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))} disabled={isEditing}>
                        <SelectTrigger className="w-full sm:w-28 border border-slate-200 rounded-lg px-2 py-1 h-9 bg-white text-slate-900 text-xs">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            {[2025, 2024, 2023].map(y => (
                                <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    {activeTab === "period" && ( // Only show period select in period tab
                        <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))} disabled={isEditing}>
                            <SelectTrigger className="w-full sm:w-28 border border-slate-200 rounded-lg px-2 py-1 h-9 bg-white text-slate-900 text-xs">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                {Array.from({ length: 13 }, (_, i) => (
                                    <SelectItem key={i + 1} value={(i + 1).toString()}>
                                        Period {i + 1}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    )}
                    {canEdit && activeTab === "period" && ( // Only show edit/save/clear buttons in period tab
                        <>
                            {isEditing && (
                                <Button variant="outline" size="sm" onClick={handleCancelEdit} className="h-9 px-3 text-xs">
                                    <X className="w-4 h-4 mr-1"/>
                                    Cancel
                                </Button>
                            )}
                            <Button size="sm" onClick={handleEditToggle} className="btn-modern h-9 px-3 text-xs">
                                {isEditing ? <><Save className="w-4 h-4 mr-1"/>Save</> : <><Edit className="w-4 h-4 mr-1"/>Edit</>}
                            </Button>
                            {!isEditing && (
                                <Button variant="outline" size="sm" onClick={() => setShowClearPeriodDialog(true)} className="border-red-200 text-red-600 hover:bg-red-50 rounded-lg h-9 px-3 text-xs">
                                    <Trash2 className="w-4 h-4 mr-1" />
                                    Clear
                                </Button>
                            )}
                        </>
                    )}
                </div>
            </div>

            <Card className="glass-card">
                <CardContent className="p-4">
                    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                        <TabsList className="grid w-full grid-cols-2 mb-4">
                            <TabsTrigger value="period" className="flex items-center gap-2">
                                <Calendar className="w-4 h-4" />
                                Period View
                            </TabsTrigger>
                            <TabsTrigger value="ytd" className="flex items-center gap-2">
                                <Calendar className="w-4 h-4" />
                                Year to Date
                            </TabsTrigger>
                        </TabsList>

                        <TabsContent value="period" className="mt-0">
                            <div className="overflow-x-auto">
                                <Table>
                                    <TableHeader>
                                        {renderTableHeaders()}
                                    </TableHeader>
                                    {renderTableContent()}
                                    {totals && activeTab === 'period' && !isLoading && (
                                        <tfoot className="sticky bottom-0 bg-slate-100 z-20">
                                            <TableRow className="border-t-2 border-slate-300">
                                                <TableCell colSpan={2} className="sticky left-0 bg-slate-100 z-30 font-bold text-slate-800 px-2 py-2 text-sm">Totals</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">
                                                    {totals.avgSmoother > 0 ? `${totals.avgSmoother.toFixed(1)}%` : '-'}
                                                </TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">
                                                    {totals.avgSafer > 0 ? `${totals.avgSafer.toFixed(1)}%` : '-'}
                                                </TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l border-r px-2 py-2 text-sm">
                                                    {totals.avgCleaner > 0 ? `${totals.avgCleaner.toFixed(1)}%` : '-'}
                                                </TableCell>
                                                {/* Weekly totals */}
                                                {[1, 2, 3, 4].map(week => (
                                                    <TableCell key={`dhr-total-${week}`} className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals[`dhr_w${week}`] || '-'}</TableCell>
                                                ))}
                                                {[1, 2, 3, 4].map(week => (
                                                    <TableCell key={`breaks-total-${week}`} className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals[`breaks_w${week}`] || '-'}</TableCell>
                                                ))}
                                                {[1, 2, 3, 4].map(week => (
                                                    <TableCell key={`speeding10-total-${week}`} className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals[`speeding10_w${week}`] || '-'}</TableCell>
                                                ))}
                                                {[1, 2, 3, 4].map(week => (
                                                    <TableCell key={`speeding30-total-${week}`} className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals[`speeding30_w${week}`] || '-'}</TableCell>
                                                ))}
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals.serveLegalFail || '-'}</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l border-r px-2 py-2 text-sm">{totals.serveLegalPass || '-'}</TableCell>
                                            </TableRow>
                                        </tfoot>
                                    )}
                                </Table>
                            </div>
                        </TabsContent>

                        <TabsContent value="ytd" className="mt-0">
                            <div className="overflow-x-auto">
                                <Table>
                                    <TableHeader>
                                        {renderTableHeaders()}
                                    </TableHeader>
                                    {renderTableContent()}
                                    {totals && activeTab === 'ytd' && !isLoading && (
                                        <tfoot className="sticky bottom-0 bg-slate-100 z-20">
                                            <TableRow className="border-t-2 border-slate-300">
                                                <TableCell colSpan={2} className="sticky left-0 bg-slate-100 z-30 font-bold text-slate-800 px-2 py-2 text-sm">Totals</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">
                                                    {totals.avgSmoother > 0 ? `${totals.avgSmoother.toFixed(1)}%` : '-'}
                                                </TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">
                                                    {totals.avgSafer > 0 ? `${totals.avgSafer.toFixed(1)}%` : '-'}
                                                </TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l border-r px-2 py-2 text-sm">
                                                    {totals.avgCleaner > 0 ? `${totals.avgCleaner.toFixed(1)}%` : '-'}
                                                </TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals.smoother_violation || '-'}</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals.safer_violation || '-'}</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals.cleaner_violation || '-'}</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals.masternaut || '-'}</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals.dhr || '-'}</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals.breaks || '-'}</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals.speeding10 || '-'}</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals.speeding30 || '-'}</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l px-2 py-2 text-sm">{totals.serveLegalFail || '-'}</TableCell>
                                                <TableCell className="text-center font-bold text-slate-800 border-l border-r px-2 py-2 text-sm">{totals.serveLegalPass || '-'}</TableCell>
                                            </TableRow>
                                        </tfoot>
                                    )}
                                </Table>
                            </div>
                        </TabsContent>
                    </Tabs>
                </CardContent>
            </Card>
        </div>
    );
}