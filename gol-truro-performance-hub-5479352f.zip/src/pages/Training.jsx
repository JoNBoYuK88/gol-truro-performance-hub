import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { TrainingRecord } from '@/api/entities';
import { PeriodConfig } from '@/api/entities';
import { useEditLock } from '../Layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { GraduationCap, Upload, Trash2, Calendar, Users, Search, FileDown, BarChart3, Camera, ChevronDown, ChevronUp } from 'lucide-react';
import { toast } from 'sonner';
import { parseISO, format } from 'date-fns';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function Training() {
  const [pastedData, setPastedData] = useState('');
  const [parsedData, setParsedData] = useState([]);
  const [trainingRecords, setTrainingRecords] = useState([]);
  const [previousWeekRecords, setPreviousWeekRecords] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [deleteProgress, setDeleteProgress] = useState({ current: 0, total: 0 });
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;
  
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedPeriod, setSelectedPeriod] = useState(1);
  const [selectedWeek, setSelectedWeek] = useState(1);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('days_left');
  const [sortOrder, setSortOrder] = useState('asc');
  const [isUploadSectionOpen, setIsUploadSectionOpen] = useState(false);

  useEffect(() => {
    loadTrainingRecords();
  }, [selectedPeriod, selectedWeek]);

  useEffect(() => {
    const initialize = async () => {
      try {
        const user = await User.me();
        setIsAdmin(user && user.role === 'admin');
      } catch (e) {
        console.error('Auth error:', e);
        setIsAdmin(false);
      }
      
      // Load period configs and set current period/week
      try {
        const periods = await PeriodConfig.filter({ year: selectedYear }, 'period_number');
        if (periods.length > 0) {
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          
          const currentPeriodConfig = periods.find(p => {
            const startDate = parseISO(p.start_date);
            startDate.setHours(0, 0, 0, 0);
            const endDate = parseISO(p.end_date);
            endDate.setHours(23, 59, 59, 999);
            return today >= startDate && today <= endDate;
          });
          
          if (currentPeriodConfig) {
            const startDate = parseISO(currentPeriodConfig.start_date);
            startDate.setHours(0, 0, 0, 0);
            const diffTime = today.getTime() - startDate.getTime();
            const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
            const currentWeekNumber = Math.min(Math.floor(diffDays / 7) + 1, 4);
            
            setSelectedPeriod(currentPeriodConfig.period_number);
            setSelectedWeek(currentWeekNumber);
          }
        }
      } catch (error) {
        console.error("Error loading period configs:", error);
        toast.error('Failed to load period configurations');
      }
      
      await loadTrainingRecords();
    };
    initialize();
  }, [selectedYear]);

  const loadTrainingRecords = async () => {
    setIsLoading(true);
    try {
      const records = await TrainingRecord.filter(
        { year: selectedYear, period: selectedPeriod, week: selectedWeek },
        'surname'
      );
      setTrainingRecords(records);
      
      // Load previous week for comparison
      let prevPeriod = selectedPeriod;
      let prevWeek = selectedWeek - 1;
      if (prevWeek < 1) {
        prevWeek = 4;
        prevPeriod = selectedPeriod - 1;
      }
      
      if (prevPeriod >= 1) {
        const prevRecords = await TrainingRecord.filter(
          { year: selectedYear, period: prevPeriod, week: prevWeek },
          'surname'
        );
        setPreviousWeekRecords(prevRecords);
      } else {
        setPreviousWeekRecords([]);
      }
    } catch (error) {
      console.error('Error loading training records:', error);
      const errorMessage = error?.message || error?.toString() || 'Failed to load training records';
      toast.error(errorMessage);
      setTrainingRecords([]);
      setPreviousWeekRecords([]);
    } finally {
      setIsLoading(false);
    }
  };

  const parseData = () => {
    if (!pastedData.trim()) {
      toast.error('Please paste data before parsing.');
      return;
    }

    const lines = pastedData.trim().split('\n');
    if (lines.length < 2) {
      toast.error('Data must include header row and at least one data row.');
      return;
    }

    const headers = lines[0].split('\t').map(h => h.trim());
    
    // Map header names to field names (exact matching)
    const headerMap = {
      'colleague id': 'colleague_id',
      'first name': 'first_name',
      'surname': 'surname',
      'user - division': 'user_division',
      'user - division parent': 'user_division_parent',
      'user - location': 'user_location',
      'training title': 'training_title',
      'deadline': 'deadline',
      'status': 'status',
      'enrolment method': 'enrolment_method',
      'managers full name': 'managers_full_name',
      'indirect managers name': 'indirect_managers_name'
    };

    const columnIndices = {};
    headers.forEach((header, index) => {
      const normalizedHeader = header.toLowerCase().trim();
      const exactMatch = headerMap[normalizedHeader];
      if (exactMatch) {
        columnIndices[exactMatch] = index;
      }
    });

    const parsed = [];
    for (let i = 1; i < lines.length; i++) {
      if (lines[i].trim()) {
        const values = lines[i].split('\t');

        const record = {};
        for (const [field, index] of Object.entries(columnIndices)) {
          if (index !== undefined && index < values.length) {
            const value = values[index] ? values[index].trim() : '';

            // Parse date fields
            if (field === 'deadline' && value) {
              try {
                // Handle DD/MM/YYYY HH:MM format (remove time portion first)
                if (value.includes('/')) {
                  // Split by any whitespace to separate date and time
                  const datePart = value.split(/\s+/)[0];
                  const parts = datePart.split('/');
                  if (parts.length === 3) {
                    const day = parts[0].trim().padStart(2, '0');
                    const month = parts[1].trim().padStart(2, '0');
                    const year = parts[2].trim();
                    record[field] = `${year}-${month}-${day}`;
                  } else {
                    record[field] = null;
                  }
                } else if (value.includes('-')) {
                  // Already in YYYY-MM-DD format
                  record[field] = value.split(/\s+/)[0];
                } else {
                  record[field] = null;
                }
              } catch (e) {
                record[field] = null;
              }
            } else {
              record[field] = value || null;
            }
          }
        }

        console.log('Parsed record:', record);

        // Only add if we have at least colleague_id and name
        if (record.colleague_id && (record.first_name || record.surname)) {
          parsed.push(record);
        }
      }
    }

    if (parsed.length === 0) {
      toast.error('No valid data rows found after parsing.');
      return;
    }

    setParsedData(parsed);
    toast.success(`Parsed ${parsed.length} records successfully.`);
  };

  const handleUpload = async () => {
    if (parsedData.length === 0) {
      toast.error('No data to upload. Please parse data first.');
      return;
    }

    setIsLoading(true);
    try {
      const recordsToCreate = parsedData.map(record => ({
        ...record,
        period: selectedPeriod,
        week: selectedWeek,
        year: selectedYear
      }));

      await TrainingRecord.bulkCreate(recordsToCreate);
      toast.success(`Successfully uploaded ${recordsToCreate.length} training records!`);
      
      setPastedData('');
      setParsedData([]);
      await loadTrainingRecords();
    } catch (error) {
      console.error('Error uploading records:', error);
      toast.error('Failed to upload training records');
    }
    setIsLoading(false);
  };

  const handleClearData = () => {
    setPastedData('');
    setParsedData([]);
  };

  const handleDeleteAll = async () => {
    if (!window.confirm(`Are you sure you want to delete all ${trainingRecords.length} records for P${selectedPeriod}W${selectedWeek} ${selectedYear}?`)) {
      return;
    }

    setIsLoading(true);
    let deletedCount = 0;
    try {
      const recordsToDelete = await TrainingRecord.filter({ 
        period: selectedPeriod, 
        week: selectedWeek, 
        year: selectedYear 
      });
      
      setDeleteProgress({ current: 0, total: recordsToDelete.length });
      
      for (const record of recordsToDelete) {
        try {
          await TrainingRecord.delete(record.id);
          deletedCount++;
          setDeleteProgress({ current: deletedCount, total: recordsToDelete.length });
          await new Promise(resolve => setTimeout(resolve, 20)); // Small delay to avoid rate limiting
        } catch (err) {
          console.error(`Failed to delete record ${record.id}:`, err);
        }
      }
      
      toast.success(`Deleted ${deletedCount} of ${recordsToDelete.length} records`);
      await loadTrainingRecords();
    } catch (error) {
      console.error('Error deleting records:', error);
      toast.error(`Failed to delete records. ${deletedCount} deleted before error.`);
    }
    setDeleteProgress({ current: 0, total: 0 });
    setIsLoading(false);
  };

  // Filter and sort records
  const filteredRecords = trainingRecords.filter(record => {
    const fullName = `${record.first_name || ''} ${record.surname || ''}`.toLowerCase();
    const department = (record.user_division?.replace(/^[^-]+ - /, '') || '').toLowerCase();
    const searchLower = searchTerm.toLowerCase();
    
    const matchesSearch = searchTerm === '' || 
      fullName.includes(searchLower) ||
      record.colleague_id?.toLowerCase().includes(searchLower) ||
      department.includes(searchLower);
    
    const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
    
    return matchesSearch && matchesStatus;
    }).sort((a, b) => {
    if (sortBy === 'days_left') {
      const aDaysLeft = a.deadline ? Math.ceil((parseISO(a.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : 999999;
      const bDaysLeft = b.deadline ? Math.ceil((parseISO(b.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : 999999;
      return sortOrder === 'asc' ? aDaysLeft - bDaysLeft : bDaysLeft - aDaysLeft;
    }
    
    if (sortBy === 'user_division') {
      const aDivision = (a.user_division || '').replace(/^[^-]+ - /, '');
      const bDivision = (b.user_division || '').replace(/^[^-]+ - /, '');
      
      if (aDivision !== bDivision) {
        if (aDivision < bDivision) return sortOrder === 'asc' ? -1 : 1;
        if (aDivision > bDivision) return sortOrder === 'asc' ? 1 : -1;
      }
      
      // Secondary sort by days left (ascending)
      const aDaysLeft = a.deadline ? Math.ceil((parseISO(a.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : 999999;
      const bDaysLeft = b.deadline ? Math.ceil((parseISO(b.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : 999999;
      return aDaysLeft - bDaysLeft;
    }
    
    let aVal = a[sortBy] || '';
    let bVal = b[sortBy] || '';
    
    if (sortBy === 'deadline') {
      aVal = a.deadline ? new Date(a.deadline).getTime() : 0;
      bVal = b.deadline ? new Date(b.deadline).getTime() : 0;
    }
    
    if (aVal < bVal) return sortOrder === 'asc' ? -1 : 1;
    if (aVal > bVal) return sortOrder === 'asc' ? 1 : -1;
    return 0;
  });
  
  const handleSort = (column) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('asc');
    }
  };

  // Get unique statuses for filter
  const uniqueStatuses = [...new Set(trainingRecords.map(r => r.status).filter(Boolean))];

  // Calculate division data for current week
  const divisionData = trainingRecords.reduce((acc, record) => {
    let division = record.user_division?.replace(/^[^-]+ - /, '') || 'Unknown';
    // Rename specific divisions
    if (division === 'Truro Travel Money Bureau') {
      division = 'Travel Money Bureau';
    }
    if (division === 'Customer Experience') {
      division = 'Customer EX';
    }
    if (!acc[division]) {
      acc[division] = { total: 0, overdue: 0, remaining: 0, minDaysLeft: Infinity };
    }
    acc[division].total++;
    
    // Check if overdue
    const daysLeft = record.deadline ? Math.ceil((parseISO(record.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : null;
    if (daysLeft !== null && daysLeft < 0) {
      acc[division].overdue++;
    } else if (daysLeft !== null && daysLeft >= 0) {
      acc[division].remaining++;
      acc[division].minDaysLeft = Math.min(acc[division].minDaysLeft, daysLeft);
    }
    
    return acc;
  }, {});

  // Calculate division data for previous week
  const prevDivisionData = previousWeekRecords.reduce((acc, record) => {
    let division = record.user_division?.replace(/^[^-]+ - /, '') || 'Unknown';
    if (division === 'Truro Travel Money Bureau') {
      division = 'Travel Money Bureau';
    }
    if (division === 'Customer Experience') {
      division = 'Customer EX';
    }
    if (!acc[division]) {
      acc[division] = { total: 0, overdue: 0, remaining: 0 };
    }
    acc[division].total++;
    
    const daysLeft = record.deadline ? Math.ceil((parseISO(record.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : null;
    if (daysLeft !== null && daysLeft < 0) {
      acc[division].overdue++;
    } else if (daysLeft !== null && daysLeft >= 0) {
      acc[division].remaining++;
    }
    
    return acc;
  }, {});

  const chartData = Object.entries(divisionData)
    .map(([name, data]) => {
      const prevData = prevDivisionData[name] || { total: 0, remaining: 0, overdue: 0 };
      const totalDiff = data.total - prevData.total;
      const remainingDiff = data.remaining - prevData.remaining;
      const overdueDiff = data.overdue - prevData.overdue;
      
      return { 
        name, 
        remaining: data.remaining, 
        overdue: data.overdue,
        daysLeft: data.minDaysLeft === Infinity ? '-' : data.minDaysLeft,
        totalDiff,
        remainingDiff,
        overdueDiff
      };
    })
    .sort((a, b) => b.remaining + b.overdue - a.remaining - a.overdue);

  // Calculate previous week totals
  const prevWeekTotal = previousWeekRecords.length;
  const prevWeekRemaining = previousWeekRecords.filter(r => {
    const daysLeft = r.deadline ? Math.ceil((parseISO(r.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : null;
    return daysLeft !== null && daysLeft >= 0;
  }).length;
  const prevWeekOverdue = previousWeekRecords.filter(r => {
    const daysLeft = r.deadline ? Math.ceil((parseISO(r.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : null;
    return daysLeft !== null && daysLeft < 0;
  }).length;

  const currentTotal = trainingRecords.length;
  const currentRemaining = chartData.reduce((sum, d) => sum + d.remaining, 0);
  const currentOverdue = chartData.reduce((sum, d) => sum + d.overdue, 0);

  const totalDiff = currentTotal - prevWeekTotal;
  const remainingDiff = currentRemaining - prevWeekRemaining;
  const overdueDiff = currentOverdue - prevWeekOverdue;

  const handleExportPDF = () => {
    // Add print class to body
    document.body.classList.add('printing-training');
    
    // Trigger print
    window.print();
    
    // Remove print class after print dialog closes
    setTimeout(() => {
      document.body.classList.remove('printing-training');
    }, 100);
  };

  const handleCaptureChart = async () => {
    const chartElement = document.getElementById('training-chart-card');
    if (!chartElement) {
      toast.error('Chart element not found');
      return;
    }
    
    try {
      toast.info('Capturing chart...');
      
      const canvas = await html2canvas(chartElement, {
        backgroundColor: '#ffffff',
        scale: 3,
        logging: false,
        useCORS: true,
        allowTaint: true,
        scrollX: 0,
        scrollY: -window.scrollY,
        windowWidth: document.documentElement.scrollWidth,
        windowHeight: document.documentElement.scrollHeight
      });
      
      canvas.toBlob((blob) => {
        if (blob) {
          const item = new ClipboardItem({ 'image/png': blob });
          navigator.clipboard.write([item]);
          toast.success('Chart copied to clipboard!');
        } else {
          toast.error('Failed to create image');
        }
      });
    } catch (error) {
      console.error('Error capturing chart:', error);
      toast.error('Failed to capture chart: ' + error.message);
    }
  };



  return (
    <div className="p-6 space-y-6">
      <style>{`
        @media print {
          @page {
            size: A4 landscape;
            margin: 10mm;
          }
          
          /* Hide everything by default */
          body * {
            visibility: hidden !important;
          }
          
          /* Show only the table and its contents */
          #training-records-export,
          #training-records-export * {
            visibility: visible !important;
          }
          
          /* Position the table */
          #training-records-export {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
          }
          
          /* Hide the card wrapper elements */
          #training-records-export > div:first-child {
            border: none !important;
            box-shadow: none !important;
            background: transparent !important;
            padding: 0 !important;
          }
          
          /* Hide search and filter controls */
          .flex.gap-4.mb-4 {
            display: none !important;
          }
          
          /* Table styles */
          table {
            width: 100% !important;
            font-size: 7px !important;
            border-collapse: collapse !important;
          }
          
          th,
          td {
            padding: 2px 4px !important;
            border: 1px solid #ddd !important;
            line-height: 1.2 !important;
          }
          
          th {
            background: #f3f4f6 !important;
            font-weight: 600 !important;
          }
          
          /* Colored badges */
          .bg-red-600 {
            background-color: #dc2626 !important;
            color: white !important;
          }
          
          .bg-orange-600 {
            background-color: #ea580c !important;
            color: white !important;
          }
          
          .bg-green-500 {
            background-color: #22c55e !important;
            color: white !important;
          }
          
          .bg-green-600 {
            background-color: #16a34a !important;
            color: white !important;
          }
          
          span[class*="bg-"] {
            padding: 1px 4px !important;
            border-radius: 3px !important;
            font-weight: 500 !important;
            display: inline-block !important;
            font-size: 7px !important;
          }
        }
      `}</style>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <GraduationCap className="w-7 h-7 text-blue-600" />
            Training Records
          </h1>
          <p className="text-gray-600 mt-1">Upload and manage colleague training data</p>
        </div>
      </div>

      {/* Division Chart */}
      {trainingRecords.length > 0 && (
        <Card className="glass-card" id="training-chart-card">
          <CardHeader>
            <CardTitle className="flex flex-col md:flex-row justify-between gap-4">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Training by Department
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleCaptureChart}
                  className="ml-2"
                  title="Copy chart as image"
                >
                  <Camera className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Select value={selectedYear.toString()} onValueChange={(val) => setSelectedYear(parseInt(val))}>
                  <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 3 }, (_, i) => new Date().getFullYear() - 1 + i).map(y => (
                      <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedPeriod.toString()} onValueChange={(val) => setSelectedPeriod(parseInt(val))}>
                  <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 13 }, (_, i) => i + 1).map(p => (
                      <SelectItem key={p} value={p.toString()}>Period {p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedWeek.toString()} onValueChange={(val) => setSelectedWeek(parseInt(val))}>
                  <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 4 }, (_, i) => i + 1).map(w => (
                      <SelectItem key={w} value={w.toString()}>Week {w}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-blue-500 rounded"></div>
                  <span>Remaining</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-red-600 rounded"></div>
                  <span>Overdue</span>
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-4">
                  <div className="text-sm font-normal text-slate-600">
                    Total: <span className="font-bold text-slate-900">{currentTotal}</span> records
                    {previousWeekRecords.length > 0 && (
                      <span className={`ml-2 text-xs ${totalDiff > 0 ? 'text-red-600' : totalDiff < 0 ? 'text-green-600' : 'text-slate-500'}`}>
                        ({totalDiff > 0 ? '+' : ''}{totalDiff})
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-1 rounded bg-blue-100 text-blue-800 font-medium">
                      {currentRemaining} Remaining
                      {previousWeekRecords.length > 0 && (
                        <span className={`ml-1 ${remainingDiff > 0 ? 'text-red-700' : remainingDiff < 0 ? 'text-green-700' : ''}`}>
                          ({remainingDiff > 0 ? '+' : ''}{remainingDiff})
                        </span>
                      )}
                    </span>
                    <span className="text-xs px-2 py-1 rounded bg-red-100 text-red-800 font-medium">
                      {currentOverdue} Overdue
                      {previousWeekRecords.length > 0 && (
                        <span className={`ml-1 ${overdueDiff > 0 ? 'text-red-900' : overdueDiff < 0 ? 'text-green-700' : ''}`}>
                          ({overdueDiff > 0 ? '+' : ''}{overdueDiff})
                        </span>
                      )}
                    </span>
                  </div>
                </div>
              </div>
            </CardTitle>
            <CardDescription>
              Number of training records per department for P{selectedPeriod}W{selectedWeek} {selectedYear}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={340}>
              <BarChart data={chartData} margin={{ top: 20, right: 10, left: 10, bottom: 35 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="name" 
                  height={50}
                  angle={0}
                  textAnchor="middle"
                  interval={0}
                  tick={(props) => {
                    const { x, y, payload, index } = props;
                    const item = chartData[index];
                    if (!item) return null;
                    const daysText = item.daysLeft === '-' ? 'No upcoming' : `${item.daysLeft}d`;
                    return (
                      <g transform={`translate(${x},${y})`}>
                        <text x={0} y={0} dy={6} textAnchor="middle" fill="#666" fontSize="11px">
                          {payload.value}
                        </text>
                        <text x={0} y={0} dy={20} textAnchor="middle" fill="#dc2626" fontSize="10px" fontWeight="600">
                          {daysText}
                        </text>
                      </g>
                    );
                  }}
                />
                <YAxis hide />
                <Tooltip />
                <Bar 
                  dataKey="remaining" 
                  fill="#3b82f6" 
                  name="Remaining" 
                  label={(props) => {
                    const { x, y, width, value, index } = props;
                    const item = chartData[index];
                    const diff = item.remainingDiff;
                    return (
                      <g>
                        <text x={x + width / 2} y={y - 4} fill="#1e40af" textAnchor="middle" fontSize={11} fontWeight="bold">
                          {value}
                        </text>
                        {previousWeekRecords.length > 0 && diff !== 0 && (
                          <text x={x + width / 2} y={y - 15} fill={diff > 0 ? '#dc2626' : '#16a34a'} textAnchor="middle" fontSize={8} fontWeight="600">
                            ({diff > 0 ? '+' : ''}{diff})
                          </text>
                        )}
                      </g>
                    );
                  }}
                />
                <Bar 
                  dataKey="overdue" 
                  fill="#dc2626" 
                  name="Overdue" 
                  label={(props) => {
                    const { x, y, width, value, index } = props;
                    const item = chartData[index];
                    const diff = item.overdueDiff;
                    return (
                      <g>
                        <text x={x + width / 2} y={y - 4} fill="#991b1b" textAnchor="middle" fontSize={11} fontWeight="bold">
                          {value}
                        </text>
                        {previousWeekRecords.length > 0 && diff !== 0 && (
                          <text x={x + width / 2} y={y - 15} fill={diff > 0 ? '#dc2626' : '#16a34a'} textAnchor="middle" fontSize={8} fontWeight="600">
                            ({diff > 0 ? '+' : ''}{diff})
                          </text>
                        )}
                      </g>
                    );
                  }}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Data Upload */}
      {canEdit && (
      <Card className="glass-card">
        <CardHeader className="cursor-pointer" onClick={() => setIsUploadSectionOpen(!isUploadSectionOpen)}>
          <CardTitle className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-blue-600" />
              Upload Training Data
            </div>
            {isUploadSectionOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </CardTitle>
          <CardDescription>
            Paste data from Excel (tab-separated). Expected columns: Colleague ID, First Name, Surname, User Decision, Status, Deadline, etc.
          </CardDescription>
        </CardHeader>
        {isUploadSectionOpen && (
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Paste Excel data here (tab-separated with headers)..."
            className="h-40 font-mono text-xs"
            value={pastedData}
            onChange={(e) => setPastedData(e.target.value)}
          />

          <div className="flex gap-2">
            <Button 
              onClick={parseData} 
              disabled={!pastedData.trim() || isLoading}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              <Search className="w-4 h-4 mr-2" />
              Parse and Check Data
            </Button>
            <Button variant="outline" onClick={handleClearData} disabled={isLoading}>
              <Trash2 className="w-4 h-4 mr-2" />
              Clear
            </Button>
          </div>

          {parsedData.length > 0 && (
            <div className="space-y-2">
              <div className="text-sm text-green-600">
                ✓ Parsed {parsedData.length} records
              </div>
              <div className="border border-gray-200 rounded-lg max-h-96 overflow-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead>Colleague ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Training Title</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Deadline</TableHead>
                      <TableHead>Days Left</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {parsedData.slice(0, 50).map((record, index) => {
                      const daysLeft = record.deadline ? Math.ceil((parseISO(record.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : null;
                      return (
                        <TableRow key={index}>
                          <TableCell className="font-mono text-xs">{record.colleague_id}</TableCell>
                          <TableCell>{record.first_name} {record.surname}</TableCell>
                          <TableCell className="text-xs">{
                            (() => {
                              let div = record.user_division?.replace(/^[^-]+ - /, '');
                              if (div === 'Truro Travel Money Bureau') return 'Travel Money Bureau';
                              if (div === 'Customer Experience') return 'Customer EX';
                              return div;
                            })()
                          }</TableCell>
                          <TableCell className="text-xs">{record.training_title}</TableCell>
                          <TableCell>
                            <span className={`text-xs px-2 py-1 rounded ${
                              record.status === 'Passed' ? 'bg-green-100 text-green-800' :
                              record.status === 'Registered' ? 'bg-blue-100 text-blue-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {record.status}
                            </span>
                          </TableCell>
                          <TableCell className="text-xs">
                            {record.deadline ? format(parseISO(record.deadline), 'dd/MM/yyyy') : ''}
                          </TableCell>
                          <TableCell>
                            {daysLeft !== null && (
                              <span className={`text-[9px] px-1.5 py-0.5 rounded font-medium inline-block w-16 text-center ${
                                daysLeft < 0 ? 'bg-red-600 text-white' :
                                daysLeft <= 7 ? 'bg-red-600 text-white' :
                                daysLeft <= 14 ? 'bg-orange-600 text-white' :
                                daysLeft <= 21 ? 'bg-green-500 text-white' :
                                'bg-green-600 text-white'
                              }`}>
                                {daysLeft < 0 ? `${Math.abs(daysLeft)}d overdue` : `${daysLeft}d`}
                              </span>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    {parsedData.length > 50 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-gray-500 text-sm">
                          ... and {parsedData.length - 50} more records
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
              <Button 
                onClick={handleUpload} 
                disabled={isLoading}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                Upload {parsedData.length} Records
              </Button>
            </div>
            )}
            </CardContent>
        )}
            </Card>
            )}

      {/* Existing Records */}
      <Card className="glass-card">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Saved Records - P{selectedPeriod}W{selectedWeek} {selectedYear} ({filteredRecords.length} records)
              {deleteProgress.total > 0 && (
                <span className="text-sm text-red-600 ml-2">
                  Deleting {deleteProgress.current} / {deleteProgress.total}...
                </span>
              )}
            </CardTitle>
            <div className="flex gap-2">
              {trainingRecords.length > 0 && (
                <>
                  <Button variant="outline" onClick={handleExportPDF}>
                    <FileDown className="w-4 h-4 mr-2" />
                    Export PDF
                  </Button>
                  {canEdit && (
                    <Button variant="outline" onClick={handleDeleteAll} className="text-red-600 border-red-200">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete All
                    </Button>
                  )}
                </>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div id="training-records-export">
          {trainingRecords.length > 0 && (
            <div className="flex gap-4 mb-4">
              <div className="flex-1">
                <Input
                  placeholder="Search by name, department, or colleague ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                  icon={<Search className="w-4 h-4" />}
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  {uniqueStatuses.map(status => (
                    <SelectItem key={status} value={status}>{status}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {isLoading ? (
            <p>Loading records...</p>
          ) : filteredRecords.length === 0 ? (
            <p className="text-center text-gray-500 py-8">
              {trainingRecords.length === 0 ? 'No records found for this period' : 'No records match your filters'}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="h-8">
                    <TableHead className="py-2 text-xs">Colleague ID</TableHead>
                    <TableHead className="py-2 text-xs">Name</TableHead>
                    <TableHead className="py-2 text-xs cursor-pointer hover:bg-gray-100" onClick={() => handleSort('user_division')}>
                      <div className="flex items-center gap-1">
                        Department
                        {sortBy === 'user_division' && (
                          <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>
                        )}
                      </div>
                    </TableHead>
                    <TableHead className="py-2 text-xs">Training Title</TableHead>
                    <TableHead className="py-2 text-xs">Status</TableHead>
                    <TableHead className="py-2 text-xs">Deadline</TableHead>
                    <TableHead className="py-2 text-xs cursor-pointer hover:bg-gray-100" onClick={() => handleSort('days_left')}>
                      <div className="flex items-center gap-1">
                        Days Left
                        {sortBy === 'days_left' && (
                          <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>
                        )}
                      </div>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => {
                    const daysLeft = record.deadline ? Math.ceil((parseISO(record.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : null;
                    const wasOnPreviousWeek = previousWeekRecords.some(
                      prev => prev.colleague_id === record.colleague_id && prev.training_title === record.training_title
                    );
                    return (
                      <TableRow key={record.id} className={`h-8 ${wasOnPreviousWeek ? 'bg-red-50' : ''}`}>
                        <TableCell className="font-mono text-[10px] py-1">{record.colleague_id}</TableCell>
                        <TableCell className="text-xs py-1">{record.first_name} {record.surname}</TableCell>
                        <TableCell className="text-[10px] py-1">{
                          (() => {
                            let div = record.user_division?.replace(/^[^-]+ - /, '');
                            if (div === 'Truro Travel Money Bureau') return 'Travel Money Bureau';
                            if (div === 'Customer Experience') return 'Customer EX';
                            return div;
                          })()
                        }</TableCell>
                        <TableCell className="text-[9px] py-1 max-w-[200px] truncate">{record.training_title}</TableCell>
                        <TableCell className="py-1 whitespace-nowrap">
                          <span className={`text-[9px] px-1.5 py-0.5 rounded ${
                            record.status === 'Passed' ? 'bg-green-100 text-green-800' :
                            record.status === 'Registered' ? 'bg-blue-100 text-blue-800' :
                            record.status === 'Started' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {record.status}
                          </span>
                        </TableCell>
                        <TableCell className="text-[10px] py-1">
                          {record.deadline && format(parseISO(record.deadline), 'dd/MM/yyyy')}
                        </TableCell>
                        <TableCell className="py-1">
                          {daysLeft !== null && (
                            <span className={`text-[9px] px-1.5 py-0.5 rounded font-medium inline-block w-20 text-center ${
                              daysLeft < 0 ? 'bg-red-600 text-white' :
                              daysLeft <= 7 ? 'bg-red-600 text-white' :
                              daysLeft <= 14 ? 'bg-orange-600 text-white' :
                              daysLeft <= 21 ? 'bg-green-500 text-white' :
                              'bg-green-600 text-white'
                            }`}>
                              {daysLeft < 0 ? `${Math.abs(daysLeft)}d overdue` : `${daysLeft}d`}
                            </span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}