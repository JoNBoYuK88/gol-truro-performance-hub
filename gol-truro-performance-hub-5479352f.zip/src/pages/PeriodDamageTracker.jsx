
import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, Plus, Save, Calendar, Download, Check, Printer, CheckCircle2, Lock } from 'lucide-react';
import { PeriodConfig } from '@/api/entities';
import { AppConfig } from '@/api/entities';
import { DamageReport } from '@/api/entities';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';
import { UploadFile } from '@/api/integrations';

const damageKeys = {
  'B': 'Bent',
  'C': 'Cracked',
  'D': 'Dent',
  'L': 'Loose',
  'M': 'Missing',
  'S': 'Smashed',
  'T': 'Torn',
  'Z': 'Scratch / Scrape'
};

const vanRegistrations = [
  // Newest DRM vans first, sorted alphabetically
  'PF24HHA', 'PL24BGK', 'PL24BGO', 'PL24BGU', 'PL24BGV', 'PL24BKX',
  'PL24BXU', 'PL24BXY', 'PL24BXZ', 'PL24BYR', 'PL24BYS', 'PL24BYT',
  'PL24BYW', 'PL24BYX', 'PL24DXS', 'PL24FPA', 'PL24FPD', 'PL24FPE',
  // Spare and other vans at the bottom, sorted alphabetically
  'PF68BDV', 'PG19RWY', 'PL19XFG', 'PL24BYV', 'PO19ZHD', 'XNP'
];

const vanTypeMap = {
  'PF24HHA': 'DRM', 'PL24BGK': 'DRM', 'PL24BGO': 'DRM', 'PL24BGU': 'DRM',
  'PL24BGV': 'DRM', 'PL24BKX': 'DRM', 'PL24BXU': 'DRM', 'PL24BXY': 'DRM',
  'PL24BXZ': 'DRM', 'PL24BYR': 'DRM', 'PL24BYS': 'DRM', 'PL24BYT': 'DRM',
  'PL24BYV': 'DRM Spare', 'PL24BYW': 'DRM', 'PL24BYX': 'DRM', 'PL24DXS': 'DRM',
  'PL24FPA': 'DRM', 'PL24FPD': 'DRM', 'PL24FPE': 'DRM',
  'PF68BDV': 'Training Van',
  'PG19RWY': 'Spare',
  'PL19XFG': 'Click & Collect (Truro)',
  'PO19ZHD': 'Click & Collect (Falmouth)',
  'XNP': 'DRM'
};

const DAMAGE_TYPE_COLORS = {
  'B': '#FF4500', // Orange Red for Bent
  'C': '#DC143C', // Crimson for Cracked
  'D': '#FFD700', // Gold for Dent
  'L': '#9932CC', // Dark Orchid for Loose
  'M': '#FF1493', // Deep Pink for Missing
  'S': '#00CED1', // Dark Turquoise for Smashed
  'T': '#FF6347', // Tomato for Torn
  'Z': '#32CD32'  // Lime Green for Scratch/Scrape
};

// Configurable clickable areas - you can adjust these percentages
const DEFAULT_CLICKABLE_AREAS = [
  {
    area: 'Near Side (Left)',
    style: { top: '8%', height: '42%', left: '0%', width: '55%' }
  },
  {
    area: 'Off Side (Right)',
    style: { top: '50%', height: '42%', left: '0%', width: '55%' }
  },
  {
    area: 'Rear',
    style: { top: '8%', height: '42%', left: '55%', width: '22%' }
  },
  {
    area: 'Front',
    style: { top: '50%', height: '42%', left: '55%', width: '22%' }
  }
];

export default function PeriodDamageTracker() {
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [currentPeriod, setCurrentPeriod] = useState(1);
  const [selectedVan, setSelectedVan] = useState('');
  const [vanType, setVanType] = useState('');
  const [cleaningDates, setCleaningDates] = useState({
    exterior: '',
    cab: '',
    box: ''
  });
  const [damageMarkers, setDamageMarkers] = useState([]);
  const [selectedDamageType, setSelectedDamageType] = useState('D');
  const [isAddingDamage, setIsAddingDamage] = useState(false);
  const [clickableAreas, setClickableAreas] = useState(DEFAULT_CLICKABLE_AREAS);
  const [showAreaEditor, setShowAreaEditor] = useState(false);
  const [configRecordId, setConfigRecordId] = useState(null);

  const [overlayPositions, setOverlayPositions] = useState({
    vanReg: { top: '2.4%', left: '25%', width: '15%', height: '3.8%' },
    period: { top: '2.4%', left: '46%', width: '5.5%', height: '3.8%' },
    exteriorCleanDate: { top: '29%', left: '80%', width: '15%', height: '4%' },
    cabCleanDate: { top: '51%', left: '80%', width: '15%', height: '4%' },
    boxCleanDate: { top: '73%', left: '80%', width: '15%', height: '4%' }
  });
  const [isDragging, setIsDragging] = useState(null);
  const [showOverlayEditor, setShowOverlayEditor] = useState(false);
  const diagramContainerRef = useRef(null);

  const [selectedMarkers, setSelectedMarkers] = new useState(new Set());
  const [isCombiningMode, setIsCombiningMode] = useState(false);
  const [isNewReport, setIsNewReport] = useState(true);
  const [selectedShape, setSelectedShape] = useState('square');
  const [completedVanRegs, setCompletedVanRegs] = useState(new Set());
  const [isRemovingDamage, setIsRemovingDamage] = useState(false);

  const [isDraggingMarker, setIsDraggingMarker] = useState(null);
  const [selectedMarkerForKeyboard, setSelectedMarkerForKeyboard] = useState(null);
  const [isLocked, setIsLocked] = useState(false);
  const [lockedReports, setLockedReports] = new useState(new Set());
  const [uploadingMarkerId, setUploadingMarkerId] = useState(null);

  useEffect(() => {
    if (selectedVan) {
      setVanType(vanTypeMap[selectedVan] || '');
    } else {
      setVanType('');
    }
  }, [selectedVan]);

  const loadDamageReport = async () => {
    setDamageMarkers([]);
    setCleaningDates({ exterior: '', cab: '', box: '' });
    setSelectedMarkers(new Set());
    setIsCombiningMode(false);
    setIsRemovingDamage(false);
    setIsAddingDamage(false);
    setSelectedMarkerForKeyboard(null);
    setIsLocked(false);

    if (!selectedVan) {
      setIsNewReport(true);
      return;
    }

    try {
      // Fetch all reports for the selected van and sort them client-side
      const allReports = await DamageReport.filter({ van_registration: selectedVan });
      
      // Sort by updated_date descending (most recent first)
      const sortedReports = allReports.sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date));
      
      if (sortedReports.length > 0) {
        setIsNewReport(false);
        const report = sortedReports[0]; // Get the most recent report
        setCleaningDates(report.cleaning_dates || { exterior: '', cab: '', box: '' });
        setIsLocked(report.is_locked || false);
        
        if (report.damage_markers && report.damage_markers.length > 0) {
            const groupSizes = {};
            report.damage_markers.forEach(marker => {
                if (marker.groupId) {
                    groupSizes[marker.groupId] = (groupSizes[marker.groupId] || 0) + 1;
                }
            });

            let loadedMarkers = report.damage_markers.map((marker, index) => ({
                id: Date.now() + index,
                x: marker.position.x,
                y: marker.position.y,
                area: marker.area,
                damageType: marker.damage_type,
                description: marker.description || '',
                date: marker.date_found,
                color: DAMAGE_TYPE_COLORS[marker.damage_type] || marker.color,
                groupId: marker.groupId,
                isGroupLeader: marker.isGroupLeader,
                groupSize: marker.groupId ? groupSizes[marker.groupId] : undefined,
                groupDescription: marker.isGroupLeader ? marker.description : undefined,
                isNew: false,
                shape: marker.shape || 'circle'
            }));

            const finalMarkers = loadedMarkers.map(marker => {
                if (marker.groupId && !marker.isGroupLeader) {
                    const leader = loadedMarkers.find(m => m.groupId === marker.groupId && m.isGroupLeader);
                    return { ...marker, groupDescription: leader ? leader.description : marker.description };
                } else if (marker.isGroupLeader) {
                     return { ...marker, groupDescription: marker.description };
                }
                return marker;
            });

            setDamageMarkers(finalMarkers);
        }
        toast.success(`Loaded existing report for ${selectedVan}.`);
      } else {
          setIsNewReport(true);
          toast.info(`No existing report found for ${selectedVan}. Starting a new report.`);
      }
    } catch (error) {
      console.error("Failed to load damage report:", error);
      toast.error("Could not load damage report.");
    }
  };

  useEffect(() => {
    loadDamageReport();
  }, [selectedVan]);

  useEffect(() => {
    const checkLockedReports = async () => {
      try {
        const allReports = await DamageReport.filter({
          is_locked: true
        });
        
        const lockedVanRegs = new Set(allReports.map(report => report.van_registration));
        setLockedReports(lockedVanRegs);
      } catch (error) {
        console.error("Failed to load locked reports:", error);
      }
    };
    
    checkLockedReports();
  }, []);

  useEffect(() => {
    const loadClickableAreasConfig = async () => {
      try {
        const configData = await AppConfig.filter({ key: 'damageTrackerClickableAreas' });
        if (configData && configData.length > 0 && configData[0].value) {
            let configValue = configData[0].value;
            let parsedValue;
            if (typeof configValue === 'string') {
                try {
                    parsedValue = JSON.parse(configValue);
                } catch (e) { 
                    console.error("Failed to parse clickable areas config JSON:", e);
                    setClickableAreas(DEFAULT_CLICKABLE_AREAS);
                    return; 
                }
            } else {
                parsedValue = configValue; 
            }

            if (Array.isArray(parsedValue)) {
              setClickableAreas(parsedValue);
            } else {
              setClickableAreas(DEFAULT_CLICKABLE_AREAS);
            }
        }
        if (configData && configData.length > 0) {
          setConfigRecordId(configData[0].id);
        } else {
          setConfigRecordId(null);
        }
      } catch (error) {
        console.error("Failed to load clickable areas configuration:", error);
        setClickableAreas(DEFAULT_CLICKABLE_AREAS);
      }
    };
    loadClickableAreasConfig();
  }, []);

  useEffect(() => {
    const loadOverlayConfig = async () => {
      const defaultPositions = {
        vanReg: { top: '2.4%', left: '25%', width: '15%', height: '3.8%' },
        period: { top: '2.4%', left: '46%', width: '5.5%', height: '3.8%' },
        exteriorCleanDate: { top: '29%', left: '80%', width: '15%', height: '4%' },
        cabCleanDate: { top: '51%', left: '80%', width: '15%', height: '4%' },
        boxCleanDate: { top: '73%', left: '80%', width: '15%', height: '4%' }
      };
      try {
        const configData = await AppConfig.filter({ key: 'damageTrackerOverlayPositions' });
        if (configData && configData.length > 0 && configData[0].value) {
            let configValue = configData[0].value;
            let parsedValue;
             if (typeof configValue === 'string') {
                try {
                    parsedValue = JSON.parse(configValue);
                } catch (e) {
                    console.error("Failed to parse overlay positions config JSON:", e);
                    setOverlayPositions(defaultPositions);
                    return;
                }
            } else {
                parsedValue = configValue; 
            }
            if(typeof parsedValue === 'object' && parsedValue !== null && !Array.isArray(parsedValue)) {
              setOverlayPositions({ ...defaultPositions, ...parsedValue });
            } else {
              setOverlayPositions(defaultPositions);
            }
        } else {
            setOverlayPositions(defaultPositions);
        }
      } catch (error) {
        console.error("Failed to load or parse overlay positions:", error);
        setOverlayPositions(defaultPositions);
      }
    };
    loadOverlayConfig();
  }, []);

  useEffect(() => {
    const initializeDefaultPeriod = async () => {
      try {
        const today = new Date();
        const currentYearValue = today.getFullYear();

        const periodsData = await PeriodConfig.filter({ year: currentYearValue });

        if (periodsData && periodsData.length > 0) {
          const currentPeriodConfig = periodsData.find(p => {
            const startDate = new Date(p.start_date);
            const endDate = new Date(p.end_date);
            today.setHours(0, 0, 0, 0);
            startDate.setHours(0, 0, 0, 0);
            endDate.setHours(0, 0, 0, 0);
            return today >= startDate && today <= endDate;
          });

          if (currentPeriodConfig) {
            setCurrentYear(currentYearValue);
            setCurrentPeriod(currentPeriodConfig.period_number);
          }
        }
      } catch (error) {
        console.error("Failed to set default period:", error);
      }
    };

    initializeDefaultPeriod();
  }, []);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!selectedMarkerForKeyboard || isCombiningMode || isRemovingDamage || isAddingDamage || isLocked) return;

      const moveAmount = e.shiftKey ? 0.05 : 0.25;
      let moved = false;

      setDamageMarkers(prev => prev.map(marker => {
        if (marker.id === selectedMarkerForKeyboard) {
          let newX = marker.x;
          let newY = marker.y;

          switch (e.key) {
            case 'ArrowUp':
              newY = Math.max(0.5, marker.y - moveAmount);
              moved = true;
              break;
            case 'ArrowDown':
              newY = Math.min(99.5, marker.y + moveAmount);
              moved = true;
              break;
            case 'ArrowLeft':
              newX = Math.max(0.5, marker.x - moveAmount);
              moved = true;
              break;
            case 'ArrowRight':
              newX = Math.min(99.5, marker.x + moveAmount);
              moved = true;
              break;
            case 'Escape':
              setSelectedMarkerForKeyboard(null);
              moved = true; 
              break;
          }

          if (moved && e.key !== 'Escape') {
            e.preventDefault(); 
            return { ...marker, x: newX, y: newY };
          }
        }
        return marker;
      }));
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [selectedMarkerForKeyboard, isCombiningMode, isRemovingDamage, isAddingDamage, isLocked]);

  const handleImageUploadForMarker = async (markerId, file) => {
    if (!file || !selectedVan) return;

    setUploadingMarkerId(markerId);

    try {
        const { file_url } = await UploadFile({ file });
        const updatedMarkers = damageMarkers.map(m => m.id === markerId ? { ...m, image_url: file_url } : m);
        setDamageMarkers(updatedMarkers);
        toast.success("Image uploaded. Remember to save the report.");
    } catch (error) {
        console.error("Error uploading image:", error);
        let errorMessage = "Failed to upload image. Please try again.";
        if (error.message && (error.message.includes('500') || error.message.includes('timeout') || error.message.includes('544'))) {
            errorMessage = 'A server error occurred while uploading. Please try again in a few moments.';
        } else if (error.message) {
            errorMessage = `Failed to upload image: ${error.message}`;
        }
        toast.error(errorMessage);
    } finally {
        setUploadingMarkerId(null);
    }
  };

  const gridSize = 0.25;

  const formatDateForDiagram = (dateString) => {
    if (!dateString) return '';
    try {
      const date = new Date(dateString);
      const adjustedDate = new Date(date.getTime() + date.getTimezoneOffset() * 60000);
      const day = String(adjustedDate.getDate()).padStart(2, '0');
      const month = String(adjustedDate.getMonth() + 1).padStart(2, '0');
      const year = adjustedDate.getFullYear().toString().slice(-2);
      return `${day}/${month}/${year}`;
    } catch (e) {
      return '';
    }
  };

  const handleVanClick = (event, area) => {
    if (!isAddingDamage || isCombiningMode || !diagramContainerRef.current || isLocked) return;

    const rect = diagramContainerRef.current.getBoundingClientRect();
    let x = ((event.clientX - rect.left) / rect.width) * 100;
    let y = ((event.clientY - rect.top) / rect.height) * 100;

    x = Math.round(x / gridSize) * gridSize;
    y = Math.round(y / gridSize) * gridSize;

    x = Math.max(0.5, Math.min(99.5, x));
    y = Math.max(0.5, Math.min(99.5, y));

    const newMarker = {
      id: Date.now(),
      x,
      y,
      area,
      damageType: selectedDamageType,
      description: '',
      date: new Date().toISOString().split('T')[0],
      color: DAMAGE_TYPE_COLORS[selectedDamageType],
      isNew: true,
      shape: selectedShape
    };

    setDamageMarkers([...damageMarkers, newMarker]);
  };

  const removeDamageMarker = (id) => {
    const markerToRemove = damageMarkers.find(m => m.id === id);
    
    if (markerToRemove && markerToRemove.groupId) {
      const groupMarkers = damageMarkers.filter(m => m.groupId === markerToRemove.groupId);
      const remainingMarkers = damageMarkers.filter(m => m.groupId !== markerToRemove.groupId);
      
      setDamageMarkers(remainingMarkers);
      toast.info(`Removed combined damage group (${groupMarkers.length} markers)`);
    } else {
      setDamageMarkers(damageMarkers.filter(marker => marker.id !== id));
    }
    if (selectedMarkerForKeyboard === id) {
      setSelectedMarkerForKeyboard(null);
    }
  };

  const updateMarkerDescription = (id, description) => {
    const marker = damageMarkers.find(m => m.id === id);
    
    if (marker && marker.groupId) {
      setDamageMarkers(damageMarkers.map(m =>
        m.groupId === marker.groupId 
          ? { ...m, description: description, groupDescription: description }
          : m
      ));
    } else {
      setDamageMarkers(damageMarkers.map(m =>
        m.id === id ? { ...m, description } : m
      ));
    }
  };

  const updateMarkerDate = (id, newDate) => {
    const marker = damageMarkers.find(m => m.id === id);
    
    if (marker && marker.groupId) {
      setDamageMarkers(damageMarkers.map(m =>
        m.groupId === marker.groupId 
          ? { ...m, date: newDate }
          : m
      ));
    } else {
      setDamageMarkers(damageMarkers.map(marker =>
        marker.id === id ? { ...marker, date: newDate } : marker
      ));
    }
  };

  const updateClickableArea = (index, property, value) => {
    setClickableAreas(prev => prev.map((area, i) =>
      i === index
        ? { ...area, style: { ...area.style, [property]: value } }
        : area
    ));
  };

  const resetAreas = () => {
    setClickableAreas(DEFAULT_CLICKABLE_AREAS);
    toast.info("Clickable area layout reset to default. Remember to save if you want this to persist.");
  };

  const handleSaveAreas = async () => {
    try {
      const valueToSave = JSON.stringify(clickableAreas);
      const existingConfig = await AppConfig.filter({ key: 'damageTrackerClickableAreas' });

      if (existingConfig && existingConfig.length > 0) {
        await AppConfig.update(existingConfig[0].id, { value: valueToSave });
      } else {
        const newConfig = await AppConfig.create({
          key: 'damageTrackerClickableAreas',
          value: valueToSave
        });
        setConfigRecordId(newConfig.id);
      }
      toast.success("Clickable area layout saved successfully!");
    } catch (error) {
      console.error("Failed to save clickable area configuration:", error);
      toast.error("Could not save layout. Please try again.");
    }
  };

  const handleOverlayMouseDown = (e, overlayType) => {
    if (!showOverlayEditor) return; 

    e.preventDefault();
    setIsDragging(overlayType);
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;

    const imageContainer = diagramContainerRef.current; 
    if (!imageContainer) return;

    const rect = imageContainer.getBoundingClientRect();
    let x = ((e.clientX - rect.left) / rect.width) * 100;
    let y = ((e.clientY - rect.top) / rect.height) * 100;

    const currentOverlay = overlayPositions[isDragging];
    const overlayWidthPercent = parseFloat(currentOverlay.width);
    const overlayHeightPercent = parseFloat(currentOverlay.height);

    x = Math.max(0, Math.min(100 - overlayWidthPercent, x));
    y = Math.max(0, Math.min(100 - overlayHeightPercent, y));

    setOverlayPositions(prev => ({
      ...prev,
      [isDragging]: {
        ...prev[isDragging],
        top: `${y}%`,
        left: `${x}%`
      }
    }));
  };

  const handleMouseUp = () => {
    setIsDragging(null);
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
  };

  const updateOverlayPosition = (overlayType, property, value) => {
    setOverlayPositions(prev => ({
      ...prev,
      [overlayType]: {
        ...prev[overlayType],
        [property]: value.includes('%') ? value : `${value}%`
      }
    }));
  };

  const resetOverlays = () => {
    setOverlayPositions({
      vanReg: { top: '2.4%', left: '25%', width: '15%', height: '3.8%' },
      period: { top: '2.4%', left: '46%', width: '5.5%', height: '3.8%' },
      exteriorCleanDate: { top: '29%', left: '80%', width: '15%', height: '4%' },
      cabCleanDate: { top: '51%', left: '80%', width: '15%', height: '4%' },
      boxCleanDate: { top: '73%', left: '80%', width: '15%', height: '4%' }
    });
    toast.info("Overlay positions reset to default.");
  };

  const handleSaveOverlays = async () => {
    try {
      const valueToSave = JSON.stringify(overlayPositions);
      const configData = await AppConfig.filter({ key: 'damageTrackerOverlayPositions' });
      if (configData && configData.length > 0) {
        await AppConfig.update(configData[0].id, { value: valueToSave });
      } else {
        await AppConfig.create({
          key: 'damageTrackerOverlayPositions',
          value: valueToSave
        });
      }
      toast.success("Overlay positions saved successfully!");
    } catch (error) {
      console.error("Failed to save overlay positions:", error);
      toast.error("Could not save overlay positions. Please try again.");
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportAsImage = async () => {
    if (!diagramContainerRef.current) {
      toast.error("Diagram not ready for export. Please try again.");
      return;
    }

    try {
      const html2canvas = (await import('html2canvas')).default;
      
      const canvas = await html2canvas(diagramContainerRef.current, {
        backgroundColor: '#ffffff',
        scale: 2, 
        useCORS: true, 
        allowTaint: true, 
        logging: false,
        width: diagramContainerRef.current.offsetWidth,
        height: diagramContainerRef.current.offsetHeight
      });

      const today = new Date();
      const day = String(today.getDate()).padStart(2, '0');
      const month = String(today.getMonth() + 1).padStart(2, '0');
      const year = today.getFullYear().toString().slice(-2);
      const todaysDate = `${day}${month}${year}`;

      const link = document.createElement('a');
      link.download = `${selectedVan || 'Unknown'}_${todaysDate}_P${currentPeriod}.png`;
      link.href = canvas.toDataURL('image/png');
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success("Image exported successfully!");
    } catch (error) {
      console.error("Error exporting image:", error);
      toast.error("Failed to export image. Please try again.");
    }
  };

  const handleSaveDamageReport = async () => {
    if (!selectedVan) {
      toast.error("Please select a van before saving the damage report.");
      return;
    }

    const reportData = {
      van_registration: selectedVan,
      van_type: vanType,
      period: currentPeriod,
      year: currentYear,
      cleaning_dates: cleaningDates,
      is_locked: isLocked,
      damage_markers: damageMarkers.map(marker => ({
        area: marker.area,
        damage_type: marker.damageType,
        damage_description: damageKeys[marker.damageType],
        date_found: marker.date,
        description: marker.description || '',
        position: { x: marker.x, y: marker.y },
        color: marker.color,
        groupId: marker.groupId,
        isGroupLeader: marker.isGroupLeader,
        shape: marker.shape || 'circle'
      })),
      total_damage_items: damageMarkers.length
    };

    try {
      // Find the most recent existing report for this van
      const allReports = await DamageReport.filter({ van_registration: selectedVan });
      const sortedReports = allReports.sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date));

      if (sortedReports.length > 0) {
        await DamageReport.update(sortedReports[0].id, reportData);
        toast.success(`Damage report updated successfully for ${selectedVan}!`);
      } else {
        await DamageReport.create(reportData);
        toast.success(`Damage report saved successfully for ${selectedVan}!`);
      }
      setCompletedVanRegs(prev => new Set(prev).add(selectedVan));
      await loadDamageReport();
    } catch (error) {
      console.error("Error saving damage report:", error);
      toast.error("Failed to save damage report. Please try again.");
    }
  };
  
  const formatDateForOverlay = (dateString) => {
    if (!dateString) return 'DD / MM / YY';
    const date = new Date(dateString);
    const adjustedDate = new Date(date.getTime() + date.getTimezoneOffset() * 60000);
    const day = String(adjustedDate.getDate()).padStart(2, '0');
    const month = String(adjustedDate.getMonth() + 1).padStart(2, '0');
    const year = adjustedDate.getFullYear().toString().slice(-2);
    return `${day} / ${month} / ${year}`;
  };

  const toggleMarkerSelection = (markerId) => {
    if (!isCombiningMode) return;
    
    setSelectedMarkers(prev => {
      const newSet = new Set(prev);
      if (newSet.has(markerId)) {
        newSet.delete(markerId);
      } else {
        newSet.add(markerId);
      }
      return newSet;
    });
  };

  const combineSelectedMarkers = () => {
    if (selectedMarkers.size < 2) {
      toast.error("Please select at least 2 damage markers to combine.");
      return;
    }

    const selectedMarkerObjects = damageMarkers.filter(marker => selectedMarkers.has(marker.id));
    
    const sortedSelectedMarkers = [...selectedMarkerObjects].sort((a, b) => a.id - b.id);
    const middleIndex = Math.floor((sortedSelectedMarkers.length - 1) / 2);
    const leaderId = sortedSelectedMarkers[middleIndex].id;

    const groupId = `group_${Date.now()}`;
    
    const earliestDate = selectedMarkerObjects.reduce((minDate, marker) => {
      return (marker.date && (!minDate || marker.date < minDate)) ? marker.date : minDate;
    }, '');

    const combinedDesc = `Combined damage (${selectedMarkerObjects.length} areas): ${selectedMarkerObjects.map(m => m.description || (damageKeys[m.damageType] || 'unmarked')).join(', ')}`;

    const newDamageMarkers = damageMarkers.map(marker => {
      if (selectedMarkers.has(marker.id)) {
        return {
          ...marker,
          groupId: groupId,
          isGroupLeader: marker.id === leaderId,
          groupSize: selectedMarkerObjects.length,
          groupDescription: combinedDesc,
          description: combinedDesc,
          date: earliestDate,
          isNew: marker.isNew
        };
      }
      return marker;
    });

    setDamageMarkers(newDamageMarkers);
    
    setSelectedMarkers(new Set());
    setIsCombiningMode(false);
    setSelectedMarkerForKeyboard(null);
    
    toast.success(`Combined ${selectedMarkerObjects.length} damage markers. All dots remain visible on diagram.`);
  };

  const cancelCombining = () => {
    setSelectedMarkers(new Set());
    setIsCombiningMode(false);
    setSelectedMarkerForKeyboard(null);
    toast.info("Combine mode cancelled.");
  };

  const getSummaryEntries = () => {
    return damageMarkers.filter(marker => 
      !marker.groupId || marker.isGroupLeader
    );
  };

  const handleMarkerMouseDown = (e, markerId) => {
    if (isCombiningMode || isRemovingDamage || isAddingDamage || isLocked) return;
    
    e.preventDefault();
    e.stopPropagation();
    
    setIsDraggingMarker(markerId);
    setSelectedMarkerForKeyboard(null);
    
    // Find if the clicked marker is part of a group
    const clickedMarker = damageMarkers.find(m => m.id === markerId);
    if (!clickedMarker) return; // Should not happen if markerId is valid
    
    const isPartOfGroup = clickedMarker.groupId;
    
    // If part of a group, get all group members
    const groupMembers = isPartOfGroup 
      ? damageMarkers.filter(m => m.groupId === clickedMarker.groupId)
      : [clickedMarker];
    
    // Calculate initial offsets for each group member relative to the clicked marker
    const initialOffsets = groupMembers.map(member => ({
      id: member.id,
      offsetX: member.x - clickedMarker.x,
      offsetY: member.y - clickedMarker.y
    }));
    
    const handleMouseMove = (moveEvent) => {
      if (!diagramContainerRef.current) return;
      
      moveEvent.preventDefault();
      
      const rect = diagramContainerRef.current.getBoundingClientRect();
      let newClickedMarkerX = ((moveEvent.clientX - rect.left) / rect.width) * 100;
      let newClickedMarkerY = ((moveEvent.clientY - rect.top) / rect.height) * 100;
      
      newClickedMarkerX = Math.round(newClickedMarkerX / gridSize) * gridSize;
      newClickedMarkerY = Math.round(newClickedMarkerY / gridSize) * gridSize;
      
      newClickedMarkerX = Math.max(0.5, Math.min(99.5, newClickedMarkerX));
      newClickedMarkerY = Math.max(0.5, Math.min(99.5, newClickedMarkerY));
      
      setDamageMarkers(prev => prev.map(marker => {
        // Find if this marker is in the group being moved
        const offset = initialOffsets.find(o => o.id === marker.id);
        
        if (offset) {
          // Calculate new position for this group member
          const memberNewX = Math.max(0.5, Math.min(99.5, newClickedMarkerX + offset.offsetX));
          const memberNewY = Math.max(0.5, Math.min(99.5, newClickedMarkerY + offset.offsetY));
          
          return { ...marker, x: memberNewX, y: memberNewY };
        }
        return marker;
      }));
    };
    
    const handleMouseUp = () => {
      setIsDraggingMarker(null);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      
      if (isPartOfGroup) {
        toast.success(`Combined damage group (${groupMembers.length} markers) repositioned`);
      } else {
        toast.success("Damage marker repositioned");
      }
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleMarkerClick = (e, markerId) => {
    e.stopPropagation();

    if (isLocked) {
      toast.info("Markers are locked. Click the lock button to unlock editing.");
      return;
    }

    if (isCombiningMode) {
      toggleMarkerSelection(markerId);
    } else if (isRemovingDamage) {
      removeDamageMarker(markerId);
    } else if (isAddingDamage) {
      return;
    } else {
      if (selectedMarkerForKeyboard === markerId) {
        setSelectedMarkerForKeyboard(null);
        toast.info("Marker deselected. Click to select for arrow key movement.");
      } else {
        setSelectedMarkerForKeyboard(markerId);
        toast.info("Marker selected! Use arrow keys to move precisely (hold Shift for finer control). Press Escape to deselect.");
      }
    }
  };

  const handleLockToggle = async () => {
    const newLockState = !isLocked;
    
    if (newLockState) {
        setIsAddingDamage(false);
        setIsRemovingDamage(false);
        setIsCombiningMode(false);
        setSelectedMarkers(new Set());
        setSelectedMarkerForKeyboard(null);
        toast.success("Report locked. Editing disabled.");
        if (selectedVan) {
            setLockedReports(prev => new Set(prev).add(selectedVan));
        }
    } else {
        toast.success("Report unlocked. Editing enabled.");
        if (selectedVan) {
            setLockedReports(prev => {
                const newSet = new Set(prev);
                newSet.delete(selectedVan);
                return newSet;
            });
        }
    }

    try {
        if (!selectedVan) {
            setIsLocked(newLockState); 
            toast.info("No van selected. Lock status will apply when you save a report for a selected van.");
            return;
        }

        // Find the most recent existing report for this van
        const allReports = await DamageReport.filter({ van_registration: selectedVan });
        const sortedReports = allReports.sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date));

        if (sortedReports.length > 0) {
            // Update the existing report with the new lock status
            await DamageReport.update(sortedReports[0].id, { is_locked: newLockState });
            setIsLocked(newLockState);
            toast.info("Lock status saved to database.");
        } else {
            // No existing report found. The lock status has already been updated in the UI
            // and will be saved when a new report is created (handleSaveDamageReport).
            setIsLocked(newLockState);
            toast.info("No existing report to update. Lock status will apply when you save the report.");
        }
    } catch (error) {
        console.error("Failed to save lock status:", error);
        toast.error("Could not save lock status. It will be saved with your next report save.");
        setIsLocked(newLockState);
    }
  };

  return (
    <div className="p-6 space-y-6 bg-white min-h-screen">
      <style>{`
        @media print {
          body {
            margin: 0;
            padding: 0;
          }
          .no-print {
            display: none !important;
          }
          .print-wrapper-card {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            padding: 0 !important;
            margin: 0 !important;
            box-shadow: none !important;
            border: none !important;
            background: none !important;
            backdrop-filter: none !important;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .print-wrapper-card > div { 
            padding: 0 !important;
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .van-diagram-container {
            width: 95% !important; 
            height: 95% !important; 
            object-fit: contain;
            margin: auto;
          }
          .van-diagram-container div {
            -webkit-print-color-adjust: exact !important;
            color-adjust: exact !important;
          }
          .van-diagram-container svg {
            width: auto !important; /* Allow SVG to scale according to its viewBox and container */
            height: auto !important;
            overflow: visible !important; /* Ensure content outside viewBox is visible */
            z-index: 100 !important;
          }
          .van-diagram-container img {
            width: 100% !important;
            height: auto !important;
            max-height: 100% !important;
            object-fit: contain;
          }
          @page {
            size: A4 landscape;
            margin: 0;
          }
        }
      `}</style>
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 no-print">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-gray-900">Period Damage Tracker</h1>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setCompletedVanRegs(new Set());
              toast.success("All completion tracking reset!");
            }}
            className="text-xs text-gray-600 hover:text-gray-800"
          >
            Untick All
          </Button>
          
          <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))}>
            <SelectTrigger className="w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 3 }, (_, i) => new Date().getFullYear() - i).map(y => (
                <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))}>
            <SelectTrigger className="w-20">
              <SelectValue placeholder="P" />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 13 }, (_, i) => i + 1).map(p => (
                <SelectItem key={p} value={p.toString()}>P{p}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card className="glass-card print-wrapper-card">
        <CardHeader className="no-print">
          <div className="flex flex-col gap-4">
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg">Vehicle Inspection Diagram</CardTitle>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowOverlayEditor(!showOverlayEditor)}
                  className="text-xs"
                >
                  {showOverlayEditor ? "Hide Overlay Editor" : "Edit Overlays"}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAreaEditor(!showAreaEditor)}
                  className="text-xs"
                >
                  {showAreaEditor ? "Hide Area Editor" : "Edit Click Areas"}
                </Button>
              </div>
            </div>
            
            <div className="p-3 bg-gray-50 rounded-lg border">
                <h3 className="text-md font-semibold text-gray-800 mb-3">Vehicle &amp; Cleaning Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                    <div className="lg:col-span-1">
                        <label className="block text-xs font-medium text-gray-600 mb-1">Van Registration</label>
                        <Select value={selectedVan} onValueChange={setSelectedVan}>
                            <SelectTrigger>
                                <SelectValue placeholder="Select a van" />
                            </SelectTrigger>
                            <SelectContent>
                            {vanRegistrations.map(reg => (
                                <SelectItem key={reg} value={reg}>
                                <div className="flex items-center justify-between w-full">
                                    <div className="flex items-center gap-2">
                                        {lockedReports.has(reg) && (
                                            <Lock className="w-3 h-3 mr-1" />
                                        )}
                                        <span>{reg}</span>
                                    </div>
                                    {completedVanRegs.has(reg) && (
                                    <Check className="w-4 h-4 text-green-500 ml-2" />
                                    )}
                                </div>
                                </SelectItem>
                            ))}
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="lg:col-span-1">
                        <label className="block text-xs font-medium text-gray-600 mb-1">Van Type</label>
                        <Input value={vanType} readOnly placeholder="Van type" className="bg-gray-200" />
                    </div>
                    <div className="lg:col-span-1">
                        <label className="block text-xs font-medium text-gray-600 mb-1">Exterior Clean</label>
                        <Input type="date" value={cleaningDates.exterior} onChange={(e) => setCleaningDates(prev => ({ ...prev, exterior: e.target.value }))} disabled={isLocked} />
                    </div>
                    <div className="lg:col-span-1">
                        <label className="block text-xs font-medium text-gray-600 mb-1">Cab Clean</label>
                        <Input type="date" value={cleaningDates.cab} onChange={(e) => setCleaningDates(prev => ({ ...prev, cab: e.target.value }))} disabled={isLocked} />
                    </div>
                    <div className="lg:col-span-1">
                        <label className="block text-xs font-medium text-gray-600 mb-1">Box Clean</label>
                        <Input type="date" value={cleaningDates.box} onChange={(e) => setCleaningDates(prev => ({ ...prev, box: e.target.value }))} disabled={isLocked} />
                    </div>
                </div>
            </div>
            
            <div className="flex flex-col gap-2 p-3 bg-gray-50 rounded-lg border">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Button
                    variant={isLocked ? "default" : "outline"}
                    size="sm"
                    onClick={handleLockToggle}
                    className={`text-xs ${isLocked ? "bg-red-600 hover:bg-red-700 text-white" : "text-gray-600"}`}
                  >
                    <Lock className="w-3 h-3 mr-1" />
                    {isLocked ? "Locked" : "Lock"}
                  </Button>
                  <Button
                    variant={isAddingDamage ? "default" : "outline"}
                    size="sm"
                    onClick={() => {
                      setIsAddingDamage(!isAddingDamage);
                      setIsRemovingDamage(false);
                      setIsCombiningMode(false);
                      setSelectedMarkers(new Set());
                      setSelectedMarkerForKeyboard(null);
                    }}
                    className={`text-xs ${isAddingDamage ? "bg-green-600 hover:bg-green-700" : ""}`}
                    disabled={isCombiningMode || isRemovingDamage || isLocked}
                  >
                    <Plus className="w-3 h-3 mr-1" />
                    {isAddingDamage ? "Adding" : "Add"}
                  </Button>
                  <Button
                    variant={isRemovingDamage ? "destructive" : "outline"}
                    size="sm"
                    onClick={() => {
                      setIsRemovingDamage(!isRemovingDamage);
                      setIsAddingDamage(false);
                      setIsCombiningMode(false);
                      setSelectedMarkers(new Set());
                      setSelectedMarkerForKeyboard(null);
                    }}
                    className="text-xs"
                    disabled={isCombiningMode || isAddingDamage || isLocked}
                  >
                    <X className="w-3 h-3 mr-1" />
                    {isRemovingDamage ? "Removing" : "Remove"}
                  </Button>
                  {isCombiningMode ? (
                    <>
                      <span className="text-xs text-blue-600 font-medium">
                        {selectedMarkers.size} selected
                      </span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={cancelCombining}
                        className="text-xs text-gray-600"
                      >
                        Cancel
                      </Button>
                      <Button
                        size="sm"
                        onClick={combineSelectedMarkers}
                        disabled={selectedMarkers.size < 2}
                        className="text-xs bg-green-600 hover:bg-green-700 text-white"
                      >
                        Combine ({selectedMarkers.size})
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setIsCombiningMode(true);
                          setIsAddingDamage(false);
                          setIsRemovingDamage(false);
                          setSelectedMarkerForKeyboard(null);
                        }}
                        className="text-xs text-blue-600 border-blue-200 hover:bg-blue-50"
                        disabled={damageMarkers.length < 2 || isAddingDamage || isRemovingDamage || isCombiningMode}
                      >
                        Combine
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          if (selectedVan) {
                            setCompletedVanRegs(prev => new Set(prev).add(selectedVan));
                            toast.success(`${selectedVan} marked as completed!`);
                          } else {
                            toast.error("Please select a van first.");
                          }
                        }}
                        className="text-xs text-green-600 border-green-200 hover:bg-green-50"
                        disabled={!selectedVan || isAddingDamage || isRemovingDamage || isCombiningMode}
                      >
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Complete
                      </Button>
                    </>
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium text-gray-600">Shape:</span>
                  <div className="flex border rounded">
                    <Button 
                      size="sm" 
                      variant="ghost"
                      className={`text-xs px-2 py-1 rounded-none ${selectedShape === 'circle' ? 'bg-blue-600 text-white hover:bg-blue-700' : 'hover:bg-gray-100'}`} 
                      onClick={() => setSelectedShape('circle')}
                      disabled={isLocked}
                    >
                      ●
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      className={`text-xs px-2 py-1 rounded-none ${selectedShape === 'square' ? 'bg-blue-600 text-white hover:bg-blue-700' : 'hover:bg-gray-100'}`} 
                      onClick={() => setSelectedShape('square')}
                      disabled={isLocked}
                    >
                      ■
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 pt-2">
                {Object.entries(damageKeys).map(([key, description]) => (
                  <Button
                    key={key}
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedDamageType(key)}
                    className={`text-sm flex items-center justify-between gap-x-3 px-3 py-2 transition-all duration-150 ${
                      selectedDamageType === key
                        ? "bg-blue-600 text-white border-blue-600 shadow-md hover:bg-blue-700"
                        : "text-gray-800 bg-white hover:bg-gray-100"
                    }`}
                    disabled={isCombiningMode || isLocked}
                  >
                    <div className="flex items-center gap-2">
                        <div
                          className="w-3 h-3 rounded-full border border-white/50 flex-shrink-0"
                          style={{ backgroundColor: DAMAGE_TYPE_COLORS[key] }}
                        />
                        <span className="truncate font-medium">{description}</span>
                    </div>
                    <div 
                        className="w-5 h-5 rounded-sm flex items-center justify-center text-white text-xs font-bold"
                        style={{ backgroundColor: DAMAGE_TYPE_COLORS[key] }}
                    >
                        {key}
                    </div>
                  </Button>
                ))}
              </div>
              
              <div className="text-xs text-gray-600 text-center pt-2">
                {isLocked ? (
                  <span className="text-red-600 font-medium">🔒 Markers are locked - click Lock button to unlock editing</span>
                ) : isAddingDamage ? (
                  <span>Click on diagram to add <strong>{damageKeys[selectedDamageType]}</strong> damage</span>
                ) : isRemovingDamage ? (
                  <span className="text-red-600">Click on damage markers to remove them</span>
                ) : isCombiningMode ? (
                  <span className="text-blue-600">Select markers to combine them</span>
                ) : selectedMarkerForKeyboard ? (
                  <span className="text-green-600">Use arrow keys to move selected marker (Shift for fine control, Escape to deselect)</span>
                ) : (
                  <span>Click markers to select for arrow key movement • Drag markers to move them</span>
                )}
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {showOverlayEditor && (
            <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200 no-print">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-sm">Text Overlay Position Editor</h3>
                <div>
                  <Button variant="outline" size="sm" onClick={resetOverlays} className="mr-2">
                    Reset Positions
                  </Button>
                  <Button size="sm" onClick={handleSaveOverlays} className="bg-blue-600 hover:bg-blue-700">
                    <Save className="w-3 h-3 mr-2" />
                    Save Positions
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium text-xs text-gray-700">Van Registration Overlay</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-xs text-gray-600">Top (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.vanReg.top)}
                        onChange={(e) => updateOverlayPosition('vanReg', 'top', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Left (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.vanReg.left)}
                        onChange={(e) => updateOverlayPosition('vanReg', 'left', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Width (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.vanReg.width)}
                        onChange={(e) => updateOverlayPosition('vanReg', 'width', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Height (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.vanReg.height)}
                        onChange={(e) => updateOverlayPosition('vanReg', 'height', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium text-xs text-gray-700">Period Overlay</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-xs text-gray-600">Top (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.period.top)}
                        onChange={(e) => updateOverlayPosition('period', 'top', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Left (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.period.left)}
                        onChange={(e) => updateOverlayPosition('period', 'left', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Width (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.period.width)}
                        onChange={(e) => updateOverlayPosition('period', 'width', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Height (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.period.height)}
                        onChange={(e) => updateOverlayPosition('period', 'height', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium text-xs text-gray-700">Exterior Clean Date</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-xs text-gray-600">Top (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.exteriorCleanDate.top)}
                        onChange={(e) => updateOverlayPosition('exteriorCleanDate', 'top', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Left (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.exteriorCleanDate.left)}
                        onChange={(e) => updateOverlayPosition('exteriorCleanDate', 'left', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Width (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.exteriorCleanDate.width)}
                        onChange={(e) => updateOverlayPosition('exteriorCleanDate', 'width', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Height (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.exteriorCleanDate.height)}
                        onChange={(e) => updateOverlayPosition('exteriorCleanDate', 'height', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium text-xs text-gray-700">Cab Clean Date</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-xs text-gray-600">Top (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.cabCleanDate.top)}
                        onChange={(e) => updateOverlayPosition('cabCleanDate', 'top', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Left (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.cabCleanDate.left)}
                        onChange={(e) => updateOverlayPosition('cabCleanDate', 'left', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Width (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.cabCleanDate.width)}
                        onChange={(e) => updateOverlayPosition('cabCleanDate', 'width', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Height (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.cabCleanDate.height)}
                        onChange={(e) => updateOverlayPosition('cabCleanDate', 'height', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium text-xs text-gray-700">Box Clean Date</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-xs text-gray-600">Top (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.boxCleanDate.top)}
                        onChange={(e) => updateOverlayPosition('boxCleanDate', 'top', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Left (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.boxCleanDate.left)}
                        onChange={(e) => updateOverlayPosition('boxCleanDate', 'left', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Width (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.boxCleanDate.width)}
                        onChange={(e) => updateOverlayPosition('boxCleanDate', 'width', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600">Height (%)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={parseFloat(overlayPositions.boxCleanDate.height)}
                        onChange={(e) => updateOverlayPosition('boxCleanDate', 'height', `${e.target.value}%`)}
                        className="w-full px-2 py-1 border rounded text-xs"
                      />
                    </div>
                  </div>
                </div>

              </div>
              <div className="mt-4 p-3 bg-white rounded border text-xs text-blue-700">
                <strong>💡 Tip:</strong> You can drag the text overlays directly on the image to reposition them, or use the controls above for precise positioning.
              </div>
            </div>
          )}

          {showAreaEditor && (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg no-print">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-sm">Clickable Area Editor</h3>
                <div>
                  <Button variant="outline" size="sm" onClick={resetAreas} className="mr-2">
                    Reset to Default
                  </Button>
                  <Button size="sm" onClick={handleSaveAreas} className="bg-blue-600 hover:bg-blue-700">
                    <Save className="w-3 h-3 mr-2" />
                    Save Layout
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {clickableAreas.map((area, index) => (
                  <div key={area.area} className="space-y-2">
                    <h4 className="font-medium text-xs text-gray-700">{area.area}</h4>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <label className="block text-xs text-gray-600">Top (%)</label>
                        <input
                          type="number"
                          value={parseInt(area.style.top)}
                          onChange={(e) => updateClickableArea(index, 'top', `${e.target.value}%`)}
                          className="w-full px-2 py-1 border rounded text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-600">Left (%)</label>
                        <input
                          type="number"
                          value={parseInt(area.style.left)}
                          onChange={(e) => updateClickableArea(index, 'left', `${e.target.value}%`)}
                          className="w-full px-2 py-1 border rounded text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-600">Width (%)</label>
                        <input
                          type="number"
                          value={parseInt(area.style.width)}
                          onChange={(e) => updateClickableArea(index, 'width', `${e.target.value}%`)}
                          className="w-full px-2 py-1 border rounded text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-600">Height (%)</label>
                        <input
                          type="number"
                          value={parseInt(area.style.height)}
                          onChange={(e) => updateClickableArea(index, 'height', `${e.target.value}%`)}
                          className="w-full px-2 py-1 border rounded text-xs"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

           <div ref={diagramContainerRef} className="relative w-full mx-auto van-diagram-container">
            <img
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/15e451ed5_NEWPeriodDamageTracker1.png"
              alt="Van damage diagram"
              className="w-full h-auto rounded-md"
            />

            {isAddingDamage && (
              <div
                className="absolute top-0 left-0 w-full h-full pointer-events-none z-10"
                style={{
                  backgroundImage: 'linear-gradient(rgba(100, 100, 100, 0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(100, 100, 100, 0.2) 1px, transparent 1px)',
                  backgroundSize: `${gridSize}% ${gridSize}%`,
                }}
              />
            )}

            {isAddingDamage && (
              <div
                className="absolute top-0 left-0 w-full h-full pointer-events-none z-10"
                style={{
                  backgroundImage: 'radial-gradient(circle, rgba(100, 100, 100, 0.3) 0.5px, transparent 0.5px)',
                  backgroundSize: `${gridSize}% ${gridSize}%`,
                }}
              />
            )}

            {selectedVan && (
              <div
                className={`absolute p-1 rounded border-2 transition-all select-none ${
                  isDragging === 'vanReg' ? 'border-blue-500 shadow-lg cursor-grabbing' : 'border-transparent cursor-grab hover:border-blue-300'
                }`}
                style={{
                  top: overlayPositions.vanReg.top,
                  left: overlayPositions.vanReg.left,
                  width: overlayPositions.vanReg.width,
                  height: overlayPositions.vanReg.height,
                  zIndex: isDragging === 'vanReg' ? 10 : 5,
                  fontSize: '36px',
                  fontWeight: 'bold',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'black',
                  backgroundColor: 'transparent'
                }}
                onMouseDown={(e) => handleOverlayMouseDown(e, 'vanReg')}
                title="Drag to reposition"
              >
                {selectedVan}
              </div>
            )}

            <div
              className={`absolute p-1 rounded border-2 transition-all select-none ${
                isDragging === 'period' ? 'border-blue-500 shadow-lg cursor-grabbing' : 'border-transparent cursor-grab hover:border-blue-300'
              }`}
              style={{
                top: overlayPositions.period.top,
                left: overlayPositions.period.left,
                width: overlayPositions.period.width,
                height: overlayPositions.period.height,
                zIndex: isDragging === 'period' ? 10 : 5,
                fontSize: '36px',
                fontWeight: 'bold',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'black',
                backgroundColor: 'transparent'
              }}
              onMouseDown={(e) => handleOverlayMouseDown(e, 'period')}
              title="Drag to reposition"
            >
              {currentPeriod}
            </div>

            <div
                className={`absolute p-1 rounded border-2 transition-all select-none ${
                    isDragging === 'exteriorCleanDate' ? 'border-blue-500 shadow-lg cursor-grabbing' : 'border-transparent cursor-grab hover:border-blue-300'
                }`}
                style={{ 
                  ...overlayPositions.exteriorCleanDate, 
                  zIndex: isDragging === 'exteriorCleanDate' ? 10 : 5, 
                  fontSize: '36px', 
                  fontWeight: 'bold', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  color: 'black',
                  backgroundColor: 'transparent'
                }}
                onMouseDown={(e) => handleOverlayMouseDown(e, 'exteriorCleanDate')}
                title="Drag to reposition"
            >
                {formatDateForOverlay(cleaningDates.exterior)}
            </div>
            <div
                className={`absolute p-1 rounded border-2 transition-all select-none ${
                    isDragging === 'cabCleanDate' ? 'border-blue-500 shadow-lg cursor-grabbing' : 'border-transparent cursor-grab hover:border-blue-300'
                }`}
                style={{ 
                  ...overlayPositions.cabCleanDate, 
                  zIndex: isDragging === 'cabCleanDate' ? 10 : 5, 
                  fontSize: '36px', 
                  fontWeight: 'bold', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  color: 'black',
                  backgroundColor: 'transparent'
                }}
                onMouseDown={(e) => handleOverlayMouseDown(e, 'cabCleanDate')}
                title="Drag to reposition"
            >
                {formatDateForOverlay(cleaningDates.cab)}
            </div>
            <div
                className={`absolute p-1 rounded border-2 transition-all select-none ${
                    isDragging === 'boxCleanDate' ? 'border-blue-500 shadow-lg cursor-grabbing' : 'border-transparent cursor-grab hover:border-blue-300'
                }`}
                style={{ 
                  ...overlayPositions.boxCleanDate, 
                  zIndex: isDragging === 'boxCleanDate' ? 10 : 5, 
                  fontSize: '36px', 
                  fontWeight: 'bold', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  color: 'black',
                  backgroundColor: 'transparent'
                }}
                onMouseDown={(e) => handleOverlayMouseDown(e, 'boxCleanDate')}
                title="Drag to reposition"
            >
                {formatDateForOverlay(cleaningDates.box)}
            </div>

            {clickableAreas.map(({ area, style }) => (
              <div
                key={area}
                className="absolute cursor-crosshair border border-transparent hover:border-blue-400/50 hover:bg-blue-100/20 transition-all rounded-md" 
                onClick={(e) => handleVanClick(e, area)}
                style={style}
              />
            ))}

            {damageMarkers.map(marker => {
              const descriptionText = (marker.groupId ? marker.groupDescription : marker.description) || '';
              const truncatedDescription = descriptionText.length > 15 ? descriptionText.substring(0, 12) + '...' : descriptionText;
              
              return (
                <div
                  key={marker.id}
                  className={`absolute transition-all ${
                    isCombiningMode ? 'cursor-pointer' : 
                    isRemovingDamage ? 'cursor-pointer' : 
                    isLocked ? 'cursor-not-allowed' :
                    'cursor-grab'
                  } ${ isDraggingMarker === marker.id ? 'cursor-grabbing z-50' : 'z-20' }`}
                  style={{
                    left: `${marker.x}%`,
                    top: `${marker.y}%`,
                    transform: 'translate(-50%, -50%)',
                    width: '80px',
                    height: '50px',
                  }}
                  onClick={(e) => handleMarkerClick(e, marker.id)}
                  onMouseDown={(e) => {
                    if (!isCombiningMode && !isRemovingDamage && !isAddingDamage && !isLocked) {
                      handleMarkerMouseDown(e, marker.id);
                    }
                  }}
                  onDragStart={(e) => e.preventDefault()}
                  title={
                    isLocked ? 'Markers are locked. Click the lock button to unlock editing.'
                    : selectedMarkerForKeyboard === marker.id ? 'Selected for arrow key movement (Shift for fine control, Escape to deselect)'
                    : isCombiningMode ? `${selectedMarkers.has(marker.id) ? 'Deselect' : 'Select'} ${damageKeys[marker.damageType]} for combining`
                    : isRemovingDamage ? `Click to remove ${marker.groupId ? 'group of ' : ''} ${damageKeys[marker.damageType]} damage`
                    : isDraggingMarker === marker.id ? 'Moving marker...'
                    : `Click to select for arrow keys or drag to move | ${damageKeys[marker.damageType]} - ${descriptionText} - Found: ${marker.date}`
                  }
                >
                  <svg
                    width="80"
                    height="50"
                    viewBox="0 0 80 50"
                    className={`w-full h-full transition-transform duration-150 origin-top-center ${
                      isCombiningMode ? 'hover:scale-125' : 
                      isRemovingDamage ? 'hover:opacity-75' : 
                      !isLocked ? 'hover:scale-110' : ''
                    } ${
                      selectedMarkers.has(marker.id) ? 'ring-2 ring-blue-500 rounded-full' : ''
                    } ${
                      selectedMarkerForKeyboard === marker.id ? 'ring-2 ring-green-500 rounded-full' : ''
                    } ${
                      isDraggingMarker === marker.id ? 'scale-125 opacity-75' : ''
                    } ${
                      isLocked ? 'opacity-80' : ''
                    }`}
                    style={{
                      shapeRendering: 'crispEdges',
                      textRendering: 'optimizeLegibility'
                    }}
                  >
                    
                    <g transform="translate(32, 0)">
                      {marker.shape === 'square' ? (
                        <rect x="0" y="0" width="16" height="16" rx="2" fill={marker.color} stroke="white" strokeWidth="1.5" shapeRendering="crispEdges"/>
                      ) : (
                        <circle cx="8" cy="8" r="7.5" fill={marker.color} stroke="white" strokeWidth="1.5"/>
                      )}
                      <text 
                        x="8" 
                        y="8.5" 
                        dominantBaseline="middle" 
                        textAnchor="middle" 
                        fill="white" 
                        fontSize="9" 
                        fontWeight="900" 
                        fontFamily="Arial, sans-serif"
                        className="pointer-events-none"
                        style={{ textRendering: 'optimizeLegibility' }}
                      >
                        {marker.damageType}
                      </text>
                    </g>
                    
                    {!marker.isNew && (!marker.groupId || marker.isGroupLeader) && (
                      <g transform="translate(40, 20)">
                        <text 
                          x="0" 
                          y="5" 
                          dominantBaseline="middle" 
                          textAnchor="middle" 
                          fill="#0066CC" 
                          fontSize="9" 
                          fontWeight="900"
                          fontFamily="Arial, sans-serif"
                          className="pointer-events-none"
                          style={{ textRendering: 'optimizeLegibility' }}
                        >
                          {formatDateForDiagram(marker.date)}
                        </text>
                        {truncatedDescription && (
                          <text 
                            x="0" 
                            y="16" 
                            dominantBaseline="middle" 
                            textAnchor="middle" 
                            fill="#CC0000" 
                            fontSize="9" 
                            fontWeight="900"
                            fontFamily="Arial, sans-serif"
                            className="pointer-events-none"
                            style={{ textRendering: 'optimizeLegibility' }}
                          >
                            {truncatedDescription}
                          </text>
                        )}
                      </g>
                    )}
                  </svg>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
      
      {damageMarkers.length > 0 && (
        <Card className="glass-card no-print">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg">Damage Summary</CardTitle>
            </div>
            {isCombiningMode && (
              <p className="text-sm text-blue-600 mt-2">
                Click on damage markers in the diagram above to select them for combining. Selected markers will be highlighted.
              </p>
            )}
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {getSummaryEntries().map(marker => (
                <div key={marker.id} className={`p-3 rounded-lg flex flex-wrap items-center justify-between gap-x-4 gap-y-2 transition-all ${selectedMarkers.has(marker.id) ? 'bg-blue-50 border-2 border-blue-200' : 'bg-gray-50'}`}>
                    <div className="flex items-center gap-3 flex-grow min-w-[200px]">
                      <div className="w-8 h-8 rounded-sm flex items-center justify-center text-white text-base font-bold flex-shrink-0" style={{ backgroundColor: marker.color }}>
                          {marker.damageType}
                      </div>
                      <div className="min-w-0">
                          <p className="font-semibold text-gray-900 text-sm truncate">{damageKeys[marker.damageType]}</p>
                          <p className="text-xs text-gray-600">{marker.area}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center">
                      <Input
                        type="date"
                        value={marker.date || ''}
                        onChange={(e) => updateMarkerDate(marker.id, e.target.value)}
                        className="h-9 w-36 text-xs"
                        disabled={isCombiningMode || isRemovingDamage || isAddingDamage || isLocked}
                        title="Damage Date"
                      />
                      
                      <Input
                        placeholder="SIMS No."
                        value={marker.groupId ? marker.groupDescription : marker.description}
                        onChange={(e) => updateMarkerDescription(marker.id, e.target.value)}
                        className="h-9 w-40 text-xs"
                        disabled={isCombiningMode || isRemovingDamage || isAddingDamage || isLocked}
                        title="SIMS Number or Description"
                      />

                      {!isCombiningMode && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeDamageMarker(marker.id)}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50 flex-shrink-0 ml-2"
                            title={marker.groupId ? `Remove entire group (${marker.groupSize} markers)` : 'Remove marker'}
                            disabled={isLocked}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        )}
                    </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex justify-end gap-3 no-print">
        <Button variant="outline" onClick={handleExportAsImage}>
          <Download className="w-4 h-4 mr-2" />
          Export Current Image
        </Button>
        <Button asChild variant="outline" className="border-green-200 text-green-600 hover:bg-green-50">
          <Link to={createPageUrl(`PrintAllTrackers?period=${currentPeriod}&year=${currentYear}`)}>
            <Download className="w-4 h-4 mr-2" />
            Export All Images
          </Link>
        </Button>
        <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleSaveDamageReport}>
          <Save className="w-4 h-4 mr-2" />
          Save Damage Report
        </Button>
      </div>
    </div>
  );
}
