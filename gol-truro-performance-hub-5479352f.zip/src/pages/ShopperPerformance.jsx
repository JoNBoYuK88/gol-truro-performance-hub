import React, { useState, useEffect, useMemo } from "react";
import { User } from "@/api/entities";
import { ShopperPerformance as ShopperPerformanceEntity } from "@/api/entities";
import { Shopper } from "@/api/entities";
import { ShopperIPHTarget } from "@/api/entities";
import { PeriodConfig } from "@/api/entities";
import { useEditLock } from "../Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, ArrowUpDown, Edit, Save, X, FileDown, Trash2, Target } from "lucide-react";
import { toast } from "sonner";
import { groupBy, sumBy } from 'lodash';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";

import KPICard from "../components/dashboard/KPICard";
import ShopperDetailModal from "../components/performance/ShopperDetailModal";
import TopPerformersCard from "../components/performance/TopPerformersCard";
import AchievementRatioCard from "../components/performance/AchievementRatioCard";

const SortableHeader = ({ children, column, sortConfig, onSort, className }) => {
  const isSorted = sortConfig.key === column;
  return (
    <TableHead onClick={() => onSort(column)} className={className}>
      <div className="flex items-center gap-2 cursor-pointer">
        {children}
        <ArrowUpDown className={`w-4 h-4 transition-opacity ${isSorted ? 'opacity-100' : 'opacity-30'}`} />
      </div>
    </TableHead>
  );
};

export default function ShopperPerformance() {
  const [performanceData, setPerformanceData] = useState([]);
  const [allYearShopperData, setAllYearShopperData] = useState([]);
  const [shoppers, setShoppers] = useState([]);
  const [periods, setPeriods] = useState([]);
  const [currentPeriod, setCurrentPeriod] = useState(1);
  const [currentWeek, setCurrentWeek] = useState(1);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [iphTarget, setIphTarget] = useState(85);
  const [iphTargets, setIphTargets] = useState([]);
  const [greenThreshold, setGreenThreshold] = useState(80);
  const [sortConfig, setSortConfig] = useState({ key: 'iph', direction: 'desc' });
  const [periodicSortConfig, setPeriodicSortConfig] = useState({ key: 'avg_iph', direction: 'desc' });
  const [roleFilter, setRoleFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState(''); // NEW: search state
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedShopper, setSelectedShopper] = useState(null);
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const fallbackData = [
    { id: "fb1", colleague_id: "SP001", name: "Sarah Mitchell", iph: 92.5, iph_target: 85, picked_items: 1850, total_shift_time: 480, non_shop_walk_time: 45, shop_walk_time: 380, skipped_items: 12, period: 1, week: 1, wrap_status: false },
    { id: "fb2", colleague_id: "SP002", name: "James Wilson", iph: 88.3, iph_target: 85, picked_items: 1720, total_shift_time: 465, non_shop_walk_time: 52, shop_walk_time: 365, skipped_items: 8, period: 1, week: 1, wrap_status: false },
    { id: "fb3", colleague_id: "SP003", name: "Emily Davis", iph: 91.2, iph_target: 85, picked_items: 1980, total_shift_time: 520, non_shop_walk_time: 38, shop_walk_time: 420, skipped_items: 15, period: 1, week: 2, wrap_status: true },
    { id: "fb4", colleague_id: "SP004", name: "Michael Brown", iph: 78.9, iph_target: 85, picked_items: 1420, total_shift_time: 430, non_shop_walk_time: 65, shop_walk_time: 310, skipped_items: 22, period: 1, week: 2, wrap_status: false },
    { id: "fb5", colleague_id: "SP005", iph: 95.8, iph_target: 85, picked_items: 2150, total_shift_time: 535, non_shop_walk_time: 32, shop_walk_time: 445, skipped_items: 6, period: 1, week: 3, wrap_status: false },
  ];

  const getCurrentPeriodAndWeek = async (periodsData = null) => {
    try {
      const periods = periodsData && periodsData.length > 0
        ? periodsData
        : await PeriodConfig.filter({ year: currentYear }, 'period_number');

      if (periods.length === 0) {
        return { period: 1, week: 1 };
      }

      const today = new Date();
      const currentPeriodConfig = periods.find(p => {
        const startDate = new Date(p.start_date);
        const endDate = new Date(p.end_date);
        const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
        const startPeriodDate = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
        const endPeriodDate = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate());

        return todayStart >= startPeriodDate && todayStart <= endPeriodDate;
      });

      if (currentPeriodConfig) {
        const startDate = new Date(currentPeriodConfig.start_date);
        const startPeriodDateNormalized = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
        const daysDiff = Math.floor((today.getTime() - startPeriodDateNormalized.getTime()) / (1000 * 60 * 60 * 24));
        const currentWeekNumber = Math.min(Math.floor(daysDiff / 7) + 1, 4);

        let targetPeriod = currentPeriodConfig.period_number;
        let targetWeek = currentWeekNumber - 1;

        if (targetWeek < 1) {
          targetPeriod = Math.max(1, targetPeriod - 1);
          targetWeek = 4;
        }

        return { period: targetPeriod, week: targetWeek };
      }

      const sortedPeriods = periods.sort((a, b) => new Date(b.start_date).getTime() - new Date(a.start_date).getTime());
      const latestPeriod = sortedPeriods.length > 0 ? sortedPeriods[0] : null;

      return { period: latestPeriod ? latestPeriod.period_number : 1, week: 4 };
    } catch (error) {
      console.error("Error determining current period:", error);
      return { period: 1, week: 1 };
    }
  };

  const loadUserAndYearConfigs = async () => {
    try {
        const currentUser = await User.me();
        setIsAdmin(currentUser && currentUser.role === 'admin');
    } catch (error) {
        console.error("User not logged in or error checking user:", error);
        setIsAdmin(false);
    }

    try {
        const periodsData = await PeriodConfig.filter({ year: currentYear }, 'period_number');
        setPeriods(periodsData);
        const { period, week } = await getCurrentPeriodAndWeek(periodsData);
        setCurrentPeriod(period);
        setCurrentWeek(week);
        const targetsData = await ShopperIPHTarget.filter({ year: currentYear }, 'period');
        setIphTargets(targetsData);
    } catch (error) {
        console.error("Error loading year configuration or determining current period:", error);
        setPeriods([]);
        setIphTargets([]);
        setCurrentPeriod(1);
        setCurrentWeek(1);
    }
  };

  useEffect(() => {
    if (currentYear) {
      loadUserAndYearConfigs();
    }
  }, [currentYear]);

  // Load all year data only when year changes
  useEffect(() => {
    if (currentYear && iphTargets.length > 0) {
      loadYearData(currentYear);
    }
  }, [currentYear, iphTargets]);

  // Force reload on component mount to ensure fresh shopper data
  useEffect(() => {
    if (currentYear && iphTargets.length > 0) {
      loadYearData(currentYear);
    }
  }, []);

  // Load weekly data when week/period changes OR when shoppers data updates
  useEffect(() => {
    if (currentPeriod && currentWeek && currentYear && iphTargets.length > 0 && shoppers.length > 0) {
      loadWeeklyData(currentPeriod, currentWeek, currentYear);
    }
  }, [currentPeriod, currentWeek, iphTargets, shoppers, currentYear]);

  const loadYearData = async (year, forceReload = false) => {
    try {
      // Always fetch fresh shopper data to get latest roles
      const [allShoppers, allYearPerformance] = await Promise.all([
        Shopper.list('-updated_date', 1000),
        ShopperPerformanceEntity.filter({ year: year }, '-date', 5000)
      ]);

      setShoppers(allShoppers);

      const shopperMasterMap = new Map(allShoppers.map(s => [s.colleague_id, s]));
      
      const allYearPerformanceMerged = allYearPerformance.map(perfRecord => {
        const masterShopperData = shopperMasterMap.get(perfRecord.colleague_id);
        return {
          ...perfRecord,
          role: masterShopperData?.role || 'shopper',
          wrap_status: masterShopperData ? masterShopperData.wrap_status : false,
          name: masterShopperData?.name || perfRecord.name,
        };
      });
      setAllYearShopperData(allYearPerformanceMerged);
    } catch (error) {
      console.error("Error loading year data:", error);
      toast.error("Failed to load year data.");
      setShoppers([]);
      setAllYearShopperData([]);
    }
  };

  const loadWeeklyData = async (period, week, year) => {
    try {
      const weeklyPerformance = await ShopperPerformanceEntity.filter({ period: period, week: week, year: year }, '-date', 100);

      const shopperMasterMap = new Map(shoppers.map(s => [s.colleague_id, s]));

      let currentTarget;
      if (period === 11) {
        currentTarget = iphTargets.find(t => t.period === period && t.week === week);
      }
      if (!currentTarget) {
        currentTarget = iphTargets.find(t => t.period === period && !t.week);
      }
      const targetValue = currentTarget ? currentTarget.iph_target : 85;
      setIphTarget(targetValue);

      const mergedWeeklyData = weeklyPerformance.map(perfRecord => {
        const masterShopperData = shopperMasterMap.get(perfRecord.colleague_id);
        return {
          ...perfRecord,
          role: masterShopperData?.role || 'shopper',
          wrap_status: masterShopperData ? masterShopperData.wrap_status : false,
          name: masterShopperData?.name || perfRecord.name,
          iph_target: targetValue,
        };
      });

      setPerformanceData(mergedWeeklyData.length > 0 ? mergedWeeklyData : []);

    } catch (error) {
      console.error("Error loading weekly data:", error);
      toast.error("Failed to load weekly data.");
      setPerformanceData([]);
    }
  };

  useEffect(() => {
    const handleVisibilityChange = async () => {
      if (!document.hidden && currentPeriod && currentWeek && currentYear && iphTargets.length > 0) {
        await loadYearData(currentYear, true);
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [currentPeriod, currentWeek, currentYear, iphTargets]);

  // Reload data when page gains focus (handles navigation from other pages)
  useEffect(() => {
    const handleFocus = async () => {
      if (currentYear && iphTargets.length > 0 && currentPeriod && currentWeek) {
        await loadYearData(currentYear, true);
      }
    };

    window.addEventListener('focus', handleFocus);

    return () => {
      window.removeEventListener('focus', handleFocus);
    };
  }, [currentPeriod, currentWeek, currentYear, iphTargets]);

  const handleClearWeeklyData = async () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to clear data.");
      return;
    }

    setShowClearDialog(false);

    try {
      const recordsToDelete = await ShopperPerformanceEntity.filter({
        period: currentPeriod,
        week: currentWeek,
        year: currentYear
      });

      if (recordsToDelete.length === 0) {
        toast.info(`No performance data found for Period ${currentPeriod}, Week ${currentWeek}, ${currentYear} to clear.`);
        return;
      }

      const sequentialDelete = async () => {
        for (const record of recordsToDelete) {
            await ShopperPerformanceEntity.delete(record.id);
            await new Promise(resolve => setTimeout(resolve, 50));
        }
        return recordsToDelete.length;
      };

      await toast.promise(sequentialDelete(), {
        loading: `Deleting ${recordsToDelete.length} records...`,
        success: (deletedCount) => {
          loadYearData(currentYear);
          loadWeeklyData(currentPeriod, currentWeek, currentYear);
          return `Successfully cleared ${deletedCount} records for Period ${currentPeriod}, Week ${currentWeek}.`;
        },
        error: (err) => {
          console.error("Error clearing weekly data:", err);
          return `Failed to clear data: ${err.message || 'Unknown error'}`;
        },
      });

    } catch (error) {
      toast.error("An unexpected error occurred while trying to clear data.");
      console.error("Error in handleClearWeeklyData:", error);
    }
  };

  const handleSyncAllData = async () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to sync data.");
      return;
    }

    setIsSyncing(true);

    try {
      // Force reload all data to get the latest role and wrap status information
      await loadYearData(currentYear);
      if (shoppers.length > 0) {
        await loadWeeklyData(currentPeriod, currentWeek, currentYear);
      }
      toast.success("All data synced successfully! Roles and WRAP statuses are now current.");
    } catch (error) {
      console.error("Error syncing data:", error);
      toast.error("Failed to sync data. Please try again.");
    } finally {
      setIsSyncing(false);
    }
  };

  const handleEditToggle = () => {
    if (!canEdit) {
      toast.error("You must be logged in as an administrator to edit data.");
      return;
    }
    if (isEditing) {
        handleSave();
    } else {
        const initialEditedData = {};
        performanceData.forEach(item => {
            initialEditedData[item.id] = { ...item };
        });
        setEditedData(initialEditedData);
        setIsEditing(true);
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedData({});
    toast.info("Editing cancelled.");
  };

  const handleDataChange = (id, field, value) => {
    setEditedData(prev => {
        let processedValue = value;

        if (field === 'iph' || field === 'picked_items' || field === 'skipped_items') {
            processedValue = parseFloat(value);
            if (isNaN(processedValue)) {
                processedValue = 0;
            }
        } else if (field === 'wrap_status') {
            processedValue = (value === 'true');
        }

        const updatedRecord = { ...prev[id], [field]: processedValue };
        const updatedState = { ...prev, [id]: updatedRecord };

        if ((field === 'role' || field === 'wrap_status') && updatedRecord.colleague_id) {
            setAllYearShopperData(prevAllYearData =>
                prevAllYearData.map(record =>
                    record.colleague_id === updatedRecord.colleague_id
                        ? { ...record, [field]: processedValue }
                        : record
                )
            );
        }

        return updatedState;
    });
  };

  const handleSave = async () => {
    const updatePromises = [];
    const originalDataMap = new Map(performanceData.map(item => [item.id, item]));
    const currentShopperMasterMap = new Map(shoppers.map(s => [s.colleague_id, s]));

    for (const id in editedData) {
      const originalPerformanceRecord = originalDataMap.get(id);
      const editedPerformanceRecord = editedData[id];

      if (!originalPerformanceRecord) continue;

      const currentIph = parseFloat(editedPerformanceRecord.iph);
      const currentPicked = parseInt(editedPerformanceRecord.picked_items);
      const currentSkipped = parseInt(editedPerformanceRecord.skipped_items);

      if (
          currentIph !== originalPerformanceRecord.iph ||
          currentPicked !== originalPerformanceRecord.picked_items ||
          currentSkipped !== originalPerformanceRecord.skipped_items
      ) {
          updatePromises.push(ShopperPerformanceEntity.update(id, {
              iph: currentIph,
              picked_items: currentPicked,
              skipped_items: currentSkipped,
          }));
      }

      const masterShopper = currentShopperMasterMap.get(editedPerformanceRecord.colleague_id);
      if (masterShopper) {
          if (
              editedPerformanceRecord.role !== masterShopper.role ||
              editedPerformanceRecord.wrap_status !== masterShopper.wrap_status
          ) {
              updatePromises.push(Shopper.update(masterShopper.id, {
                  role: editedPerformanceRecord.role,
                  wrap_status: editedPerformanceRecord.wrap_status
              }));
          }
      }
    }

    if (updatePromises.length === 0) {
        toast.info("No changes to save.");
        setIsEditing(false);
        setEditedData({});
        return;
    }

    toast.promise(Promise.all(updatePromises), {
        loading: 'Saving all changes...',
        success: (res) => {
            loadYearData(currentYear);
            loadWeeklyData(currentPeriod, currentWeek, currentYear);
            setIsEditing(false);
            setEditedData({});
            return `Successfully updated ${updatePromises.length} record(s)!`;
        },
        error: (err) => {
          console.error("Error saving changes:", err);
          return `Failed to save changes: ${err.message || 'Unknown error'}`;
        },
    });
  };

  const handleShopperNameClick = async (shopper) => {
    try {
        const performanceRecords = await ShopperPerformanceEntity.filter({
            colleague_id: shopper.colleague_id,
            year: currentYear
        });
        setSelectedShopper({ name: shopper.name, performanceRecords });
        setIsModalOpen(true);
    } catch (error) {
        toast.error("Failed to load shopper's yearly data.");
        console.error("Error fetching shopper details:", error);
    }
  };

  const sortedData = useMemo(() => {
    let sortableItems = [...performanceData];

    sortableItems = sortableItems.map(shopper => {
      const allShopperRecords = allYearShopperData.filter(record => record.colleague_id === shopper.colleague_id);
      return {
        ...shopper,
        weeks_appeared: allShopperRecords.length
      };
    });

    if (roleFilter !== 'all') {
      sortableItems = sortableItems.filter(item => item.role === roleFilter);
    }

    // Filter by search term
    if (searchTerm.trim()) {
      sortableItems = sortableItems.filter(item => 
        item.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.colleague_id?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (sortConfig.key !== null) {
      sortableItems.sort((a, b) => {
        if (sortConfig.key === 'wrap_status') {
          const aVal = a.wrap_status ? 1 : 0;
          const bVal = b.wrap_status ? 1 : 0;
          return sortConfig.direction === 'asc' ? aVal - bVal : bVal - aVal;
        }

        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [performanceData, sortConfig, roleFilter, searchTerm, allYearShopperData]); // Added searchTerm dependency

  const periodicData = useMemo(() => {
    let sourceData = [];
    sourceData = allYearShopperData.filter(d => d.period === currentPeriod);

    if (sourceData.length === 0) return [];

    const groupedByShopper = sourceData.reduce((acc, curr) => {
        acc[curr.colleague_id] = acc[curr.colleague_id] || {
            colleague_id: curr.colleague_id,
            name: curr.name,
            role: curr.role,
            wrap_status: curr.wrap_status,
            firstRecordPeriod: curr.period,
            weeks: new Set(),
            total_picked_items: 0,
            total_weighted_iph: 0,
            total_skipped_items: 0,
        };
        const shopperDetails = acc[curr.colleague_id];

        shopperDetails.weeks.add(curr.week);
        shopperDetails.total_picked_items += curr.picked_items;
        shopperDetails.total_weighted_iph += curr.iph * curr.picked_items;
        shopperDetails.total_skipped_items += curr.skipped_items;

        return acc;
    }, {});

    const aggregated = Object.values(groupedByShopper).map(s => {
        const avg_iph = s.total_picked_items > 0 ? s.total_weighted_iph / s.total_picked_items : 0;
        // For Period 11, use average of all weekly targets
        let calculatedTarget;
        if (s.firstRecordPeriod === 11) {
          const weeklyTargets = iphTargets.filter(t => t.period === 11 && t.week);
          if (weeklyTargets.length > 0) {
            calculatedTarget = weeklyTargets.reduce((sum, t) => sum + t.iph_target, 0) / weeklyTargets.length;
          }
        }
        if (!calculatedTarget) {
          calculatedTarget = (s.firstRecordPeriod && iphTargets.find(t => t.period === s.firstRecordPeriod && !t.week && t.year === currentYear)?.iph_target) || iphTarget;
        }

        return {
            id: s.colleague_id,
            colleague_id: s.colleague_id,
            name: s.name,
            role: s.role,
            avg_iph: avg_iph,
            iph_target: calculatedTarget,
            total_picked_items: s.total_picked_items,
            total_skipped_items: s.total_skipped_items,
            weeks_in_period: s.weeks.size,
            has_wrap: s.wrap_status,
        };
    }).filter(s => s.total_picked_items >= 4000);

    let filteredSummary = aggregated;
    if (roleFilter !== 'all') {
      filteredSummary = filteredSummary.filter(item => item.role === roleFilter);
    }

    // Filter by search term for periodic data too
    if (searchTerm.trim()) {
      filteredSummary = filteredSummary.filter(item => 
        item.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.colleague_id?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (periodicSortConfig.key !== null) {
      filteredSummary.sort((a, b) => {
        if (a[periodicSortConfig.key] < b[periodicSortConfig.key]) {
          return periodicSortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[periodicSortConfig.key] > b[periodicSortConfig.key]) {
          return periodicSortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }

    return filteredSummary;
  }, [allYearShopperData, currentPeriod, iphTargets, iphTarget, currentYear, roleFilter, searchTerm, periodicSortConfig]); // Added searchTerm dependency

  const topPerformers = useMemo(() => {
    const eligibleShoppers = sortedData.filter(s => s.picked_items >= 1000 && s.role !== 'manager');
    const sorted = eligibleShoppers.sort((a, b) => b.iph - a.iph);
    return sorted.slice(0, 5);
  }, [sortedData]);

  const topPeriodicPerformers = useMemo(() => {
    const eligibleShoppers = periodicData.filter(s => s.role !== 'manager');
    const sorted = eligibleShoppers.sort((a, b) => b.avg_iph - a.avg_iph);
    return sorted.slice(0, 5);
  }, [periodicData]);

  const achievementStats = useMemo(() => {
    const achievers = performanceData.filter(s => s.iph >= s.iph_target).length;
    const total = performanceData.length;
    const percentage = total > 0 ? (achievers / total) * 100 : 0;
    return { achievers, total, percentage };
  }, [performanceData, iphTarget]);

  const shoppersToTargetCount = useMemo(() => {
    return performanceData.filter(s => s.iph < s.iph_target).length;
  }, [performanceData, iphTarget]);

  const requestSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const requestPeriodicSort = (key) => {
    let direction = 'asc';
    if (periodicSortConfig.key === key && periodicSortConfig.direction === 'asc') {
        direction = 'desc';
    }
    setPeriodicSortConfig({ key, direction });
  };

  const getIPHStatus = (iph, target) => {
    if (iph >= target) return "green";
    if (iph >= target * 0.9) return "amber";
    return "red";
  };

  const getRoleBadge = (role) => {
    const roleConfig = {
      'shopper': { label: 'Shopper', className: 'bg-blue-100 text-blue-800 px-2 py-1 rounded-md' },
      'new': { label: 'New', className: 'bg-indigo-100 text-indigo-800 px-2 py-1 rounded-md' },
      'new_sd_shopper': { label: 'New SD Shopper', className: 'bg-purple-100 text-purple-800 px-2 py-1 rounded-md' },
      'sd_shopper': { label: 'SD Shopper', className: 'bg-pink-100 text-pink-800 px-2 py-1 rounded-md' },
      'ga': { label: 'GA', className: 'bg-yellow-100 text-yellow-800 px-2 py-1 rounded-md' },
      'driver': { label: 'Driver', className: 'bg-green-100 text-green-800 px-2 py-1 rounded-md' },
      'manager': { label: 'Manager', className: 'bg-gray-100 text-gray-800 px-2 py-1 rounded-md' },
      'quit': { label: 'Quit', className: 'bg-red-100 text-red-800 px-2 py-1 rounded-md' },
      'store_support': { label: 'Store Support', className: 'bg-black text-white px-2 py-1 rounded-md' },
      'boom': { label: 'Boom', className: 'bg-orange-100 text-orange-800 px-2 py-1 rounded-md' }
    };

    const config = roleConfig[role] || roleConfig['shopper'];
    return <span className={`text-xs font-medium ${config.className}`}>{config.label}</span>;
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      'On Target': 'bg-green-100 text-green-800 px-2 py-1 rounded-md',
      'Close': 'bg-amber-100 text-amber-800 px-2 py-1 rounded-md',
      'Below Target': 'bg-red-100 text-red-800 px-2 py-1 rounded-md'
    };
    return <span className={`text-xs font-medium ${statusClasses[status]}`}>{status}</span>;
  };

  const getWrapBadge = (wrapStatus) => {
    const config = wrapStatus
      ? { label: 'Yes', className: 'bg-red-100 text-red-800' }
      : { label: 'No', className: 'bg-green-100 text-green-800' };

    return <span className={`text-xs font-medium px-2 py-1 rounded-md ${config.className}`}>{config.label}</span>;
  };

  const weeklyIPH = useMemo(() => {
    if (performanceData.length === 0) return 0;
    const totalItems = performanceData.reduce((sum, s) => sum + s.picked_items, 0);
    const totalMinutes = performanceData.reduce((sum, s) => sum + s.total_shift_time, 0);
    return totalMinutes > 0 ? (totalItems / (totalMinutes / 60)).toFixed(2) : 0;
  }, [performanceData]);

  const periodicIPH = useMemo(() => {
    const dataForPeriod = allYearShopperData.filter(r => r.period === currentPeriod);
    if (dataForPeriod.length === 0) return 0;
    const totalItems = dataForPeriod.reduce((sum, s) => sum + s.picked_items, 0);
    const totalMinutes = dataForPeriod.reduce((sum, s) => sum + s.total_shift_time, 0);
    return totalMinutes > 0 ? (totalItems / (totalMinutes / 60)).toFixed(2) : 0;
  }, [allYearShopperData, currentPeriod]);

  return (
    <div className="p-6 space-y-6">
      <Dialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Data Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete all performance data for Period {currentPeriod}, Week {currentWeek}, {currentYear}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClearDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleClearWeeklyData}>Yes, Delete Data</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ShopperDetailModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        shopperData={selectedShopper}
        iphTargets={iphTargets}
      />

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-gray-900">Shopper Performance</h1>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))}>
            <SelectTrigger className="border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900 w-24">
              <SelectValue placeholder="Select Year"/>
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 3 }, (_, i) => new Date().getFullYear() + i - 1).map(y => (
                <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))}>
            <SelectTrigger className="border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900 w-28">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 13 }, (_, i) => (
                <SelectItem key={i + 1} value={(i + 1).toString()}>P{i + 1}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={currentWeek.toString()} onValueChange={(val) => setCurrentWeek(parseInt(val))}>
            <SelectTrigger className="border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900 w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 4 }, (_, i) => (
                <SelectItem key={i + 1} value={(i + 1).toString()}>W{i + 1}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900 w-28">
              <SelectValue placeholder="Filter by Role"/>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              <SelectItem value="shopper">Shopper</SelectItem>
              <SelectItem value="sd_shopper">SD Shopper</SelectItem>
              <SelectItem value="ga">GA</SelectItem>
              <SelectItem value="driver">Driver</SelectItem>
              <SelectItem value="manager">Manager</SelectItem>
              <SelectItem value="quit">Quit</SelectItem>
              <SelectItem value="store_support">Store Support</SelectItem>
              <SelectItem value="boom">Boom</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex items-center gap-2 text-sm whitespace-nowrap md:ml-auto">
              <span className="font-medium text-gray-700">IPH Target:</span>
              <span className="font-bold text-orange-600 text-base">{iphTarget}</span>
          </div>

          {canEdit && (
              <>
                  <Button
                      variant="outline"
                      size="sm"
                      onClick={handleSyncAllData}
                      disabled={isSyncing || isEditing}
                      className="border-blue-200 text-blue-700 hover:bg-blue-50 rounded-lg px-4 py-2"
                  >
                      {isSyncing ? (
                          <>
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
                              Syncing...
                          </>
                      ) : (
                          <>
                              <Users className="w-4 h-4 mr-2" />
                              Sync All Data
                          </>
                      )}
                  </Button>
                  {isEditing && (
                      <Button variant="outline" size="sm" onClick={handleCancelEdit} className="border-slate-200 rounded-lg px-4 py-2">
                          <X className="w-4 h-4 mr-2"/>
                          Cancel
                      </Button>
                  )}
                  <Button size="sm" onClick={handleEditToggle} className="btn-modern" disabled={isSyncing}>
                      {isEditing ? <><Save className="w-4 h-4 mr-2"/>Save Changes</> : <><Edit className="w-4 h-4 mr-2"/>Edit Mode</>}
                  </Button>
                  <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => setShowClearDialog(true)}
                      className="text-white bg-red-600 hover:bg-red-700 rounded-lg px-4 py-2"
                      disabled={isEditing || isSyncing}
                  >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Clear Weekly Data
                  </Button>
              </>
          )}
          <Button variant="outline" className="border-slate-200 rounded-lg px-4 py-2" onClick={() => window.print()}>
            <FileDown className="w-4 h-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <TopPerformersCard
          title="Top 5 Weekly Performers"
          performers={topPerformers}
          period={currentPeriod}
          week={currentWeek}
          compact={true}
          iconPosition="left"
          isPeriodic={false}
        />
        <div className="flex flex-col gap-4">
          <AchievementRatioCard
            title="Shoppers Achieving Target"
            achievers={achievementStats.achievers}
            total={achievementStats.total}
            compact={true}
            className="flex-1"
          />
          <div className="grid grid-cols-2 gap-3 flex-1">
            <KPICard
              title="Remaining to Hit Target"
              value={shoppersToTargetCount > 0 ? shoppersToTargetCount : ''}
              unit="count"
              icon={Users}
              amberThreshold={5}
              redThreshold={10}
              compact={true}
              className="flex-1 flex flex-col justify-center items-center"
            />
            <KPICard
              title="Required to Hit 80%"
              value={Math.max(0, Math.ceil(achievementStats.total * 0.8) - achievementStats.achievers) > 0 ? Math.max(0, Math.ceil(achievementStats.total * 0.8) - achievementStats.achievers) : ''}
              unit="count"
              icon={Target}
              amberThreshold={5}
              redThreshold={10}
              compact={true}
              className="flex-1 flex flex-col justify-center items-center"
            />
          </div>
          <KPICard
            title="Achievement Rate"
            value={achievementStats.percentage}
            unit="percentage"
            icon={Users}
            greenThreshold={greenThreshold}
            amberThreshold={60}
            redThreshold={59.99}
            compact={true}
            className="flex-1 flex col justify-center items-center"
          />
        </div>
        <TopPerformersCard
          title={`Top 5 Period ${currentPeriod} Performers`}
          performers={topPeriodicPerformers}
          period={currentPeriod}
          week={null}
          compact={true}
          iconPosition="right"
          isPeriodic={true}
        />
      </div>

      <Tabs defaultValue="weekly" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="weekly">Weekly Detail</TabsTrigger>
          <TabsTrigger value="periodic">Periodic Summary</TabsTrigger>
        </TabsList>
        <TabsContent value="weekly">
          <Card className="table-modern mt-4">
            <CardHeader className="pb-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="space-y-2">
                  <CardTitle className="text-xl font-semibold text-slate-800">Detailed Performance Table</CardTitle>
                </div>
                <div className="flex items-center gap-2">
                  <Input
                    type="text"
                    placeholder="Search by name or ID..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900 w-64"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-200/50">
                    <TableHead>#</TableHead>
                    <SortableHeader column="colleague_id" sortConfig={sortConfig} onSort={requestSort}>
                      ID
                    </SortableHeader>
                    <SortableHeader column="name" sortConfig={sortConfig} onSort={requestSort}>
                      Name
                    </SortableHeader>
                    <SortableHeader column="iph" sortConfig={sortConfig} onSort={requestSort}>
                      IPH
                    </SortableHeader>
                    <TableHead>IPH vs Target</TableHead>
                    <SortableHeader column="picked_items" sortConfig={sortConfig} onSort={requestSort}>
                      Picked Items
                    </SortableHeader>
                    <TableHead>Skipped Items</TableHead>
                    <TableHead>Status</TableHead>
                    <SortableHeader column="role" sortConfig={sortConfig} onSort={requestSort}>
                      Role
                    </SortableHeader>
                    <SortableHeader column="weeks_appeared" sortConfig={sortConfig} onSort={requestSort}>
                      Weeks
                    </SortableHeader>
                    <SortableHeader column="wrap_status" sortConfig={sortConfig} onSort={requestSort}>WRAP</SortableHeader>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedData.length > 0 ? sortedData.map((shopper, index) => (
                    <TableRow key={shopper.id} className={
                      isEditing ? "bg-blue-50/50" : shopper.wrap_status ? "bg-red-100" :
                      shopper.weeks_appeared < 6 ? "bg-orange-100" : ""
                    }>
                      <TableCell className="font-medium text-gray-500">{index + 1}</TableCell>
                      <TableCell>
                        {isEditing ? <Input value={editedData[shopper.id]?.colleague_id || ''} onChange={(e) => handleDataChange(shopper.id, 'colleague_id', e.target.value)} className="w-24" /> : shopper.colleague_id}
                      </TableCell>
                      <TableCell>
                        {isEditing ? <Input value={editedData[shopper.id]?.name || ''} onChange={(e) => handleDataChange(shopper.id, 'name', e.target.value)} /> :
                          <span
                            className="cursor-pointer hover:text-sainsbury-orange hover:underline"
                            onClick={() => handleShopperNameClick(shopper)}
                          >
                            {shopper.role === 'quit' ? <span className="line-through text-red-600 opacity-60">{shopper.name}</span> : <span>{shopper.name}</span>}
                          </span>
                        }
                      </TableCell>
                      <TableCell>
                        {isEditing ? <Input type="number" value={editedData[shopper.id]?.iph || 0} onChange={(e) => handleDataChange(shopper.id, 'iph', e.target.value)} className="w-20"/> : <span className="font-bold">{shopper.iph.toFixed(2)}</span>}
                      </TableCell>
                      <TableCell>
                        <span className={`font-medium ${ shopper.iph >= shopper.iph_target ? 'text-green-600' : 'text-red-600' }`}>
                          {shopper.iph >= shopper.iph_target ? '+' : ''}{(shopper.iph - shopper.iph_target).toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell>
                        {isEditing ? <Input type="number" value={editedData[shopper.id]?.picked_items || 0} onChange={(e) => handleDataChange(shopper.id, 'picked_items', e.target.value)} className="w-24" /> : shopper.picked_items.toLocaleString()}
                      </TableCell>
                      <TableCell>
                        {isEditing ? <Input type="number" value={editedData[shopper.id]?.skipped_items || 0} onChange={(e) => handleDataChange(shopper.id, 'skipped_items', e.target.value)} className="w-20" /> : shopper.skipped_items}
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(getIPHStatus(shopper.iph, shopper.iph_target) === "green" ? "On Target" :
                         getIPHStatus(shopper.iph, shopper.iph_target) === "amber" ? "Close" : "Below Target")}
                      </TableCell>
                      <TableCell className="text-center">
                        {isEditing ? (
                          <Select value={editedData[shopper.id]?.role || ''} onValueChange={(value) => handleDataChange(shopper.id, 'role', value)}>
                            <SelectTrigger><SelectValue/></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="shopper">Shopper</SelectItem>
                              <SelectItem value="sd_shopper">SD Shopper</SelectItem>
                              <SelectItem value="ga">GA</SelectItem>
                              <SelectItem value="driver">Driver</SelectItem>
                              <SelectItem value="manager">Manager</SelectItem>
                              <SelectItem value="quit">Quit</SelectItem>
                              <SelectItem value="store_support">Store Support</SelectItem>
                              <SelectItem value="boom">Boom</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : getRoleBadge(shopper.role)}
                      </TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-md text-xs font-medium border border-slate-300 bg-slate-50 text-slate-600">{shopper.weeks_appeared}</span>
                      </TableCell>
                      <TableCell>
                        {isEditing ? (
                          <Select
                            value={String(editedData[shopper.id]?.wrap_status)}
                            onValueChange={(value) => handleDataChange(shopper.id, 'wrap_status', value)}
                            disabled={!isEditing}
                          >
                            <SelectTrigger className="w-24">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="false">No</SelectItem>
                              <SelectItem value="true">Yes</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          getWrapBadge(shopper.wrap_status)
                        )}
                      </TableCell>
                    </TableRow>
                  )) : (
                    <TableRow>
                        <TableCell colSpan="12" className="text-center py-10  text-slate-500">
                            No weekly data available for the selected period and week.
                        </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="periodic">
           <Card className="table-modern mt-4">
            <CardHeader className="pb-6">
              <div className="space-y-2">
                <CardTitle className="text-xl font-semibold text-slate-800">Periodic Performance Summary</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-200/50">
                    <TableHead>#</TableHead>
                    <SortableHeader column="colleague_id" sortConfig={periodicSortConfig} onSort={requestPeriodicSort}>
                      ID
                    </SortableHeader>
                    <SortableHeader column="name" sortConfig={periodicSortConfig} onSort={requestPeriodicSort}>
                      Name
                    </SortableHeader>
                    <SortableHeader column="avg_iph" sortConfig={periodicSortConfig} onSort={requestPeriodicSort}>
                      IPH
                    </SortableHeader>
                    <TableHead>IPH vs Target</TableHead>
                    <SortableHeader column="total_picked_items" sortConfig={periodicSortConfig} onSort={requestPeriodicSort}>
                      Total Picked
                    </SortableHeader>
                    <SortableHeader column="total_skipped_items" sortConfig={periodicSortConfig} onSort={requestPeriodicSort}>
                      Total Skipped
                    </SortableHeader>
                    <TableHead>Status</TableHead>
                    <SortableHeader column="role" sortConfig={periodicSortConfig} onSort={requestPeriodicSort}>
                      Role
                    </SortableHeader>
                    <TableHead>WRAP</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {periodicData.map((shopper, index) => (
                    <TableRow key={shopper.id} className={shopper.has_wrap ? "bg-red-100" : ""}>
                      <TableCell className="font-medium text-gray-500">{index + 1}</TableCell>
                      <TableCell>{shopper.colleague_id}</TableCell>
                       <TableCell
                        className="cursor-pointer hover:text-sainsbury-orange hover:underline"
                        onClick={() => handleShopperNameClick(shopper)}
                       >
                        {shopper.role === 'quit' ? (
                          <span className="line-through text-red-600 opacity-60">{shopper.name}</span>
                        ) : (
                          <span>{shopper.name}</span>
                        )}
                      </TableCell>
                      <TableCell className="font-bold">{shopper.avg_iph.toFixed(2)}</TableCell>
                      <TableCell>
                        <span className={`font-medium ${ shopper.avg_iph >= shopper.iph_target ? 'text-green-600' : 'text-red-600' }`}>
                          {shopper.avg_iph >= shopper.iph_target ? '+' : ''}{(shopper.avg_iph - shopper.iph_target).toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell>{shopper.total_picked_items.toLocaleString()}</TableCell>
                      <TableCell>{shopper.total_skipped_items}</TableCell>
                      <TableCell>
                        {getStatusBadge(getIPHStatus(shopper.avg_iph, shopper.iph_target) === "green" ? "On Target" :
                         getIPHStatus(shopper.avg_iph, shopper.iph_target) === "amber" ? "Close" : "Below Target")}
                      </TableCell>
                      <TableCell className="text-center">{getRoleBadge(shopper.role)}</TableCell>
                      <TableCell>
                        {getWrapBadge(shopper.has_wrap)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}