
import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowRight, ArrowLeft, Edit, Save, ChevronLeft, ChevronRight, Download, CheckCircle, Users, Clock, Package, Heart, RefreshCw } from 'lucide-react';
import { KPIMetric } from '@/api/entities';
import { toast } from 'sonner';

const KPI_CONFIG = [
  { id: 1, kpiName: 'Ops Score', label: 'Ops Score', icon: CheckCircle, greenThreshold: 80, amberThreshold: 60, redThreshold: 59.99, higherIsBetter: true },
  { id: 2, kpiName: 'Shoppers Achieving', label: 'Shoppers', icon: Users, greenThreshold: 80, amberThreshold: 60, redThreshold: 59.99, higherIsBetter: true },
  { id: 3, kpiName: 'On Time Departures', label: 'OTDept', icon: Clock, greenThreshold: 98, amberThreshold: 95, redThreshold: 94.99, higherIsBetter: true },
  { id: 4, kpiName: 'Availability', label: 'Availability', icon: Package, greenThreshold: 98, amberThreshold: 95, redThreshold: 94.99, higherIsBetter: true },
  { id: 5, kpiName: 'Delivery Without Complaints', label: 'DWC', icon: Heart, greenThreshold: 98, amberThreshold: 96, redThreshold: 95.99, higherIsBetter: true },
  { id: 6, kpiName: 'Secondary Replenishment', label: 'Sec Replen', icon: RefreshCw, greenThreshold: 1.99, amberThreshold: 2.99, redThreshold: 3, higherIsBetter: false },
  { id: 7, kpiName: 'iCare', label: 'iCare', icon: Heart, greenThreshold: 49.5, amberThreshold: 49.4, redThreshold: 49.39, higherIsBetter: true },
];

export default function Slides() {
  const [period, setPeriod] = useState(8);
  const [year, setYear] = useState(2025);
  const [isEditing, setIsEditing] = useState(false);
  const [kpiData, setKpiData] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const slideRef = useRef(null);

  useEffect(() => {
    loadKPIData();
  }, [period, year]);

  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.key === 'ArrowLeft') {
        setCurrentSlide(prev => Math.max(0, prev - 1));
      } else if (e.key === 'ArrowRight') {
        setCurrentSlide(prev => Math.min(0, prev + 1));
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  const loadKPIData = async () => {
    setIsLoading(true);
    try {
      const metrics = await KPIMetric.filter({ 
        period: period, 
        year: year 
      }, '-created_date', 100);

      const data = {};
      KPI_CONFIG.forEach(config => {
        const periodMetric = metrics.find(m => 
          m.name === config.kpiName && 
          m.period === period && 
          m.week === null &&
          m.quarter === null
        );

        if (periodMetric) {
          data[config.kpiName] = periodMetric.value;
        } else {
          const weeklyMetrics = metrics.filter(m => 
            m.name === config.kpiName && 
            m.period === period && 
            m.week !== null
          );
          
          if (weeklyMetrics.length > 0) {
            const avg = weeklyMetrics.reduce((sum, m) => sum + m.value, 0) / weeklyMetrics.length;
            data[config.kpiName] = avg;
          } else {
            data[config.kpiName] = 0;
          }
        }
      });

      setKpiData(data);
    } catch (error) {
      console.error("Failed to load KPI data:", error);
      toast.error("Failed to load KPI data");
    } finally {
      setIsLoading(false);
    }
  };

  const formatValue = (kpiName, value) => {
    if (!value) return '—';
    
    if (kpiName === 'Secondary Replenishment') {
      return `${value.toFixed(2)}%`;
    }
    
    if (['Ops Score', 'Shoppers Achieving', 'On Time Departures', 'Availability', 'Delivery Without Complaints', 'iCare'].includes(kpiName)) {
      return `${value.toFixed(1)}%`;
    }
    
    return value.toFixed(1);
  };

  const getBoxColor = (config, value) => {
    if (!value) return { bg: 'rgba(148, 163, 184, 0.1)', border: '#cbd5e1', text: '#64748b' };

    let status;
    if (config.higherIsBetter) {
      if (value >= config.greenThreshold) status = 'green';
      else if (value >= config.amberThreshold) status = 'amber';
      else status = 'red';
    } else {
      if (value <= config.greenThreshold) status = 'green';
      else if (value <= config.amberThreshold) status = 'amber';
      else status = 'red';
    }

    // Use same colors as KPI Overview dashboard
    if (status === 'green') {
      return { bg: 'rgba(34, 197, 94, 0.1)', border: 'rgba(34, 197, 94, 0.3)', text: '#15803d' };
    } else if (status === 'amber') {
      return { bg: 'rgba(245, 158, 11, 0.1)', border: 'rgba(245, 158, 11, 0.3)', text: '#b45309' };
    } else {
      return { bg: 'rgba(239, 68, 68, 0.1)', border: 'rgba(239, 68, 68, 0.3)', text: '#b91c1c' };
    }
  };

  const handleExportSlide = async () => {
    if (!slideRef.current) {
      toast.error("Slide not ready for export");
      return;
    }

    setIsExporting(true);
    toast.info("Exporting slide as image...");

    try {
      const html2canvas = (await import('html2canvas')).default;
      
      const canvas = await html2canvas(slideRef.current, {
        backgroundColor: '#ffffff',
        scale: 2,
        useCORS: true,
        allowTaint: true,
        logging: false,
        width: slideRef.current.offsetWidth,
        height: slideRef.current.offsetHeight
      });

      const link = document.createElement('a');
      link.download = `GOL_Truro_Period_${period}_${year}_Slide_${currentSlide + 1}.png`;
      link.href = canvas.toDataURL('image/png');
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success("Slide exported! You can now insert it into PowerPoint.");
    } catch (error) {
      console.error("Error exporting slide:", error);
      toast.error("Failed to export slide");
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100 p-8">
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=Caveat:wght@400;700&display=swap');
          
          .handwritten {
            font-family: 'Caveat', cursive;
          }
          
          .kpi-box {
            width: 180px;
            height: 180px;
            border: 5px solid;
            border-radius: 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            cursor: default;
            transition: all 0.3s ease;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
          }
          
          .kpi-box:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
          }
          
          .slide-container {
            transition: opacity 0.5s ease-in-out, transform 0.5s ease-in-out;
          }
          
          .slide-enter {
            opacity: 0;
            transform: translateX(100px);
          }
          
          .slide-active {
            opacity: 1;
            transform: translateX(0);
          }
          
          .slide-exit {
            opacity: 0;
            transform: translateX(-100px);
          }
        `}
      </style>

      {/* Header Controls */}
      <div className="max-w-7xl mx-auto mb-8">
        <Card className="glass-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium">Period:</label>
                  <Select value={period.toString()} onValueChange={(val) => setPeriod(parseInt(val))}>
                    <SelectTrigger className="w-24 h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 13 }, (_, i) => i + 1).map(p => (
                        <SelectItem key={p} value={p.toString()}>{p}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium">Year:</label>
                  <Input 
                    type="number" 
                    value={year} 
                    onChange={(e) => setYear(parseInt(e.target.value))}
                    className="w-24 h-8"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExportSlide}
                  disabled={isExporting || isLoading}
                  className="h-8 px-3"
                >
                  {isExporting ? (
                    <>
                      <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-blue-600 mr-2"></div>
                      Exporting...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Export for PowerPoint
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setCurrentSlide(prev => Math.max(0, prev - 1))}
                  disabled={currentSlide === 0}
                  className="h-8 w-8"
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-sm text-gray-600 min-w-[60px] text-center">
                  Slide {currentSlide + 1}/1
                </span>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setCurrentSlide(prev => Math.min(0, prev + 1))}
                  disabled={currentSlide === 0}
                  className="h-8 w-8"
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Slide */}
      <div className="max-w-7xl mx-auto">
        <Card 
          ref={slideRef}
          className={`glass-card bg-white/95 backdrop-blur-xl slide-container ${currentSlide === 0 ? 'slide-active' : 'slide-exit'}`}
        >
          <CardContent className="p-16">
            {/* Title */}
            <h1 className="text-6xl font-bold text-center mb-20 handwritten text-gray-800">
              GOL Truro GOL Period {period}
            </h1>

            {isLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
                <p className="text-gray-600 mt-4">Loading KPI data...</p>
              </div>
            ) : (
              <>
                {/* KPI Box Flow */}
                <div className="relative flex items-center justify-center gap-6 py-16">
                  {KPI_CONFIG.map((config, index) => {
                    const value = kpiData[config.kpiName];
                    const colors = getBoxColor(config, value);
                    const Icon = config.icon;
                    
                    return (
                      <div key={config.id} className="relative flex flex-col items-center">
                        {/* Square Box */}
                        <div 
                          className="kpi-box"
                          style={{ 
                            backgroundColor: colors.bg,
                            borderColor: colors.border
                          }}
                        >
                          <Icon className="w-12 h-12 mb-3" style={{ color: colors.text }} />
                          <div className="text-3xl font-bold mb-1" style={{ color: colors.text }}>
                            {formatValue(config.kpiName, value)}
                          </div>
                          <div className="text-lg font-semibold" style={{ color: colors.text }}>
                            {config.label}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Navigation Help Text */}
      <div className="max-w-7xl mx-auto mt-4 text-center text-sm text-gray-500">
        Use arrow keys ← → or buttons above to navigate slides | Click "Export for PowerPoint" to download as image
      </div>
    </div>
  );
}
