import Layout from "./Layout.jsx";

import AppExportDocumentation from "./AppExportDocumentation";

import CustomerComplaints from "./CustomerComplaints";

import Dashboard from "./Dashboard";

import DeliveryCostReport from "./DeliveryCostReport";

import DriverDataUpload from "./DriverDataUpload";

import DriverViolations from "./DriverViolations";

import ForecastAndLabour from "./ForecastAndLabour";

import Home from "./Home";

import IPHCalculator from "./IPHCalculator";

import KpiSettings from "./KpiSettings";

import Link from "./Link";

import PerformanceMatrix from "./PerformanceMatrix";

import PerformanceMatrixDataUpload from "./PerformanceMatrixDataUpload";

import PeriodDamageTracker from "./PeriodDamageTracker";

import PeriodResults from "./PeriodResults";

import PeriodSettings from "./PeriodSettings";

import PrintAllTrackers from "./PrintAllTrackers";

import RegionalDataUpload from "./RegionalDataUpload";

import Schedules from "./Schedules";

import ShopperDataUpload from "./ShopperDataUpload";

import ShopperIPHTargets from "./ShopperIPHTargets";

import ShopperPerformance from "./ShopperPerformance";

import SimsTtcMasternaut from "./SimsTtcMasternaut";

import Slides from "./Slides";

import Training from "./Training";

import WereListeningSurvey from "./WereListeningSurvey";

import Worm from "./Worm";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    AppExportDocumentation: AppExportDocumentation,
    
    CustomerComplaints: CustomerComplaints,
    
    Dashboard: Dashboard,
    
    DeliveryCostReport: DeliveryCostReport,
    
    DriverDataUpload: DriverDataUpload,
    
    DriverViolations: DriverViolations,
    
    ForecastAndLabour: ForecastAndLabour,
    
    Home: Home,
    
    IPHCalculator: IPHCalculator,
    
    KpiSettings: KpiSettings,
    
    Link: Link,
    
    PerformanceMatrix: PerformanceMatrix,
    
    PerformanceMatrixDataUpload: PerformanceMatrixDataUpload,
    
    PeriodDamageTracker: PeriodDamageTracker,
    
    PeriodResults: PeriodResults,
    
    PeriodSettings: PeriodSettings,
    
    PrintAllTrackers: PrintAllTrackers,
    
    RegionalDataUpload: RegionalDataUpload,
    
    Schedules: Schedules,
    
    ShopperDataUpload: ShopperDataUpload,
    
    ShopperIPHTargets: ShopperIPHTargets,
    
    ShopperPerformance: ShopperPerformance,
    
    SimsTtcMasternaut: SimsTtcMasternaut,
    
    Slides: Slides,
    
    Training: Training,
    
    WereListeningSurvey: WereListeningSurvey,
    
    Worm: Worm,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<AppExportDocumentation />} />
                
                
                <Route path="/AppExportDocumentation" element={<AppExportDocumentation />} />
                
                <Route path="/CustomerComplaints" element={<CustomerComplaints />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/DeliveryCostReport" element={<DeliveryCostReport />} />
                
                <Route path="/DriverDataUpload" element={<DriverDataUpload />} />
                
                <Route path="/DriverViolations" element={<DriverViolations />} />
                
                <Route path="/ForecastAndLabour" element={<ForecastAndLabour />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/IPHCalculator" element={<IPHCalculator />} />
                
                <Route path="/KpiSettings" element={<KpiSettings />} />
                
                <Route path="/Link" element={<Link />} />
                
                <Route path="/PerformanceMatrix" element={<PerformanceMatrix />} />
                
                <Route path="/PerformanceMatrixDataUpload" element={<PerformanceMatrixDataUpload />} />
                
                <Route path="/PeriodDamageTracker" element={<PeriodDamageTracker />} />
                
                <Route path="/PeriodResults" element={<PeriodResults />} />
                
                <Route path="/PeriodSettings" element={<PeriodSettings />} />
                
                <Route path="/PrintAllTrackers" element={<PrintAllTrackers />} />
                
                <Route path="/RegionalDataUpload" element={<RegionalDataUpload />} />
                
                <Route path="/Schedules" element={<Schedules />} />
                
                <Route path="/ShopperDataUpload" element={<ShopperDataUpload />} />
                
                <Route path="/ShopperIPHTargets" element={<ShopperIPHTargets />} />
                
                <Route path="/ShopperPerformance" element={<ShopperPerformance />} />
                
                <Route path="/SimsTtcMasternaut" element={<SimsTtcMasternaut />} />
                
                <Route path="/Slides" element={<Slides />} />
                
                <Route path="/Training" element={<Training />} />
                
                <Route path="/WereListeningSurvey" element={<WereListeningSurvey />} />
                
                <Route path="/Worm" element={<Worm />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}