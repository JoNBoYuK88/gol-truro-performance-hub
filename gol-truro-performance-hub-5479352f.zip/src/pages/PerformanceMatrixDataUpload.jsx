import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { PerformanceMatrixData } from '@/api/entities';
import { Driver } from '@/api/entities';
import { ExtractDataFromUploadedFile, UploadFile } from '@/api/integrations';
import { useEditLock } from '../Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"; // Added Tabs imports
import { Upload, ClipboardPaste, Calendar, FileText, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function PerformanceMatrixDataUpload() {
  const [pastedData, setPastedData] = useState("");
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [preparedData, setPreparedData] = useState([]);
  const { canEdit: unlockCanEdit } = useEditLock();
  const [isAdmin, setIsAdmin] = useState(false);
  const canEdit = isAdmin || unlockCanEdit;
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [currentPeriod, setCurrentPeriod] = useState(1);
  const [currentWeek, setCurrentWeek] = useState(1);
  const [drivers, setDrivers] = useState([]);
  
  // PDF upload states
  const [selectedFile, setSelectedFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);

  useEffect(() => {
    const checkUserRole = async () => {
        setIsAuthLoading(true);
        try {
            const currentUser = await User.me();
            setIsAdmin(currentUser && currentUser.role === 'admin');
        } catch (error) {
            setIsAdmin(false);
        } finally {
            setIsAuthLoading(false);
        }
    };
    
    checkUserRole();
    loadDrivers();
  }, []);

  const loadDrivers = async () => {
    try {
      const data = await Driver.filter({ is_active: true });
      setDrivers(data);
    } catch (error) {
      console.error("Error loading drivers:", error);
      toast.error("Failed to load drivers data.");
    }
  };

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.type === 'application/pdf') {
        setSelectedFile(file);
      } else {
        toast.error("Please select a PDF file.");
        event.target.value = '';
      }
    }
  };

  const processPDFData = (extractedData) => {
    const parsed = [];
    const errors = [];

    extractedData.forEach((row, index) => {
      const driverName = row.driver_name || row.name;
      const colleagueId = row.colleague_id || driverName;

      if (!driverName) {
        errors.push(`Row ${index + 1}: Missing driver name`);
        return;
      }

      // Find driver by name or colleague_id
      const driver = drivers.find(d => 
        d.name.toLowerCase() === driverName.toLowerCase() || 
        d.colleague_id.toLowerCase() === colleagueId.toLowerCase()
      );

      if (!driver) {
        errors.push(`Row ${index + 1}: Driver "${driverName}" not found`);
        return;
      }

      // Process each metric with more flexible property matching
      const metrics = [
        { name: 'Smoother', value: row.smoother || row.Smoother || row.SMOOTHER },
        { name: 'Safer', value: row.safer || row.Safer || row.SAFER || row['safer_98'] || row['Safer (98%)'] },
        { name: 'Cleaner', value: row.cleaner || row.Cleaner || row.CLEANER },
        { name: 'DHR', value: row.dhr || row.DHR || row.Dhr },
        { name: 'Breaks', value: row.breaks || row.Breaks || row.BREAKS },
        { name: 'DWC', value: row.dwc || row.DWC || row.Dwc },
        { name: 'Speeding 30%', value: row.speeding_30 || row['speeding_30%'] || row.speeding30 || row['Speeding 30%'] || row.SPEEDING },
        { name: 'Serve Legal', value: row.serve_legal || row['Serve Legal'] || row.serveLegal || row.SERVE_LEGAL }
      ];

      metrics.forEach(metric => {
        if (metric.value !== undefined && metric.value !== null && !isNaN(parseFloat(metric.value))) {
          parsed.push({
            shopper_colleague_id: driver.colleague_id,
            driver_name: driver.name,
            metric_name: metric.name,
            value: parseFloat(metric.value),
            date: new Date().toISOString().split('T')[0],
            period: currentPeriod,
            week: currentWeek,
            year: currentYear
          });
        }
      });
    });

    if (errors.length > 0) {
      toast.error(`Found ${errors.length} errors:\n${errors.slice(0, 3).join('\n')}${errors.length > 3 ? '\n...' : ''}`);
      console.log("PDF Processing errors:", errors);
      console.log("Extracted data:", extractedData);
    }

    if (parsed.length === 0) {
      toast.error("No valid data found in PDF.");
      console.log("No parsed data. Raw extracted data:", extractedData);
      console.log("Available drivers:", drivers.map(d => ({ id: d.colleague_id, name: d.name })));
      return;
    }

    console.log("Successfully parsed data:", parsed);
    setPreparedData(parsed);
    setShowReviewDialog(true);
    setSelectedFile(null);
    // Reset file input
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput) fileInput.value = '';
  };

  const handlePDFUpload = async () => {
    if (!selectedFile) {
      toast.error("Please select a PDF file first.");
      return;
    }

    setIsUploading(true);
    try {
      // Upload the file
      const { file_url } = await UploadFile({ file: selectedFile });
      
      setIsExtracting(true);
      
      // Enhanced JSON schema for extraction with more flexible field names
      const jsonSchema = {
        type: "object",
        properties: {
          performance_data: {
            type: "array",
            items: {
              type: "object",
              properties: {
                driver_name: { type: "string", description: "Driver name or colleague name" },
                name: { type: "string", description: "Alternative field for driver name" },
                colleague_id: { type: "string", description: "Colleague ID if available" },
                smoother: { type: "number", description: "Smoother percentage score" },
                safer: { type: "number", description: "Safer percentage score or Safer 98% score" },
                cleaner: { type: "number", description: "Cleaner percentage score" },
                dhr: { type: "number", description: "DHR count or score" },
                breaks: { type: "number", description: "Breaks count or violations" },
                dwc: { type: "number", description: "DWC count or score" },
                speeding_30: { type: "number", description: "Speeding 30% violations count" },
                serve_legal: { type: "number", description: "Serve Legal count or failures" }
              },
              required: ["driver_name"]
            }
          }
        },
        required: ["performance_data"]
      };

      console.log("Starting PDF extraction...");

      // Extract data from the PDF
      const extractResult = await ExtractDataFromUploadedFile({
        file_url: file_url,
        json_schema: jsonSchema
      });

      console.log("PDF extraction result:", extractResult);

      if (extractResult.status === 'success' && extractResult.output?.performance_data) {
        const extractedData = extractResult.output.performance_data;
        console.log("Extracted performance data:", extractedData);
        processPDFData(extractedData);
      } else {
        console.error("PDF extraction failed:", extractResult);
        toast.error(`Failed to extract performance data from PDF: ${extractResult.details || 'Unknown error'}`);
      }

    } catch (error) {
      console.error("Error processing PDF:", error);
      let errorMessage = "Failed to process PDF file. Please try again.";
      if (error.message && (error.message.includes('500') || error.message.includes('timeout') || error.message.includes('544'))) {
          errorMessage = 'A server error occurred while uploading the PDF. Please try again in a few moments.';
      } else if (error.message) {
          errorMessage = `Failed to process PDF: ${error.message}`;
      }
      toast.error(errorMessage);
    } finally {
      setIsUploading(false);
      setIsExtracting(false);
    }
  };

  const handleParseData = () => {
    if (!pastedData.trim()) {
      toast.error("Paste data before parsing.");
      return;
    }

    const lines = pastedData.trim().split('\n');
    const parsed = [];
    const errors = [];

    lines.forEach((line, index) => {
      if (!line.trim()) return;
      
      const parts = line.split('\t').map(s => s.trim());
      
      // New format: ID, Smoother, Safer, Cleaner
      if (parts.length === 4) {
        const [driverIdentifier, smootherStr, saferStr, cleanerStr] = parts;

        const driver = drivers.find(d =>
          d.colleague_id.toLowerCase() === driverIdentifier.toLowerCase()
        );

        if (!driver) {
          errors.push(`Line ${index + 1}: Driver with ID "${driverIdentifier}" not found`);
          return;
        }

        const metrics = [
          { name: 'Smoother', valueStr: smootherStr },
          { name: 'Safer', valueStr: saferStr },
          { name: 'Cleaner', valueStr: cleanerStr },
        ];

        metrics.forEach(metric => {
          if (metric.valueStr && metric.valueStr.trim() !== "" && metric.valueStr.trim() !== "-") {
            const value = parseFloat(metric.valueStr);
            if (isNaN(value)) {
              errors.push(`Line ${index + 1}: Invalid value for ${metric.name}: "${metric.valueStr}"`);
            } else {
              parsed.push({
                shopper_colleague_id: driver.colleague_id,
                driver_name: driver.name,
                metric_name: metric.name,
                value: value,
                date: new Date().toISOString().split('T')[0],
                period: currentPeriod,
                week: currentWeek,
                year: currentYear
              });
            }
          }
        });
      }
      // Old format: Driver_Name/ID, Metric_Name, Value
      else if (parts.length === 3) {
        const [driverIdentifier, metricName, valueStr] = parts;
        const value = parseFloat(valueStr);

        if (isNaN(value)) {
          errors.push(`Line ${index + 1}: Invalid value "${valueStr}"`);
          return;
        }

        const driver = drivers.find(d => 
          d.name.toLowerCase() === driverIdentifier.toLowerCase() || 
          d.colleague_id.toLowerCase() === driverIdentifier.toLowerCase()
        );

        if (!driver) {
          errors.push(`Line ${index + 1}: Driver "${driverIdentifier}" not found`);
          return;
        }

        parsed.push({
          shopper_colleague_id: driver.colleague_id,
          driver_name: driver.name,
          metric_name: metricName,
          value: value,
          date: new Date().toISOString().split('T')[0],
          period: currentPeriod,
          week: currentWeek,
          year: currentYear
        });
      } else {
        errors.push(`Line ${index + 1}: Invalid format. Please check the data format.`);
      }
    });

    if (errors.length > 0) {
      toast.error(`Found ${errors.length} errors:\n${errors.slice(0, 3).join('\n')}${errors.length > 3 ? '\n...' : ''}`);
      return;
    }

    if (parsed.length === 0) {
      toast.error("No valid data found to import.");
      return;
    }

    setPreparedData(parsed);
    setShowReviewDialog(true);
  };

  const handleConfirmImport = async () => {
    if (!canEdit) return;

    try {
      console.log("Starting import of", preparedData.length, "records");
      
      // Delete existing data for this period/week/year first
      const existingData = await PerformanceMatrixData.filter({
        year: currentYear,
        period: currentPeriod,
        week: currentWeek
      });

      console.log("Found", existingData.length, "existing records to delete");

      if (existingData.length > 0) {
        const deletePromises = existingData.map(record => 
          PerformanceMatrixData.delete(record.id)
        );
        await Promise.all(deletePromises);
        console.log("Deleted existing records");
      }

      // Create new records using bulkCreate to avoid rate limiting
      if (preparedData.length > 0) {
        await toast.promise(PerformanceMatrixData.bulkCreate(preparedData), {
          loading: `Importing ${preparedData.length} performance records...`,
          success: `Successfully imported ${preparedData.length} performance records!`,
          error: 'Failed to import performance data.',
        });
      } else {
        toast.info("No new records to import.");
      }

      console.log("Import completed successfully");

      setShowReviewDialog(false);
      setPastedData("");
      setPreparedData([]);

    } catch (error) {
      console.error("Error importing performance data:", error);
      toast.error("Import failed: " + error.message);
    }
  };

  if (isAuthLoading) {
    return (
      <div className="p-6">
        <div className="text-center">Loading...</div>
      </div>
    );
  }



  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Performance Matrix Data Upload</h1>
          <p className="text-gray-600 mt-1">Upload weekly driver performance data from CSV files.</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Period Selection
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium">Year</label>
              <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[2025, 2024, 2023].map(y => (
                    <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Period</label>
              <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 13 }, (_, i) => (
                    <SelectItem key={i + 1} value={(i + 1).toString()}>
                      Period {i + 1}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Week</label>
              <Select value={currentWeek.toString()} onValueChange={(val) => setCurrentWeek(parseInt(val))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 4 }, (_, i) => (
                    <SelectItem key={i + 1} value={(i + 1).toString()}>
                      Week {i + 1}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="upload" className="w-full">
        <TabsList className="grid w-fit grid-cols-1">
          <TabsTrigger value="upload">Upload Data</TabsTrigger>
        </TabsList>
        <TabsContent value="upload" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Upload from PDF
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 mb-4">
                  Upload a PDF file containing performance data. The system will automatically extract driver names and their performance metrics.
                </p>
                <div className="flex items-center gap-4">
                  <input
                    type="file"
                    accept=".pdf"
                    onChange={handleFileSelect}
                    className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                  />
                  <Button 
                    onClick={handlePDFUpload} 
                    disabled={!selectedFile || isUploading || isExtracting}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    {isUploading || isExtracting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        {isUploading ? 'Uploading...' : 'Extracting...'}
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Process PDF
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5" />
                Upload Performance Data (Manual)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <p className="text-sm text-blue-800 font-medium mb-2">
                    📋 Data Format Instructions
                  </p>
                  <p className="text-sm text-blue-700 mb-2">
                    Paste data from a spreadsheet. <strong>Do not include headers.</strong> Two formats are supported (use one per upload):
                  </p>
                  <div className="space-y-2 text-sm text-blue-700">
                    <div className="bg-white rounded p-2 border border-blue-100">
                      <strong>Format 1:</strong> ID, Smoother, Safer, Cleaner (tab separated)
                      <div className="font-mono text-xs text-blue-600 mt-1">12345→85.5→92.3→76.8</div>
                    </div>
                    <div className="bg-white rounded p-2 border border-blue-100">
                      <strong>Format 2:</strong> Driver/ID, Metric Name, Value (tab separated) for DHR, Breaks, etc.
                      <div className="font-mono text-xs text-blue-600 mt-1">John Doe→DHR→2</div>
                    </div>
                  </div>
                </div>
                <Textarea
                  placeholder={`Paste data here. Do not include headers.\n\nFormat 1 (ID, Smoother, Safer, Cleaner):\n12345\t85.5\t92.3\t76.8\n\nFormat 2 (Driver, Metric, Value):\nJohn Doe\tDHR\t2`}
                  className="h-40 w-full font-mono text-sm border-2 border-gray-300 focus:border-blue-500"
                  value={pastedData}
                  onChange={(e) => setPastedData(e.target.value)}
                />
              </div>
              <Button 
                onClick={handleParseData} 
                disabled={!pastedData.trim()}
                className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2"
              >
                <ClipboardPaste className="w-4 h-4 mr-2" />
                Parse & Review Data
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Review Performance Data</DialogTitle>
            <DialogDescription>
              Review the parsed data before importing. This will replace existing data for Period {currentPeriod}, Week {currentWeek}, {currentYear}.
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-96 overflow-y-auto">
            <div className="grid grid-cols-4 gap-2 p-2 bg-gray-100 font-medium text-sm">
              <div>Driver</div>
              <div>Metric</div>
              <div>Value</div>
              <div>Period/Week</div>
            </div>
            {preparedData.map((record, index) => (
              <div key={index} className="grid grid-cols-4 gap-2 p-2 border-b text-sm">
                <div>{record.driver_name}</div>
                <div>{record.metric_name}</div>
                <div>{record.value}{record.metric_name.includes('Smoother') || record.metric_name.includes('Safer') || record.metric_name.includes('Cleaner') ? '%' : ''}</div>
                <div>P{record.period} W{record.week}</div>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReviewDialog(false)}>Cancel</Button>
            <Button onClick={handleConfirmImport} className="bg-green-600 hover:bg-green-700 text-white">
              Import {preparedData.length} Records
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}