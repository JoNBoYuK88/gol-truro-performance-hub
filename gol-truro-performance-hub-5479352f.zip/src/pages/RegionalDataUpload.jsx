import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Upload, FileUp, Save, Trash2, ClipboardPaste, RotateCw } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { User } from '@/api/entities';
import { RegionalPerformance } from '@/api/entities';
import { ExtractDataFromUploadedFile, UploadFile } from "@/api/integrations";
import { useEditLock } from '../Layout';

const requiredHeaders = [
    "year", "period", "store_id", "store_name", "drm", "score_percentage", 
    "shoppers_achieved_percentage", "otdep_percentage", "online_availability_percentage",
    "dwc_percentage", "secondary_replen_percentage", "legacy_otdel_percentage",
    "otdel_percentage", "view_type", "icare_score_percentage"
];

const headerMapping = {
    // Year variations
    "year": "year", "Year": "year", "YEAR": "year",
    
    // Period variations  
    "period": "period", "Period": "period", "PERIOD": "period",
    
    // Store ID variations
    "store_id": "store_id", "Store ID": "store_id", "StoreID": "store_id", "Store_ID": "store_id", "Store Number": "store_id",
    
    // Store name variations
    "store_name": "store_name", "Store": "store_name", "Store Name": "store_name", "StoreName": "store_name", "STORE": "store_name",
    
    // Score percentage variations
    "score_percentage": "score_percentage", "Score %": "score_percentage", "Score": "score_percentage", "Score Percentage": "score_percentage",
    
    // Shoppers achieved variations
    "shoppers_achieved_percentage": "shoppers_achieved_percentage", "Shoppers Achieved %": "shoppers_achieved_percentage", "Shoppers Achieved": "shoppers_achieved_percentage",
    
    // OTDep variations
    "otdep_percentage": "otdep_percentage", "OTDep % Adj": "otdep_percentage", "OTDep %": "otdep_percentage",
    
    // Online availability variations  
    "online_availability_percentage": "online_availability_percentage", "Online Availability %": "online_availability_percentage", "Online Availability": "online_availability_percentage",
    
    // DWC variations
    "dwc_percentage": "dwc_percentage", "DWC %": "dwc_percentage", "DWC": "dwc_percentage",
    
    // Secondary replen variations
    "secondary_replen_percentage": "secondary_replen_percentage", "Secondary Replen %": "secondary_replen_percentage", "Secondary Replen": "secondary_replen_percentage",
    
    // Legacy OTDel variations
    "legacy_otdel_percentage": "legacy_otdel_percentage", "Legacy OTDel %": "legacy_otdel_percentage", "Legacy OTDel": "legacy_otdel_percentage",
    
    // OTDel variations
    "otdel_percentage": "otdel_percentage", "OTDel %": "otdel_percentage", "OTDel": "otdel_percentage",
    
    // DRM variations
    "drm": "drm", "DRM": "drm", "Vans": "drm", "vans": "drm", "DRM Name": "drm", "VANS Name": "drm",
    
    // View type variations
    "view_type": "view_type", "View Type": "view_type", "ViewType": "view_type", "Type": "view_type",

    // iCare variations
    "icare_score_percentage": "icare_score_percentage", "iCare Score %": "icare_score_percentage", "iCare Score": "icare_score_percentage"
};

export default function RegionalDataUpload() {
    const { canEdit: unlockCanEdit } = useEditLock();
    const [isAdmin, setIsAdmin] = useState(false);
    const canEdit = isAdmin || unlockCanEdit;
    const [isProcessing, setIsProcessing] = useState(false);
    const [isUploading, setIsUploading] = useState(false);
    const [pastedData, setPastedData] = useState("");
    const [parsedData, setParsedData] = useState([]);
    const [selectedFile, setSelectedFile] = useState(null);
    const [selectedViewType, setSelectedViewType] = useState('YTD');
    const [year, setYear] = useState(new Date().getFullYear());
    
    useEffect(() => {
        const checkUserRole = async () => {
            try {
                const user = await User.me();
                setIsAdmin(user && user.role === 'admin');
            } catch (error) {
                setIsAdmin(false);
            }
        };
        checkUserRole();
    }, []);

    const processAndSetData = (records) => {
        const processed = records.map(record => {
            const newRecord = {};
            // Iterate over all keys in the mapped record (the `record` coming into this function)
            for (const key in record) {
                if (record.hasOwnProperty(key)) {
                    let value = record[key];
                    // Apply numeric conversion only to the relevant fields
                    if (['year', 'store_id', 'drm'].includes(key) || key.endsWith('_percentage')) {
                        value = parseFloat(String(value || '').replace(/[%$,]/g, '')) || null;
                        if (value === null && String(record[key]).trim() !== '') {
                            value = 0;
                        }
                    }
                    newRecord[key] = value;
                }
            }
            
            // Ensure required string fields exist, even if they were not in the source
            newRecord.period = newRecord.period || "";
            newRecord.store_name = newRecord.store_name || "Unknown";
            newRecord.view_type = selectedViewType;

            // Ensure all required numeric fields exist, defaulting to null if missing
            requiredHeaders.forEach(header => {
                if (!newRecord.hasOwnProperty(header)) {
                     if (['year', 'store_id', 'drm'].includes(header) || header.endsWith('_percentage')) {
                        newRecord[header] = null;
                    }
                }
            });

            return newRecord;
        });
        setParsedData(processed);
    };

    const handleFileChange = (event) => {
        if (event.target.files && event.target.files[0]) {
            setSelectedFile(event.target.files[0]);
            setPastedData("");
            setParsedData([]);
        }
    };

    const handleProcessFile = async () => {
        if (!selectedFile) {
            toast.warning("Please select a file to process.");
            return;
        }

        const isSupported = selectedFile.type === 'text/csv' || selectedFile.name.toLowerCase().endsWith('.csv');
        if (!isSupported) {
            toast.error("Unsupported file format. Please upload a CSV file. Convert your Excel file to CSV first.");
            return;
        }

        setIsProcessing(true);
        setPastedData("");
        
        try {
            const { file_url } = await UploadFile({ file: selectedFile });
            const schema = {
                type: "object",
                properties: {
                    records: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: Object.fromEntries(Object.keys(headerMapping).map(h => [h, { type: "string" }]))
                        }
                    }
                }
            };

            const extraction = await ExtractDataFromUploadedFile({ file_url, json_schema: schema });

            if (extraction.status === 'success' && extraction.output.records) {
                const preProcessedRecords = extraction.output.records.map(record => {
                    const newRecord = {};
                    let hasStoreName = false;
                    Object.entries(record).forEach(([key, value]) => {
                        const mappedKey = headerMapping[key] || key;
                        newRecord[mappedKey] = value;
                        if (mappedKey === 'store_name') hasStoreName = true;
                    });

                    if (!hasStoreName) {
                        throw new Error("Uploaded file must include a 'Store' or 'Store Name' column.");
                    }

                    if (!newRecord.year) newRecord.year = year;
                    if (!newRecord.period) newRecord.period = "";
                    if (!newRecord.view_type) newRecord.view_type = selectedViewType;
                    if (!newRecord.store_id && newRecord.store_name) {
                        const match = String(newRecord.store_name).match(/\d+/);
                        newRecord.store_id = match ? parseInt(match[0]) : Math.floor(Math.random() * 9000) + 1000;
                    }
                    return newRecord;
                });

                processAndSetData(preProcessedRecords);
                toast.success("File processed successfully. Review the data below.");
            } else {
                throw new Error(extraction.details || "Failed to extract data from file.");
            }

        } catch (error) {
            console.error("File processing failed:", error);
            toast.error(error.message || "File processing failed. Please check the file format and content.");
        } finally {
            setIsProcessing(false);
        }
    };
    
    const handleParsePastedData = () => {
        if (!pastedData.trim()) {
            toast.error("Please paste data into the text area before parsing.");
            return;
        }
        setSelectedFile(null);
        setParsedData([]);
        setIsProcessing(true);

        try {
            const lines = pastedData.trim().split('\n');
            if (lines.length < 2) {
                throw new Error("Pasted data must include a header row and at least one data row.");
            }
            
            const headers = lines[0].split('\t').map(h => h.trim());
            const mappedInputHeaders = headers.map(h => headerMapping[h] || h);
            const hasStore = mappedInputHeaders.includes('store_name');
            if (!hasStore) {
                throw new Error("Pasted data must include a 'Store' or 'Store Name' column.");
            }

            const data = [];
            for (let i = 1; i < lines.length; i++) {
                if (lines[i].trim()) {
                    const values = lines[i].split('\t').map(v => v.trim());
                    const row = {};
                    headers.forEach((header, index) => {
                        const mappedHeader = headerMapping[header] || header;
                        row[mappedHeader] = values[index] || '';
                    });
                    
                    if (!row.year) row.year = year;
                    if (!row.period) row.period = "";
                    if (!row.view_type) row.view_type = selectedViewType;
                    if (!row.store_id && row.store_name) {
                        const match = String(row.store_name).match(/\d+/);
                        row.store_id = match ? parseInt(match[0]) : Math.floor(Math.random() * 9000) + 1000;
                    }
                    
                    data.push(row);
                }
            }
            
            processAndSetData(data);
            toast.success("Pasted data parsed successfully. Review the data below.");
        } catch (error) {
            console.error("Pasted data parsing failed:", error);
            toast.error(error.message || "Pasted data parsing failed. Please ensure data is tab-separated and contains at least a 'Store' column.");
        } finally {
            setIsProcessing(false);
        }
    };

    const handleConfirmUpload = async () => {
        if (parsedData.length === 0) {
            toast.warning("No data to upload.");
            return;
        }
        setIsUploading(true);

        try {
            await toast.promise(RegionalPerformance.bulkCreate(parsedData), {
                loading: `Uploading ${parsedData.length} records...`,
                success: () => {
                    handleClear();
                    return 'All records uploaded successfully!';
                },
                error: (err) => {
                    console.error("Bulk create failed:", err);
                    return `An error occurred during the bulk upload: ${err.message || 'Unknown error'}`;
                },
            });
        } catch (error) {
            // Error is handled by toast.promise
        } finally {
            setIsUploading(false);
        }
    };
    
    const handleClear = () => {
        setPastedData("");
        setParsedData([]);
        setSelectedFile(null);
    };



    return (
        <div className="p-6 space-y-6 min-h-screen">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Regional Performance Data Upload</h1>
                    <p className="text-gray-600 mt-1">Upload CSV files or paste data to update regional performance metrics.</p>
                </div>
            </div>

            <div className="space-y-6">
                <Card className="glass-card">
                    <CardHeader>
                        <CardTitle>Regional Data Upload</CardTitle>
                        <CardDescription>Upload a CSV file or paste tab-separated data to update regional performance metrics.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="mb-4 p-4 border rounded-md bg-gray-50">
                            <div className="flex justify-between items-center mb-3">
                                <h3 className="text-md font-semibold flex items-center">
                                    <FileUp className="w-5 h-5 mr-2 text-blue-600" /> Upload Data File
                                </h3>
                                <div className="flex gap-2">
                                    <Select value={year.toString()} onValueChange={(val) => setYear(parseInt(val))}>
                                        <SelectTrigger className="w-24 border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {Array.from({ length: 5 }, (_, i) => new Date().getFullYear() + i - 2).map(y => (
                                                <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    <Select value={selectedViewType} onValueChange={setSelectedViewType}>
                                        <SelectTrigger className="w-48 border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-900">
                                            <SelectValue placeholder="Select view type" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="YTD">YTD Performance</SelectItem>
                                            <SelectItem value="Mid Year">Mid Year Performance</SelectItem>
                                            <SelectItem value="Last Year">Last Year Performance</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                            <p className="text-sm text-gray-600 mb-3">Choose a comma-separated values (CSV) file to upload for processing. Data will be added to the <strong>{selectedViewType}</strong> view for <strong>{year}</strong>.</p>
                            <div className="flex items-center gap-2">
                                <Input
                                    type="file"
                                    accept=".csv"
                                    onChange={handleFileChange}
                                    className="flex-grow"
                                />
                                <Button 
                                    onClick={handleProcessFile} 
                                    disabled={!selectedFile || isProcessing || isUploading}
                                    className="bg-blue-600 hover:bg-blue-700 text-white font-medium"
                                >
                                    {isProcessing ? <><RotateCw className="w-4 h-4 mr-2 animate-spin" /> Processing...</> : <><Upload className="w-4 h-4 mr-2" /> Process File</>}
                                </Button>
                            </div>
                            {selectedFile && <p className="text-sm text-gray-500 mt-2">Selected: {selectedFile.name}</p>}
                        </div>

                        <div className="relative mb-4">
                        <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-2 text-xs text-gray-400 uppercase font-medium">Or Paste Data for {selectedViewType} {year}</span>
                        <hr className="border-gray-200" />
                        </div>

                        <Textarea
                            placeholder={`Paste your data here (tab-separated) for ${selectedViewType}.\n\nMinimum required column: Store (or Store Name)\nOptional columns: Year, Period, DRM, Score %, Shoppers Achieved %, OTDep % Adj, Online Availability %, DWC %, Secondary Replen %, Legacy OTDel %, OTDel %, iCare Score %`}
                            className="h-40 w-full font-mono text-sm"
                            value={pastedData}
                            onChange={(e) => {
                                setPastedData(e.target.value);
                                setParsedData([]);
                                setSelectedFile(null);
                            }}
                            disabled={isProcessing || isUploading}
                        />
                        <div className="mt-4 flex justify-between">
                            <Button 
                                onClick={handleParsePastedData} 
                                disabled={!pastedData.trim() || isProcessing || isUploading}
                                className="bg-blue-600 hover:bg-blue-700 text-white font-medium"
                            >
                                <ClipboardPaste className="w-4 h-4 mr-2" /> {isProcessing ? 'Parsing...' : `Parse Data for ${selectedViewType}`}
                            </Button>
                            <Button 
                                variant="destructive" 
                                onClick={handleClear} 
                                size="sm" 
                                disabled={(!pastedData && parsedData.length === 0 && !selectedFile) || isProcessing || isUploading}
                            >
                                <Trash2 className="w-4 h-4 mr-2" /> Clear
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                {parsedData.length > 0 && (
                    <Card className="glass-card mt-6">
                        <CardHeader>
                            <div className="flex justify-between items-center">
                                <CardTitle>Review & Confirm Upload for {selectedViewType} {year}</CardTitle>
                                <Button 
                                    onClick={handleConfirmUpload} 
                                    disabled={isUploading || isProcessing} 
                                    className="bg-green-600 hover:bg-green-700 text-white"
                                >
                                    <Save className="w-4 h-4 mr-2" />
                                    {isUploading ? 'Uploading...' : 'Confirm & Upload Data'}
                                </Button>
                            </div>
                            <p className="text-sm text-gray-600 mt-2">{parsedData.length} records ready for upload to <strong>{selectedViewType}</strong>. Please review all data carefully.</p>
                        </CardHeader>
                        <CardContent>
                            <div className="overflow-x-auto max-h-96 overflow-y-auto border rounded-lg">
                                <Table>
                                    <TableHeader className="bg-slate-100 sticky top-0">
                                        <TableRow>
                                            {requiredHeaders.map(header => <TableHead key={header} className="min-w-[100px] text-xs">{header.replace(/_/g, ' ')}</TableHead>)}
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {parsedData.map((row, index) => (
                                            <TableRow key={index}>
                                                {requiredHeaders.map(header => (
                                                    <TableCell key={header} className="text-xs">
                                                        {row[header]}
                                                    </TableCell>
                                                ))}
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}