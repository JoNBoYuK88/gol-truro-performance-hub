
import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { WormReview } from '@/api/entities';
import { PeriodConfig } from '@/api/entities';
import { wormSections } from '../components/worm/wormQuestions';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Save, Upload, Image, X, Loader2 } from 'lucide-react';
import { UploadFile } from '@/api/integrations';
import ImagePreviewModal from '../components/performance/ImagePreviewModal';

const statusConfig = {
    green: { color: 'bg-green-500', hover: 'hover:bg-green-600', text: 'text-white' },
    amber: { color: 'bg-amber-500', hover: 'hover:bg-amber-600', text: 'text-white' },
    red: { color: 'bg-red-500', hover: 'hover:bg-red-600', text: 'text-white' },
    n_a: { color: 'bg-gray-400', hover: 'hover:bg-gray-500', text: 'text-white' },
};

const violationQuestions = ['reports_1_1', 'reports_1_2', 'reports_1_3', 'reports_1_4', 'reports_1_5'];
const costCategories = ['orders', 'damage', 'accidents', 'fines', 'equipment'];

export default function WormPage() {
    const [canEdit, setCanEdit] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
    const [currentPeriod, setCurrentPeriod] = useState(1);
    const [currentWeek, setCurrentWeek] = useState(1);
    const [activeTab, setActiveTab] = useState('risk');

    const [reviewAnswers, setReviewAnswers] = useState({});
    const [summaryActions, setSummaryActions] = useState([
        { action: '', assigned_manager: '' },
        { action: '', assigned_manager: '' },
        { action: '', assigned_manager: '' }
    ]);
    const [existingReview, setExistingReview] = useState(null);

    // Changed from Set to single ID for upload tracking
    const [uploadingImageId, setUploadingImageId] = useState(null);
    const [isImagePreviewOpen, setIsImagePreviewOpen] = useState(false);
    const [previewImageUrl, setPreviewImageUrl] = useState('');

    // Add debounce ref to prevent excessive API calls
    const debounceTimeoutRef = React.useRef(null);

    const determineCurrentPeriodAndWeek = (periods) => {
        const today = new Date();
        today.setHours(0, 0, 0, 0); 

        const currentPeriodConfig = periods.find(p => {
            const startDate = new Date(p.start_date);
            startDate.setHours(0, 0, 0, 0);
            const endDate = new Date(p.end_date);
            endDate.setHours(0, 0, 0, 0);
            return today >= startDate && today <= endDate;
        });

        if (currentPeriodConfig) {
            const startDate = new Date(currentPeriodConfig.start_date);
            startDate.setHours(0, 0, 0, 0);

            const daysDiff = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
            const currentWeekNumber = Math.min(Math.floor(daysDiff / 7) + 1, 4);
            
            return { period: currentPeriodConfig.period_number, week: currentWeekNumber };
        }
        
        const latestPeriod = periods
            .sort((a, b) => new Date(b.start_date).getTime() - new Date(a.start_date).getTime())[0];
        
        return latestPeriod ? { period: latestPeriod.period_number, week: 4 } : { period: 1, week: 1 };
    };

    useEffect(() => {
        const initializePage = async () => {
            try {
                await User.me();
                setCanEdit(true);
            } catch (e) {
                setCanEdit(false);
            }

            try {
                const periodsData = await PeriodConfig.filter({ year: new Date().getFullYear() }, 'period_number');
                if (periodsData && periodsData.length > 0) {
                    const { period, week } = determineCurrentPeriodAndWeek(periodsData);
                    setCurrentPeriod(period);
                    setCurrentWeek(week);
                } else {
                    console.warn("No period configurations found for the current year. Defaulting to Period 1, Week 1.");
                    setCurrentPeriod(1);
                    setCurrentWeek(1);
                }
            } catch (error) {
                console.error("Failed to load period configuration for W.O.R.M. page.", error);
                setCurrentPeriod(1);
                setCurrentWeek(1);
            } finally {
                setIsLoading(false); // Set isLoading to false after initialization
            }
        };

        initializePage();
    }, []);

    const loadReviewData = useCallback(async () => {
        setIsLoading(true);
        try {
            const data = await WormReview.filter({
                year: currentYear,
                period: currentPeriod,
                week: currentWeek,
            });

            if (data.length > 0) {
                const review = data[0];
                setExistingReview(review);
                const answersMap = review.answers.reduce((acc, ans) => {
                    acc[ans.question_id] = { 
                        status: ans.status, 
                        comment: ans.comment, 
                        violations: ans.violations || 0,
                        image_url: ans.image_url || null,
                        icare_value: ans.icare_value === undefined ? null : ans.icare_value,
                        ...(ans.driveTimeData && { driveTimeData: ans.driveTimeData }), // Load driveTimeData if present
                        ...(ans.costReportData && { costReportData: ans.costReportData }) // Load costReportData
                    };
                    return acc;
                }, {});
                setReviewAnswers(answersMap);
                
                const loadedActions = review.summary_actions || [];
                const fullActions = Array(3).fill(null).map((_, i) => {
                    const savedAction = loadedActions[i];
                    if (savedAction && typeof savedAction === 'object') {
                        return { action: savedAction.action || '', assigned_manager: savedAction.assigned_manager || '' };
                    } else if (savedAction && typeof savedAction === 'string') {
                        // Handle case where old data might just store action as string
                        return { action: savedAction, assigned_manager: '' };
                    }
                    return { action: '', assigned_manager: '' };
                });
                setSummaryActions(fullActions);

            } else {
                setExistingReview(null);
                setReviewAnswers({});
                setSummaryActions([
                    { action: '', assigned_manager: '' },
                    { action: '', assigned_manager: '' },
                    { action: '', assigned_manager: '' }
                ]);
            }
        } catch (error) {
            toast.error('Failed to load review data.');
            console.error('Error loading review data:', error);
        } finally {
            setIsLoading(false);
        }
    }, [currentYear, currentPeriod, currentWeek]);

    // Updated useEffect with debouncing to prevent rate limiting
    useEffect(() => {
        // Clear any existing timeout to ensure only the latest filter selection is acted upon.
        if (debounceTimeoutRef.current) {
            clearTimeout(debounceTimeoutRef.current);
        }

        // Set a new timeout to fetch data after the user has stopped changing filters.
        // The isLoading check is removed from here and the dependency array to break the feedback loop.
        debounceTimeoutRef.current = setTimeout(() => {
            loadReviewData();
        }, 500); // 500ms debounce delay

        // Cleanup timeout on unmount or when dependencies change
        return () => {
            if (debounceTimeoutRef.current) {
                clearTimeout(debounceTimeoutRef.current);
            }
        };
    // The `isLoading` dependency is removed to prevent an infinite loop.
    // The effect now only runs when the filter values or the function reference changes.
    }, [currentYear, currentPeriod, currentWeek, loadReviewData]);

    useEffect(() => {
        if (currentWeek === 1) {
            setActiveTab('risk');
        }
        else if (currentWeek === 2) {
            setActiveTab('commercial');
        }
        else if (currentWeek === 3) {
            setActiveTab('colleague');
        }
        else if (currentWeek === 4) {
            setActiveTab('kpis');
        }
    }, [currentWeek]);

    const shouldShowQuestion = (question) => {
        return !question.weeks || question.weeks.includes(currentWeek);
    };

    const handleAnswerChange = useCallback((questionId, field, value) => {
        setReviewAnswers(prev => {
            const currentQuestion = prev[questionId] || {};
            return {
                ...prev,
                [questionId]: {
                    ...currentQuestion,
                    [field]: value,
                },
            };
        });
    }, []);
    
    const handleStatusChange = (questionId, status) => {
        handleAnswerChange(questionId, 'status', status);
    };

    const handleCommentChange = (questionId, comment) => {
        handleAnswerChange(questionId, 'comment', comment);
    };

    const handleIcareChange = (questionId, value) => {
        handleAnswerChange(questionId, 'icare_value', value === '' ? null : parseFloat(value));
    };

    const handleViolationsChange = (questionId, value) => {
        handleAnswerChange(questionId, 'violations', parseInt(value, 10) || 0);
    };

    const handleDriveTimeChange = (questionId, weekIndex, field, value) => {
        setReviewAnswers(prev => {
            const current = prev[questionId] || {};
            const driveTimeData = current.driveTimeData || [];
            const updatedData = [...driveTimeData];
            
            // Ensure we have an object for this week
            if (!updatedData[weekIndex]) {
                updatedData[weekIndex] = { percentage: '', uncovered_shifts: '' };
            }
            
            updatedData[weekIndex] = {
                ...updatedData[weekIndex],
                [field]: value
            };
            
            return {
                ...prev,
                [questionId]: { 
                    ...current, 
                    driveTimeData: updatedData 
                }
            };
        });
    };
    
    const handleCostReportChange = (questionId, category, type, value) => {
        setReviewAnswers(prev => {
            const currentQuestion = prev[questionId] || {};
            const costData = currentQuestion.costReportData || {};
            
            const updatedCostData = {
                ...costData,
                [category]: {
                    ...costData[category],
                    [type]: parseFloat(value) || 0 // Store as number
                }
            };
            
            return {
                ...prev,
                [questionId]: {
                    ...currentQuestion,
                    costReportData: updatedCostData
                }
            };
        });
    };

    const handleSummaryActionChange = (index, field, value) => {
        setSummaryActions(prev => {
            const newActions = [...prev];
            newActions[index] = { ...newActions[index], [field]: value };
            return newActions;
        });
    };

    const handleImageUpload = async (questionId, file) => {
        if (!file || !canEdit) return;

        if (!file.type.startsWith('image/')) {
            toast.error('Please select an image file.');
            return;
        }

        if (file.size > 10 * 1024 * 1024) { // 10MB limit
            toast.error('Image file too large. Please select a file under 10MB.');
            return;
        }

        setUploadingImageId(questionId);

        try {
            const { file_url } = await UploadFile({ file });
            handleAnswerChange(questionId, 'image_url', file_url);
            toast.success('Image uploaded successfully.');
        } catch (error) {
            console.error('Image upload failed:', error);
            let errorMessage = 'Image upload failed. Please try again.';
            if (error.message && (error.message.includes('500') || error.message.includes('timeout') || error.message.includes('544'))) {
                errorMessage = 'A server error occurred while uploading. Please try again in a few moments.';
            }
            toast.error(errorMessage);
        } finally {
            setUploadingImageId(null);
        }
    };

    const handleRemoveImage = (questionId) => {
        if (!canEdit) return;
        handleAnswerChange(questionId, 'image_url', null);
        toast.info('Image removed.');
    };

    const handleImagePreview = (url) => {
        setPreviewImageUrl(url);
        setIsImagePreviewOpen(true);
    };

    const handleSave = async () => {
        if (!canEdit) {
            toast.error('You do not have permission to save.');
            return;
        }

        const user = await User.me();

        const answersPayload = Object.entries(reviewAnswers).map(([question_id, data]) => ({
            question_id,
            status: data.status || 'n_a',
            comment: data.comment || '',
            violations: data.violations || 0,
            image_url: data.image_url || null,
            ...(data.icare_value !== null && data.icare_value !== undefined && { icare_value: data.icare_value }),
            ...(data.driveTimeData && { driveTimeData: data.driveTimeData.map(d => ({ percentage: parseFloat(d.percentage) || 0, uncovered_shifts: parseInt(d.uncovered_shifts) || 0 })) }),
            ...(data.costReportData && { costReportData: data.costReportData }),
        }));

        const payload = {
            year: currentYear,
            period: currentPeriod,
            week: currentWeek,
            answers: answersPayload,
            summary_actions: summaryActions.filter(a => a.action || a.assigned_manager),
            completed_by: user.email,
        };

        toast.promise(
            existingReview
                ? WormReview.update(existingReview.id, payload)
                : WormReview.create(payload),
            {
                loading: 'Saving W.O.R.M. review...',
                success: () => {
                    loadReviewData();
                    return 'Review saved successfully!';
                },
                error: 'Failed to save review.',
            }
        );
    };

    const getIcareStatusClass = (value) => {
        const numericValue = parseFloat(value);
        if (isNaN(numericValue) || value === null) return 'bg-white border-slate-300';
        if (numericValue >= 49.5) return 'bg-green-100 border-green-500 text-green-800';
        if (numericValue < 49.5) return 'bg-red-100 border-red-500 text-red-800'; 
        return 'bg-amber-100 border-amber-500 text-amber-800';
    };

    return (
        <div className="p-6 space-y-6 min-h-screen">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="space-y-2">
                    <h1 className="text-2xl font-bold text-gray-900">Weekly Ops Review Module (W.O.R.M.)</h1>
                </div>
                <div className="flex items-center gap-2">
                    <Select value={currentYear.toString()} onValueChange={(val) => setCurrentYear(parseInt(val))}>
                        <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                        <SelectContent>{Array.from({ length: 3 }, (_, i) => new Date().getFullYear() - i).map(y => <SelectItem key={y} value={y.toString()}>{y}</SelectItem>)}</SelectContent>
                    </Select>
                    <Select value={currentPeriod.toString()} onValueChange={(val) => setCurrentPeriod(parseInt(val))}>
                        <SelectTrigger className="w-32"><SelectValue placeholder="Period" /></SelectTrigger>
                        <SelectContent>{Array.from({ length: 13 }, (_, i) => i + 1).map(p => <SelectItem key={p} value={p.toString()}>Period {p}</SelectItem>)}</SelectContent>
                    </Select>
                    <Select value={currentWeek.toString()} onValueChange={(val) => setCurrentWeek(parseInt(val))}>
                        <SelectTrigger className="w-32"><SelectValue placeholder="Week" /></SelectTrigger>
                        <SelectContent>
                            {Array.from({ length: 4 }, (_, i) => i + 1).map(w => <SelectItem key={w} value={w.toString()}>Week {w}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Button onClick={handleSave} disabled={isLoading || !canEdit} className="bg-indigo-600 hover:bg-indigo-700">
                        <Save className="w-4 h-4 mr-2" />
                        Save Review
                    </Button>
                </div>
            </div>

            <Card className="glass-card">
                <CardHeader>
                    <CardTitle>Summary Actions</CardTitle>
                    <CardDescription>Record the 3 key SMART actions from this week's review.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {summaryActions.map((actionData, index) => (
                        <div key={index} className="grid grid-cols-1 md:grid-cols-4 gap-3 items-center">
                            <Textarea
                                placeholder={`Action ${index + 1}...`}
                                value={actionData.action}
                                onChange={(e) => handleSummaryActionChange(index, 'action', e.target.value)}
                                disabled={!canEdit || isLoading}
                                className="md:col-span-3"
                                rows={2}
                            />
                            <Input
                                placeholder={`Assigned Manager...`}
                                value={actionData.assigned_manager}
                                onChange={(e) => handleSummaryActionChange(index, 'assigned_manager', e.target.value)}
                                disabled={!canEdit || isLoading}
                            />
                        </div>
                    ))}
                </CardContent>
            </Card>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    {wormSections.map(section => (
                        <TabsTrigger 
                            key={section.id} 
                            value={section.id}
                            className={`${
                                (section.id === 'risk' && currentWeek === 1) ||
                                (section.id === 'commercial' && currentWeek === 2) ||
                                (section.id === 'colleague' && currentWeek === 3) ||
                                (section.id === 'kpis' && currentWeek === 4)
                                    ? 'bg-gray-700 text-white data-[state=active]:bg-gray-800 data-[state=active]:text-white'
                                    : ''
                            }`}
                        >
                            {section.title}
                        </TabsTrigger>
                    ))}
                </TabsList>
                {wormSections.map(section => (
                    <TabsContent key={section.id} value={section.id} className="space-y-4 mt-4">
                        {section.subsections.map(subsection => {
                            const relevantQuestions = subsection.questions.filter(shouldShowQuestion);
                            
                            if (relevantQuestions.length === 0) return null;
                            
                            return (
                                <Card key={subsection.title} className="glass-card">
                                    <CardHeader>
                                        <CardTitle>{subsection.title}</CardTitle>
                                        <CardDescription className="text-sm text-slate-600">
                                            Questions for Week {currentWeek}
                                        </CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        {relevantQuestions.map(q => (
                                            <div key={q.id} className="p-3 rounded-lg border bg-slate-50/50">
                                                <p className="text-sm font-medium text-slate-800 mb-2">
                                                    {q.isLiteOptional && <span className="text-red-500 font-bold">* </span>}
                                                    {q.text}
                                                </p>
                                                <div className="flex flex-col sm:flex-row gap-2 items-start">
                                                    {!q.hasCostReportGrid && !q.hasIcareInput &&
                                                        <div className="flex items-center gap-2 flex-shrink-0">
                                                            {Object.entries(statusConfig).map(([status, config]) => (
                                                                <Button
                                                                    key={status}
                                                                    size="sm"
                                                                    className={`w-20 ${reviewAnswers[q.id]?.status === status ? config.color : 'bg-gray-200'} ${reviewAnswers[q.id]?.status === status ? config.hover : 'hover:bg-gray-300'} ${reviewAnswers[q.id]?.status === status ? config.text : 'text-gray-800'}`}
                                                                    onClick={() => handleStatusChange(q.id, status)}
                                                                    disabled={!canEdit || isLoading}
                                                                >
                                                                    {status.replace('_', ' ').toUpperCase()}
                                                                </Button>
                                                            ))}
                                                        </div>
                                                    }
                                                    {q.hasIcareInput && (
                                                        <div className="relative w-36 flex-shrink-0">
                                                            <div className={`w-full h-24 border-2 rounded-lg flex items-center justify-center ${getIcareStatusClass(reviewAnswers[q.id]?.icare_value)}`}>
                                                                <Input
                                                                    type="number"
                                                                    step="0.1"
                                                                    placeholder="0.0"
                                                                    className="text-center text-7xl font-bold bg-transparent border-0 p-0 h-full focus-visible:ring-0 focus-visible:ring-offset-0 w-full"
                                                                    value={reviewAnswers[q.id]?.icare_value ?? ''}
                                                                    onChange={(e) => handleIcareChange(q.id, e.target.value)}
                                                                    disabled={!canEdit || isLoading}
                                                                />
                                                            </div>
                                                        </div>
                                                    )}
                                                    {violationQuestions.includes(q.id) && (
                                                        <div className="flex flex-col items-center w-20 flex-shrink-0">
                                                            <label className="text-xs text-slate-500 mb-1">Violations</label>
                                                            <Input
                                                                type="number"
                                                                placeholder="No."
                                                                className="w-full h-8 text-center"
                                                                style={{ textAlign: 'center' }}
                                                                value={reviewAnswers[q.id]?.violations ?? ''}
                                                                onChange={(e) => handleViolationsChange(q.id, e.target.value)}
                                                                disabled={!canEdit || isLoading}
                                                            />
                                                        </div>
                                                    )}
                                                    <div className="flex-grow">
                                                        {q.hasCostReportGrid ? (
                                                            <div className="w-full space-y-4">
                                                                <div className="text-center mb-2">
                                                                    <span className="text-sm font-semibold text-slate-700">Period {currentPeriod}</span>
                                                                </div>
                                                                <div className="grid grid-cols-7 gap-2 items-center">
                                                                    <div /> {/* Empty cell for alignment */}
                                                                    {costCategories.map(cat => (
                                                                        <div key={cat} className="text-center font-medium text-xs capitalize text-slate-600">{cat}</div>
                                                                    ))}
                                                                    <div className="text-center font-medium text-xs text-slate-600">Total</div>

                                                                    {/* Budget Row */}
                                                                    <div className="text-right font-medium text-sm pr-2 text-slate-700">Budget</div>
                                                                    {costCategories.map(cat => (
                                                                        <div key={`${cat}-budget`} className="relative">
                                                                            {cat !== 'orders' && (
                                                                                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">£</span>
                                                                            )}
                                                                            <Input
                                                                                type="number"
                                                                                placeholder={cat === 'orders' ? 'Orders' : '0'}
                                                                                className={`h-8 text-center ${cat !== 'orders' ? 'pl-6' : ''}`}
                                                                                value={reviewAnswers[q.id]?.costReportData?.[cat]?.budget ?? ''}
                                                                                onChange={(e) => handleCostReportChange(q.id, cat, 'budget', e.target.value)}
                                                                                disabled={!canEdit || isLoading}
                                                                            />
                                                                        </div>
                                                                    ))}
                                                                    <div /> {/* Empty cell for total column in budget row */}

                                                                    {/* Actual Row */}
                                                                    <div className="text-right font-medium text-sm pr-2 text-slate-700">Actual</div>
                                                                    {costCategories.map(cat => (
                                                                        <div key={`${cat}-actual`} className="relative">
                                                                            {cat !== 'orders' && (
                                                                                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">£</span>
                                                                            )}
                                                                            <Input
                                                                                type="number"
                                                                                placeholder={cat === 'orders' ? 'Orders' : '0'}
                                                                                className={`h-8 text-center ${cat !== 'orders' ? 'pl-6' : ''}`}
                                                                                value={reviewAnswers[q.id]?.costReportData?.[cat]?.actual ?? ''}
                                                                                onChange={(e) => handleCostReportChange(q.id, cat, 'actual', e.target.value)}
                                                                                disabled={!canEdit || isLoading}
                                                                            />
                                                                        </div>
                                                                    ))}
                                                                    <div /> {/* Empty cell for total column in actual row */}

                                                                    {/* Variance Row */}
                                                                    <div className="text-right font-medium text-sm pr-2 text-slate-700">Variance</div>
                                                                    {costCategories.map(cat => {
                                                                        const budget = reviewAnswers[q.id]?.costReportData?.[cat]?.budget || 0;
                                                                        const actual = reviewAnswers[q.id]?.costReportData?.[cat]?.actual || 0;
                                                                        const variance = actual - budget;

                                                                        const isCost = cat !== 'orders';
                                                                        // For costs (damage, etc.), good if variance is <= 0 (less actual cost is better). For orders, good if variance is >= 0 (more actual orders is better).
                                                                        const isGood = isCost ? variance <= 0 : variance >= 0;
                                                                        
                                                                        const textColor = variance === 0 ? 'text-slate-800' : isGood ? 'text-green-600' : 'text-red-600';
                                                                        
                                                                        const formattedVariance = cat === 'orders'
                                                                                            ? variance.toLocaleString()
                                                                                            : variance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

                                                                        const sign = variance > 0 ? '+' : '';

                                                                        return (
                                                                            <div key={`${cat}-variance`} className="h-9 flex items-center justify-center">
                                                                                <div className={`text-center font-bold text-sm p-2 rounded-md bg-slate-100 w-full ${textColor}`}>
                                                                                    {cat !== 'orders' && `£`}{sign}{formattedVariance}
                                                                                </div>
                                                                            </div>
                                                                        );
                                                                    })}
                                                                    {/* Total Variance */}
                                                                    <div className="h-9 flex items-center justify-center">
                                                                        <div className={`text-center font-bold text-sm p-2 rounded-md bg-slate-200 w-full border-2 border-slate-300 ${(() => {
                                                                            const totalVariance = costCategories.reduce((total, cat) => {
                                                                                const budget = reviewAnswers[q.id]?.costReportData?.[cat]?.budget || 0;
                                                                                const actual = reviewAnswers[q.id]?.costReportData?.[cat]?.actual || 0;
                                                                                return total + (actual - budget);
                                                                            }, 0);
                                                                            return totalVariance === 0 ? 'text-slate-800' : totalVariance < 0 ? 'text-green-600' : 'text-red-600';
                                                                        })()}`}>
                                                                            £{(() => {
                                                                                const totalVariance = costCategories.reduce((total, cat) => {
                                                                                    const budget = reviewAnswers[q.id]?.costReportData?.[cat]?.budget || 0;
                                                                                    const actual = reviewAnswers[q.id]?.costReportData?.[cat]?.actual || 0;
                                                                                    return total + (actual - budget);
                                                                                }, 0);
                                                                                const sign = totalVariance > 0 ? '+' : '';
                                                                                return `${sign}${totalVariance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                                                                            })()}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <Textarea
                                                                    placeholder="Add comments or actions for the cost report..."
                                                                    className="w-full"
                                                                    value={reviewAnswers[q.id]?.comment || ''}
                                                                    onChange={(e) => handleCommentChange(q.id, e.target.value)}
                                                                    disabled={!canEdit || isLoading}
                                                                />
                                                            </div>
                                                        ) : q.hasSpecialInputs ? (
                                                            <div className="w-full">
                                                                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                                                                    {Array.from({ length: 4 }, (_, weekIndex) => {
                                                                        const driveTimeData = reviewAnswers[q.id]?.driveTimeData || [];
                                                                        const weekData = driveTimeData[weekIndex] || { 
                                                                            percentage: '', 
                                                                            uncovered_shifts: ''
                                                                        };
                                                                        
                                                                        return (
                                                                            <div key={weekIndex} className="space-y-2">
                                                                                <div className="text-xs font-medium text-slate-600 text-center">Period {currentPeriod} Week {weekIndex + 1}</div>
                                                                                <div className="grid grid-cols-2 gap-2">
                                                                                    <div className="text-center">
                                                                                        <label className="text-xs text-slate-500 mb-1 block">Percentage</label>
                                                                                        <Input
                                                                                            type="number"
                                                                                            placeholder="%"
                                                                                            className="text-xs h-8 text-center w-16 mx-auto"
                                                                                            value={weekData.percentage ?? ''}
                                                                                            onChange={(e) => handleDriveTimeChange(q.id, weekIndex, 'percentage', e.target.value)}
                                                                                            disabled={!canEdit || isLoading}
                                                                                        />
                                                                                    </div>
                                                                                     <div className="text-center">
                                                                                        <label className="text-xs text-slate-500 mb-1 block">Uncovered Shifts</label>
                                                                                        <Input
                                                                                            type="number"
                                                                                            placeholder="Shifts"
                                                                                            className="text-xs h-8 text-center w-16 mx-auto"
                                                                                            value={weekData.uncovered_shifts ?? ''}
                                                                                            onChange={(e) => handleDriveTimeChange(q.id, weekIndex, 'uncovered_shifts', e.target.value)}
                                                                                            disabled={!canEdit || isLoading}
                                                                                        />
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        );
                                                                    })}
                                                                </div>
                                                            </div>
                                                        ) : (
                                                            <Textarea
                                                                placeholder="Add comments or actions..."
                                                                className="w-full h-20"
                                                                value={reviewAnswers[q.id]?.comment || ''}
                                                                onChange={(e) => handleCommentChange(q.id, e.target.value)}
                                                                disabled={!canEdit || isLoading}
                                                            />
                                                        )}
                                                    </div>
                                                    <div className="flex-shrink-0 flex items-center justify-center pt-1">
                                                        <input
                                                            type="file"
                                                            accept="image/*"
                                                            onChange={(e) => {
                                                                const file = e.target.files[0];
                                                                if (file) handleImageUpload(q.id, file);
                                                                e.target.value = ''; // Clear input to allow re-uploading the same file
                                                            }}
                                                            className="hidden"
                                                            id={`image-upload-${q.id}`}
                                                            disabled={!canEdit || isLoading || uploadingImageId === q.id}
                                                        />
                                                        {reviewAnswers[q.id]?.image_url ? (
                                                            <div className="flex items-center gap-2">
                                                                <Button
                                                                    variant="ghost"
                                                                    size="icon"
                                                                    className="h-8 w-8 text-blue-600 hover:text-blue-800"
                                                                    onClick={() => handleImagePreview(reviewAnswers[q.id].image_url)}
                                                                    title="View image"
                                                                >
                                                                    <Image className="w-5 h-5" />
                                                                </Button>
                                                                <Button
                                                                    variant="ghost"
                                                                    size="icon"
                                                                    className="h-8 w-8 text-red-500 hover:text-red-700"
                                                                    onClick={() => handleRemoveImage(q.id)}
                                                                    disabled={!canEdit || isLoading}
                                                                    title="Remove image"
                                                                >
                                                                    <X className="w-5 h-5" />
                                                                </Button>
                                                            </div>
                                                        ) : (
                                                            <Button
                                                                variant="outline"
                                                                size="icon"
                                                                className="h-8 w-8"
                                                                onClick={() => document.getElementById(`image-upload-${q.id}`).click()}
                                                                disabled={!canEdit || isLoading || uploadingImageId === q.id}
                                                                title="Upload image"
                                                            >
                                                                {uploadingImageId === q.id ? (
                                                                    <Loader2 className="w-4 h-4 animate-spin" />
                                                                ) : (
                                                                    <Upload className="w-4 h-4" />
                                                                )}
                                                            </Button>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </CardContent>
                                </Card>
                            );
                        })}
                    </TabsContent>
                ))}
            </Tabs>
            <ImagePreviewModal
                isOpen={isImagePreviewOpen}
                onClose={() => setIsImagePreviewOpen(false)}
                imageUrl={previewImageUrl}
            />
        </div>
    );
}
